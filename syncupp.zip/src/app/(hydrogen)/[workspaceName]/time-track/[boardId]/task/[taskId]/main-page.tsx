'use client';

import { GetColumns } from '@/app/shared/(user)/time-track/tracked-time-list/columns';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import { routes } from '@/config/routes';
import { getTaskById } from '@/redux/slices/user/task/taskSlice';
import {
  setPaginationDetails,
  trackedTimeTaskHistoryDetails,
  updateDeleteTrackedTime,
} from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect from 'react-select';

export default function MainPage({
  params,
}: Readonly<{ params: { taskId: string } }>) {
  const pageHeader = {
    title: 'Task',
  };

  const customStyles = {
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected ? '#8c80d2' : 'white',
      color: state.isSelected ? 'white' : 'black',
    }),
  };

  const dispatch = useDispatch();
  const { boardId }: { boardId: string } = useParams();
  const [pageSize, setPageSize] = useState<number>(10);
  const [reset, setReset] = useState('');
  const [assignee, setAssignee] = useState<any>({
    name: 'Assigned to',
    value: '',
    label: 'Assigned to',
  });
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [period, setPeriod] = useState('');

  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { task } = useSelector((state: any) => state?.root?.task);

  console.log(task, 'task--------------------56')

  const {
    trackedTimeTaskHistoryDetailsData,
    trackedTimeTaskHistoryDetailsLoader,
    paginationParams,
  } = useSelector((state: any) => state?.root?.timeTracking);

  useEffect(() => {
    setPaginationDetails({});
    dispatch(getTaskById({ taskId: params.taskId }));
  }, [dispatch, params.taskId]);

  useEffect(() => {
    if (!!endDate) {
      dispatch(
        trackedTimeTaskHistoryDetails({
          ...paginationParams,
          page: 1,
          sort_field: 'createdAt',
          sort_order: 'desc',
          pagination: true,
          filter: {
            date: period,
            start_date: startDate,
            end_date: endDate,
          },
        })
      );

      setPaginationDetails({
        ...paginationParams,
        page: 1,
        sort_field: 'createdAt',
        sort_order: 'desc',
        pagination: true,
        filter: {
          date: period,
          start_date: startDate,
          end_date: endDate,
        },
      });
    }
  }, [dispatch, endDate, period, startDate]);

  // Pagination
  const handleChangePage = async (paginationParams: any) => {
    const { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        task_id: params?.taskId,
        pagination: true,
      })
    );

    const response = await dispatch(
      trackedTimeTaskHistoryDetails({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        task_id: params?.taskId,
        pagination: true,
      })
    );

    const { data } = response?.payload;
    if (data?.tracked_history?.length > 0) {
      return data?.tracked_history;
    }
  };

  // Ḍelete the trakced time in task
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      // DELETE API CALL PANDING
      console.log(id, currentPage, countPerPage, sortConfig, searchTerm);

      const res = await dispatch(
        updateDeleteTrackedTime({ timerId: id, event_type: 'delete' })
      );
      if (res.payload.success) {
        await dispatch(
          trackedTimeTaskHistoryDetails({
            page: currentPage,
            items_per_page: countPerPage,
            sort_field: sortConfig?.key,
            sort_order: sortConfig?.direction,
            search: searchTerm,
            task_id: params?.taskId,
            pagination: true,
          })
        );
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleAssigneeChange = (selectedOption: Record<string, any>) => {
    // setStatusValue(selectedOption?.value);

    dispatch(
      setPaginationDetails({
        ...paginationParams,
        page: 1,
        assignee_id: selectedOption?.value,
      })
    );

    dispatch(
      trackedTimeTaskHistoryDetails({
        ...paginationParams,
        page: 1,
        assignee_id: selectedOption?.value,
      })
    );
  };

  // Reset Filter
  const handleResetFilters = () => {
    setAssignee({ name: 'Assigned to', value: '', label: 'Assigned to' });
    setPeriod('');
    setStartDate('');
    setEndDate('');
    setReset('reset');

    dispatch(
      setPaginationDetails({
        page: 1,
        sort_field: 'createdAt',
        sort_order: 'desc',
        search: '',
        filter: '',
        task_id: params?.taskId,
        assignee_id: '',
      })
    );

    dispatch(
      trackedTimeTaskHistoryDetails({
        page: 1,
        sort_field: 'createdAt',
        sort_order: 'desc',
        search: '',
        filter: '',
        task_id: params?.taskId,
        assignee_id: '',
      })
    );
  };

  const assigneeOptions = [{ name: 'All', value: '', label: 'All' }];
  trackedTimeTaskHistoryDetailsData?.users?.length > 0 &&
    trackedTimeTaskHistoryDetailsData?.users?.map(
      (assignee: Record<string, any>) => {
        assigneeOptions.push({
          name: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          label: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          value: assignee?._id,
        });
      }
    );

  // My Tasks Table Filters
  const MyTasksFilter = () => {
    return (
      <>
        {/* {(signIn.role === 'agency' ||
          (signIn?.role === 'team_agency' &&
            signIn?.teamMemberRole === 'admin') || (signIn?.role === 'client')) && ( */}
        <>
          <ReactSelect
            options={assigneeOptions}
            onChange={(selectedOption: Record<string, any>) => {
              handleAssigneeChange(selectedOption);
              setAssignee(selectedOption);
            }}
            value={assignee}
            placeholder="Assigned to"
            className="poppins_font_number react-select-options w-full text-black"
            classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
            styles={customStyles}
          />
          <div>
          <Button
            className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
          </div>
        </>
        {/* )} */}
      </>
    );
  };

  return (
    <>
      <CustomePageHeader
        title={capitalizeFirstLetter(task?.activity?.title)}
        titleClassName="montserrat_font_title"
        route={routes.timeTrackBoardDetails(defaultWorkSpace?.name, boardId)}
      />
      <div className=" ">
        <div className="main_card_block">
          <WidgetCard rounded="lg" title="">
            <div className="table_border_remove overflow-y-auto">
              <CustomTable
                data={trackedTimeTaskHistoryDetailsData?.tracked_history || []}
                total={trackedTimeTaskHistoryDetailsData?.page_count || 0}
                loading={trackedTimeTaskHistoryDetailsLoader}
                pageSize={pageSize}
                setPageSize={setPageSize}
                handleDeleteById={handleDeleteById}
                handleChangePage={handleChangePage}
                getColumns={GetColumns}
                filtersList={<MyTasksFilter />}
                resetValue={reset}
                setReset={setReset}
                scroll={{ x: 1000 }}
                setPeriod={setPeriod}
                setStartDate={setStartDate}
                setEndDate={setEndDate}
                isRangeFilter={true}
              />
            </div>
          </WidgetCard>
        </div>
      </div>
    </>
  );
}
