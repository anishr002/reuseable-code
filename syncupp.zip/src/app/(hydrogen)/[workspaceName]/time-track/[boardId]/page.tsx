import { metaObject } from '@/config/site.config';
import MainPage from './main-page';

export const metadata = {
  ...metaObject('Tasks'),
};

export default function Page({ params }: Readonly<{ params: { boardId: string } }>) {
  return (
    <div className="main_card_block">
      <MainPage params={params} />
    </div>
  );
}
