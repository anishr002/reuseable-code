'use client';
import { GetColumns } from '@/app/shared/(user)/time-track/task-list/columns';
import PageHeader from '@/app/shared/page-header';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { Button } from '@/components/ui/button';
import Select from '@/components/ui/select';
import { routes } from '@/config/routes';
import '@/layouts/helium/style.css';
import { setPagginationParams } from '@/redux/slices/user/client/clientSlice';
import {
  getAllAssignees,
  SetBoardId,
} from '@/redux/slices/user/task/boardSlice';
import { setTaskPaginationDetails } from '@/redux/slices/user/task/taskSlice';
import {
  assignedByList,
  removeTrackedBoardsData,
  trackedBoards,
  trackedTimeTaskHistory,
} from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import backIcon from '@public/assets/images/back_arrow_icon.svg';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { PiCaretDownBold } from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect from 'react-select';
import { Text } from '@/components/ui/text';
import TimerForm from '@/app/shared/(user)/task/task-grid/timer-form';
import { useModal } from '@/app/shared/modal-views/use-modal';

export default function MainPage({
  params,
}: Readonly<{ params: { boardId: string } }>) {
  const dispatch = useDispatch();
  const router = useRouter();
  const [reset, setReset] = useState(false);
  const [sortObject, setSortObject] = useState({});
  const { openModal, closeModal } = useModal();

  const {
    trackedBoardsData,
    trackedTimeTaskHistoryData,
    trackedTimeTaskHistoryLoader,
    assignedByListData,
  } = useSelector((state: any) => state?.root?.timeTracking);
  const { assignees } = useSelector((state: any) => state?.root?.board);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const { paginationParams } = useSelector((state: any) => state?.root?.task);

  const [pageSize, setPageSize] = useState<number>(10);
  const [selectedBoard, setSelectedBoard] = useState<any>(null);
  const [assignee, setAssignee] = useState<any>({
    name: 'Assigned to',
    value: '',
    label: 'Assigned to',
  });
  const [assignBy, setAssignBy] = useState<any>({
    name: 'Assigned By',
    value: '',
    label: 'Assigned By',
  });

  // Get all boards api
  useEffect(() => {
    dispatch(removeTrackedBoardsData());
    dispatch(trackedBoards({ all: true }));
    dispatch(assignedByList({ board_id: params?.boardId }));
    // Get all the assignees list
    dispatch(getAllAssignees());

    return () => dispatch(setTaskPaginationDetails({}));
  }, [dispatch, params?.boardId]);

  useEffect(() => {
    if (params?.boardId) {
      dispatch(SetBoardId(params?.boardId));
    }
  }, [dispatch, params?.boardId]);

  useEffect(() => {
    if (assignee?.value !== '' && assignBy?.value !== '') {
      setReset(false);
      //When filter change the pagination params store in redux.
      dispatch(
        setPagginationParams({
          ...paginationParams,
          assignee_id: assignee?.value,
          assignBy: assignBy?.value,
        })
      );
    }
  }, [assignee?.value, assignBy?.value, dispatch]);

  useEffect(() => {
    if (trackedBoardsData?.board_details?.length > 0) {
      const selectedBoard = trackedBoardsData?.board_details?.find(
        (board: any) => board?._id === params?.boardId
      );

      if (selectedBoard) {
        setSelectedBoard(capitalizeFirstLetter(selectedBoard?.project_name));
      } else {
        // router.replace(routes?.task(defaultWorkSpace?.name));
      }
    }
  }, [
    dispatch,
    trackedBoardsData,
    params?.boardId,
    router,
    defaultWorkSpace?.name,
  ]);

  const boardOptions: Record<string, any>[] =
    trackedBoardsData?.board_details?.length > 0
      ? trackedBoardsData?.board_details?.map((board: Record<string, any>) => {
          return {
            name: capitalizeFirstLetter(board?.project_name),
            value: board?._id,
            key: board,
          };
        })
      : [];

  // Pagination
  const handleChangePage = async (paginationParams: any) => {
    const { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    setSortObject({ page, items_per_page, sort_field, sort_order, search });

    dispatch(
      setTaskPaginationDetails({
        ...paginationParams,
        board_id: params?.boardId,
        pagination: true,
      })
    );

    const response = await dispatch(
      trackedTimeTaskHistory({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        board_id: params?.boardId,
        pagination: true,
      })
    );

    const { data } = response?.payload;
    if (data?.tracked_history?.length > 0) {
      return data?.tracked_history;
    }
  };

  // Ḍelete the trakced time in task
  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    try {
      // DELETE API CALL PANDING
    } catch (error) {
      console.error(error);
    }
  };

  // Select style
  const customStyles: any = {
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isSelected ? '#8c80d2' : 'white',
      color: state.isSelected ? 'white' : 'black',
    }),
    menu: (provided: any) => ({
      ...provided,
      zIndex: 9999, // Higher than any surrounding elements
    }),
  };

  // Assignee options
  const assigneeOptions = [{ name: 'All', value: '', label: 'All' }];
  assignees?.length > 0 &&
    assignees?.map((assignee: Record<string, any>) => {
      assigneeOptions.push({
        name: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        label: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        value: assignee?._id,
      });
    });

  // Assign By options
  const assignByOptions = [{ name: 'All', value: '', label: 'All' }];
  assignedByListData?.length > 0 &&
    assignedByListData?.map((assignee: Record<string, any>) => {
      assignByOptions.push({
        name: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        label: `${capitalizeFirstLetter(
          assignee?.first_name
        )} ${capitalizeFirstLetter(assignee?.last_name)}`,
        value: assignee?._id,
      });
    });

  // Reset Filter
  const handleResetFilters = () => {
    setAssignee({ name: 'Assigned to', value: '', label: 'Assigned to' });
    setAssignBy({ name: 'Assigned By', value: '', label: 'Assigned By' });

    setReset(true);

    dispatch(
      setTaskPaginationDetails({
        ...sortObject,
        page: 1,
        sort_field: 'createdAt',
        sort_order: 'desc',
        search: '',
        filter: '',
        board_id: params?.boardId,
        assignee_id: '',
        assigned_by: '',
      })
    );

    dispatch(
      trackedTimeTaskHistory({
        ...sortObject,
        page: 1,
        sort_field: 'createdAt',
        sort_order: 'desc',
        search: '',
        filter: '',
        board_id: params?.boardId,
        assignee_id: '',
        assigned_by: '',
      })
    );
  };

  // Assignee filter
  const handleAssigneeChange = (selectedOption: Record<string, any>) => {
    // setStatusValue(selectedOption?.value);

    dispatch(
      setTaskPaginationDetails({
        ...paginationParams,
        page: 1,
        assignee_id: selectedOption?.value,
        board_id: params?.boardId,
      })
    );

    dispatch(
      trackedTimeTaskHistory({
        ...paginationParams,
        page: 1,
        assignee_id: selectedOption?.value,
        board_id: params?.boardId,
      })
    );
  };

  // Assgin By filter
  const handleAssignByChange = (selectedOption: Record<string, any>) => {
    // setStatusValue(selectedOption?.value);

    dispatch(
      setTaskPaginationDetails({
        ...paginationParams,
        page: 1,
        assigned_by: selectedOption?.value,
        board_id: params?.boardId,
      })
    );

    dispatch(
      trackedTimeTaskHistory({
        ...paginationParams,
        page: 1,
        assigned_by: selectedOption?.value,
        board_id: params?.boardId,
      })
    );
  };

  // My Tasks Table Filters
  const MyTasksFilter = () => {
    return (
      <>
        {/* {(signIn.role === 'agency' ||
          (signIn?.role === 'team_agency' &&
            signIn?.teamMemberRole === 'admin') || (signIn?.role === 'client')) && ( */}
        <>
          <ReactSelect
            options={assigneeOptions}
            onChange={(selectedOption: Record<string, any>) => {
              handleAssigneeChange(selectedOption);
              setAssignee(selectedOption);
            }}
            value={assignee}
            placeholder="Assigned to"
            className="poppins_font_number react-select-options w-full text-black"
            classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
            styles={customStyles}
          />

          <ReactSelect
            options={assignByOptions}
            onChange={(selectedOption: Record<string, any>) => {
              handleAssignByChange(selectedOption);
              setAssignBy(selectedOption);
            }}
            value={assignBy}
            placeholder="Assigned by"
            className="poppins_font_number react-select-options w-full text-black"
            classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
            styles={customStyles}
          />

          <div>
            <Button
              className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
              onClick={handleResetFilters}
            >
              <Image
                className="mr-2 text-white"
                alt="reste"
                width={15}
                height={15}
                src={restImg}
              />
              Reset
            </Button>
          </div>
        </>
        {/* )} */}
      </>
    );
  };

  return (
    <>
      <div className="main_card_block relative z-40">
        <PageHeader isTaskModule={true} className="">
          <div className="flex w-full flex-col items-center justify-start lg:flex-row">
            {/* left side back and filter for board */}
            <div className="flex w-full items-center justify-start gap-4 lg:w-1/2">
              <Link href={routes.timeTrack(defaultWorkSpace?.name)}>
                <Image src={backIcon} alt="back icon" width={15} height={15} />
              </Link>
              <Select
                variant="text"
                value={selectedBoard}
                onChange={(selectedOption: any) => {
                  setSelectedBoard(selectedOption?.name);
                  router?.push(
                    routes.timeTrackBoardDetails(
                      defaultWorkSpace?.name,
                      selectedOption?.value
                    )
                  );
                }}
                options={boardOptions}
                placeholder="Select Board"
                className="task-list-tour-step-one min-w-[225px] rounded-lg border-[1.5px] border-[#DDDDDD] bg-white p-[1px] text-black"
                selectClassName="focus:outline-none focus:ring-0 focus:border-none disabled:!bg-transparent font-semibold"
                prefix={<Text>Board :</Text>}
                suffix={<PiCaretDownBold className="h-4 w-4" />}
              />
            </div>
          </div>
          <div className="flex w-full justify-end gap-2">
            <Link
              href={
                routes?.timesheetReports(defaultWorkSpace?.name) +
                `?board_id=${params?.boardId}`
              }
            >
              <Button
                variant="solid"
                className="w-[30] bg-[#E3E1F4] text-[#8C80D2] lg:w-auto"
              >
                Report
              </Button>
            </Link>
            <Button
              // variant="solid"
              className="flex items-center justify-between rounded-md bg-[#7667CF] px-6 py-2 text-sm font-medium text-white shadow-md transition-colors hover:bg-[#7a6acb]"
              onClick={() => {
                openModal({
                  view: (
                    <div>
                      <TimerForm
                        onClose={closeModal}
                        // task_id={taskId}
                        boardId={params?.boardId}
                        isTimeTrack={true}
                      />
                    </div>
                  ),
                  customSize: '600px',
                });
              }}
            >
              Start Time Tracking
            </Button>
          </div>
        </PageHeader>
      </div>

      <div className=" ">
        <div className="main_card_block">
          <WidgetCard rounded="lg" title="">
            <div className="table_border_remove overflow-y-auto">
              <CustomTable
                data={trackedTimeTaskHistoryData?.tracked_history || []}
                total={trackedTimeTaskHistoryData?.page_count || 0}
                loading={trackedTimeTaskHistoryLoader}
                pageSize={pageSize}
                setPageSize={setPageSize}
                handleDeleteById={handleDeleteById}
                handleChangePage={handleChangePage}
                getColumns={GetColumns}
                scroll={{ x: 1000 }}
                filtersList={<MyTasksFilter />}
                reset={reset}
                setReset={setReset}
              />
            </div>
          </WidgetCard>
        </div>
      </div>
    </>
  );
}
