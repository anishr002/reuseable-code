'use client';
// import Link from 'next/link';
import CardSkeleton from '@/components/loader/card-skeleton';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { routes } from '@/config/routes';
import '@/layouts/helium/style.css';
import { RemoveBoardListData } from '@/redux/slices/user/task/boardSlice';
import { RemoveGetAllTasksData } from '@/redux/slices/user/task/taskSlice';
import {
  removeTrackedBoardsData,
  trackedBoards,
} from '@/redux/slices/user/time-tracking/timeTrackingSlice';
import cn from '@/utils/class-names';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import syncUppLogo from '@public/assets/images/logo_icon.png';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import InfiniteScroll from 'react-infinite-scroll-component';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Empty, Title } from 'rizzui';

const pageHeader = {
  title: 'Your Boards',
};

export default function MainPage() {
  const dispatch = useDispatch();
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const clientSliceData = useSelector((state: any) => state?.root?.client);
  const { defaultWorkSpace } = useSelector(
    (state: any) => state?.root?.workspace
  );
  const [updatedData, setUpdatedData] = useState<any[]>([]);
  const [totalBoardData, setTotalBoardData] = useState(0);
  const [skeletonLoader, setSkeletonLoader] = useState(true);

  //Infinite Scroll state
  const [hasMore, setHasMore] = useState(true);

  const [payload, setPayload] = useState({
    skip: 0,
    limit: 20,
    all: false,
  });

  // Remove tracked board data
  useEffect(() => {
    dispatch(removeTrackedBoardsData());
  }, [dispatch]);

  // Remove tasks data from redux
  useEffect(() => {
    dispatch(RemoveGetAllTasksData());
  }, [dispatch]);

  // Infinite Scroll
  useEffect(() => {
    let updatedPayload;
    if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
      updatedPayload = payload;
    } else {
      updatedPayload = { ...payload, agency_id: clientSliceData?.agencyId };
    }

    dispatch(trackedBoards(updatedPayload)).then((result: any) => {
      if (trackedBoards.fulfilled.match(result)) {
        setTotalBoardData(result?.payload?.data?.total_boards);
        if (result.payload?.data?.board_details?.length > 0) {
          setSkeletonLoader(false);
          setUpdatedData([
            ...updatedData,
            ...result?.payload?.data?.board_details,
          ]);
          const updateArray = [
            ...updatedData,
            ...result?.payload?.data?.board_details,
          ];
          if (result?.payload?.data?.total_boards > updateArray?.length) {
            setHasMore(true);
          } else {
            setHasMore(false);
          }
        } else {
          setHasMore(false);
        }

        setSkeletonLoader(false);
      } else {
        setHasMore(false);
        setSkeletonLoader(false);
      }
    });
  }, [payload, clientSliceData?.agencyId, signIn?.role, dispatch]);

  //Infinite Scroll Handler
  const fetchMoreData = () => {
    // Assuming you have some way to track the current page and page size
    if (updatedData?.length < totalBoardData) {
      setPayload({
        ...payload,
        skip: updatedData?.length,
      });
    } else {
      setHasMore(false);
    }
  };

  return (
    <>
      {/* <div className="flex flex-row items-start  justify-between"> */}
      {/* <div className="w-[40%]"> */}
      <CustomePageHeader
        title={pageHeader.title}
        titleClassName="montserrat_font_title"
      >
        <div className="flex items-center justify-end gap-2">
          <Link href={routes.timesheetReports(defaultWorkSpace?.name)}>
            <Button
              variant="solid"
              className="w-[30] bg-[#E3E1F4] text-[#8C80D2] lg:w-auto"
            >
              Report
            </Button>
          </Link>
          <Link href={routes.manualtimesheetReports(defaultWorkSpace?.name)}>
            <Button
              rounded="lg"
              className="task-list-tour-step-seven flex h-10 w-auto  items-center justify-start gap-2 bg-[#8C80D2] text-sm text-white"
            >
              Time Entry
            </Button>
          </Link>
        </div>
      </CustomePageHeader>
      {/* </div> */}
      {/* </div> */}

      <InfiniteScroll
        dataLength={updatedData?.length || 0}
        next={fetchMoreData}
        hasMore={hasMore}
        loader={
          <Button
            variant="text"
            size="xl"
            isLoading={true}
            className="flex w-full items-center justify-center"
          />
        }
        height={`h-[59vh] lg:h-[72vh]`}
        className="h-[59vh] lg:h-[72vh]"
      >
        <div
          className={cn(
            'px-[6px]',
            (skeletonLoader || (updatedData && updatedData?.length > 0)) &&
              'grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-5'
          )}
        >
          {skeletonLoader ? (
            <>
              <CardSkeleton />
              <CardSkeleton />
              <CardSkeleton />
              <CardSkeleton />
              <CardSkeleton />
            </>
          ) : (
            <>
              {updatedData && updatedData?.length > 0 ? (
                updatedData.map((board: Record<string, any>, index: number) => {
                  return (
                    <div key={board?._id}>
                      <InformationCard
                        data={board}
                        defaultWorkSpace={defaultWorkSpace}
                      />
                    </div>
                  );
                })
              ) : (
                <div className="flex items-center justify-center">
                  <div className="flex flex-col items-center justify-center gap-2">
                    <Empty />{' '}
                    <p className="mt-3 w-full text-center text-[15px] font-semibold">
                      You currently don’t have tracked hours on any board.
                    </p>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </InfiniteScroll>
    </>
  );
}

function InformationCard({
  data,
  defaultWorkSpace,
}: Readonly<{
  data: any;
  defaultWorkSpace: any;
}>) {
  const dispatch = useDispatch();

  return (
    <div
      className={
        'relative flex h-[188px] w-auto cursor-pointer flex-col items-center justify-center rounded-[20px] border bg-white p-5 shadow-sm hover:border hover:border-[#8C80D2] @3xl:p-7'
      }
    >
      <Link
        className="mt-7 flex h-full w-full items-center justify-start"
        href={routes.timeTrackBoardDetails(defaultWorkSpace?.name, data?._id)}
        onClick={() => dispatch(RemoveBoardListData())}
      >
        <div className="flex cursor-pointer flex-col items-start justify-center">
          <div className="relative aspect-square h-[65px] w-[65px] overflow-hidden rounded-[19px] border-white bg-[#F6F6FB] shadow-profilePic">
            {data?.board_image ? (
              <img
                src={`${process.env.NEXT_PUBLIC_IMAGE_URL}/${data?.board_image}`}
                alt={data?.project_name}
                onError={(event: any) => {
                  event.target.src = syncUppLogo?.src;
                }}
                className="aspect-auto h-full w-full object-cover"
              />
            ) : (
              <div
                className="flex h-[65px] w-[65px] items-center justify-center rounded-[19px] border-white"
                style={{ backgroundColor: data?.board_color }}
              ></div>
            )}
          </div>
          <Title
            as="h1"
            className={
              'max-w-[210px] overflow-hidden truncate text-ellipsis whitespace-nowrap text-[16px] font-bold text-[#111928]'
            }
          >
            {capitalizeFirstLetter(data?.project_name)}
          </Title>

          {/* Description container with consistent height */}
          <div
            className="line-clamp-2 max-w-[233px] text-[12px] font-[400] leading-[16.8px] text-[#4B5563] sm:max-w-[300px] md:max-w-[350px] lg:max-w-[450px] xl:max-w-[600px]"
            style={{
              display: '-webkit-box',
              WebkitBoxOrient: 'vertical',
              WebkitLineClamp: 2,
              overflow: 'hidden',
              wordBreak: 'break-word',
              overflowWrap: 'break-word',
              minHeight: '34px',
            }}
          >
            <div>{data?.description || '\u00A0'}</div>
          </div>
        </div>
      </Link>
    </div>
  );
}
