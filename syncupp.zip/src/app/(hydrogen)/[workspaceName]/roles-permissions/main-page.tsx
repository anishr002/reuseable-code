'use client';

import RoleCard from "@/app/shared/(user)/roles-permissions/role-card";
import { checkPermission } from "@/app/shared/(user)/roles-permissions/utils";
import { CustomePageHeader } from "@/components/pageheader/pageheader";
import { Button } from '@/components/ui/button';
import { Empty } from '@/components/ui/empty';
import Spinner from '@/components/ui/spinner';
import { routes } from "@/config/routes";
import { deleteSubRole, getRolesList } from "@/redux/slices/user/roles-permissions/rolePermissionSlice";
import Link from 'next/link';
import { useEffect, useState } from "react";
import { PiPlusBold } from 'react-icons/pi';
import { useDispatch, useSelector } from "react-redux";

const pageHeader = {
    title: 'Roles & Permissions',
};

function RolePermissionPage() {
    const dispatch = useDispatch();
    const [subRole, setSubRole] = useState('');
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace);
    const { getRolesListData, getRolesListLoader } = useSelector((state: any) => state?.root?.rolePermission);
    const { role, teamMemberRole, permission } = useSelector((state: any) => state?.root?.signIn);

    const canEdit = ['team_agency', 'team_client'].includes(role) ? checkPermission('roles_permissions', null, 'update', permission) : ['agency', 'client'].includes(role);
    const canDelete = ['team_agency', 'team_client'].includes(role) ? checkPermission('roles_permissions', null, 'update', permission) : ['agency', 'client'].includes(role)

    // Set role to get role list by login user
    useEffect(() => {
        const subRoleName = ['agency', 'team_agency'].includes(role) ? 'team_agency' : ['client', 'team_client'].includes(role) ? 'team_client' : ''
        setSubRole(subRoleName);
    }, [role]);

    // Component init
    useEffect(() => {
        subRole && dispatch(getRolesList({ role: subRole }));
    }, [dispatch, subRole]);

    // Delete role API calling
    const deleteRole = (id: string) => {
        dispatch(deleteSubRole(id)).then((result: any) => {
            if (deleteSubRole.fulfilled.match(result)) {
                if (result.payload.success === true) {
                    subRole && dispatch(getRolesList({ role: subRole }));
                }
            }
        });
    };

    return (
        <>
            <CustomePageHeader
                title={pageHeader.title}
                titleClassName="montserrat_font_title"
            >
                {
                    (['agency', 'client'].includes(role) || (['team_agency', 'team_client'].includes(role) && checkPermission('roles_permissions', null, 'create', permission))
                    ) &&
                    <div className="mt-4 flex items-center gap-3 @lg:mt-0">
                        <Link href={routes.createRole(defaultWorkSpace?.name)} className="w-full">
                            <Button
                                type='button'
                                // onClick={() => { pathname ? router.push(`${routes.invoiceForm(defaultWorkSpace?.name)}?reference=${clientSliceData?._id}`) : router.push(routes.invoiceForm(defaultWorkSpace?.name)) }}
                                className="bg-[#8C80D2] w-32 h-12 rounded-lg text-sm font-medium px-0"
                            >
                                <PiPlusBold className="me-1.5 h-[17px] w-[17px]" /> Create Role
                            </Button>
                        </Link>
                    </div>
                }
            </CustomePageHeader>
            {getRolesListLoader &&

                <div className="flex justify-center items-center">
                    <Spinner size="xl" tag='div' />
                </div>}
            {!getRolesListLoader && getRolesListData?.length === 0 &&
                <div className="flex items-center justify-center">
                    <div className="flex flex-col items-center justify-center gap-2">
                        <Empty />{' '}
                        <p className="mt-3 w-full text-center text-[15px] font-semibold">
                            You currently don’t have any role.
                        </p>
                    </div>
                </div>
            }
            {!getRolesListLoader && getRolesListData?.length > 0 &&
                <div className='@container'>
                    <div
                        className=
                        'grid grid-cols-1 gap-6 @[36.65rem]:grid-cols-2 @[56rem]:grid-cols-3 @[78.5rem]:grid-cols-4 @[100rem]:grid-cols-5'
                    >
                        {getRolesListData?.map((permission: any) =>
                        (
                            <RoleCard key={permission?._id} roleName={permission?.sub_role} data={permission} canEdit={canEdit && (teamMemberRole !== permission?.sub_role)} canDelete={canDelete && (teamMemberRole !== permission?.sub_role)} defaultWorkSpace={defaultWorkSpace} deleteRole={deleteRole} />)
                        )}
                    </div>
                </div >
            }
        </>
    );
}

export default RolePermissionPage;
