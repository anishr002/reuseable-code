
import { metaObject } from '@/config/site.config';
import MainPage from './main-page';

export const metadata = {
    ...metaObject('Edit Role'),
};

export default function Page() {
    return (
        <>
            <MainPage />
        </>
    );
}
