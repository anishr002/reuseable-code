'use client';

import CreateRole from '@/app/shared/(user)/roles-permissions/create-role';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { routes } from '@/config/routes';
import { useSelector } from 'react-redux';

const pageHeader = {
    title: 'Edit Role'
};

const MainPage = () => {
    const { defaultWorkSpace } = useSelector((state: any) => state?.root?.workspace);

    return (
        <>
            <CustomePageHeader title={pageHeader.title} route={routes.roleAndPermission(defaultWorkSpace?.name)} titleClassName='montserrat_font_title' />
            <CreateRole />
        </>
    );
}

export default MainPage;
