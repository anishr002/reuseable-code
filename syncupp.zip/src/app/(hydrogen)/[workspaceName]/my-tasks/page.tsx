import { metaObject } from '@/config/site.config';
import MyTasksPage from './main-page';

export const metadata = {
  ...metaObject('Tasks'),
};

export default function Page() {
  return (
    <div className="main_card_block">
      <MyTasksPage />
    </div>
  );
}
