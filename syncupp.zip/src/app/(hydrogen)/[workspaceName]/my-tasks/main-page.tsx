'use client';
import { GetColumns } from '@/app/shared/(user)/my-tasks/column';
import { checkPermission } from '@/app/shared/(user)/roles-permissions/utils';
import AddTaskForm from '@/app/shared/(user)/task/task-grid/add-task-form';
import { useModal } from '@/app/shared/modal-views/use-modal';
import WidgetCard from '@/components/cards/widget-card';
import CustomTable from '@/components/common-tables/table';
import { CustomePageHeader } from '@/components/pageheader/pageheader';
import { Button } from '@/components/ui/button';
import Select from '@/components/ui/select';
import Spinner from '@/components/ui/spinner';
import socket from '@/io';
import { setPagginationParams } from '@/redux/slices/user/client/clientSlice';
import {
  bulkTaskUpdateForAllTask,
  exportAllTasks,
  getAllMyTasks,
  RemoveMyTasksData,
  updateActiveTimer,
} from '@/redux/slices/user/dashboard/dashboardSlice';
import {
  getAllAssignees,
  getAllBoard,
  removeTaskFormData,
} from '@/redux/slices/user/task/boardSlice';
import { RemoveGetAllTasksData } from '@/redux/slices/user/task/taskSlice';
import { capitalizeFirstLetter } from '@/utils/common-functions';
import restImg from '@public/assets/images/reset_icon.svg';
import Image from 'next/image';
import { usePathname, useRouter, useSearchParams } from 'next/navigation';
import React, { useEffect, useRef, useState } from 'react';
import {
  PiArrowLineDownBold,
  PiCaretDownBold,
  PiPlusBold,
} from 'react-icons/pi';
import { useDispatch, useSelector } from 'react-redux';
import ReactSelect, { components } from 'react-select';
import { Checkbox, Text } from 'rizzui';

const pageHeader = {
  title: 'Tasks',
};

export default function MyTasksPage() {
  const dispatch = useDispatch();
  const { openModal, closeModal } = useModal();
  const [statusName, setStatusName] = useState<any>([]);
  const [statusValue, setStatusValue] = useState<any>([]);
  const [boardName, setBoardName] = useState<any>([]);
  const [boardValue, setBoardValue] = useState([]);
  const [period, setPeriod] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [assignee, setAssignee] = useState<any>([]);
  const [selectedAssignees, setSelectedAssignees] = useState([]);

  const [reset, setReset] = useState(false);
  const [sortObject, setSortObject] = useState({});
  const searchParams = useSearchParams();
  const router = useRouter();
  const path = usePathname();

  const { getAllMyTasksLoader, tasksData, exportAllTasksLoader } = useSelector(
    (state: any) => state?.root?.dashbord
  );
  const { data, assignees } = useSelector((state: any) => state?.root?.board);
  const { paginationParams } = useSelector((state: any) => state?.root?.client);
  const signIn = useSelector((state: any) => state?.root?.signIn);
  const { activeTimerData } = useSelector(
    (state: any) => state?.root?.timeTracking
  );
  const previousTimerDataRef = useRef(activeTimerData);

  const [pageSize, setPageSize] = useState<number>(10);

  // Header Board selection dropdown states
  const [selectedBoard, setSelectedBoard] = useState<any>('');

  useEffect(() => {
    const handleTimerEnd = (res: any) => {
      console.log('TIMER_UPDATE_ALL_TASK', res);
      dispatch(updateActiveTimer({ ...res, checkPermission, signIn }));
      socket.emit('CONFIRMATION', { event: 'TIMER_UPDATE_ALL_TASK' });
    };

    socket.on('TIMER_UPDATE_ALL_TASK', handleTimerEnd);

    // Cleanup to remove the event listener
    return () => {
      socket.off('TIMER_UPDATE_ALL_TASK', handleTimerEnd);
    };
  }, []);

  // Bulk Task update socket events
  // called when bulk task is update
  useEffect(() => {
    socket.on('BULK_TASK_UPDATE', (res) => {
      console.log(res, 'BULK_TASK_UPDATE');
      socket.emit('CONFIRMATION', { event: 'BULK_TASK_UPDATE' });

      if (res?.task_completed || res?.task_deleted) {
        return;
      }
      dispatch(bulkTaskUpdateForAllTask(res));
    });

    return () => {
      socket.off('BULK_TASK_UPDATE');
    };
  }, [dispatch, paginationParams]);

  console.log('paginationParams.......', paginationParams);

  useEffect(() => {
    if (period !== '' || startDate !== '' || endDate !== '') {
      setReset(true);
    }
  }, [period, startDate, endDate]);

  useEffect(() => {
    if (
      statusValue !== '' ||
      boardName?.value !== '' ||
      assignee?.value !== '' ||
      startDate !== '' ||
      endDate !== ''
    ) {
      setReset(false);
      //When filter change the pagination params store in redux.
      dispatch(
        setPagginationParams({
          ...sortObject,
          filter: {
            status: statusName,
            date: { start_date: startDate, end_date: endDate },
          },
          board_id: boardName,
          assignee_id: assignee,
        })
      );
    }
  }, [statusName, boardName, assignee, startDate, endDate, sortObject, dispatch]);

  useEffect(() => {
    // Get all boards api
    dispatch(getAllBoard({ all: true }));

    // Get all the assignees list
    dispatch(getAllAssignees());

    // Remove tasks module page data from redux
    dispatch(RemoveGetAllTasksData());

    // clear task form board data
    dispatch(removeTaskFormData());

    // Remove Tasks data on ummount page
    return () => {
      dispatch(RemoveMyTasksData());
      dispatch(setPagginationParams({}));
    };
  }, [dispatch]);

  const statusOptionsDropdown: any = [
    // { name: 'All tasks', value: '', label: 'All tasks' },
    { name: 'My tasks', value: 'my_task', label: 'My tasks' },
    {
      name: 'Incomplete',
      value: 'in_completed',
      label: 'Incomplete',
    },
    { name: 'Completed', value: 'completed', label: 'Completed' },
    { name: 'Overdue', value: 'overdue', label: 'Overdue' },
    { name: 'Archive', value: 'archived', label: 'Archive' },
    { name: 'Timer on', value: 'timer_on', label: 'Timer on' },
    { name: 'Unassigned', value: 'unassigned', label: 'Unassigned' },
    { name: 'Due this week', value: 'due_this_week', label: 'Due this week' },
    { name: 'Due next week', value: 'due_next_week', label: 'Due next week' },
  ];

  // Adjust options based on user role
  const filteredStatusOptions =
    signIn.role === 'agency' ||
    (signIn?.role === 'team_agency' && signIn?.teamMemberRole === 'admin')
      ? statusOptionsDropdown
      : statusOptionsDropdown.filter((data: any) => data.value !== 'my_task');
  useEffect(() => {
    const filterValue = searchParams.get('filter');
    if (filterValue) {
      const selectedOptions = getNameByValue(
        filterValue,
        filteredStatusOptions
      );
      setStatusValue(selectedOptions);
      setStatusName(selectedOptions.map((option: any) => option.value));

      // Update the URL but keep query parameters intact
      const updatedPath = `${path}?filter=${filterValue}`;
      router.replace(updatedPath);
    }
  }, [searchParams]);

  // Table api call logic
  const handleChangePage = async (paginationParams: any) => {
    let { page, items_per_page, sort_field, sort_order, search } =
      paginationParams;

    setSortObject({ page, items_per_page, sort_field, sort_order, search });
    dispatch(
      setPagginationParams({
        ...paginationParams,
        filter: {
          status: searchParams.get('filter')
            ? [searchParams.get('filter')]
            : statusName,
          date: { start_date: startDate, end_date: endDate },
        },
        board_id: boardName,
        assignee_id: assignee,
      })
    );

    const response = await dispatch(
      getAllMyTasks({
        page,
        items_per_page,
        sort_field,
        sort_order,
        search,
        filter: {
          status: searchParams.get('filter')
            ? [searchParams.get('filter')]
            : statusName,
          date: { start_date: startDate, end_date: endDate },
        },
        board_id: boardName,
        assignee_id: assignee,
      })
    );

    const { data } = response?.payload;
    const maxPage: number = data?.page_count;

    if (page > maxPage) {
      page = maxPage > 0 ? maxPage : 1;
      await dispatch(
        getAllMyTasks({
          page,
          items_per_page,
          sort_field,
          sort_order,
          search,
          filter: {
            status: searchParams.get('filter')
              ? [searchParams.get('filter')]
              : statusName,
            date: { start_date: startDate, end_date: endDate },
          },
          board_id: boardName,
          assignee_id: assignee,
        })
      );
      return data?.activity;
    }
    if (data && data?.activity && data?.activity?.length !== 0) {
      return data?.activity;
    }
  };

  const handleDeleteById = async (
    id: string | string[],
    currentPage?: any,
    countPerPage?: number,
    sortConfig?: Record<string, string>,
    searchTerm?: string
  ) => {
    console.log('delete function called.');
  };

  const getNameByValue = (value: any, options: any) => {
    const selectedOptions = value
      .split(',')
      .map((v: any) => options.find((opt: any) => opt.value === v));
    return selectedOptions.filter(Boolean);
  };

  // Dropdown style
  // const customStyles = {
  //   option: (provided: any, state: any) => ({
  //     ...provided,
  //     cursor: 'pointer',
  //     backgroundColor: state.isFocused ? '#EBF8FF' : 'white', // Light blue when hovered
  //     color: state.isSelected ? 'black' : 'black',
  //     padding: '8px',
  //   }),
  // };

  const customStyles = {
    control: (provided: any, state: any) => ({
      ...provided,
      height: '40px',
      display: 'flex',
      alignItems: 'center',
      borderRadius: '8px',
      borderColor: state.isFocused ? 'black' : 'rgb(209 213 219)',
      boxShadow: state.isFocused ? 'none' : 'none', // Ensure no box-shadow on focus
      outline: 'none !important',
      padding: '0 8px',
      transition: 'border-color 0.2s ease',
      '&:hover': {
        borderColor: 'black', // Black border on hover
      },
    }),
    input: (provided: any) => ({
      ...provided,
      border: 'none !important',
      boxShadow: 'none !important',
      outline: 'none !important',
      caretColor: 'rgb(209 213 219)', // Ensures visible text cursor
    }),
    valueContainer: (provided: any) => ({
      ...provided,
      display: 'flex',
      alignItems: 'center',
      padding: '0 8px',
      gap: '8px',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
    }),
    placeholder: (provided: any) => ({
      ...provided,
      color: 'rgb(209 213 219)',
      fontSize: '14px',
      fontWeight: '500',
      whiteSpace: 'nowrap',
    }),
    singleValue: (provided: any) => ({
      ...provided,
      fontWeight: '600',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
    }),
    multiValue: (provided: any) => ({
      ...provided,
      backgroundColor: '#e1e7ff',
      borderRadius: '12px',
      padding: '2px 6px',
      display: 'flex',
      alignItems: 'center',
    }),
    multiValueLabel: (provided: any) => ({
      ...provided,
      fontSize: '12px',
      fontWeight: '500',
      color: '#4a4a4a',
    }),
    multiValueRemove: (provided: any) => ({
      ...provided,
      color: '#8c80d2',
      cursor: 'pointer',
      ':hover': {
        backgroundColor: '#e0e0e0',
        color: '#4a4a4a',
      },
    }),
    option: (provided: any, state: any) => ({
      ...provided,
      backgroundColor: state.isFocused ? '#f3f4f6' : 'white',
      color: state.isSelected ? '#4a4a4a' : '#000',
      padding: '8px 12px',
      fontSize: '14px',
      fontWeight: state.isSelected ? '600' : '400',
      ':active': {
        backgroundColor: '#e1e7ff',
      },
    }),
    menu: (provided: any) => ({
      ...provided,
      zIndex: 9999,
      borderRadius: '8px',
      boxShadow: '0px 4px 10px rgba(0, 0, 0, 0.1)',
      marginTop: '4px',
    }),
    dropdownIndicator: (provided: any) => ({
      ...provided,
      color: '#8c80d2',
      ':hover': {
        color: '#4a4a4a',
      },
    }),
    indicatorSeparator: () => ({
      display: 'none !important',
    }),
  };

  // Filters logic

  // Assignee options
  // Assignee options
  const assigneeOptions: any = [
    // { name: 'All', value: '', label: 'All' },
    ...(assignees && assignees?.length > 0
      ? assignees?.map((assignee: Record<string, any>) => ({
          name: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          label: `${capitalizeFirstLetter(
            assignee?.first_name
          )} ${capitalizeFirstLetter(assignee?.last_name)}`,
          value: assignee?._id,
          key: assignee,
        }))
      : []),
  ];

  console.log(assigneeOptions, 'assigneeOptions345');
  // Board options....
  const boardOptions: any = [
    // Uncomment this line if you want a default option // for page hearder board selection dropdown also
    { name: 'All Boards', value: '', label: 'All Boards' },
    ...(data?.board_list?.length > 0
      ? data?.board_list.map((board: Record<string, any>) => ({
          name: capitalizeFirstLetter(board?.project_name),
          label: capitalizeFirstLetter(board?.project_name),
          value: board?._id,
        }))
      : []),
  ];

  console.log(boardOptions, 'boardOptions1234');

  const handleStatusChange = (selectedOptions: any) => {
    const isAllSelected = selectedOptions?.some(
      (option: any) => option.value === allOption?.value
    );

    if (isAllSelected) {
      const isDeselectingAll =
        statusValue?.length === statusOptionsDropdown?.length;

      if (isDeselectingAll) {
        // Unselect everything
        setStatusValue([]);
        setStatusName([]);
        dispatch(
          getAllMyTasks({
            ...sortObject,
            page: 1,
            filter: {
              status: [],
              date: { start_date: startDate, end_date: endDate },
            },
            board_id: boardName,
            assignee_id: assignee,
          })
        );
      } else {
        // Select everything
        setStatusValue(statusOptionsDropdown);
        setStatusName(
          statusOptionsDropdown?.map((option: any) => option.value)
        );
        dispatch(
          getAllMyTasks({
            ...sortObject,
            page: 1,
            filter: {
              status: statusOptionsDropdown?.map((option: any) => option.value),
              date: { start_date: startDate, end_date: endDate },
            },
            board_id: boardName,
            assignee_id: assignee,
          })
        );
      }
    } else {
      const selectedStatus = selectedOptions?.map(
        (option: any) => option.value
      );
      setStatusValue(selectedOptions);
      setStatusName(selectedStatus);
      dispatch(
        getAllMyTasks({
          ...sortObject,
          page: 1,
          filter: {
            status: selectedStatus,
            date: { start_date: startDate, end_date: endDate },
          },
          board_id: boardName,
          assignee_id: assignee,
        })
      );
    }
  };

  useEffect(() => {
    !!endDate &&
      dispatch(
        getAllMyTasks({
          ...sortObject,
          page: 1,
          filter: {
            status: statusName,
            date: { start_date: startDate, end_date: endDate },
          },
          board_id: boardName,
          assignee_id: assignee,
        })
      );
  }, [endDate, startDate]);

  const handleAssigneeChange = (selectedOptions: any) => {
    const allSelected = selectedOptions?.some(
      (option: any) => option.value === allOption.value
    );

    if (allSelected) {
      const isDeselectingAll =
        selectedAssignees?.length === assigneeOptions?.length;

      if (isDeselectingAll) {
        // Unselect everything
        setSelectedAssignees([]);
        setAssignee([]);
        dispatch(
          getAllMyTasks({
            ...sortObject,
            page: 1,
            filter: {
              status: statusName,
              date: { start_date: startDate, end_date: endDate },
            },
            board_id: boardName,
            assignee_id: [],
          })
        );
      } else {
        // Select everything
        setSelectedAssignees(assigneeOptions);
        setAssignee(assigneeOptions?.map((option: any) => option.value));
        dispatch(
          getAllMyTasks({
            ...sortObject,
            page: 1,
            filter: {
              status: statusName,
              date: { start_date: startDate, end_date: endDate },
            },
            board_id: boardName,
            assignee_id: assigneeOptions?.map((option: any) => option.value),
          })
        );
      }
    } else {
      // Normal selection
      const selectedAssigneeIds = selectedOptions?.map(
        (option: any) => option.value
      );
      setSelectedAssignees(selectedOptions);
      setAssignee(selectedAssigneeIds);
      dispatch(
        getAllMyTasks({
          ...sortObject,
          page: 1,
          filter: {
            status: statusName,
            date: { start_date: startDate, end_date: endDate },
          },
          board_id: boardName,
          assignee_id: selectedAssigneeIds,
        })
      );
    }
  };

  const handleBoardChange = (selectedOptions: any) => {
    const allSelected = selectedOptions?.some(
      (option: any) => option.value === allOption.value
    );

    if (allSelected) {
      const isDeselectingAll = boardValue?.length === boardOptions?.length;

      if (isDeselectingAll) {
        setBoardValue([]);
        setBoardName([]);
        dispatch(
          getAllMyTasks({
            ...sortObject,
            page: 1,
            filter: {
              status: statusName,
              date: { start_date: startDate, end_date: endDate },
            },
            board_id: [],
            assignee_id: assignee, // Keep existing assignee selection
          })
        );
      } else {
        setBoardValue(boardOptions);
        setBoardName(boardOptions?.map((option: any) => option.value));
        dispatch(
          getAllMyTasks({
            ...sortObject,
            page: 1,
            filter: {
              status: statusName,
              date: { start_date: startDate, end_date: endDate },
            },
            board_id: boardOptions?.map((option: any) => option.value),
            assignee_id: assignee, // Keep existing assignee selection
          })
        );
      }
    } else {
      const selectedBoardIds = selectedOptions?.map(
        (option: any) => option.value
      );
      setBoardValue(selectedOptions);
      setBoardName(selectedBoardIds);
      dispatch(
        getAllMyTasks({
          ...sortObject,
          page: 1,
          filter: {
            status: statusName,
            date: { start_date: startDate, end_date: endDate },
          },
          board_id: selectedBoardIds,
          assignee_id: assignee, // Keep existing assignee selection
        })
      );
    }
  };

  const handleResetFilters = () => {
    setStatusName([]);
    setStatusValue([]);
    // board filter commented
    // setBoardName([]);
    // setBoardValue([]);
    setPeriod('');
    setStartDate('');
    setEndDate('');
    setAssignee([]);
    setSelectedAssignees([]);

    setReset(true);

    dispatch(
      getAllMyTasks({
        ...sortObject,
        page: 1,
        sort_field: 'createdAt',
        sort_order: 'desc',
        search: '',
        filter: { status: [], date: { start_date: '', end_date: '' } },
        board_id: boardName, // board filter commented
        assignee_id: [],
      })
    );
  };

  // useEffect(() => {
  //   // Check if activeTimerData transitioned from non-empty to empty
  //   const wasPreviouslyNonEmpty =
  //     previousTimerDataRef.current &&
  //     Object.keys(previousTimerDataRef.current).length > 0;

  //   const isNowEmpty = Object.keys(activeTimerData).length === 0;

  //   if (wasPreviouslyNonEmpty && isNowEmpty) {
  //     handleResetFilters();
  //   }

  //   // Update the ref to the current state
  //   previousTimerDataRef.current = activeTimerData;
  // }, [activeTimerData]);

  const allOption = {
    label: 'Select all',
    value: '*',
  };

  const optionsWithSelectAllStatus = [allOption, ...statusOptionsDropdown];

  const displayName = (data: any) => {
    return `${
      capitalizeFirstLetter(data?.first_name) +
      ' ' +
      capitalizeFirstLetter(data?.last_name)
    }`;
  };

  const Option = (props: any) => {
    console.log(props, 'props12345');
    const { data, isSelected, selectOption, selectProps, allOptions } = props;
    // Determine if this is the "Select All" option
    const isAllOption = data?.value === allOption?.value;

    // const allOptions = selectProps.allOptions || [];
    const allSelected = selectProps.value?.length === allOptions?.length;

    const handleChange = (e: React.MouseEvent<HTMLDivElement>) => {
      e.stopPropagation();
      if (isAllOption) {
        // If all options are selected, clicking "Select All" will clear selection
        // Otherwise, clicking "Select All" selects all available options.
        if (allSelected) {
          selectProps.onChange([]);
        } else {
          selectProps.onChange(allOptions);
        }
      } else {
        // For a normal option, simply call selectOption to add or remove it.
        selectOption(data);
      }
    };

    return (
      <components.Option {...props}>
        <div
          className="flex cursor-pointer items-center gap-2"
          onClick={handleChange}
        >
          <Checkbox
            label={data?.label}
            checked={isAllOption ? allSelected : isSelected}
            color="info"
            // variant="flat"
            inputClassName="checkbox-color"
            className="cursor-pointer [&>label>span]:font-medium"
            labelClassName="text-1.20em md:text-1.20em lg:text-1.20em xl:text-1.20em text-gray-700 dark:text-gray-600 cursor-pointer"
            onClick={(e) => e.stopPropagation()}
          />
          {/* <img
            src={props.data.profile}
            alt={props.data.label}
            className="h-8 w-8 rounded-full"
          /> */}
        </div>
      </components.Option>
    );
  };

  const MultiValue = (props: any) => (
    <components.MultiValue {...props}>
      <div className="flex items-center gap-2">
        {/* <img
          src={props.data.profile}
          alt={props.data.label}
          className="h-6 w-6 rounded-full"
        /> */}
        <span>{props.data.label}</span>
      </div>
    </components.MultiValue>
  );

  const allTaskDownload = () => {
    dispatch(
      exportAllTasks({
        ...sortObject,
        page: 1,
        filter: {
          status: statusName,
          date: { start_date: startDate, end_date: endDate },
        },
        board_id: boardName,
        assignee_id: assignee,
      })
    );
  };

  const optionsWithSelectAll = [allOption, ...assigneeOptions];
  const optionsWithSelectAllBoards = [allOption, ...boardOptions];

  const ValueContainer = ({ children, ...props }: any) => {
    const selectedOptions = props.getValue();
    const hasSelections = selectedOptions.length > 0;

    // Determine the placeholder and truncate it if it’s too long during selected state
    let placeholder = props.selectProps.placeholder || 'Select';

    if (
      hasSelections &&
      placeholder === 'Select assignee' &&
      selectedOptions?.length > 0
    ) {
      // Truncate when displaying selected options count
      placeholder = `Select assig...`;
    } else if (hasSelections && placeholder.length > 15) {
      // Truncate if longer than 15 characters during selected state
      placeholder = `${placeholder.substring(0, 15)}...`;
    }

    return (
      <components.ValueContainer {...props}>
        <div className="flex items-center gap-2 whitespace-nowrap">
          {hasSelections ? (
            <div className="font-medium text-[#4a4a4a]">
              {placeholder}{' '}
              <span className="rounded-full bg-[#8c80d2] px-2 py-1 text-xs font-bold text-white">
                {selectedOptions.length.toString().padStart(2, '0')}
              </span>
            </div>
          ) : (
            <span className="text-[#4a4a4a]">{placeholder}</span>
          )}
          {React.cloneElement(children[1])}
        </div>
      </components.ValueContainer>
    );
  };

  // My Tasks Table Filters
  const MyTasksFilter = () => {
    return (
      <>
        {/* <ReactSelect
          options={boardOptions}
          isMulti
          onChange={handleBoardChange}
          value={boardValue}
          placeholder="All Boards"
          className="poppins_font_number react-select-options task-assign w-full"
          styles={customStyles}
          hideSelectedOptions={false}
        /> */}

        {/* Multiple Board selection filter */}
        {/* <ReactSelect
          options={optionsWithSelectAllBoards}
          onChange={(selected: any) => {
            console.log(selected, 'selected1234');
            if (
              selected !== null &&
              selected?.length > 0 &&
              selected[selected?.length - 1]?.value === allOption.value
            ) {
              return handleBoardChange(boardOptions);
            }
            return handleBoardChange(selected);
          }}
          value={boardValue}
          isMulti
          closeMenuOnSelect={false}
          placeholder="Select board"
          className="poppins_font_number react-select-options task-assign w-full"
          classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
          components={{ Option, MultiValue, ValueContainer }}
          hideSelectedOptions={false}
          styles={customStyles}
          isClearable={false}
          // type="board" // Custom type to differentiate
        /> */}

        <ReactSelect
          options={optionsWithSelectAllStatus}
          onChange={(selected: any) => {
            console.log(selected, 'selected1234');
            if (!selected || selected?.length === 0) {
              return handleStatusChange([]);
            }

            const isAllSelected = selected?.some(
              (option: any) => option.value === allOption.value
            );

            if (isAllSelected) {
              const isDeselectingAll =
                statusValue?.length === statusOptionsDropdown?.length;

              if (isDeselectingAll) {
                return handleStatusChange([]);
              }
              return handleStatusChange(statusOptionsDropdown);
            }

            return handleStatusChange(selected);
          }}
          value={statusValue}
          isMulti
          closeMenuOnSelect={false}
          placeholder="Select status"
          className="poppins_font_number react-select-options task-assign w-full"
          classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
          components={{
            Option: (props) => (
              <Option {...props} allOptions={statusOptionsDropdown} />
            ),
            MultiValue,
            ValueContainer,
          }}
          hideSelectedOptions={false}
          styles={customStyles}
          isClearable={false}
          // type="status" // Custom type to differentiate
        />

        {(['agency'].includes(signIn.role) ||
          (['team_agency'].includes(signIn.role) &&
            checkPermission(
              'projects',
              'tasks',
              'everyone',
              signIn?.permission
            ))) && (
          <ReactSelect
            options={optionsWithSelectAll}
            onChange={(selected: any) => {
              console.log(selected, 'selected1234');
              if (!selected || selected?.length === 0) {
                return handleAssigneeChange([]);
              }

              const isAllSelected = selected?.some(
                (option: any) => option.value === allOption.value
              );

              if (isAllSelected) {
                const isDeselectingAll =
                  selectedAssignees?.length === assigneeOptions?.length;

                if (isDeselectingAll) {
                  return handleAssigneeChange([]);
                }
                return handleAssigneeChange(assigneeOptions);
              }

              return handleAssigneeChange(selected);
            }}
            value={selectedAssignees}
            isMulti
            closeMenuOnSelect={false}
            placeholder="Select assignee"
            className="poppins_font_number react-select-options task-assign w-full"
            classNamePrefix="custom-multi-select" // ✅ Apply scoped styles
            components={{
              Option: (props) => (
                <Option {...props} allOptions={assigneeOptions} />
              ),
              MultiValue,
              ValueContainer,
            }}
            hideSelectedOptions={false}
            styles={customStyles}
            isClearable={false}
            // type="assignee" // Custom type to differentiate
          />
        )}
        <div>
          <Button
            className="flex h-[40px] w-[90px] items-center justify-center rounded-lg border border-[#7667CF] !bg-transparent text-sm text-[#7667CF]"
            onClick={handleResetFilters}
          >
            <Image
              className="mr-2 text-white"
              alt="reste"
              width={15}
              height={15}
              src={restImg}
            />
            Reset
          </Button>
        </div>
      </>
    );
  };

  return (
    <>
      <CustomePageHeader
      // title={pageHeader?.title}
      >
        <Select
          variant="text"
          value={selectedBoard}
          onChange={(selectedOption: any) => {
            setSelectedBoard(selectedOption);
            setBoardName(selectedOption === '' ? [] : [selectedOption]);
            dispatch(
              getAllMyTasks({
                ...sortObject,
                page: 1,
                filter: {
                  status: statusName,
                  date: { start_date: startDate, end_date: endDate },
                },
                board_id: selectedOption === '' ? [] : [selectedOption],
                assignee_id: assignee,
              })
            );
          }}
          options={boardOptions}
          getOptionValue={(option) => option?.value}
          getOptionDisplayValue={(option: any) => option?.name}
          displayValue={(value) => {
            const displayValue = boardOptions?.find(
              (option: any) => option?.value === value
            );
            return displayValue?.name ? displayValue?.name : '';
          }}
          placeholder="All Boards"
          className="task-list-tour-step-one min-w-[225px] rounded-lg border-[1.5px] border-[#DDDDDD] bg-white p-[1px] text-black"
          selectClassName="focus:outline-none focus:ring-0 focus:border-none disabled:!bg-transparent font-semibold"
          prefix={<Text>Board :</Text>}
          suffix={<PiCaretDownBold className="h-4 w-4" />}
        />
        <div className="flex items-center gap-4">
          {['agency'].includes(signIn?.role) && (
            <Button
              variant="solid"
              className="w-[30] bg-[#E3E1F4] text-[#8C80D2] lg:w-auto"
              onClick={allTaskDownload}
              disabled={exportAllTasksLoader}
            >
              <PiArrowLineDownBold className="me-1.5 h-[17px] w-[17px]" />
              Export
              {exportAllTasksLoader && (
                <Spinner
                  size="sm"
                  tag="div"
                  className="ms-3 bg-[#E3E1F4] text-[#8C80D2] "
                  // style={{ color: '#8C80D2' }}
                />
              )}
            </Button>
          )}
          {((['team_client', 'team_agency'].includes(signIn?.role) &&
            checkPermission(
              'projects',
              'tasks',
              'create',
              signIn?.permission
            )) ||
            ['agency'].includes(signIn?.role)) && (
            <Button
              rounded="lg"
              className="task-list-tour-step-seven flex h-10 w-[125px]  items-center justify-center gap-2 bg-[#8C80D2] text-sm text-white"
              onClick={() => {
                openModal({
                  view: (
                    <AddTaskForm
                      onClose={() => closeModal()}
                      editMode={false}
                      rowData={null}
                      isAllTasksModule={true}
                    />
                  ),
                  customSize: '800px',
                });
              }}
            >
              {' '}
              <span className="flex items-center justify-start gap-[inherit]">
                <PiPlusBold className="h-4 w-4" /> Add Task
              </span>
            </Button>
          )}
        </div>
      </CustomePageHeader>
      <WidgetCard rounded="lg" className="mt-2" title="">
        <div className="table_border_remove">
          <CustomTable
            data={(tasksData && tasksData?.activity) ?? []}
            total={(tasksData && tasksData?.page_count) ?? 1}
            loading={getAllMyTasksLoader ?? false}
            pageSize={pageSize}
            setPageSize={setPageSize}
            handleDeleteById={handleDeleteById}
            handleChangePage={handleChangePage}
            getColumns={GetColumns}
            scroll={{ x: 1100 }}
            filtersList={<MyTasksFilter />}
            reset={reset}
            setReset={setReset}
            ismyTask={true}
            setPeriod={setPeriod}
            setStartDate={setStartDate}
            setEndDate={setEndDate}
            isRangeFilter={true}
            resetValue={reset}
          />
        </div>
      </WidgetCard>
    </>
  );
}
