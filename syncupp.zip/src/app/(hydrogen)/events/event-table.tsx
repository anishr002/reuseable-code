"use client";
import { useDispatch, useSelector } from 'react-redux';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import CustomTable from '@/components/common-tables/table';
import { deleteTask } from '@/redux/slices/user/task/taskSlice';
import { getAllActivity, setPaginationDetails } from '@/redux/slices/user/activity/activitySlice';
import cn from '@/utils/class-names';
import { Button } from 'rizzui';
import { GetEventColumns } from '@/app/shared/(user)/events/events-list/columns';
import { getAllEvent, putCancelEvent } from '@/redux/slices/user/events/eventSlice';
import EventDatePeriodSelectionForm from '@/app/shared/(user)/forms/event-select-period-form';
import { DatePicker } from '@/components/ui/datepicker';
import moment from 'moment';


export default function EventTablePage(props: any) {


    const dispatch = useDispatch();
    const router = useRouter();
    const signIn = useSelector((state: any) => state?.root?.signIn)
    const clientSliceData = useSelector((state: any) => state?.root?.client);
    const { paginationParams } = useSelector((state: any) => state?.root?.activity);
    const eventSliceData = useSelector((state: any) => state?.root?.event);

    const [pageSize, setPageSize] = useState<number>(10);
    const [period, setPeriod] = useState('');
    const [startDate, setStartDate] = useState('');
    const [endDate, setEndDate] = useState('');
    const [reset, setReset] = useState('');
    const [startRangeDate, setStartRangeDate] = useState(null);
    const [endRangeDate, setEndRangeDate] = useState(null);

    // console.log("Activity is....", activityData?.activityName)
    // console.log("Activity is....", activityType)
    // console.log("Start date is....", startDate)
    // console.log("End date is....", endDate)

    useEffect(() => {
        setPeriod('');
        setStartDate('');
        setEndDate('');
        setStartRangeDate(null);
        setEndRangeDate(null);
    }, [clientSliceData?.agencyId]);

    useEffect(() => {
        if (period !== '' || startDate !== '' || endDate !== '') {
            setReset('')
        }
    }, [period, startDate, endDate]);

    const handleResetFilters = () => {
        setPeriod('');
        setStartDate('');
        setEndDate('');
        setStartRangeDate(null);
        setEndRangeDate(null);
        setReset('reset');

        if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
            dispatch(getAllEvent({ sort_field: 'createdAt', sort_order: 'desc', pagination: true }))
        } else {
            dispatch(getAllEvent({ sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, pagination: true }))
        }

    }


    const handleChangePage = async (paginationParams: any) => {
        let { page, items_per_page, sort_field, sort_order, search } = paginationParams;

        dispatch(setPaginationDetails({ ...paginationParams, filter: { date: period, start_date: startDate, end_date: endDate } }))

        const response = signIn?.role !== 'client' && signIn?.role !== 'team_client' ? await dispatch(getAllEvent({ page, items_per_page, sort_field, sort_order, search, filter: { date: period, start_date: startDate, end_date: endDate }, pagination: true })) : await dispatch(getAllEvent({ page, items_per_page, sort_field, sort_order, search, agency_id: clientSliceData?.agencyId, filter: { date: period, start_date: startDate, end_date: endDate }, pagination: true }));
        const { data } = response?.payload;
        const maxPage: number = data?.page_count;

        if (page > maxPage) {
            page = maxPage > 0 ? maxPage : 1;
            // await dispatch(getAllActivity({ page, items_per_page, sort_field, sort_order, search }));
            signIn?.role !== 'client' && signIn?.role !== 'team_client' ? await dispatch(getAllEvent({ page, items_per_page, sort_field, sort_order, search, filter: { date: period, start_date: startDate, end_date: endDate }, pagination: true })) : await dispatch(getAllEvent({ page, items_per_page, sort_field, sort_order, search, agency_id: clientSliceData?.agencyId, filter: { date: period, start_date: startDate, end_date: endDate }, pagination: true }));
            return data?.event
        }
        if (data && data?.event && data?.event?.length !== 0) {
            return data?.event
        }
    };

    const handleDeleteById = async (id: string | string[], currentPage?: any, countPerPage?: number, sortConfig?: Record<string, string>, searchTerm?: string) => {

        // console.log("delete id in main page....", id)

        try {
            const res = await dispatch(putCancelEvent({ eventId: id }))
            if (res.payload.success === true) {
                const reponse = signIn?.role !== 'client' && signIn?.role !== 'team_client' ? await dispatch(getAllEvent({ page: currentPage, items_per_page: countPerPage, sort_field: sortConfig?.key, sort_order: sortConfig?.direction, search: searchTerm, filter: { date: period, start_date: startDate, end_date: endDate }, pagination: true })) : await dispatch(getAllActivity({ page: currentPage, items_per_page: countPerPage, sort_field: sortConfig?.key, sort_order: sortConfig?.direction, search: searchTerm, agency_id: clientSliceData?.agencyId, filter: { date: period, start_date: startDate, end_date: endDate }, pagination: true }));
            }
        } catch (error) {
            console.error(error);
        }
    };

    const handleRangeChange = (dates: any) => {
        const [start, end] = dates;
        setStartRangeDate(start);
        setEndRangeDate(end);
        setStartDate(moment(start).format('DD-MM-YYYY'))
        !!end && setEndDate(moment(end).format('DD-MM-YYYY'))

        dispatch(setPaginationDetails({ ...paginationParams, page: 1, filter: { date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') } }))


        if (signIn?.role !== 'client' && signIn?.role !== 'team_client') {
            !!end && dispatch(getAllEvent({ page: 1, sort_field: 'createdAt', sort_order: 'desc', filter: { date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') }, pagination: true }))
        } else {
            !!end && dispatch(getAllEvent({ page: 1, sort_field: 'createdAt', sort_order: 'desc', agency_id: clientSliceData?.agencyId, filter: { date: 'period', start_date: moment(start).format('DD-MM-YYYY'), end_date: moment(end).format('DD-MM-YYYY') }, pagination: true }))
        }

        !!end && setPeriod('period')

    };


    const FilterList = () => {
        return (
            <>
                {/* <DatePeriodSelectionForm setStartDate={setStartDate} setEndDate={setEndDate} statusType={statusType} activityType={activityType} setPeriod={setPeriod} reset={reset} /> */}
                <DatePicker
                    selected={startRangeDate}
                    onChange={handleRangeChange}
                    startDate={startRangeDate}
                    endDate={endRangeDate}
                    // isClearable={true}
                    monthsShown={1}
                    placeholderText="Select Date in a Range"
                    className="w-full"
                    selectsRange
                />

                <Button
                    className={cn(
                        "w-full text-xs @lg:w-auto sm:text-sm lg:mt-0"
                    )}
                    onClick={handleResetFilters}
                >
                    Reset
                </Button>
            </>
        )
    }



    return (
        <>
            <div className='mt-8'>
                <CustomTable
                    data={(eventSliceData && eventSliceData?.data?.event) || []}
                    total={(eventSliceData && eventSliceData?.data?.page_count) || 1}
                    loading={eventSliceData && eventSliceData?.loading}
                    pageSize={pageSize}
                    setPageSize={setPageSize}
                    handleDeleteById={handleDeleteById}
                    handleChangePage={handleChangePage}
                    getColumns={GetEventColumns}
                    scroll={{ x: 1150 }}
                    filtersList={<FilterList />}
                />
            </div>
        </>
    );
}
