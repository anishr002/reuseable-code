
import { metaObject } from '@/config/site.config';
import EventMainPage from './main-page';

export const metadata = {
  ...metaObject('Events'),
};

export default function EventPage() {
  return (
    <>
      <EventMainPage />
    </>
  );
}
