import { googleLogout } from "@react-oauth/google";
import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export const Dashboard = () => {
  const navigate = useNavigate();
  const userDetails = JSON.parse(localStorage.getItem("user"));
  const token = localStorage.getItem("token");

  const getFirstLetters = (...args) => {
    let result = "";
    for (const str of args) {
      if (typeof str === "string" && str.length > 0) {
        result += str.charAt(0);
      }
    }
    return result.toUpperCase();
  };

  useEffect(() => {
    if (!token) navigate("/signin");
  }, []);

  const logoutUser = () => {
    localStorage.clear();
    googleLogout();
    navigate("/signin");
  };

  return (
    <>
      <div className="border rounded-lg p-4">
        <div class="inline-flex items-center justify-center w-20 h-20 overflow-hidden bg-gray-100 rounded-full dark:bg-gray-600">
          <span class="font-medium text-gray-600 dark:text-gray-300">
            {getFirstLetters(userDetails?.first_name, userDetails?.last_name)}
          </span>
        </div>
        <div>
          Welcome, {userDetails?.first_name} {userDetails?.last_name}
        </div>
        <div>Email: {userDetails?.email};</div>
        <div>
          <button onClick={logoutUser}>Logout</button>
        </div>
      </div>
    </>
  );
};
