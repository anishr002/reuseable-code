module.exports = {
  extends: ['airbnb', 'prettier'],
  plugins: ['prettier'],
  globals: {
    localStorage: 'readonly',
    window: 'readonly',
    document: 'readonly',
  },
  rules: {
    'prettier/prettier': [
      'error',
      {
        endOfLine: 'auto',
      },
    ],
    'react/function-component-definition': [
      'error',
      {
        namedComponents: 'function-declaration',
        unnamedComponents: 'function-expression',
      },
    ],
    'react/jsx-filename-extension': [
      1,
      {
        extensions: ['.js', '.jsx'],
      },
    ],
    'default-param-last': 0,
    'no-multi-spaces': ['error'],
    'no-console': 'off',
  },
};
