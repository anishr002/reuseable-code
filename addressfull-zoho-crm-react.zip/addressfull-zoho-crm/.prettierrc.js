module.exports = {
    singleQuote: true,
    trailingComma: 'all',
    overrides: [
        {
            files: ['*.js', '*.jsx'],
            options: {
                printWidth: 120,
            },
        },
    ],
};
