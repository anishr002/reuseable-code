import { X } from 'react-feather';
import toast from 'react-hot-toast';

const CustomToast = ({ message, type }) => {
  return (
    <div className="d-flex justify-content-center align-items-center">
      <div className="me-2">{message}</div>
      <X className="cursor-pointer" onClick={() => toast?.dismiss()} />
    </div>
  );
};
const successCss = () => {
  return {
    duration: 10000, // 5 minutes in milliseconds
    position: 'top-center',
    className: '',
    style: {
      minWidth: 'fit-content',
      background: '#e5f8ed',
      color: '#00B000',
    },
  };
};
const errorCss = () => {
  return {
    duration: 10000, // 5 minutes in milliseconds
    position: 'top-center',
    className: 'text-danger',
    style: {
      minWidth: 'fit-content',
      background: '#fceaea',
      fontColor: 'red',
    },
  };
};
export { successCss as SuccessCss, errorCss as ErrorCss };
export default CustomToast;
