import { createContext, useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { io } from 'socket.io-client';
export const SocketContext = createContext();

export const SocketContextProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isSocketConnected, setIsConnected] = useState(null);
  const user_token = localStorage.getItem('accessToken');
  const { UserData } = useSelector((state) => state.root?.authentication);
  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);

  useEffect(() => {
    setSocket(
      io(`wss://${import.meta.env.VITE_APP_SOCKET_URL}`, {
        autoConnect: true,
        // transports: ['websocket'],
        auth: {
          token: user_token,
        },
      }),
    );
  }, []);

  useEffect(() => {
    if (
      socket !== null &&
      socket !== undefined &&
      user_token &&
      (UserData?.role === 'super-admin' || UserData?.role === 'organization-admin')
    ) {
      function onConnect() {
        setIsConnected(true);
        // console.log(socket, 'socket');
        // console.log('Server Connected');
        {
          user_token && socket?.emit('joinRoom', UserData?.role === 'organization-admin' ? profileData?.user_id : 1);
        }
      }

      function onDisconnect() {
        setIsConnected(false);
        // console.log('Server Disconnected', 3333);
      }

      socket?.on('connect', onConnect);
      socket?.on('disconnect', onDisconnect);

      return () => {
        socket?.off('connect', onConnect);
        socket?.off('disconnect', onDisconnect);
      };
    }
  }, [socket]);

  return (
    <>
      <SocketContext.Provider value={{ socket, isSocketConnected }}>{children}</SocketContext.Provider>
    </>
  );
};
