import { Buffer } from 'buffer';
import CryptoJS from 'crypto-js';
import moment from 'moment-timezone';
import forge from 'node-forge';
import React from 'react';
import toast from 'react-hot-toast';
import * as XLSX from 'xlsx';
import { findFirstExistingSection } from '../router/routes';
import CustomToast, { ErrorCss } from './toast/CustomToast';
import { store } from '../redux/store';

export const checkErrorEnc = () => {
  localStorage.clear();
  const resetStore = async () => {
    store.dispatch({ type: 'RESET' });
  };
  resetStore();
  localStorage.setItem('flag', 'ok');
  window.location.href = `/`;
  window.location.reload(false);
};

export const decryptData = (privateKeyPem, dataaa) => {
  try {
    const dataArray = dataaa?.split('|');
    const Skey = dataArray[1];
    const ivKey = dataArray[2];
    const data = dataArray[0];

    const sBuffer = Buffer.from(Skey, 'base64');
    const ivBuffer = Buffer.from(ivKey, 'base64');

    const privateKey = forge.pki.privateKeyFromPem(privateKeyPem);

    const decryptedSymmetrickey = privateKey.decrypt(sBuffer, 'RSAES-PKCS1-V1_5');
    const decryptedIvKey = privateKey.decrypt(ivBuffer, 'RSAES-PKCS1-V1_5');

    const symmetricKeyFinal = decryptedSymmetrickey.toString('base64');
    const ivKeyFinal = decryptedIvKey.toString('base64');

    const key = CryptoJS.enc.Base64.parse(symmetricKeyFinal);
    const iv = CryptoJS.enc.Base64.parse(ivKeyFinal);

    const decryptedText = CryptoJS.AES.decrypt(data, key, {
      iv,
    }).toString(CryptoJS.enc.Utf8);

    const userobj = JSON.parse(decryptedText);
    // console.log(userobj, 'objj');
    return userobj;
  } catch (error) {
    if (localStorage?.getItem('accessToken')) {
      checkErrorEnc();
    }
  }
};
export const encryptData = (Key, data) => {
  // Generate a random symmetric key (256 bits) and IV (128 bits)
  const symmetricKey = forge.random.getBytesSync(32); // 256 bits
  const iv = forge.random.getBytesSync(16); // 128 bits

  // Convert the object to a string
  const obj = data;
  // console.log('###$%^&^$%', obj);
  const jsonString = JSON.stringify(obj);
  // console.log(obj);
  // Encrypt the data using AES with the symmetric key and IV
  const cipher = forge.cipher.createCipher('AES-CBC', forge.util.createBuffer(symmetricKey));
  cipher.start({ iv: forge.util.createBuffer(iv) });
  cipher.update(forge.util.createBuffer(jsonString));
  cipher.finish();

  const encryptedData = cipher.output.getBytes();

  // Convert the binary string to a Base64-encoded string
  const encryptedDataBase64 = forge.util.encode64(encryptedData);

  // console.log('Symmetric Key:', forge.util.encode64(symmetricKey));
  // console.log('IV:', forge.util.encode64(iv));
  // console.log('Encrypted Data (Base64):', encryptedDataBase64);

  const encryptSymmetricKeyWithRSA = (symmetricKey, publicKeyPem) => {
    try {
      // Sanitize the public key according to the format
      const publicKeya = publicKeyPem.replace(/\|/g, '');
      const publicKey = forge.pki.publicKeyFromPem(publicKeya);

      // Encrypt the symmetric key with RSA
      const encryptedSymmetricKey = publicKey.encrypt(forge.util.createBuffer(symmetricKey));

      // Convert the encrypted key to base64
      const encryptedSymmetricKeyBase64 = forge.util.encode64(encryptedSymmetricKey);

      return encryptedSymmetricKeyBase64;
    } catch (error) {
      console.error(`Error encrypting symmetric key: ${error.message}`);
      return null;
    }
  };

  const encryptIVWithRSA = (symmetricKey, publicKeyPem) => {
    try {
      // Sanitize the public key according to the format
      const publicKeya = publicKeyPem.replace(/\|/g, '');
      const publicKey = forge.pki.publicKeyFromPem(publicKeya);

      // Encrypt the symmetric key with RSA
      const encryptedSymmetricKey = publicKey.encrypt(forge.util.createBuffer(symmetricKey));

      // Convert the encrypted key to base64
      const encryptedSymmetricKeyBase64 = forge.util.encode64(encryptedSymmetricKey);

      return encryptedSymmetricKeyBase64;
    } catch (error) {
      console.error(`Error encrypting symmetric key: ${error.message}`);
      return null;
    }
  };

  // Example usage:
  const symmetricKeys = forge.util.encode64(symmetricKey);
  const IVKeys = forge.util.encode64(iv);

  const encryptedKey = encryptSymmetricKeyWithRSA(symmetricKeys, Key);

  const IVENCRYPT = encryptIVWithRSA(IVKeys, Key);
  // console.log('Encrypted Symmetric Keyde:', `${encryptedDataBase64}|${encryptedKey}|${IVENCRYPT}`);

  return `${encryptedDataBase64}|${encryptedKey}|${IVENCRYPT}`;
};

export const generateKeyPair = () => {
  const keyPair = forge.pki.rsa.generateKeyPair({ bits: 1024, e: 0x10001 });

  // Get the public key in PEM format
  const publicKeyPem = forge.pki.publicKeyToPem(keyPair.publicKey);
  const formattedPublicKeyPem = publicKeyPem.replace(/[\r\n]+/g, '|').replace(/\|$/, '');

  // Get the private key in PEM format
  const privateKeyPem = forge.pki.privateKeyToPem(keyPair.privateKey);

  // console.log('Private Key (PEM format):', privateKeyPem);
  // console.log('Public Key (PEM format):', publicKeyPem);
  // console.log('Public Key (PEM format):', formattedPublicKeyPem);

  return { privateKeyPem, formattedPublicKeyPem, publicKeyPem };
};

export const convertExcelToJson = (file) => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(sheet, { header: 1 });
      resolve(jsonData);
    };
    reader.onerror = (error) => {
      reject(error);
    };
    reader.readAsArrayBuffer(file);
  });
};

// ** Checks if an object is empty (returns boolean)
export const isObjEmpty = (obj) => Object.keys(obj).length === 0;

// ** Returns K format from a number
export const kFormatter = (num) => (num > 999 ? `${(num / 1000).toFixed(1)}k` : num);

// ** Converts HTML to string
export const htmlToString = (html) => html.replace(/<\/?[^>]+(>|$)/g, '');

// ** Checks if the passed date is today
const isToday = (date) => {
  const today = new Date();
  return (
    /* eslint-disable operator-linebreak */
    date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear()
    /* eslint-enable */
  );
};

/**
 ** Format and return date in Humanize format
 ** Intl docs: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat/format
 ** Intl Constructor: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/DateTimeFormat/DateTimeFormat
 * @param {String} value date to format
 * @param {Object} formatting Intl object to format with
 */
export const formatDate = (value, formatting = { month: 'short', day: 'numeric', year: 'numeric' }) => {
  if (!value) {
    return value;
  }
  return new Intl.DateTimeFormat('en-US', formatting).format(new Date(value));
};

// ** Returns short month of passed date
export const formatDateToMonthShort = (value, toTimeForCurrentDay = true) => {
  const date = new Date(value);
  let formatting = { month: 'short', day: 'numeric' };

  if (toTimeForCurrentDay && isToday(date)) {
    formatting = { hour: 'numeric', minute: 'numeric' };
  }

  return new Intl.DateTimeFormat('en-US', formatting).format(new Date(value));
};

/**
 ** Return if user is logged in
 ** This is completely up to you and how you want to store the token in your frontend application
 *  ? e.g. If you are using cookies to store the application please update this function
 */
export const isUserLoggedIn = () => localStorage.getItem('userData');
export const getUserData = () => JSON.parse(localStorage.getItem('userData'));

/**
 ** This function is used for demo purpose route navigation
 ** In real app you won't need this function because your app will navigate to same route for each users regardless of ability
 ** Please note role field is just for showing purpose it's not used by anything in frontend
 ** We are checking role just for ease
 * ? NOTE: If you have different pages to navigate based on user ability then this function can be useful. However, you need to update it.
 * @param {String} userRole Role of user
 */
export const getHomeRouteForLoggedInUser = (userRole, route, userData) => {
  return `/${findFirstExistingSection(userData)}`;
};

// ** React Select Theme Colors
export const selectThemeColors = (theme) => ({
  ...theme,
  colors: {
    ...theme.colors,
    primary25: '#7367f01a', // for option hover bg-color
    primary: '#7367f0', // for selected option bg-color
    neutral10: '#00B000', // for tags bg-color
    neutral20: '#ededed', // for input border-color
    neutral30: '#ededed', // for input hover border-color
  },
});

export const rolesArrSuperAdmin = [
  {
    name: 'dashboard',
    title: 'Dashboard',
  },
  {
    name: 'admins',
    title: 'Admin Management',
  },
  {
    name: 'requests',
    title: 'Requests',
  },
  {
    name: 'roles',
    title: 'Role Management',
  },
  {
    name: 'organizations',
    title: 'Organization Management',
  },

  {
    name: 'settings',
    title: 'Settings',
  },
];

export const rolesArrOrganization = [
  {
    name: 'dashboard',
    title: 'Dashboard',
  },
  {
    name: 'users',
    title: 'Users',
  },
  {
    name: 'admins',
    title: 'Admin Management',
  },
  {
    name: 'requests',
    title: 'Requests',
  },
  {
    name: 'roles',
    title: 'Role Management',
  },
  {
    name: 'transactions',
    title: 'Transactions',
  },
  {
    name: 'settings',
    title: 'Settings',
  },
];

export const customStyles = {
  headRow: {
    style: {
      backgroundColor: 'whitesmoke !important', // Set your desired background color here
      color: '#4C4C4C', // Set the text color
      fontWeight: 'bold',
      height: '38px',
      minHeight: '38px',
    },
  },
};

export const onSetLogo = (e, setImageObj, setAvatar) => {
  const reader = new FileReader();
  const files = e.target.files;

  // Check if a file is selected
  if (files.length > 0) {
    const file = files[0];

    // Check if the file size is within the allowed limit (2 MB)
    if (file.size <= 100 * 1024) {
      // setImageObj(reader.result);

      reader.onload = function () {
        setAvatar(reader.result);
        setImageObj(reader.result);
      };

      reader.readAsDataURL(file);
    } else {
      // Handle the case when the file size exceeds the limit
      toast(
        <CustomToast
          message={'File size exceeds the allowed limit (100 KB). Please select a smaller file.'}
          type={'error'}
        />,
        ErrorCss(),
      );
      // You can also clear the input value to allow the user to select a different file
      e.target.value = null;
    }
  }
};
export const reduceImageSize = async (file, MAX_WIDTH = 256, MAX_HEIGHT = 144) => {
  return new Promise((resolve) => {
    const img = new Image();
    const reader = new FileReader();

    reader.onload = function (e) {
      img.src = e.target.result;

      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        // Convert the canvas content to a Blob
        canvas.toBlob((blob) => {
          // Create a File object from the Blob
          const resizedFile = new File([blob], file.name, { type: file.type });

          // Resolve with the resized File object
          resolve(resizedFile);
        }, file.type);
      };
    };

    // Read the content of the input file
    reader.readAsDataURL(file);
  });
};

export const maskString = ({ str = '', mask = '...', startIndex = 0, endIndex = 3 } = {}) =>
  str.substring(startIndex, endIndex).concat(mask);

export const isValidData = (data) => {
  switch (typeof data) {
    case 'string':
      return !!data && ![',', 'null', 'undefined'].includes(data);
    case 'object':
      return data && (Array.isArray(data) ? data.length && data.length > 0 : Object.keys(data).length > 0);
    default:
      return !!data;
  }
};

export const convertToTimeZone = (requestDate, timezones) => {
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  const findOffset = moment().tz(timeZone).utcOffset();
  const defaultZone = `(UTC ${findOffset}) ${timeZone}`;
  let zone;
  zone = timezones;
  const date = moment(new Date(requestDate));
  if (['null', null, 'undefined', undefined, ''].includes(zone)) {
    zone = defaultZone;
  }
  return date.tz(zone.substring(zone.lastIndexOf(' ') + 1)).format('DD/MM/YYYY');
};

export const downloadDemoFile = () => {
  const fileURL = 'https://addressfull-uat-filesystem.s3.eu-west-2.amazonaws.com/AddressFull%2BSample%2BFile+(7).xlsx';
  window.open(fileURL, '_blank');
};
