// ** React Imports
import { lazy } from 'react';
import AddEditCrm from '../../pages/Settings/AddEditCrm';
import PrivacyPolicy from '../../pages/Settings/PrivacyPolicy/PrivacyPolicy';
import AddEditPolicy from '../../pages/Settings/PrivacyPolicy/AddEditPolicy';

const General = lazy(() => import('../../pages/Settings/General/General'));
const Crmntegration = lazy(() => import('../../pages/Settings/Crmntegration'));

// ** Merge Routes
const SettingsRoutes = [
  {
    path: 'settings/general_settings',
    element: <General />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'general_settings',
  },
  {
    path: 'settings/privacy_policy_settings',
    element: <PrivacyPolicy />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'privacy_policy_settings',
  },
  {
    path: 'settings/privacy_policy_settings/:id',
    element: <AddEditPolicy />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'privacy_policy_settings',
  },
  {
    path: 'settings/privacy_policy_settings/add-policy',
    element: <AddEditPolicy />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'privacy_policy_settings',
  },
  {
    path: 'settings/crm_settings',
    element: <Crmntegration />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'crm_settings',
  },

  {
    path: 'settings/crm_settings/add-crm',
    element: <AddEditCrm />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'crm_settings',
  },
  {
    path: 'settings/crm_settings/edit-crm/:id',
    element: <AddEditCrm />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'crm_settings',
  },
];

export default SettingsRoutes;
