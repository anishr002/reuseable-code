import { lazy } from 'react';

const ZohoConfiguration = lazy(() => import('@src/pages/Zoho/ZohoConfiguration'));
const ZohoCallback = lazy(() => import('@src/pages/Zoho/ZohoCallback'));

const ZohoRoutes = [
  {
    path: '/zoho-configration',
    element: <ZohoConfiguration />,
    meta: { publicRoute: true, layout: 'blank' },
    id: 'ZohoPublic',
  },
  {
    path: '/zoho-callback',
    element: <ZohoCallback />,
    meta: { publicRoute: true, layout: 'blank' },
    id: 'ZohoPublic',
  },
];

export default ZohoRoutes;
