// ** React Imports
import { Fragment } from 'react';
// ** Layouts
import BlankLayout from '@layouts/BlankLayout';
import LayoutWrapper from '@src/@core/layouts/components/layout-wrapper';
import VerticalLayout from '@src/layouts/VerticalLayout';

// ** Route Components
import PrivateRoute from '@components/routes/PrivateRoute';
import PublicRoute from '@components/routes/PublicRoute';

// ** Utils
import { isObjEmpty } from '@utils';
import AdminsStaffManagment from './AdminsStaffManagment';
import DashboardRoutes from './Dashboard';
import OrganizationManagmentRoutes from './OrganizationManagment';
import OrganizationUsersRoutes from './OrganizationUsers';
import SettingsRoutes from './Settings';
import TransactionsRoutes from './Transactions';
import ZohoRoutes from './Zoho';

const getLayout = {
  blank: <BlankLayout />,
  vertical: <VerticalLayout />,
};

// ** Document title
const TemplateTitle = '%s - Vuexy React Admin Template';

// ** Default Route
const findFirstExistingSection = (userData) => {
  const PermissionArray = userData?.permissions;

  const sectionOrder = [
    'dashboard',
    'users',
    'roles',
    'admins',
    'transactions',
    'organizations',
    'requests',
    'settings',
    'profile',
  ];

  for (const sectionName of sectionOrder) {
    const foundSection = [
      ...PermissionArray,
      {
        permissions: {
          read: true,
          write: true,
        },
        section: 'profile',
      },
    ]?.find((item) => item.section === sectionName);

    if (foundSection?.permissions?.read) {
      // console.log('######@32', foundSection);
      switch (sectionName) {
        case 'dashboard':
          return `dashboard`;
        case 'roles':
          return `admin/role`;
        case 'users':
          return `organization-users`;
        case 'admins':
          return `admin/listing`;
        case 'organizations':
          return `organization-managment`;
        case 'block_organizations':
          return `block_organizations`;
        case 'requests':
          return `requests`;
        case 'crm_settings':
          return 'settings/crm_settings';
        case 'general_settings':
          return `settings/general_settings`;
        case 'privacy_policy_settings':
          return `settings/privacy_policy_settings`;
        case 'transactions':
          return `transactions`;
        case 'profile':
          return `profile`;
        default:
          return `login`;
      }
    }
  }
  // Return the login path
  return `/login`;
};
const DefaultRoute = '/dashboard';

// ** Merge Routes
const Routes = [
  ...DashboardRoutes,
  ...AdminsStaffManagment,
  ...OrganizationUsersRoutes,
  ...TransactionsRoutes,
  ...SettingsRoutes,
  ...OrganizationManagmentRoutes,
  ...ZohoRoutes,
];

const getRouteMeta = (route) => {
  if (isObjEmpty(route.element.props)) {
    if (route.meta) {
      return { routeMeta: route.meta };
    } else {
      return {};
    }
  }
};

const mergeLayoutRoutes = (layout, defaultLayout, userData) => {
  const LayoutRoutes = [];

  if (Routes) {
    Routes?.forEach((route) => {
      const sectionExists = userData?.permissions?.filter((item) => item.section === route.id);
      let isBlank = false;

      const routeAdd = () => {
        let RouteTag = PrivateRoute;
        // ** Check for public or private route
        if (route.meta) {
          route.meta.layout === 'blank' ? (isBlank = true) : (isBlank = false);
          RouteTag = route.meta.publicRoute ? PublicRoute : PrivateRoute;
        }
        if (route.element) {
          const Wrapper = isObjEmpty(route.element.props) && isBlank === false ? LayoutWrapper : Fragment;

          route.element = (
            <Wrapper {...(isBlank === false ? getRouteMeta(route) : {})}>
              <RouteTag route={route}>{route.element}</RouteTag>
            </Wrapper>
          );
        }
        // Push route to LayoutRoutes
        LayoutRoutes.push(route);
      };

      // Allow public routes to bypass permission checks
      if (
        route?.meta?.publicRoute &&
        ((route?.meta.layout && route.meta.layout === layout) ||
          ((route.meta === undefined || route.meta.layout === undefined) && defaultLayout === layout))
      ) {
        routeAdd();
        return;
      }

      if (sectionExists?.[0]?.permissions?.read) {
        if (
          (route?.meta.layout && route.meta.layout === layout) ||
          ((route.meta === undefined || route.meta.layout === undefined) && defaultLayout === layout)
        ) {
          if (sectionExists?.length !== 0) {
            if (sectionExists[0]?.permissions?.read) {
              routeAdd();
            }
          }
        }
      } else {
        const routePermission = route?.id;

        // console.log('######23RUTE ID', routePermission);

        if (
          (sectionExists?.length === 0 && routePermission === 'Profile') ||
          (sectionExists?.length === 0 && routePermission === 'Notifications') ||
          (sectionExists?.length === 0 && routePermission === 'Totalcounts')
        ) {
          routeAdd();
        }
      }
    });
  }
  return LayoutRoutes;
};

const getRoutes = (layout, userData) => {
  const defaultLayout = layout || 'vertical';
  const layouts = ['vertical', 'blank'];

  const AllRoutes = [];

  layouts.forEach((layoutItem) => {
    const LayoutRoutes = mergeLayoutRoutes(layoutItem, defaultLayout, userData);

    AllRoutes.push({
      path: '',
      element: getLayout[layoutItem] || getLayout[defaultLayout],
      children: LayoutRoutes,
    });
  });
  return AllRoutes;
};

export { DefaultRoute, findFirstExistingSection, getRoutes, Routes, TemplateTitle };
