// ** React Imports
import UserProfile from '../../pages/OrganizationUsers/UserProfile';
import UsersListing from '../../pages/OrganizationUsers';
import Request from '../../pages/OrganizationUsers/Request';

// ** Merge Routes
const OrganizationUsersRoutes = [
  {
    path: 'organization-users',
    element: <UsersListing />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'users',
  },
  {
    path: 'organization-users/user-profile',
    element: <UserProfile />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'users',
  },

  {
    path: 'organization-users/:id',
    element: <Request />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'users',
  },
];

export default OrganizationUsersRoutes;
