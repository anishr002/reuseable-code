// ** React Imports
import { lazy } from 'react';

const AdminStaffRole = lazy(() => import('../../pages/AdminStaffManagment/AdminRole/Role'));
const AdminStaffListing = lazy(() => import('../../pages/AdminStaffManagment/AdminStaff/AdminStaffListing'));
const AdminStaffAddEdit = lazy(() => import('../../pages/AdminStaffManagment/AdminStaff/AddEdit'));
const AdminStaffChangePassword = lazy(() => import('../../pages/AdminStaffManagment/AdminStaff/AdminChPassword'));
const AdminStaffRoleAddEdit = lazy(() => import('../../pages/AdminStaffManagment/AdminRole/AddEdit'));

// ** Merge Routes
const AdminsStaffManagment = [
  {
    path: 'admin/role',
    element: <AdminStaffRole />,
    meta: {
      className: 'dashboard-org-admin',
    },
    id: 'roles',
  },
  {
    path: 'admin/role/add',
    element: <AdminStaffRoleAddEdit />,
    meta: {
      className: 'dashboard-org-admin',
    },
    id: 'roles',
  },
  {
    path: 'admin/role/edit/:id',
    element: <AdminStaffRoleAddEdit />,
    meta: {
      className: 'dashboard-org-admin',
    },
    id: 'roles',
  },
  {
    path: 'admin/listing',
    element: <AdminStaffListing />,
    meta: {
      className: 'dashboard-org-admin',
    },
    id: 'admins',
  },
  {
    path: 'admin/listing/add',
    element: <AdminStaffAddEdit />,
    meta: {
      className: 'dashboard-org-admin',
    },
    id: 'admins',
  },
  {
    path: 'admin/listing/edit/:id',
    element: <AdminStaffAddEdit />,
    meta: {
      className: 'dashboard-org-admin',
    },
    id: 'admins',
  },
  {
    path: 'admin/listing/change-password/:id',
    element: <AdminStaffChangePassword />,
    meta: {
      className: 'dashboard-org-admin',
    },
    id: 'admins',
  },
];

export default AdminsStaffManagment;
