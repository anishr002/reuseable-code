// ** React Imports
import Transactions from '../../pages/Transactions';

const TransactionsRoutes = [
  {
    path: 'transactions',
    element: <Transactions />,
    meta: {
      className: 'transactions',
    },
    id: 'transactions',
  },
];

export default TransactionsRoutes;
