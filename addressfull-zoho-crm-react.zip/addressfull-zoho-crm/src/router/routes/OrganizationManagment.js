// ** React Imports
import OrganizationManagmentTab from '../../pages/OrganizationManagment/AddEdit';
import BlockOrganization from '../../pages/OrganizationManagment/BlockOrg';
import OrganizationManagment from '../../pages/OrganizationManagment/index';
import BulkMessageLog from '../../pages/OrganizationManagment/MessageLog';

// ** Merge Routes
const OrganizationManagmentRoutes = [
  {
    path: 'organization-managment',
    element: <OrganizationManagment />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'organizations',
  },
  {
    path: 'block_organizations',
    element: <BlockOrganization />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'block_organizations',
  },
  {
    path: 'organization-managment/add',
    element: <OrganizationManagmentTab />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'organizations',
  },

  {
    path: 'organization-managment/edit/:id',
    element: <OrganizationManagmentTab />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'organizations',
  },

  {
    path: 'message_logs',
    element: <BulkMessageLog />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'message_logs',
  },
];

export default OrganizationManagmentRoutes;
