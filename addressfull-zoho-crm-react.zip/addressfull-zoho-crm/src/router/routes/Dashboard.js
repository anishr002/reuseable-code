// ** React Imports
import { lazy } from 'react';
import Profile from '../../pages/Profile';
import TotalCounts from '../../pages/Dashboard/TotalCounts';
const Dashboard = lazy(() => import('../../pages/Dashboard/index'));
const Notifications = lazy(() => import('../../pages/Notifications'));

// ** Merge Routes
const DashboardRoutes = [
  {
    path: 'dashboard',
    element: <Dashboard />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'dashboard',
  },
  {
    path: 'notifications',
    element: <Notifications />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'Notifications',
  },
  {
    path: 'profile',
    element: <Profile />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'Profile',
  },

  {
    path: 'totalcounts',
    element: <TotalCounts />,
    meta: {
      className: 'dashboard-aplication',
    },
    id: 'Totalcounts',
  },
];

export default DashboardRoutes;
