import { lazy } from 'react';

// ** Router imports
import { Navigate, useRoutes } from 'react-router-dom';

// ** Layouts
import BlankLayout from '@layouts/BlankLayout';

// ** Hooks Imports
import { useLayout } from '@hooks/useLayout';

// ** Utils
import { useSelector } from 'react-redux';
import Confirmation from '../pages/Auth/Confirmation';
import { getHomeRouteForLoggedInUser } from '../utility/Utils';
import { getRoutes } from './routes/index';

import LinkExpired from '../pages/Auth/LinkExpire';
import PdfGenerate from '../pages/error/PdfGenerater/PdfGenerate';

// ** Components
const Login = lazy(() => import('../pages/Auth/Login'));
const Register = lazy(() => import('../pages/Auth/Register'));
const ForgotPassword = lazy(() => import('../pages/Auth/ForgotPassword'));
const ChangePassword = lazy(() => import('../pages/Auth/ChangePassword'));
const VerifyOTP = lazy(() => import('../pages/Auth/VerifyOTP'));
const ErrorComponent = lazy(() => import('../pages/error/Error'));
const NotAuthorized = lazy(() => import('../pages/error/NotAuthorized'));

const MainRouter = (props) => {
  const { UserData, AdminRoute } = useSelector((state) => state.root?.authentication);

  // ** Hooks for layout
  const { layout } = useLayout();

  const allRoutes = getRoutes(layout, UserData);

  const checkDefaultSubRoute = () => {
    return '/login';
  };

  const getHomeRoute = () => {
    // const user = UserData?.token;
    const user = localStorage.getItem('accessToken');
    if (user) {
      return getHomeRouteForLoggedInUser(user, AdminRoute, UserData);
    } else {
      return checkDefaultSubRoute();
    }
  };

  function areAllPermissionsFalse(data) {
    return data?.every((item) => !item?.permissions?.read && !item?.permissions?.write);
  }
  const getErrorElemnet = () => {
    const user = localStorage.getItem('accessToken');
    const checkAllpermission = areAllPermissionsFalse(UserData?.permissions);

    if (user) {
      return checkAllpermission ? (
        <Navigate to={getHomeRouteForLoggedInUser(user, AdminRoute, UserData)} />
      ) : (
        <ErrorComponent />
      );
    } else {
      return <Navigate to={checkDefaultSubRoute()} />;
    }
  };

  const routesArray = [
    {
      path: '/',
      index: true,
      element: <Navigate replace to={getHomeRoute()} />,
    },
    {
      path: 'login',
      element: <Login />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: 'email-verified',
      element: <Confirmation />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: 'link-expired',
      element: <LinkExpired />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: 'forgot-password',
      element: <ForgotPassword />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: 'change-password',
      element: <ChangePassword />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: 'set-password',
      element: <ChangePassword />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: 'otp-verification',
      element: <VerifyOTP />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: 'register',
      element: <Register />,
      meta: {
        layout: 'blank',
      },
    },
    {
      path: '/auth/not-auth',
      element: <BlankLayout />,
      children: [{ path: '/auth/not-auth', element: <NotAuthorized /> }],
    },
    {
      path: '/routes/pdf-generate',
      element: <BlankLayout />,
      children: [{ path: '/routes/pdf-generate', element: <PdfGenerate /> }],
    },
    {
      path: '*',
      element: <BlankLayout />,
      children: [{ path: '*', element: getErrorElemnet() }],
    },
    ...allRoutes,
  ];

  const routes = useRoutes(routesArray);

  return routes;
};

export default MainRouter;
