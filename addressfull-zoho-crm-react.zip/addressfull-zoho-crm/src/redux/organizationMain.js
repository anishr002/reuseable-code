// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss, SuccessCss } from '../utility/toast/CustomToast';
import { encryptData, decryptData, isObjEmpty } from '../utility/Utils';
import { handleLogin } from './authentication';
import { editProfile, loadingFlag } from './mainLoading';

export const OrganizationSlice = createSlice({
  name: 'OrganizationMain',
  initialState: {
    soket: {},
    rowsPerPagesData: '10',
    OrganizationDetailes: {
      profileData: {},
      ProfileTab: '1',
      encd_pair: '',
      paginationDefaultList: {
        page: 1,
        page_size: 10,
        order_by: 'desc',
        sort_by: 'created_at',
      },
    },
    NotificationData: {},
  },
  reducers: {
    handleGetProfile: (state, action) => {
      state.OrganizationDetailes = {
        ...state.OrganizationDetailes,
        profileData: action.payload,
      };
    },
    handleEditProfile: (state, action) => {
      state.OrganizationDetailes = {
        ...state?.OrganizationDetailes,
        profileData: action.payload,
      };
    },
    handleGetNotification: (state, action) => {
      state.NotificationData = { ...action.payload };
    },

    handlesetRowsPerPageForNotification: (state, action) => {
      state.rowsPerPagesData = action.payload;
    },

    setPaginationList: (state, action) => {
      state.TransactionData = { ...state.TransactionData, paginationDefaultList: action.payload };
    },
    setProfileManTab: (state, action) => {
      state.OrganizationDetailes = {
        ...state?.OrganizationDetailes,
        ProfileTab: action.payload,
      };
    },
    setEncdPair: (state, action) => {
      state.OrganizationDetailes = {
        ...state?.OrganizationDetailes,
        encd_pair: action.payload,
      };
    },
    setSokectData: (state, action) => {
      state.soket = action.payload;
    },
  },
});

export const {
  handleGetProfile,
  handleEditProfile,
  handleGetNotification,
  setProfileManTab,
  setSokectData,
  handlesetRowsPerPageForNotification,
  setPaginationList,
  setEncdPair,
} = OrganizationSlice.actions;

export const getProfileAPI = () => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));

    await axios.get('users/profile').then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      isObjEmpty(resultData?.data) && dispatch(editProfile(true));
      dispatch(handleGetProfile(resultData?.data));

      resultData?.data?.permissions && dispatch(handleLogin({ permissions: resultData?.data?.permissions }));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editProfileAPI = (data) => async (dispatch, getState) => {
  const formData = new FormData();
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  // if (typeof data?.imageObj !== 'string') {
  //   formData.append('profile_picture', data?.imageObj === null ? '' : await reduceImageSize(data?.imageObj));
  // }

  function isURL(str) {
    const urlRegex = /^(?:ftp|http|https):\/\/(?:\w+:{0,1}\w*@)?(?:\S+)(:[0-9]+)?(?:\/|\/(?:[\w#!:.?+=&%@!\-\/]))?$/;
    return urlRegex.test(str);
  }

  const xyz = { ...data };

  if (!isURL(data?.imageObj)) {
    xyz.profile_picture = data?.imageObj;
  }
  delete xyz?.imageObj;

  for (const [key, value] of Object.entries(data)) {
    // If the value is an array, iterate over it and append each value
    if (Array.isArray(value)) {
      value.forEach((item, index) => {
        formData.append(`${key}[${index}]`, item);
      });
    } else {
      // If the value is not an array, append it directly
      formData.append(key, value);
    }
  }

  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, xyz);

    // dispatch(handleEditProfile(data));
    await axios.post('users/profile', `${Encryption}|20$`, { contentType: 'application/base64' }).then((response) => {
      // dispatch(handleEditProfile(response.data?.data));
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(handleGetProfile({}));
      dispatch(getProfileAPI());
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }

    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getNotificationAPI = (page, pageSize, IS_READ) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    // debugger;

    const token = localStorage.getItem('accessToken');

    await axios
      .get(`notifications`, {
        params:
          IS_READ !== undefined
            ? {
                page,
                page_size: pageSize,
                is_read: IS_READ,
              }
            : {
                page,
                page_size: pageSize,
              },
        headers: {
          Authorization: `Bearer ${token}`,
          // Other headers if needed
        },
      })
      .then((response) => {
        const resultData = decryptData(privateSecureKey, response?.data);

        if (IS_READ !== undefined) {
          IS_READ === 0 && dispatch(setSokectData(resultData?.data));
        } else {
          dispatch(handleGetNotification(resultData?.data));
          dispatch(handlesetRowsPerPageForNotification(pageSize));
        }
      });
  } catch (error) {
    console.error('###', error);
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const readNotificationAPI = () => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));

    await axios.get(`notifications/read-all`).then((response) => {
      dispatch(getNotificationAPI(1, 5, 0));
    });
  } catch (error) {
    console.error('###', error);
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default OrganizationSlice.reducer;
