// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss, SuccessCss } from '../utility/toast/CustomToast';
import { decryptData, generateKeyPair } from '../utility/Utils';
import { editProfile, loadingFlag } from './mainLoading';
import { getNotificationAPI } from './organizationMain';

export const AuthSlice = createSlice({
  name: 'Authentication',
  initialState: {
    UserData: { token: localStorage.getItem('accessToken') },
    isLoading: false,
    AdminRoute: '',
    loginEmail: '',
    secureKeys: {},
  },
  reducers: {
    handleLogin: (state, action) => {
      state.UserData = { ...state.UserData, ...action.payload };
    },
    handleOtp: (state, action) => {
      state.isLoading = action.payload;
    },
    setMainRoute: (state, action) => {
      state.AdminRoute = action.payload;
    },
    setLoginEmail: (state, action) => {
      state.loginEmail = action.payload;
    },
    setSecureKey: (state, action) => {
      state.secureKeys = action.payload;
    },
  },
});

export const { handleLogin, handleOtp, setMainRoute, setLoginEmail, setSecureKey } = AuthSlice.actions;
// export const { initialState } = AuthSlice;

export const loginAPI = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post('users/login', data).then((response) => {
      dispatch(setLoginEmail(data?.email));
      dispatch(setMainRoute(data?.role_type === 'super-admin' ? 'administrator' : 'organization'));
      dispatch(loadingFlag(false));

      if (response?.data?.data?.is_password_reset === false) {
        navigate(`/change-password`);
      } else if (response?.data?.data?.isEmailVerified === false) {
        navigate(`/email-verified`);
      } else {
        toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
        navigate(`/otp-verification`);
      }
    });
  } catch (error) {
    dispatch(loadingFlag(false));
    console.log('#########', error);
    toast(
      <CustomToast message={error?.response?.data.error || error?.response?.data.message} type={'error'} />,
      ErrorCss(),
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const registerApi = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post('users/signup', data).then((response) => {
      dispatch(loadingFlag(false));

      navigate(`/email-verified`);
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data.message || error?.response?.data.error} type={'error'} />,
      ErrorCss(),
    );
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const verifyOtpApi = (data, navigate) => async (dispatch, getState) => {
  const loginEmail = getState()?.root?.authentication?.loginEmail;

  let privateSecureKey;

  try {
    dispatch(loadingFlag(true));
    const keys = generateKeyPair();
    await dispatch(setSecureKey(keys));

    privateSecureKey = keys?.privateKeyPem;
    const formattedPublicKeyPem = keys?.formattedPublicKeyPem;

    await axios
      .post('users/verify-otp', { ...data, email: loginEmail, x_api_key: formattedPublicKeyPem })
      .then((response) => {
        // toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
        const resultData = decryptData(privateSecureKey, response?.data);
        localStorage.setItem('accessToken', resultData?.data?.token);
        dispatch(handleLogin(resultData?.data));
        dispatch(getNotificationAPI(1, 5, 0));
        dispatch(loadingFlag(false));
        navigate('/');
        // dispatch(setLoginEmail(''));
      });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
    dispatch(loadingFlag(false));
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const forgotPasswordApi = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post('users/forgot-password', data).then((response) => {
      toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
      dispatch(loadingFlag(false));
      navigate(`/login`);
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data.message || error?.response?.data.error} type={'error'} />,
      ErrorCss(),
    );

    console.log('###', error);
    dispatch(loadingFlag(false));
    navigate(`/login`);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const changePasswordApi = (data, token, navigate) => async (dispatch, getState) => {
  const loginEmail = getState()?.root?.authentication?.loginEmail;

  try {
    dispatch(loadingFlag(true));
    await axios
      .post(
        token ? `users/reset-password/${token}` : 'users/change-password',
        token ? data : { ...data, email: loginEmail },
      )
      .then((response) => {
        toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
        localStorage.clear();
        dispatch({ type: 'RESET' });
        dispatch(handleLogin({ token: null }));
        dispatch(editProfile(false));
        dispatch(loadingFlag(false));
        navigate(`/login`);
      });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data.message} type={'error'} />, ErrorCss());
    console.log('###', error);
    dispatch(loadingFlag(false));
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const setPasswordApi = (data, navigate) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post('/set-password', data).then((response) => {
      CustomToast('success', 'password set sucessfully!!');
      navigate('/profile');
    });
  } catch (error) {
    CustomToast('error', error?.response?.data.message);
    console.log('###', error);
  } finally {
    setTimeout(() => {
      dispatch(loadingFlag(false));
    }, 2000);
  }
};

export const resendOtpAPI = (data) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post('users/resend-otp', data).then((response) => {
      toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    toast(
      <CustomToast message={error?.response?.data.message || error?.response?.data.error} type={'error'} />,
      ErrorCss(),
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const checkTokenExpiryApi = (token, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`users/verifyTokenExpiration/${token}`).then((response) => {});

    return { status: true };
  } catch (error) {
    navigate(`/link-expired`);
    console.log('###', error);
    dispatch(loadingFlag(false));
    return { status: false };
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default AuthSlice.reducer;
