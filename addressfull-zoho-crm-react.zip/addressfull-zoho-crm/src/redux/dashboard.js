// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss } from '../utility/toast/CustomToast';
import { decryptData } from '../utility/Utils';
import { loadingFlag } from './mainLoading';

export const DashboardSlice = createSlice({
  name: 'Dashboard',
  initialState: {
    DashboardData: {},
    dashboardLoading: false,
    TotalUserCounts: [],
    rowsPerPagesData: '10',
    paginationDefaultUsers: {
      page: 1,
      page_size: 10,
    },
  },
  reducers: {
    setDashboardData: (state, action) => {
      state.DashboardData = action.payload;
    },
    setDashboardLoading: (state, action) => {
      state.dashboardLoading = action.payload;
    },
    setTotalCountsData: (state, action) => {
      state.TotalUserCounts = action.payload;
    },
    setPaginationTotalCount: (state, action) => {
      state.paginationDefaultUsers = action.payload;
    },
    setRowPerPageTotalCount: (state, action) => {
      state.rowsPerPagesData = action.payload;
    },
  },
});

export const {
  setDashboardData,
  setTotalCountsData,
  setPaginationTotalCount,
  setRowPerPageTotalCount,
  setDashboardLoading,
} = DashboardSlice.actions;

export const getDashboardAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    dispatch(setDashboardLoading(true));

    await axios.get('users/dashboard', { params: { year: data?.year } }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(setDashboardData(resultData?.data));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);

    if (resultData?.message) {
      toast(
        <CustomToast
          message={
            resultData?.status === 400
              ? 'We are facing issue with the server. Please allow some time.'
              : resultData?.message
          }
          type={'error'}
        />,
        ErrorCss(),
      );
    }

    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
    dispatch(setDashboardLoading(false));
  }
};

export const getDashBoardTotalCountAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    await axios.get('organizations/user-consent-count', { params: { ...data } }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(setTotalCountsData(resultData));
    });
    data && dispatch(setPaginationTotalCount(data));
    data && dispatch(setRowPerPageTotalCount(data?.page_size));
  } catch (error) {
    data && dispatch(setPaginationTotalCount(data));
    data && dispatch(setRowPerPageTotalCount(data?.page_size));
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(
        <CustomToast
          message={
            resultData?.status === 400
              ? 'We are facing issue with the server. Please allow some time.'
              : resultData?.message
          }
          type={'error'}
        />,
        ErrorCss(),
      );
    }

    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default DashboardSlice.reducer;
