// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss, SuccessCss } from '../utility/toast/CustomToast';
import { encryptData, decryptData } from '../utility/Utils';
import { loadingFlag } from './mainLoading';
export const AdminStaffManagment = createSlice({
  name: 'AdminStaffManagment',
  initialState: {
    AdminStaffManagmentData: {
      AdminStaffListingData: [],
      AdminRoles: [],
      AdminModuleListing: [],
      singleRoleDetailes: {},
      singleAdminStaffDetailes: {},
      rowsPerPagesData: '10',
      paginationDefaultRole: {
        page: 1,
        page_size: 10,
        order_by: 'desc',
        sort_by: 'created_at',
      },
      paginationDefaultList: {
        page: 1,
        page_size: 10,
        order_by: 'desc',
        sort_by: 'created_at',
      },
    },
  },
  reducers: {
    setAdminStaffListing: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, AdminStaffListingData: action.payload };
    },
    setAdminStaffRole: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, AdminRoles: action.payload };
    },
    setAdminModuleList: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, AdminModuleListing: action.payload };
    },
    setSingleRoleDetailes: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, singleRoleDetailes: action.payload };
    },
    setSingleAdminStaffDetailes: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, singleAdminStaffDetailes: action.payload };
    },
    setPaginationRole: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, paginationDefaultRole: action.payload };
    },
    setPaginationList: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, paginationDefaultList: action.payload };
    },
    setRowPerPageAction: (state, action) => {
      state.AdminStaffManagmentData = { ...state.AdminStaffManagmentData, rowsPerPagesData: action.payload };
    },
  },
});

export const {
  setAdminStaffListing,
  setAdminModuleList,
  setAdminStaffRole,
  setSingleRoleDetailes,
  setSingleAdminStaffDetailes,
  setPaginationList,
  setPaginationRole,
  setRowPerPageAction,
} = AdminStaffManagment.actions;

export const getAdminStaffListingAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get('users', { params: { ...data } }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(setAdminStaffListing(resultData?.data));
    });
    data && dispatch(setPaginationList(data));
    data && dispatch(setRowPerPageAction(data?.page_size));
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);

    if (resultData?.message) {
      if (resultData?.message) {
        toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
      }
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getAdminStaffRolesAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get('/roles', { params: { ...data } }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(setAdminStaffRole(resultData?.data));
    });
    data && dispatch(setPaginationRole(data));
    data && dispatch(setRowPerPageAction(data?.page_size));
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

//baki
export const deleteAdminAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.AdminStaffManagment?.AdminStaffManagmentData?.paginationDefaultList;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.delete(`users/${id}`).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
      dispatch(getAdminStaffListingAPI(data));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
    dispatch(loadingFlag(false));
  }
};

export const editAdminStaffAPI = (data, id, navigate) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);
    await axios.put(`users/${id}`, `${Encryption}|20$`, { contentType: 'application/base64' }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      navigate(`/admin/listing`);
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const addAdminStaffAPI = (data, navigate) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);
    await axios.post('users', `${Encryption}|20$`, { contentType: 'application/base64' }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());

      navigate(`/admin/listing`);
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

//baki
export const deleteRoleAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.AdminStaffManagment?.AdminStaffManagmentData?.paginationDefaultRole;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.delete(`roles/${id}`).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(getAdminStaffRolesAPI(data));
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    console.log('###', error);
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editAdminRoleAPI = (data, navigate, id) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);
    await axios.put(`roles/${id}`, `${Encryption}|20$`, { contentType: 'application/base64' }).then((response) => {
      // dispatch(setAdminStaffRole(response.data));
      const resultData = decryptData(privateSecureKey, response?.data);

      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());

      navigate(`/admin/role`);
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const addAdminRoleAPI = (data, navigate) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);

    await axios.post('roles', `${Encryption}|20$`, { contentType: 'application/base64' }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      dispatch(setAdminStaffRole(resultData?.data));
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
      navigate(`/admin/role`);
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getModuleListAPI = () => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get('modules').then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      dispatch(setAdminModuleList(resultData?.data));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getRoleDetailestAPI = (id) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get(`roles/${id}`).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      dispatch(setSingleRoleDetailes(resultData?.data));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }

    console.log('###', error);
  } finally {
    // dispatch(getModuleListAPI());
    dispatch(loadingFlag(false));
  }
};

export const getSingleAdminStaffDetailestAPI = (id) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get(`users/${id}`).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      dispatch(setSingleAdminStaffDetailes(resultData?.data));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }

    console.log('###', error);
  } finally {
    dispatch(getAdminStaffRolesAPI());
  }
};

export default AdminStaffManagment.reducer;
