// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';

export const MainLoading = createSlice({
  name: 'MainLoading',
  initialState: {
    isLoading: false,
    edit: false,
  },
  reducers: {
    loadingFlag: (state, action) => {
      state.isLoading = action.payload;
    },
    editProfile: (state, action) => {
      state.edit = action.payload;
    },
  },
});

export const { loadingFlag, editProfile } = MainLoading.actions;

export default MainLoading.reducer;
