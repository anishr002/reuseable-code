// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss, SuccessCss } from '../utility/toast/CustomToast';
import { decryptData, encryptData } from '../utility/Utils';
import { loadingFlag } from './mainLoading';

export const OrganizationManagmentSlice = createSlice({
  name: 'OrganizationManagment',
  initialState: {
    OrganizationManData: [],
    BlockOrgData: [],
    BulkMessageLogs: [],
    OrganizationManTab: '1',
    rowsPerPagesData: '10',
    singleOrgnizationDetails: {},
    paginationDefaultOrgManagment: {
      page: 1,
      page_size: 10,
      order_by: 'desc',
      sort_by: 'created_at',
    },
    paginationDefaultBlockOrg: {
      page: 1,
      page_size: 10,
      order_by: 'desc',
      sort_by: 'updated_at',
    },
    paginationDefaultBulkMessageLogs: {
      page: 1,
      page_size: 10,
      order_by: 'desc',
      sort_by: 'updated_at',
    },
  },
  reducers: {
    handleSetOrganizationManData: (state, action) => {
      state.OrganizationManData = action.payload;
    },
    setBlockOrganizationData: (state, action) => {
      state.BlockOrgData = action.payload;
    },
    setBulkMessageLogsData: (state, action) => {
      state.BulkMessageLogs = action.payload;
    },
    setOrganizationsManTab: (state, action) => {
      state.OrganizationManTab = action.payload;
    },
    setPaginationOrgManagment: (state, action) => {
      state.paginationDefaultOrgManagment = action.payload;
    },

    setPaginationBlockOrg: (state, action) => {
      state.paginationDefaultBlockOrg = action.payload;
    },
    setPaginationBulkMessgeLogs: (state, action) => {
      state.paginationDefaultBulkMessageLogs = action.payload;
    },
    setRowPerPageOrg: (state, action) => {
      state.rowsPerPagesData = action.payload;
    },
    setSignleOrganizationDetails: (state, action) => {
      state.singleOrgnizationDetails = action.payload;
    },
  },
});

export const {
  handleSetOrganizationManData,
  setOrganizationsManTab,
  setSignleOrganizationDetails,
  setPaginationOrgManagment,
  setRowPerPageOrg,
  setPaginationBlockOrg,
  setBlockOrganizationData,
  setBulkMessageLogsData,
  setPaginationBulkMessgeLogs,
} = OrganizationManagmentSlice.actions;

export const getOrganizationManagmentListAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    // dispatch(handleGetProfile())
    await axios.get('organizations', { params: data }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(handleSetOrganizationManData(resultData?.data));
      data && dispatch(setPaginationOrgManagment(data));
      data && dispatch(setRowPerPageOrg(data?.page_size));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(setOrganizationsManTab('1'));
    dispatch(setSignleOrganizationDetails({}));
    dispatch(loadingFlag(false));
  }
};

export const editOrganizationsBySuperAdminAPI = (data, id, navigate) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  const formData = new FormData();

  function isURL(str) {
    const urlRegex = /^(?:ftp|http|https):\/\/(?:\w+:{0,1}\w*@)?(?:\S+)(:[0-9]+)?(?:\/|\/(?:[\w#!:.?+=&%@!\-\/]))?$/;
    return urlRegex.test(str);
  }

  const xyz = { ...data };
  if (!isURL(data?.imageObj)) {
    xyz.profile_picture = data?.imageObj || '';
  }
  delete xyz?.imageObj;

  // data?.imageObj && formData.append('profile_picture', await reduceImageSize(data?.imageObj));
  // delete data?.imageObj;

  for (const [key, value] of Object.entries(data)) {
    // If the value is an array, iterate over it and append each value
    if (Array.isArray(value)) {
      value.forEach((item, index) => {
        formData.append(`${key}[${index}]`, item);
      });
    } else {
      // If the value is not an array, append it directly
      formData.append(key, value);
    }
  }

  const Encryption = encryptData(publicKey, xyz);
  try {
    dispatch(loadingFlag(true));
    await axios
      .put(`organizations/${id}`, `${Encryption}|20$`, { contentType: 'application/base64' })
      .then((response) => {
        const resultData = decryptData(privateSecureKey, response?.data);
        toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
        navigate(`/organization-managment`);
      });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const addOrganizationsBySuperAdminAPI = (data, navigate) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  try {
    dispatch(loadingFlag(true));
    const formData = new FormData();

    function isURL(str) {
      const urlRegex = /^(?:ftp|http|https):\/\/(?:\w+:{0,1}\w*@)?(?:\S+)(:[0-9]+)?(?:\/|\/(?:[\w#!:.?+=&%@!\-\/]))?$/;
      return urlRegex.test(str);
    }

    // data?.imageObj && formData.append('profile_picture', data?.imageObj);
    // // delete data?.imageObj;

    const xyz = { ...data };
    if (!isURL(data?.imageObj)) {
      xyz.profile_picture = data?.imageObj || '';
    }
    delete xyz?.imageObj;

    for (const [key, value] of Object.entries(data)) {
      // If the value is an array, iterate over it and append each value
      if (Array.isArray(value)) {
        value.forEach((item, index) => {
          formData.append(`${key}[${index}]`, item);
        });
      } else {
        // If the value is not an array, append it directly
        formData.append(key, value);
      }
    }

    const Encryption = encryptData(publicKey, xyz);

    await axios.post('organizations', `${Encryption}|20$`, { contentType: 'application/base64' }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
      navigate(`/organization-managment`);
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const deleteOrganizationsBySuperAdminAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.OrganizationManagment?.paginationDefaultOrgManagment;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.delete(`organizations/${id}`, data).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(getOrganizationManagmentListAPI(data));
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const uploadDocOrganizationsBySuperAdminAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    const formData = new FormData();
    for (const [key, value] of Object.entries(data)) {
      // If the value is an array, iterate over it and append each value
      if (Array.isArray(value)) {
        value.forEach((item, index) => {
          formData.append(`${key}[${index}]`, item);
        });
      } else {
        // If the value is not an array, append it directly
        formData.append(key, value);
      }
    }

    await axios.post('organizations/document', formData, { contentType: 'multipart/form-data' }).then((response) => {
      dispatch(getSingleOrganizationsDetailsAPI(data?.id));
      const resultData = decryptData(privateSecureKey, response?.data);
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    console.log('###', error);
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getSingleOrganizationsDetailsAPI = (id) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    await axios.get(`organizations/${id}`).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(setSignleOrganizationDetails(resultData?.data));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const deleteDocumnetOfOrgAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.post(`organizations/document/remove`, data).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(getSingleOrganizationsDetailsAPI(data?.org_id));
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getBlockOrganizationListAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get('organizations/my-blocked', { params: data }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(setBlockOrganizationData(resultData?.data));
      data && dispatch(setPaginationBlockOrg(data));
      data && dispatch(setRowPerPageOrg(data?.page_size));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getBulkMessageLogsAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get('organizations/bulk-sms-logs', { params: data }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      dispatch(setBulkMessageLogsData(resultData?.data));
      data && dispatch(setPaginationBulkMessgeLogs(data));
      data && dispatch(setRowPerPageOrg(data?.page_size));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getCronJobLogsAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.get('organizations/bulk-sms-logs', { params: data }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      dispatch(setBulkMessageLogsData(resultData?.data));
      data && dispatch(setPaginationBulkMessgeLogs(data));
      data && dispatch(setRowPerPageOrg(data?.page_size));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};
export default OrganizationManagmentSlice.reducer;
