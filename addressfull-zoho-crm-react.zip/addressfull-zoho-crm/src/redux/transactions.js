// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss } from '../utility/toast/CustomToast';
import { decryptData } from '../utility/Utils';
import { loadingFlag } from './mainLoading';

export const TransactionSlice = createSlice({
  name: 'transactions',
  initialState: {
    TransactionData: {
      TransactionListData: [],
      rowsPerPagesData: '10',
      nextPageString: '',
      previousPageString: [],
      last_page: false,
      first_time: false,
      transactionHistorty: [],
      paginationDefaultList: {
        page: 1,
        page_size: 10,
        mobile_number: '',
      },
    },
  },
  reducers: {
    setTransactionData: (state, action) => {
      state.TransactionData = { ...state.TransactionData, TransactionListData: action.payload };
    },
    setLastPage: (state, action) => {
      state.TransactionData = { ...state.TransactionData, last_page: action.payload };
    },
    setFirstTime: (state, action) => {
      state.TransactionData = { ...state.TransactionData, first_time: action.payload };
    },
    setPaginationList: (state, action) => {
      state.TransactionData = { ...state.TransactionData, paginationDefaultList: action.payload };
    },
    setRowPerPageAction: (state, action) => {
      state.TransactionData = { ...state.TransactionData, rowsPerPagesData: action.payload };
    },
    setNextPageString: (state, action) => {
      state.TransactionData = { ...state.TransactionData, nextPageString: action.payload };
    },
    setTransactionHistory: (state, action) => {
      state.TransactionData = { ...state.TransactionData, transactionHistorty: action.payload };
    },
    setPreviousPageString: (state, action) => {
      state.TransactionData = {
        ...state.TransactionData,
        previousPageString: action.payload,
      };
    },
  },
});

export const {
  setTransactionData,
  setPaginationList,
  setRowPerPageAction,
  setNextPageString,
  setLastPage,
  setFirstTime,
  setPreviousPageString,
  setTransactionHistory,
} = TransactionSlice.actions;

export const getTransactionsAPI = (data) => async (dispatch, getState) => {
  const profileData = getState()?.root?.Organization?.OrganizationDetailes?.profileData;
  const route = getState()?.root?.authentication?.AdminRoute;
  const nameOfOrg = profileData?.name || profileData?.org_name;
  const prevData = getState()?.root?.transactions?.TransactionData?.previousPageString;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));

    await axios
      .get('transactions', {
        params: route === 'administrator' ? data : { ...data, organization_name: nameOfOrg },
      })
      .then((response) => {
        const resultData = decryptData(privateSecureKey, response?.data);

        if (data?.page === 1) {
          dispatch(setNextPageString(''));
          dispatch(setPreviousPageString([]));
          // delete data?.bookmark;
        }
        dispatch(setLastPage(false));
        dispatch(setTransactionData(resultData?.data));
        if (prevData[prevData?.length - 1] !== resultData?.data?.bookmark) {
          dispatch(setNextPageString(resultData?.data?.bookmark));
          dispatch(setPreviousPageString([...prevData, resultData?.data?.bookmark]));
        }
      });

    data && dispatch(setPaginationList(data));
    data && dispatch(setRowPerPageAction(data?.page_size));
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    toast(
      <CustomToast
        message={
          resultData?.status === 500
            ? 'We are facing issue with the server. Please allow some time.'
            : resultData?.message
        }
        type={'error'}
      />,
      ErrorCss(),
    );
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getTransactionsHistoryAPI = (data) => async (dispatch, getState) => {
  const nameOfOrg = getState()?.root?.Organization?.OrganizationDetailes?.profileData?.name;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  const prevData = getState()?.root?.transactions?.TransactionData?.previousPageString;

  try {
    dispatch(loadingFlag(true));
    await axios
      .get('transactions/activity-list', { params: { ...data, organization_name: nameOfOrg } })
      .then((response) => {
        if (data?.page === 1) {
          dispatch(setNextPageString(''));
          dispatch(setPreviousPageString([]));
          // delete data?.bookmark;
        }
        const resultData = decryptData(privateSecureKey, response?.data);
        dispatch(setTransactionHistory(resultData?.data));

        if (prevData[prevData?.length - 1] !== resultData?.data?.bookmark) {
          dispatch(setNextPageString(resultData?.data?.bookmark));
          dispatch(setPreviousPageString([...prevData, resultData?.data?.bookmark]));
        }
        data && dispatch(setPaginationList(data));
        data && dispatch(setRowPerPageAction(data?.page_size));
      });
  } catch (error) {
    console.log('###', error);
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    toast(
      <CustomToast
        message={
          resultData?.status === 400
            ? 'We are facing issue with the server. Please allow some time.'
            : resultData?.message
        }
        type={'error'}
      />,
      ErrorCss(),
    );
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default TransactionSlice.reducer;
