// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss, SuccessCss } from '../utility/toast/CustomToast';
import { encryptData, decryptData } from '../utility/Utils';
import { loadingFlag } from './mainLoading';
import { setNextPageString, setPreviousPageString } from './transactions';

export const OrganizationUsers = createSlice({
  name: 'OrganizationUsers',
  initialState: {
    OrganizationUsersData: [],
    rowsPerPagesData: '10',
    singleUsersDetails: {},
    UserRequestValidationData: {},
    paginationDefaultUsers: {
      page: 1,
      page_size: 10,
      order_by: 'desc',
      sort_by: 'created_at',
    },
  },
  reducers: {
    setOrganizationUsersData: (state, action) => {
      state.OrganizationUsersData = action.payload;
    },
    setPaginationUsers: (state, action) => {
      state.paginationDefaultUsers = action.payload;
    },
    setRowPerPageUsers: (state, action) => {
      state.rowsPerPagesData = action.payload;
    },
    setSignleUsersDetails: (state, action) => {
      state.singleUsersDetails = action.payload;
    },
    setSingleUserRequestData: (state, action) => {
      state.UserRequestValidationData = action.payload;
    },
  },
});

export const {
  setOrganizationUsersData,
  setSignleUsersDetails,
  setRowPerPageUsers,
  setPaginationUsers,
  setSingleUserRequestData,
} = OrganizationUsers.actions;

export const getOrganizationUsersAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    await axios.get('users', { params: { ...data, mobile_user: true } }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(setOrganizationUsersData(resultData?.data));
      data && dispatch(setPaginationUsers(data));
      data && dispatch(setRowPerPageUsers(data?.page_size));
    });
    dispatch(loadingFlag(false));
  } catch (error) {
    console.log('###', error);

    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    data && dispatch(setPaginationUsers(data));
    data && dispatch(setRowPerPageUsers(data?.page_size));
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const organizationUsersDataRequestAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;

  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);
    await axios
      .post('notifications/send-request', `${Encryption}|20$`, { contentType: 'application/base64' })
      .then((response) => {
        const resultData = decryptData(privateSecureKey, response?.data);
        toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
      });
  } catch (error) {
    console.log('###', error);
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getSingleUsersDetailsAPI = (id) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get(`organizations/users/${id}`).then((response) => {
      dispatch(setSignleUsersDetails(response?.data?.data));
    });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data.message} type={'error'} />, ErrorCss());

    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const checkUserExcelValidationAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;

  try {
    const Encryption = encryptData(publicKey, data);

    dispatch(loadingFlag(true));
    const response = await axios.post(`organizations/send-data-request`, `${Encryption}|20$`, {
      contentType: 'application/base64',
    });
    const resultData = decryptData(privateSecureKey, response?.data);

    if (resultData?.openReqPopup) {
      dispatch(setNextPageString(''));
      dispatch(setPreviousPageString([]));
      // dispatch(getTransactionsHistoryAPI({ client_id: resultData?.userId, page_size: 10, page: 1 }));
      dispatch(loadingFlag(false));
    } else {
      dispatch(loadingFlag(false));
    }

    return resultData; // Return the result data
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    // //  if (resultData?.message) {
    //   toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    // }
    console.log('###', error);
    dispatch(loadingFlag(false));
    return resultData; // Return the result data in case of an error
  }
};

export const activeDeactiveUserApi = (data, id) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  const Paginationdata = getState()?.root?.organizationUsers?.paginationDefaultUsers;

  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);
    await axios.put(`users/${id}`, `${Encryption}|20$`, { contentType: 'application/base64' }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(getOrganizationUsersAPI(Paginationdata));
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default OrganizationUsers.reducer;
