// ** Redux Imports
import { createSlice } from '@reduxjs/toolkit';
import toast from 'react-hot-toast';
import { axios } from '../@core/auth/jwt/jwtService';
import CustomToast, { ErrorCss, SuccessCss } from '../utility/toast/CustomToast';
import { decryptData, encryptData } from '../utility/Utils';
import { loadingFlag } from './mainLoading';

export const SettingSlice = createSlice({
  name: 'Setting',
  initialState: {
    GeneralSettingData: {},
    CRMSettingsData: [],
    PrivacyPolicyData: {},
    rowsPerPagesData: '10',
    singleCrmDetailes: {},
    Templates: [],
    OtherSettings: {},
    paginationDefaultCRM: {
      page: 1,
      page_size: 10,
      order_by: 'desc',
      sort_by: 'created_at',
    },
    paginationDefaultPolicy: {
      page: 1,
      page_size: 10,
      order_by: 'desc',
      sort_by: 'created_at',
    },
  },
  reducers: {
    handleGetGeneralSettingData: (state, action) => {
      state.GeneralSettingData = action.payload;
    },
    handleGetCRMSettingData: (state, action) => {
      state.CRMSettingsData = action.payload;
    },
    setPrivayPolicyData: (state, action) => {
      state.PrivacyPolicyData = action.payload;
    },
    setPaginationList: (state, action) => {
      state.paginationDefaultCRM = action.payload;
    },
    setRowPerPageData: (state, action) => {
      state.rowsPerPagesData = action.payload;
    },
    setSingleCRM: (state, action) => {
      state.singleCrmDetailes = action.payload;
    },
    setTemplates: (state, action) => {
      state.Templates = action.payload;
    },
    setOtherSettings: (state, action) => {
      state.OtherSettings = action.payload;
    },

    setPaginationForPolicy: (state, action) => {
      state.paginationDefaultPolicy = action.payload;
    },
  },
});

export const {
  handleGetGeneralSettingData,
  handleGetCRMSettingData,
  setPrivayPolicyData,
  setPaginationList,
  setRowPerPageData,
  setSingleCRM,
  setTemplates,
  setOtherSettings,
  setPaginationForPolicy,
} = SettingSlice.actions;

export const getGeneralSettingsAPI = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get('/org-settings').then((response) => dispatch(handleGetGeneralSettingData(response.data?.data)));
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editGeneralSettingsAPI = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.put('/setting-edit', data).then((response) => {
      // dispatch(handleGetGeneralSettingData());
      toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getCRMDetailesAPI = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios
      .get('/settings/crm', { params: data })
      .then((response) => dispatch(handleGetCRMSettingData(response?.data?.data)));
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const deleteCRMAPI = (id) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.delete(`/org-crm/${id}`).then((response) => {
      // dispatch(getCRMDetailesAPI(data));
      toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const addCRMDetailesAPI = (data, navigate) => async (dispatch, getState) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post('/settings/crm', data).then((response) => {
      // dispatch(getCRMDetailesAPI(data))
      toast(<CustomToast message={response?.data.data} type={'success'} />, SuccessCss());
      navigate(`/settings/crm_settings`);
    });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editCRMDetailesAPI = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.put('/edit-crm', data).then((response) => {
      // dispatch(getCRMDetailesAPI(data));
      toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getSingleCRMAPI = (id) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    // await axios
    //   .get(`/src/utility/configs/datacrm.json`)
    //   .then((response) => dispatch(setSingleCRM(response?.data?.data)));

    const response = await fetch('/src/utility/configs/datacrm.json');
    const data = await response.json();
    dispatch(setSingleCRM(data));
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const getTemplate = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get('settings/emailTemplates').then((response) => dispatch(setTemplates(response.data?.data)));
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editTemplate = (type, data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.put(`settings/emailTemplates/${type}`, data).then((response) => {
      // dispatch(handleGetGeneralSettingData());
      toast(<CustomToast message={response?.data?.data} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};
export const editOtherSettings = (data) => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.post(`settings`, data).then((response) => {
      dispatch(setOtherSettings(response.data?.data));
      toast(<CustomToast message={response?.data.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};
export const getOtherSettings = () => async (dispatch) => {
  try {
    dispatch(loadingFlag(true));
    await axios.get('settings').then((response) => dispatch(setOtherSettings(response.data?.data)));
  } catch (error) {
    toast(<CustomToast message={error?.response?.data?.message} type={'error'} />, ErrorCss());
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

//<------------Privacy Policy----------->

export const getPrivacyPolicyAPI = (data) => async (dispatch, getState) => {
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    await axios.get('privacy-policies', { params: data }).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);

      dispatch(setPrivayPolicyData(resultData?.data));
      data && dispatch(setPaginationForPolicy(data));
      data && dispatch(setRowPerPageData(data?.page_size));
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const deletePrivacyPolicyAPI = (id) => async (dispatch, getState) => {
  const data = getState()?.root?.Setting?.paginationDefaultPolicy;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;

  try {
    dispatch(loadingFlag(true));
    await axios.delete(`privacy-policies/${id}`).then((response) => {
      const resultData = decryptData(privateSecureKey, response?.data);
      dispatch(getPrivacyPolicyAPI(data));
      toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
    });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const addPrivacyPolicyAPI = (data, navigate) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);
    await axios
      .post('privacy-policies', `${Encryption}|20$`, { contentType: 'application/base64' })
      .then((response) => {
        const resultData = decryptData(privateSecureKey, response?.data);
        // dispatch(getCRMDetailesAPI(data))
        toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
        navigate(`/settings/privacy_policy_settings`);
      });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
  } finally {
    dispatch(loadingFlag(false));
  }
};

export const editPrivacyPolicyAPI = (data, id, navigate) => async (dispatch, getState) => {
  const publicKey = getState()?.root?.authentication?.UserData?.encrypted_public_key;
  const privateSecureKey = getState()?.root?.authentication?.secureKeys?.privateKeyPem;
  try {
    dispatch(loadingFlag(true));
    const Encryption = encryptData(publicKey, data);

    await axios
      .put(`privacy-policies/${id}`, `${Encryption}|20$`, { contentType: 'application/base64' })
      .then((response) => {
        const resultData = decryptData(privateSecureKey, response?.data);

        toast(<CustomToast message={resultData?.message} type={'success'} />, SuccessCss());
        navigate(`/settings/privacy_policy_settings`);
      });
  } catch (error) {
    const resultData = decryptData(privateSecureKey, error?.response?.data);
    if (resultData?.message) {
      toast(<CustomToast message={resultData?.message} type={'error'} />, ErrorCss());
    }
    console.log('###', error);
    dispatch(loadingFlag(false));
    return resultData;
  } finally {
    dispatch(loadingFlag(false));
  }
};

export default SettingSlice.reducer;
