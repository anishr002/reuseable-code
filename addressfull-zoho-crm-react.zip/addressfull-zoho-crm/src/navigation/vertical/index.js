import { Database, HardDrive, Home, Link, List, MessageSquare, Settings, UserPlus, Users } from 'react-feather';
import { RiAdminLine } from 'react-icons/ri';
import { SlOrganization } from 'react-icons/sl';

export default [
  {
    id: 'dashboard',
    title: 'Dashboard',
    icon: <Home size={20} />,
    navLink: 'dashboard',
    permission: ['ALL'],
  },
  {
    id: 'users',
    title: 'Users',
    icon: <Users size={20} />,
    navLink: 'organization-users',
    permission: ['ALL'],
  },

  {
    id: 'message_logs',
    title: 'Message Log',
    icon: <MessageSquare size={20} />,
    navLink: 'message_logs',
    permission: ['ALL'],
  },
  {
    id: 'roles',
    title: 'Admins',
    icon: <UserPlus size={20} />,
    permission: ['ALL'],
    action: 'read',
    children: [
      {
        id: 'roles',
        title: 'Roles',
        icon: <RiAdminLine size={20} />,
        navLink: 'admin/role',
        parent: 'Role Management',
      },
      {
        id: 'admins',
        title: 'Staff Listing',
        icon: <List size={20} />,
        navLink: 'admin/listing',
        parent: 'Admin Management',
      },
    ],
  },
  {
    id: 'organizations',
    title: 'Organizations',
    icon: <UserPlus size={20} />,
    permission: ['ALL'],
    action: 'read',
    children: [
      {
        id: 'organizations',
        title: 'All Organization',
        icon: <SlOrganization size={20} />,
        navLink: 'organization-managment',
        parent: 'All Organizations',
      },
      {
        id: 'block_organizations',
        title: 'Blocked',
        icon: <List size={20} />,
        navLink: 'block_organizations',
        parent: 'Organizations',
      },
    ],
  },
  {
    id: 'transactions',
    title: 'Transactions',
    icon: <Database size={20} />,
    navLink: 'transactions',
    permission: ['ALL'],
  },
  {
    id: 'general_settings',
    title: 'Settings',
    icon: <Settings size={20} />,
    // navLink: 'settings',
    permission: ['ALL'],
    action: 'read',
    children: [
      {
        id: 'general_settings',
        title: 'General',
        icon: <HardDrive size={20} />,
        navLink: 'settings/general_settings',
        parent: 'General Settings',
      },
      {
        id: 'crm_settings',
        title: 'CRM Integration',
        icon: <Link size={20} />,
        navLink: 'settings/crm_settings',
        parent: 'CRM Integration',
      },
      {
        id: 'privacy_policy_settings',
        title: 'Privacy Policy',
        icon: <Link size={20} />,
        navLink: 'settings/privacy_policy_settings',
        parent: 'Privacy Policy',
      },
    ],
  },
];
