import adIcon from '@assets/images/logo/logo1.png';
import navigation from '@src/navigation/vertical';
import React, { Suspense, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { io } from 'socket.io-client';
import Spinner from './components/spinner/Fallback-spinner';
import { handleActiveItems } from './redux/layout';
import { setSokectData } from './redux/organizationMain';
import Router from './router/Router';

const App = () => {
  const roomId = 1;
  const location = useLocation();
  const dispatch = useDispatch();
  const { UserData } = useSelector((state) => state.root?.authentication);
  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);

  const user = UserData?.token;
  let socket = {};

  if (user) {
    const token = localStorage.getItem('accessToken');

    socket = socket?.connected
      ? socket
      : io.connect(`wss://${import.meta.env.VITE_APP_SOCKET_URL}`, {
          auth: {
            token,
          },
        });
  }

  useEffect(() => {
    if (UserData?.role === 'super-admin' || UserData?.role === 'organization-admin') {
      if (user) {
        socket?.on('connect', () => {
          console.log('socket', socket);
        });

        socket?.emit('joinRoom', UserData?.role === 'organization-admin' ? profileData?.user_id : roomId);

        // Error handling for socket connection
        socket?.on('connect_error', (error) => {
          console.error('Socket connection error:', error.message);
        });
      }
    }

    // Clean up the socket connection when the component unmounts
    return () => {
      socket?.connected && socket?.disconnect();
    };
  }, [user, roomId]);

  useEffect(() => {
    if (user) {
      const findSideName = location?.pathname;

      const splitItem = navigation?.find((i) =>
        findSideName.includes('organization-managment')
          ? i.id === 'organizations'
          : findSideName === '/admin/listing' || findSideName === '/admin/role'
          ? i.id === 'roles'
          : findSideName === '/settings/crm_settings' ||
            findSideName === '/settings/general_settings' ||
            findSideName === '/settings/crm_settings' ||
            findSideName === '/settings/general_settings' ||
            findSideName === '/settings/privacy_policy_settings'
          ? i.id === 'general_settings'
          : findSideName.includes(i.id),
      );

      if (splitItem?.children) {
        const spliting_r = findSideName?.split('/');

        const abc = splitItem?.children?.find((i) => spliting_r.slice(1).join('/') === i.navLink);

        dispatch(handleActiveItems(abc));
      } else {
        dispatch(handleActiveItems(splitItem));
      }
    }
  }, [location]);

  function showNotification(mess) {
    // Check if the browser supports the Notification API
    if ('Notification' in window) {
      var options = {
        body: mess,
        icon: adIcon,
        dir: 'ltr',
      };

      var notification = new Notification('AddressFull', options);

      function updateUrl(url) {
        return url + '/notifications';
      }

      // Add a click event listener to the notification
      notification.addEventListener('click', function () {
        // Open the desired URL when the notification is clicked
        window.open(updateUrl(`https://${window?.location?.host}`), '_blank');
      });
    } else {
      console.error('Notification API not supported in this browser');
    }
  }

  useEffect(() => {
    // Listen for incoming messages

    if (UserData?.role === 'super-admin' || UserData?.role === 'organization-admin') {
      if (user) {
        socket?.emit('joinRoom', UserData?.role === 'organization-admin' ? profileData?.user_id : roomId);
        socket?.on('NotificationAlert', (newMessage) => {
          // console.log('###', newMessage);
          dispatch(setSokectData(newMessage?.data));
          showNotification(newMessage?.message);
        });
      }
    }
  }, [socket]);

  useEffect(() => {
    // Check if the browser supports the Notification API
    if ('Notification' in window) {
      Notification.requestPermission().then((permission) => {
        console.log('Notification permission:', permission);
      });
    }
  }, []);

  return (
    <Suspense fallback={<Spinner />}>
      <Router />
    </Suspense>
  );
};

export default App;
