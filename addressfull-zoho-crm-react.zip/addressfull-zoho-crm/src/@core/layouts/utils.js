/**
 * Return which component to render based on it's data/context
 * @param {Object} item nav menu item
 */
export const resolveVerticalNavMenuItemComponent = (item) => {
  if (item?.header) {
    return 'VerticalNavMenuSectionHeader';
  }
  if (item?.children) {
    return 'VerticalNavMenuGroup';
  }
  return 'VerticalNavMenuLink';
};

/**
 * Return which component to render based on it's data/context
 * @param {Object} item nav menu item
 */
export const resolveHorizontalNavMenuItemComponent = (item) => {
  if (item?.children) {
    return 'HorizontalNavMenuGroup';
  }
  return 'HorizontalNavMenuLink';
};

/**
 * Check if nav-link is active
 * @param {Object} link nav-link object
 */
export const isNavLinkActive = (link, currentURL, routerProps) => {
  return currentURL === link || routerProps?.meta?.navLink === link;
  // return currentURL === link
};

/**
 * Check if the given item has the given url
 * in one of its children
 *
 * @param item
 * @param activeItem
 */
export const hasActiveChild = (item, currentUrl) => {
  const { children } = item;

  if (!children) {
    return false;
  }

  for (const child of children) {
    if (child.children) {
      if (hasActiveChild(child, currentUrl)) {
        return true;
      }
    }

    // Check if the child has a link and is active
    if (child?.navLink && currentUrl && (child.navLink === currentUrl || currentUrl.includes(child.navLink))) {
      return true;
    }
  }

  return false;
};

/**
 * Check if this is a children
 * of the given item
 *
 * @param children
 * @param openGroup
 * @param currentActiveGroup
 */
export const removeChildren = (children, openGroup, currentActiveGroup, _permission) => {
  children.forEach((child) => {
    if (!currentActiveGroup.includes(child.id)) {
      const index = openGroup.indexOf(child.id);
      if (index > -1) {
        openGroup.splice(index, 1);
      }
    }
  });
};

const checkForVisibleChild = (arr, ability) => {
  return arr.some((i) => {
    if (i.children) {
      return checkForVisibleChild(i.children, ability);
    } else {
      return ability.can(i.action, i.resource);
    }
  });
};

export const canViewMenuGroup = (item, userData) => {
  const roleData = userData?.permissions;

  const hasReadPermission = item.children.some((child) => {
    const foundPermission = roleData.find((permission) => permission.section === child.id);
    return foundPermission && foundPermission.permissions.read === true;
  });

  return hasReadPermission;
};

export const canViewMenuItem = (item, userData) => {
  const ShowHide = false;
  // ** filter sidebar access based on role-access
  const Permit = userData.permissions.find((i) => i.section === item?.id);
  const itemPermission = Permit?.permissions;
  if (itemPermission) {
    if (itemPermission?.read && itemPermission?.write) {
      return !ShowHide;
    } else if (itemPermission?.read) {
      return !ShowHide;
    } else {
      return ShowHide;
    }
  } else {
    return ShowHide;
  }
};

export const getAllParents = (obj, match) => {
  const res = [];
  const recurse = (obj, _current) => {
    for (const key in obj) {
      const value = obj[key];
      if (value !== undefined) {
        if (value && typeof value === 'object') {
          recurse(value, key);
        } else {
          if (key === match) {
            res.push(value);
          }
        }
      }
    }
  };
  recurse(obj);
  return res;
};

export const search = (navigation, currentURL, routerProps) => {
  let result;
  navigation.some((child) => {
    let children;
    // If child have children => It's group => Go deeper(recursive)
    if (child.children && (children = search(child.children, currentURL, routerProps))) {
      return (result = {
        id: child.id,
        children,
      });
    }

    // else it's link => Check for matched Route
    if (isNavLinkActive(child.navLink, currentURL, routerProps)) {
      return (result = {
        id: child.id,
      });
    }
  });
  return result;
};
