// ** React Imports
import { useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';

// ** Icons Imports
import { Circle, Disc, X } from 'react-feather';

// ** Config
import smallLogo from '../../../../../assets/images/logo/small-logo.svg';
import themeConfig from '../../../../../utility/configs/themeConfig';
// ** Utils

const VerticalMenuHeader = (props) => {
  // ** Props
  const { menuCollapsed, setMenuCollapsed, setMenuVisibility, menuVisibility, setGroupOpen, menuHover } = props;

  const navigate = useNavigate();

  // ** Reset open group
  useEffect(() => {
    if (!menuHover && menuCollapsed) setGroupOpen([]);
  }, [menuHover, menuCollapsed]);

  // ** Menu toggler component
  const Toggler = () => {
    if (!menuCollapsed) {
      return (
        <Disc
          size={20}
          data-tour="toggle-icon"
          className="text-primary toggle-icon d-none d-xl-block"
          onClick={() => setMenuCollapsed(true)}
        />
      );
    } else {
      return (
        <Circle
          size={20}
          data-tour="toggle-icon"
          className="text-primary toggle-icon d-none d-xl-block"
          onClick={() => setMenuCollapsed(false)}
        />
      );
    }
  };

  return (
    <div className="navbar-header">
      <ul className="nav navbar-nav flex-row">
        <li className="nav-item me-auto">
          <div className="navbar-brand">
            <span
              className={
                menuVisibility
                  ? 'brand-logo text-center'
                  : !menuHover && menuCollapsed
                  ? 'brand-logo-small text-center'
                  : 'brand-logo text-center'
              }
            >
              {/* <img src={themeConfig.app.appLogoImage} alt="logo" /> */}
              <img
                src={
                  menuVisibility
                    ? themeConfig.app.appLogoImage
                    : !menuHover && menuCollapsed
                    ? smallLogo
                    : themeConfig.app.appLogoImage
                }
                alt="logo"
                className="cursor-pointer"
                onClick={() => navigate('/')}
              />
            </span>
            {/* <h2 className="brand-text mb-0">{themeConfig.app.appName}</h2> */}
          </div>
        </li>
        <li className="nav-item nav-toggle">
          <div className="nav-link modern-nav-toggle cursor-pointer">
            <Toggler />
            <X onClick={() => setMenuVisibility(false)} className="toggle-icon icon-x d-block d-xl-none" size={20} />
          </div>
        </li>
      </ul>
    </div>
  );
};

export default VerticalMenuHeader;
