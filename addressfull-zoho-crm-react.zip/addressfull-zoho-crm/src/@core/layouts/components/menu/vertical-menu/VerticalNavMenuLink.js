// ** React Imports
import { NavLink, useLocation } from 'react-router-dom';

// ** Third Party Components
import classnames from 'classnames';

// ** Reactstrap Imports
import { Badge } from 'reactstrap';
import { useDispatch, useSelector } from 'react-redux';
import { handleActiveItems } from '../../../../../redux/layout';
import { useEffect } from 'react';
import { setFirstTime } from '../../../../../redux/transactions';

const VerticalNavMenuLink = (props) => {
  const { item, activeItem } = props;
  const dispatch = useDispatch();
  const location = useLocation();
  const { activeItems } = useSelector((state) => state.root?.layout);

  const LinkTag = item.externalLink ? 'a' : NavLink;

  return (
    <li
      className={classnames({
        'nav-item': !item.children,
        disabled: item.disabled,
        active: item.navLink === activeItem,
      })}
    >
      <LinkTag
        className="d-flex align-items-center"
        target={item.newTab ? '_blank' : undefined}
        /*eslint-disable */
        {...(item.externalLink === true
          ? {
              href: item.navLink || '/',
            }
          : {
              to: item.navLink || '/',
              className: ({ isActive }) => {
                if (isActive && !item.disabled) {
                  return 'd-flex align-items-center active';
                }
              },
            })}
        onClick={(e) => {
          if (item.navLink.length === 0 || item.navLink === '#' || item.disabled === true) {
            e.preventDefault();
          }
          if (activeItems?.id === 'transactions') {
            dispatch(setFirstTime(true));
          }
          props?.setActiveItem(item);
          dispatch(handleActiveItems(item));
        }}
      >
        {item.icon}
        <span className="menu-item text-truncate">{item.title}</span>

        {item.badge && item.badgeText ? (
          <Badge className="ms-auto me-1" color={item.badge} pill>
            {item.badgeText}
          </Badge>
        ) : null}
      </LinkTag>
    </li>
  );
};

export default VerticalNavMenuLink;
