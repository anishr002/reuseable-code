// ** React Imports
import { Fragment, useEffect, useState } from 'react';

// ** Custom Components

// // ** Third Party Components
import classnames from 'classnames';
import { Bell } from 'react-feather';
import PerfectScrollbar from 'react-perfect-scrollbar';

// ** Reactstrap Imports
import { Badge, Button, DropdownItem, DropdownMenu, DropdownToggle, UncontrolledDropdown } from 'reactstrap';

import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
// import socket from '../../../../utility/configs/io';
import { getProfileAPI, readNotificationAPI } from '../../../../redux/organizationMain';
import { getOtherSettings, getPrivacyPolicyAPI } from '../../../../redux/settings';

const NotificationDropdown = () => {
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dispatch = useDispatch();

  const { UserData } = useSelector((state) => state.root?.authentication);
  const data = useSelector((state) => state?.root?.Organization?.soket);

  useEffect(() => {
    const user = UserData?.token;
    if (user) {
      dispatch(getProfileAPI());
      dispatch(getOtherSettings());
      dispatch(getPrivacyPolicyAPI());
    }

    // Add event listener to handle clicks outside the dropdown
    document.addEventListener('click', handleDocumentClick);

    // Cleanup function to remove event listener when component unmounts
    return () => {
      document.removeEventListener('click', handleDocumentClick);
    };
  }, []);

  const handleDocumentClick = (e) => {
    // Check if the clicked element is outside the dropdown
    if (!e.target.closest('.dropdown-notification')) {
      setDropdownOpen(false);
    }
  };

  /*eslint-disable */
  const renderNotificationItems = () => {
    return (
      <PerfectScrollbar
        component="li"
        className="media-list scrollable-container"
        options={{
          wheelPropagation: false,
        }}
      >
        {data?.notification_list?.slice(0, 5)?.map((item, _index) => {
          return (
            <a
              key={item?.message}
              className="d-flex"
              // href={item.switch ? '#' : '/'}
              onClick={(e) => {
                if (!item.switch) {
                  e.preventDefault();
                }
              }}
            >
              <div
                className={classnames('list-item d-flex', {
                  'align-items-start': !item.switch,
                  'align-items-center': item.switch,
                })}
              >
                {!item.switch ? (
                  <div className="list-item-body flex-grow-1">
                    {item.message}
                    <small className="notification-text">{item.subtitle}</small>
                  </div>
                ) : (
                  <Fragment>
                    {item.title}
                    {item.switch}
                  </Fragment>
                )}
              </div>
            </a>
          );
        })}
      </PerfectScrollbar>
    );
  };
  /*eslint-enable */

  return (
    <UncontrolledDropdown tag="li" className="dropdown-notification  me-25 dropdown" isOpen={dropdownOpen}>
      <DropdownToggle
        tag="a"
        className="nav-link"
        onClick={(_e) => {
          setDropdownOpen(!dropdownOpen);
        }}
      >
        <Bell size={20} />
        <Badge pill color="danger" className="badge-up">
          {data?.page_info?.total_count ?? 0}
        </Badge>
      </DropdownToggle>
      <DropdownMenu end tag="ul" className="dropdown-menu-media mt-0">
        <li className="dropdown-menu-header">
          <DropdownItem className="d-flex" tag="div" header>
            <h4 className="notification-title mb-0 me-auto">Notifications</h4>
          </DropdownItem>
        </li>
        {data?.notification_list?.length > 0 ? (
          renderNotificationItems()
        ) : (
          <li className="align-items-center p-2" style={{ textAlign: 'center' }}>
            No data
          </li>
        )}

        <li className="dropdown-menu-footer">
          <Button
            color="primary"
            onClick={() => {
              navigate(`/notifications`);
              setDropdownOpen(false);
              dispatch(readNotificationAPI());
            }}
            block
          >
            {data?.notification_list?.length > 0 ? 'Read all notifications' : 'View all notifications'}
          </Button>
        </li>
      </DropdownMenu>
    </UncontrolledDropdown>
  );
};

export default NotificationDropdown;
