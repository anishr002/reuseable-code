// ** React Imports
import { Link } from 'react-router-dom';

// ** Custom Components
import Avatar from '@components/avatar';

// ** Third Party Components
import { Power, User } from 'react-feather';

// ** Reactstrap Imports
import { DropdownItem, DropdownMenu, DropdownToggle, UncontrolledDropdown } from 'reactstrap';

// ** Default Avatar Image
import AvtarUser from '@assets/images/portrait/avatar-blank.png';
import { useDispatch, useSelector } from 'react-redux';
import { handleLogin } from '../../../../redux/authentication';
import { handleActiveItems } from '../../../../redux/layout';

import { editProfile } from '../../../../redux/mainLoading';
import { store } from '../../../../redux/store';

const UserDropdown = () => {
  const dispatch = useDispatch();
  const { UserData, loginEmail } = useSelector((state) => state.root.authentication);
  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);
  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];

  const setCapitalName = () => {
    return subdomain === 'org'
      ? profileData?.name
        ? profileData?.name?.charAt(0).toUpperCase() + profileData?.name?.slice(1)
        : loginEmail.split('@')[0]?.charAt(0).toUpperCase() + loginEmail.split('@')[0]?.slice(1)
      : profileData?.first_name
      ? `${profileData?.first_name?.charAt(0).toUpperCase() + profileData?.first_name?.slice(1)} ${
          profileData?.last_name?.charAt(0).toUpperCase() + profileData?.last_name?.slice(1)
        }`
      : '';
  };

  function capitalizeString(inputString) {
    if (inputString?.includes('-')) {
      // Split the string by '-' and capitalize each word
      const capitalizedWords = inputString?.split('-')?.map((word) => word?.charAt(0).toUpperCase() + word?.slice(1));

      // Join the words back together with a space
      return capitalizedWords?.join(' ');
    } else {
      // Capitalize the first letter of the string
      return inputString?.charAt(0).toUpperCase() + inputString?.slice(1);
    }
  }

  const setCapitalRole = () => {
    return subdomain === 'org'
      ? capitalizeString(profileData?.role ? profileData?.role : UserData?.role)
      : profileData?.role === 'super-admin'
      ? 'Administrator'
      : capitalizeString(profileData?.role);
  };

  const resetStore = async () => {
    store.dispatch({ type: 'RESET' });
    dispatch(handleLogin({ token: null }));
  };

  return (
    <UncontrolledDropdown tag="li" className="dropdown-user nav-item">
      <DropdownToggle href="/" tag="a" className="nav-link dropdown-user-link" onClick={(e) => e.preventDefault()}>
        <div className="user-nav d-sm-flex d-none">
          <span className="user-name fw-bold text-dark">{setCapitalName() ?? ''}</span>
          <span className="user-status">{setCapitalRole() ?? ''}</span>
        </div>
        <Avatar
          img={(subdomain === 'org' ? profileData?.profile_picture : profileData?.profile_picture) || AvtarUser}
          imgHeight="40"
          imgWidth="40"
          status="online"
        />
      </DropdownToggle>
      <DropdownMenu end>
        <DropdownItem tag={Link} to={`/profile`}>
          <User size={14} className="me-75" />
          <span className="align-middle">Profile</span>
        </DropdownItem>

        <DropdownItem divider />

        <DropdownItem
          tag={Link}
          to="login"
          onClick={() => {
            resetStore();
            localStorage.clear();
            dispatch(
              handleActiveItems({
                id: 'dashboard',
                title: 'Dashboard',
                navLink: 'dashboard',
                permission: ['ALL'],
              }),
            );
            dispatch(handleLogin({ token: null }));
            dispatch(editProfile(false));
          }}
        >
          <Power size={14} className="me-75" />
          <span className="align-middle">Logout</span>
        </DropdownItem>
      </DropdownMenu>
    </UncontrolledDropdown>
  );
};

export default UserDropdown;
