// ** React Imports
import { Fragment, memo } from 'react';

// ** Custom Components
import NavbarUser from './NavbarUser';

// ** Third Party Components
import { Menu } from 'react-feather';

// ** Reactstrap Imports
import { useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom';
import { NavItem, NavLink } from 'reactstrap';
import PropTypes from 'prop-types';

const ThemeNavbar = (props) => {
  const location = useLocation();
  // ** Props
  const { skin, setSkin, setMenuVisibility } = props;
  const { activeItems } = useSelector((state) => state?.root?.layout);

  const checkRoute = location?.pathname.includes('notification')
    ? 'Notification'
    : location?.pathname.includes('profile')
    ? 'Profile'
    : null;

  return (
    <Fragment>
      <div className="bookmark-wrapper d-flex align-items-center">
        <ul className="navbar-nav d-xl-none">
          <NavItem className="mobile-menu me-auto">
            <NavLink
              className="nav-menu-main menu-toggle hidden-xs is-active text-center"
              onClick={() => setMenuVisibility(true)}
            >
              <Menu className="ficon" color="black" />
            </NavLink>
          </NavItem>
        </ul>
        <NavItem className="d-none d-lg-block">
          <NavLink className="nav-link-style fs-3 fw-bolder h1">
            <h1 className="h1 fw-bolder text-center">{checkRoute || activeItems?.parent || activeItems?.title}</h1>
          </NavLink>
        </NavItem>
      </div>
      <NavbarUser skin={skin} setSkin={setSkin} />
    </Fragment>
  );
};

ThemeNavbar.propTypes = {
  skin: PropTypes.any,
  setSkin: PropTypes.any,
  setMenuVisibility: PropTypes.any,
};

export default memo(ThemeNavbar);
