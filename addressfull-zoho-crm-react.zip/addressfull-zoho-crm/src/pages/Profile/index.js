import { useSelector } from 'react-redux';
import { editProfile } from '../../redux/mainLoading';
import OrganizationProfile from './OrganizationProfile';
import ProfileMainTab from './OrganizationProfile/ViewProfile';
import SuperAdminProfile from './SuperAdminProfile';
import Spinner from '@components/spinner/Loading-spinner';
import { useEffect, useState } from 'react';

const Profile = () => {
  const { UserData } = useSelector((state) => state.root.authentication);
  const { edit, isLoading } = useSelector((state) => state?.root?.appLoading);
  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];
  const { layoutStore } = useSelector((state) => state?.root?.layout);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, [layoutStore]);

  if (loading) {
    return <Spinner open={close} />;
  } else if (subdomain === 'admin' || UserData?.role === 'super-admin' || UserData?.role === 'sub-admin') {
    return <SuperAdminProfile />;
  } else if (edit) {
    return <OrganizationProfile setEdit={editProfile} />;
  } else {
    return <ProfileMainTab setEdit={editProfile} />;
  }
};

export default Profile;
