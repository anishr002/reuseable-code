// ** React Imports
import AvtarUser from '@assets/images/portrait/avatar-blank.png';
import 'cleave.js/dist/addons/cleave-phone.us';
import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
// ** Reactstrap Imports
import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Form, FormFeedback, Input, Label, Row } from 'reactstrap';
import * as Yup from 'yup';
import { editProfileAPI } from '../../redux/organizationMain';
import { onSetLogo } from '../../utility/Utils';

const SuperAdminProfile = () => {
  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const dispatch = useDispatch();
  const [countryD, setCountryD] = useState({});

  const [avatar, setAvatar] = useState('');
  const [imageObj, setImageObj] = useState(null);
  const phoneRegex = /^[0-9]{10}$/; // Regex pattern for a 10-digit phone number

  const validationSchema = Yup.object().shape({
    first_name: Yup.string().trim().required('First name is required'),
    last_name: Yup.string().trim().required('Last name is required'),
    email: Yup.string().trim().email('Please enter a valid email address').notRequired('Email is required'),
    phone_number: Yup.string()
      .trim()
      .matches(/^\+\d{11,}$/, 'Please enter a valid phone number with country code')
      .min(10, 'Phone number must be at least 10 characters')
      .required('Phone number is required'),
    role: Yup.object().nullable().notRequired('Please select role type'),
    status: Yup.object().nullable().notRequired('Please select status'),
  });

  const initialValues = {
    first_name: '',
    last_name: '',
    email: profileData?.email || '',
    role: '',
    status: '',
    phone_number: '',
  };

  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    values: initialValues,
    mode: 'onChange',
  });

  useEffect(() => {
    // dispatch(getProfileAPI());
  }, []);

  const onSubmit = (data) => {
    delete data?.email;
    delete data?.role;
    delete data?.status;
    let payload = { ...data };

    const countryCode = (coun, numb) => numb?.substring(0, coun.dialCode.length);
    const phoneNumber = (coun, number) => number?.substring(coun.dialCode.length);

    if (profileData?.role !== 'super-admin') {
      payload = {
        ...data,

        country_code: countryCode(countryD?.country, data?.phone_number?.replace('+', '')),
        mobile_number: phoneNumber(countryD?.country, data?.phone_number?.replace('+', '')),
      };
    }

    delete payload?.phone_number;

    dispatch(editProfileAPI({ ...payload, imageObj }));
  };

  const handleImgReset = () => {
    setAvatar('');
    setImageObj(null);
  };

  useEffect(() => {
    if (profileData) {
      Object.entries(initialValues).forEach(([key, value]) => {
        if (key === 'status') {
          setValue(key, profileData[`${key}`] ? 'Active' : 'InActive');
        } else if (key === 'phone_number') {
          setValue(
            key,
            profileData?.role === 'super-admin'
              ? '+19090909090'
              : profileData?.mobileNumber
              ? `+${profileData?.countryCode + profileData?.mobileNumber}`
              : '',
          );
        } else {
          setValue(key, profileData[`${key}`]);
        }
      });
      setAvatar(profileData?.profile_picture);
      setImageObj(profileData?.profile_picture);
    }
  }, [profileData]);

  const handleImageError = (e) => {
    // Replace the broken image with a default avatar or placeholder
    e.target.src = AvtarUser;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle tag="h4">Profile Picture</CardTitle>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col sm="4">
                <div className="border-end pe-3 d-flex align-item-center mt-75 ">
                  <div className="me-2">
                    <img
                      className="rounded-circle me-100"
                      src={avatar || AvtarUser}
                      alt="Generic_placeholder_image"
                      height="100"
                      width="100"
                      onError={handleImageError}
                    />
                  </div>
                  <div className="d-flex flex-column justify-content-center ms-1 ">
                    <Button tag={Label} className="mb-75  py-1 px-2" size="sm" color="primary" outline>
                      Upload Logo
                      <Input
                        type="file"
                        onChange={(e) => onSetLogo(e, setImageObj, setAvatar)}
                        hidden
                        accept="image/*"
                      />
                    </Button>

                    {avatar && (
                      <Button color="flat-danger" size="sm" onClick={handleImgReset}>
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
              </Col>
              <Col sm="8">
                <div className="ms-2">
                  <CardTitle>Image Specifications</CardTitle>
                  <ol>
                    <li>Min. 400 x 400px</li>
                    <li>Max. 100KB</li>
                    <li>Your face or company logo</li>
                  </ol>
                </div>
              </Col>
            </Row>

            <CardTitle>Details</CardTitle>
            <Row>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="first_name">
                    First Name{''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="first_name"
                    id="first_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.first_name}
                        placeholder="First Name"
                        {...field}
                      />
                    )}
                  />
                  {errors.first_name && <FormFeedback>{errors.first_name.message}</FormFeedback>}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="last_name">
                    Last Name{''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="last_name"
                    name="last_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        placeholder="Last Name"
                        invalid={errors.last_name}
                        {...field}
                      />
                    )}
                  />
                  {errors.last_name && <FormFeedback>{errors.last_name.message}</FormFeedback>}
                </div>
              </Col>
            </Row>
            <Row className="d-flex align-items-center">
              <Col md={profileData?.role !== 'super-admin' ? '6' : '12'}>
                <div className="mb-1">
                  <Label className="form-label" for="email">
                    Email
                  </Label>
                  <Controller
                    name="email"
                    id="email"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="email"
                        className="form-control"
                        placeholder="dom@yopmail.com"
                        {...field}
                        invalid={errors?.email}
                        disabled
                      />
                    )}
                  />
                  <FormFeedback className="d-block">{errors?.email?.message}</FormFeedback>
                </div>
              </Col>
              {profileData?.role !== 'super-admin' && (
                <Col md="6">
                  <div className="mb-1">
                    <Label className="form-label" for="phone_number">
                      Phone Number
                    </Label>

                    <Controller
                      name="phone_number"
                      id="phone_number"
                      className="form-control"
                      control={control}
                      render={(props) => (
                        <div>
                          <PhoneInput
                            as={<input />}
                            ref={props.field.ref}
                            onChange={(e, country) => {
                              props.field.onChange(e);
                              setCountryD(country);
                            }}
                            name="phone_number"
                            inputProps={{
                              id: 'phone_number',
                              name: 'phone_number',
                              // required: true,
                              autoComplete: 'none',
                            }}
                            // country={'us'}
                            value={props.field.value}
                            specialLabel=""
                            inputClassName="form-control"
                            dropdownClass="react-select"
                            inputStyle={{ width: '100%' }}
                            disableDialCodePrefill={true}
                          />
                        </div>
                      )}
                      rules={{
                        required: 'Phone number is required',
                        validate: (value) => value?.match(phoneRegex) || 'Phone number must be at least 10 digits',
                      }}
                    />
                    <FormFeedback className="d-block">{errors?.phone_number?.message}</FormFeedback>
                  </div>
                </Col>
              )}
            </Row>
            <Row>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="role">
                    Role
                  </Label>
                  <Controller
                    name="role"
                    id="role"
                    control={control}
                    render={({ field }) => (
                      <Input
                        autoFocus
                        type="text"
                        className="form-control"
                        invalid={errors.role}
                        placeholder="First Name"
                        {...field}
                        disabled={true}
                      />
                    )}
                  />
                  {errors && errors.role && <FormFeedback className="d-block">{errors.role.message}</FormFeedback>}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="status">
                    Status
                  </Label>
                  <Controller
                    name="status"
                    id="status"
                    control={control}
                    defaultValue={'fty'}
                    render={({ field }) => (
                      <Input
                        autoFocus
                        type="text"
                        className="form-control"
                        invalid={errors.status}
                        placeholder="First Name"
                        {...field}
                        disabled={true}
                      />
                    )}
                  />
                  {errors && errors.status && <FormFeedback className="d-block">{errors.status.message}</FormFeedback>}
                </div>
              </Col>
            </Row>
            <div className="d-flex justify-content-center mt-2">
              <Button color="primary" type="submit" className="d-flex">
                Save
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

export default SuperAdminProfile;
