import AvtarUser from '@assets/images/portrait/avatar-blank.png';
import Spinner from '@components/spinner/Loading-spinner';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';

import DocViewer, { DocViewerRenderers } from '@cyntler/react-doc-viewer';
import './doc-custome.css';
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardTitle,
  Col,
  Label,
  Modal,
  ModalBody,
  ModalHeader,
  Row,
} from 'reactstrap';
import { isObjEmpty } from '../../../utility/Utils';

const ViewProfile = ({ setEdit }) => {
  const dispatch = useDispatch();
  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);
  const [base64Data, setBase64Data] = useState('');
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [viewDoc, setViewDoc] = useState(false);
  const [viewDocURL, setViewDocURL] = useState('');
  const { PrivacyPolicyData } = useSelector((state) => state?.root?.Setting);

  useEffect(() => {
    // dispatch(getProfileAPI());
  }, []);

  useEffect(() => {
    if (!isObjEmpty(profileData)) {
      const binaryData = profileData?.QR_image?.data
        ? Array?.from(profileData?.QR_image?.data)
            .map((byte) => String.fromCharCode(byte))
            .join('')
        : '';
      setBase64Data(profileData?.QR_image?.data ? btoa(binaryData) : '');
    }
  }, [profileData]);

  const isSmallScreen = window.innerWidth < 768;
  const downloadImage = () => {
    // Convert Base64 to Blob
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const blob = new Blob([new Uint8Array(byteNumbers)], { type: 'image/png' });

    // Create a download link
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = profileData?.name + '.png';

    // Append the link to the document and trigger the download
    document.body.appendChild(link);
    link.click();

    // Remove the link from the document
    document.body.removeChild(link);
  };

  const handleImageError = (e) => {
    // Replace the broken image with a default avatar or placeholder
    e.target.src = AvtarUser;
  };

  const policyNameFc = () => {
    return PrivacyPolicyData?.policy_list
      ?.map((i) => ({ value: i?._id, label: i?.title }))
      ?.find((i) => i?.value === profileData?.policy_id);
  };

  const rulesNameFc = () => {
    const validatePolicyName = PrivacyPolicyData?.policy_list?.find((i) => i?._id === profileData?.policy_id);
    const CheckOption = PrivacyPolicyData?.policy_list?.find((i) => i?._id === validatePolicyName?._id);
    const showRules = CheckOption?.sub_rules
      .map((i) => ({ value: i?._id, label: i.name }))
      ?.find((i) => i.value === profileData?.sub_rule_ids[0]);

    return showRules;
  };
  return (
    <Card>
      <CardHeader>
        <CardTitle>View Profile</CardTitle>
      </CardHeader>
      {isLoading ? (
        <Spinner open={close} />
      ) : (
        <CardBody>
          <Row>
            <Col
              md="6"
              style={{
                borderRight: isSmallScreen ? 'none' : '1px solid #ccc',
              }}
            >
              <div className="d-flex justify-content-center ">
                <img
                  className="rounded-circle align-items-center"
                  src={profileData?.profile_picture || AvtarUser}
                  alt="Generic_placeholder_image"
                  height="100"
                  width="100"
                  onError={handleImageError}
                />
              </div>
              <p className="d-flex justify-content-center mt-3">{profileData?.name}</p>
            </Col>
            <Col md="6">
              {base64Data && (
                <>
                  <div className="d-flex justify-content-center">
                    <img
                      className=""
                      src={`data:image/png;base64,${base64Data}`}
                      alt="Generic_placeholder_image"
                      height="100"
                      width="100"
                      // onError={handleImageError}
                    />
                  </div>

                  <div className="d-flex justify-content-center mt-3">
                    <Button color="primary" onClick={() => downloadImage()} outline>
                      Download
                    </Button>
                  </div>
                </>
              )}
            </Col>
          </Row>
          <Row className="mt-5">
            <Col md="6">
              <Label>Organisation Name</Label>
              <p className="mt-2 mx-2">{profileData?.name}</p>
              <hr />
            </Col>
            <Col md="6">
              <Label>Organisation Type</Label>
              <p className="mt-2 mx-2">{profileData?.type}</p>
              <hr />
            </Col>
          </Row>
          <Row>
            <Col md="6">
              <Label>Organisation Registration Number</Label>
              <p className="mt-2  mx-2">{profileData?.registered_number}</p>
              <hr />
            </Col>
            <Col md="6">
              <Label>Registration Date</Label>
              <p className="mt-2  mx-2">{profileData?.date_of_incorporation}</p>
              <hr />
            </Col>
          </Row>
          <Row>
            <Col md="6">
              <Label>Office Address</Label>
              <p className="mt-2  mx-2">{profileData?.office_address}</p>
              <hr />
            </Col>
            <Col md="6">
              <Label>Organisation Description</Label>
              <p className="mt-2  mx-2">{profileData?.description}</p>
              <hr />
            </Col>
          </Row>
          <Row>
            <Col md="6">
              <Label>Website URL</Label>
              <p className="mt-2  mx-2">{profileData?.website}</p>
              <hr />
            </Col>
            <Col md="6">
              <Label>Legal Status</Label>
              <p className="mt-2  mx-2">{profileData?.legal_status}</p>
              <hr />
            </Col>
          </Row>
          <Row>
            <Col md="6">
              {profileData?.twitter && (
                <>
                  <Label>Twitter URL</Label>
                  <p className="mt-2  mx-2">{profileData?.twitter}</p>
                  <hr />
                </>
              )}
            </Col>
            <Col md="6">
              {profileData?.linkedin && (
                <>
                  <Label>LinkedIn URL</Label>
                  <p className="mt-2  mx-2">{profileData?.linkedin}</p>
                  <hr />
                </>
              )}
            </Col>
          </Row>
          <Row>
            <Col md="6">
              <Label>Email</Label>
              {profileData?.email_id?.map((i, _index) => (
                <div key={i}>
                  <p className="mt-2  mx-2">{i}</p>
                  <hr />
                </div>
              ))}
            </Col>
            <Col md="6">
              <Label>Contact Number</Label>
              {profileData?.contact_number?.map((i, _index) => (
                <div key={i}>
                  <p className="mt-2  mx-2">{i?.replace('|', ' ')}</p>
                  <hr />
                </div>
              ))}
            </Col>
            <Col md="6">
              {profileData?.policy_id && (
                <>
                  <Label>Policy</Label>
                  <p className="mt-2  mx-2">{policyNameFc()?.label}</p>
                  <hr />
                </>
              )}
            </Col>
            <Col md="6">
              {profileData?.policy_id && (
                <>
                  <Label>Rules</Label>
                  <p className="mt-2  mx-2">{rulesNameFc()?.label}</p>
                  <hr />
                </>
              )}
            </Col>
          </Row>

          <Row>
            {profileData?.documents?.length > 0 && <CardTitle className="pt-2">View Document</CardTitle>}
            <Col md="12">
              {profileData?.documents?.map((i, _index) => (
                <div key={i}>
                  <p
                    className="mt-2  mx-2 text-primary cursor-pointer"
                    onClick={() => {
                      setViewDocURL(i);
                      setViewDoc(true);
                    }}
                  >
                    {i?.type}
                  </p>
                  <hr />
                </div>
              ))}
            </Col>
          </Row>

          <Modal
            isOpen={viewDoc}
            toggle={() => setViewDoc(!viewDoc)}
            className="modal-dialog-centered"
            onClosed={() => setViewDoc(false)}
            scrollable={true}
            size="lg"
            fullscreen={true}
          >
            <ModalHeader toggle={() => setViewDoc(!viewDoc)}>{viewDocURL?.type}</ModalHeader>

            <h2 className="text-center mb-1"> </h2>
            <ModalBody className="px-sm-5 mx-50 pb-5">
              <DocViewer
                documents={[{ uri: viewDocURL?.url }]}
                pluginRenderers={DocViewerRenderers}
                style={{ width: '100', height: '100' }}
                config={{
                  header: {
                    disableHeader: true,
                    disableFileName: true,
                    retainURLParams: true,
                  },
                }}
              />
            </ModalBody>
          </Modal>

          <div className="mt-3 d-flex justify-content-center" color="primary">
            <Button onClick={() => dispatch(setEdit(true))} color="primary">
              Edit
            </Button>
          </div>
        </CardBody>
      )}
    </Card>
  );
};

export default ViewProfile;
