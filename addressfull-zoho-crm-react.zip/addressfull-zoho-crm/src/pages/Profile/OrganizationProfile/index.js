import React, { useState, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Card, Nav, NavItem, NavLink, TabContent, TabPane, Tooltip, Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import { setProfileManTab } from '../../../redux/organizationMain';
import { isObjEmpty } from '../../../utility/Utils';
import OrganizationProfileDetails from './Details';
import Documents from './Documents';

const ProfileMainTab = ({ setEdit }) => {
  const dispatch = useDispatch();
  const [tooltipOpen, setTooltipOpen] = useState(false);
  const [showWarningModal, setShowWarningModal] = useState(false);
  const [pendingTab, setPendingTab] = useState(null);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const toggle = () => {
    setTooltipOpen(!tooltipOpen);
  };

  const { profileData, ProfileTab } = useSelector((state) => state?.root.Organization.OrganizationDetailes);

  // useEffect(() => {
  //   ProfileTab === '1' && dispatch(getOrganizationManagmentListAPI());
  // }, []);

  const handleTabSwitch = (tabId) => {
    // If switching from Details tab and there are unsaved changes, show warning
    if (ProfileTab === '1' && tabId === '2' && hasUnsavedChanges) {
      setPendingTab(tabId);
      setShowWarningModal(true);
    } else if (tabId === '2' && !isObjEmpty(profileData)) {
      dispatch(setProfileManTab(tabId));
    } else if (tabId === '1') {
      dispatch(setProfileManTab(tabId));
    }
  };

  const confirmTabSwitch = () => {
    setHasUnsavedChanges(false);
    setShowWarningModal(false);
    if (pendingTab) {
      dispatch(setProfileManTab(pendingTab));
      setPendingTab(null);
    }
  };

  const cancelTabSwitch = () => {
    setShowWarningModal(false);
    setPendingTab(null);
  };

  return (
    <Card>
      <div className="d-flex">
        <Nav tabs className="mt-2 mx-2 h4">
          <NavItem>
            <NavLink active={ProfileTab === '1'} onClick={() => handleTabSwitch('1')}>
              Details
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink
              active={ProfileTab === '2'}
              disabled={isObjEmpty(profileData)}
              onClick={() => handleTabSwitch('2')}
              id="doc"
              style={isObjEmpty(profileData) ? { cursor: 'not-allowed', pointerEvents: 'auto' } : {}}
            >
              Documents
              <Tooltip placement={'right'} isOpen={tooltipOpen} target="doc" toggle={toggle}>
                Please complete your profile details to access Documents.
              </Tooltip>
            </NavLink>
          </NavItem>
        </Nav>
        {!isObjEmpty(profileData) && (
          <div className="ms-auto">
            <Button
              className="d-flex mx-2 mt-2"
              color="primary"
              disabled={isObjEmpty(profileData)}
              onClick={() => dispatch(setEdit(false))}
            >
              Back to view
            </Button>
          </div>
        )}
      </div>

      <TabContent className="py-50" activeTab={ProfileTab}>
        <TabPane tabId="1">
          <OrganizationProfileDetails setHasUnsavedChanges={setHasUnsavedChanges} />
        </TabPane>
        <TabPane tabId="2">
          <Documents />
        </TabPane>
      </TabContent>

      {/* Warning Modal */}
      <Modal isOpen={showWarningModal} toggle={cancelTabSwitch} centered>
        <ModalHeader toggle={cancelTabSwitch}>Unsaved Changes</ModalHeader>
        <ModalBody>
          If you have any unsaved changes in the Details tab, switching tabs now will cause you to lose them. Do you want to continue?
        </ModalBody>
        <ModalFooter>
          <Button color="secondary" onClick={cancelTabSwitch}>
            Cancel
          </Button>
          <Button color="danger" onClick={confirmTabSwitch}>
            Continue Without Saving
          </Button>
        </ModalFooter>
      </Modal>
    </Card>
  );
};

export default ProfileMainTab;
