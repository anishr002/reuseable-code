import React, { Fragment, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown, Eye, Trash2, Info } from 'react-feather';

import DocViewer, { DocViewerRenderers } from '@cyntler/react-doc-viewer';
import './doc-custome.css';

import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import { useDispatch, useSelector } from 'react-redux';
import { Button, CardHeader, Modal, ModalBody, ModalHeader, Tooltip } from 'reactstrap';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { getProfileAPI } from '../../../redux/organizationMain';
import { deleteDocumnetOfOrgAPI } from '../../../redux/organizationManagment';
import FileUpload from './FileUpload';

const Documents = () => {
  const dispatch = useDispatch();

  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const MySwal = withReactContent(Swal);
  const [show, setShow] = useState(false);
  const [viewDoc, setViewDoc] = useState(false);
  const [viewDocURL, setViewDocURL] = useState('');
  const [tooltipOpen, setTooltipOpen] = useState(false);

  const toggle = () => {
    setTooltipOpen(!tooltipOpen);
  };
  const data = profileData?.documents?.map((item) => ({
    profile_image: item?.url,
    name_of_document: item?.type,
    id: item?.id,
  }));

  const showAlert = (item) => {
    return MySwal.fire({
      title: 'Remove Document',
      html: (
        <p>
          Are you sure
          <br />
          you want to remove this document <span style={{ fontWeight: 'bold' }}>{item?.name_of_document}</span> ?
        </p>
      ),
      icon: 'warning',
      showCancelButton: false,
      confirmButtonText: 'Remove',
      showCloseButton: true,
      customClass: {
        confirmButton: 'd-flex w-100 btn btn-primary btn-ripple btn-block',
      },
      buttonsStyling: false,
    }).then(function (result) {
      if (result.isConfirmed) {
        dispatch(deleteDocumnetOfOrgAPI({ doc_id: item?.id, org_id: profileData?._id })).then(() =>
          dispatch(getProfileAPI()),
        );
        setViewDocURL('');
      }
    });
  };

  const columns = [
    {
      name: 'Document Name',
      minWidth: '180px',
      sortable: false,
      cell: (row) => row?.name_of_document,
    },
    {
      name: 'Actions',
      allowOverflow: true,
      minWidth: '150px',
      cell: (row) => {
        return (
          <div className="d-flex">
            <Eye
              size={16}
              className="me-2 cursor-pointer icon-color-cust"
              onClick={() => {
                setViewDoc(true);
                setViewDocURL(row);
              }}
            />
            <Trash2 size={16} color="red" className="cursor-pointer icon-color-cust" onClick={() => showAlert(row)} />
          </div>
        );
      },
    },
  ];

  console.log('#########3333', viewDocURL?.profile_image?.match(/\.([a-zA-Z0-9]+)$/)?.[1]);

  return (
    <Fragment>
      <CardHeader className="border-bottom ">
        {/* <CardText tag="h3">Uploaded Document</CardText> */}
        <div className="d-flex ms-auto align-items-center">
          <Tooltip placement={'right'} isOpen={tooltipOpen} target="upload-b" toggle={toggle}>
            To update existing document, delete first then upload.
          </Tooltip>
          <Info id="upload-b" className="me-1" />
          <Button color="primary" onClick={() => setShow(true)}>
            Upload
          </Button>
        </div>
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          responsive
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          persistTableHead={true}
          customStyles={customStyles}
        />
      </div>
      <Modal
        isOpen={show}
        toggle={() => setShow(!show)}
        className="modal-dialog-centered"
        onClosed={() => setShow(false)}
      >
        <ModalHeader toggle={() => setShow(!show)}>Upload</ModalHeader>

        <h2 className="text-center mb-1"> </h2>
        <ModalBody className="px-sm-5 mx-50 pb-5">
          <FileUpload setShow={setShow} />
        </ModalBody>
      </Modal>
      <Modal
        isOpen={viewDoc}
        toggle={() => setViewDoc(!viewDoc)}
        className="modal-dialog-centered"
        onClosed={() => setViewDoc(false)}
        scrollable={true}
        size="lg"
        fullscreen={true}
      >
        <ModalHeader toggle={() => setViewDoc(!viewDoc)}>{viewDocURL?.name_of_document}</ModalHeader>

        <h2 className="text-center mb-1"> </h2>
        <ModalBody className="px-sm-5 mx-50 pb-5">
          <div className="w-full ">
            <DocViewer
              documents={[{ uri: viewDocURL?.profile_image }]}
              pluginRenderers={DocViewerRenderers}
              style={{ width: '100', height: '100' }}
              config={{
                header: {
                  disableHeader: true,
                  disableFileName: true,
                  retainURLParams: true,
                },
              }}
            />
          </div>
        </ModalBody>
      </Modal>
    </Fragment>
  );
};

export default Documents;
