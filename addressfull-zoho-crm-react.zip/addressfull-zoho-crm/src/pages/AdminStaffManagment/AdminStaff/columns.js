import { Edit2, Trash2 } from 'react-feather';
import { Link } from 'react-router-dom';
import { Badge } from 'reactstrap';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { deleteAdminAPI } from '../../../redux/adminStaffManagment';
import { store } from '../../../redux/store';

const MySwal = withReactContent(Swal);

const showAlert = (_id) => {
  return MySwal.fire({
    title: 'Delete Admin',
    html: (
      <p>
        Are you sure?
        <br />
        You want to delete this Admin
      </p>
    ),
    icon: 'warning',
    showCancelButton: false,
    confirmButtonText: 'Delete',
    showCloseButton: true,
    customClass: {
      confirmButton: 'd-flex w-100 btn btn-primary btn-ripple btn-block',
    },
    buttonsStyling: false,
  }).then(function (result) {
    if (result.isConfirmed) {
      store.dispatch(deleteAdminAPI(_id));
    }
  });
};

export const columns = [
  {
    name: 'Admin Name',
    minWidth: '150px',
    sortable: true,
    sortName: 'first_name',
    cell: (row) => `${row?.first_name ?? ''} ${row?.last_name ?? ''}`,
  },
  {
    name: 'ID',
    // sortable: true,
    minWidth: '250px',
    selector: (row) => row.id,
  },
  {
    name: 'Email',
    sortable: true,
    minWidth: '250px',
    sortName: 'email',
    selector: (row) => row.email,
  },
  {
    name: 'Role',
    sortable: false,
    minWidth: '150px',
    selector: (row) => (row?.role ? row?.role?.name : '-'),
  },
  {
    name: 'Status',
    sortable: true,
    minWidth: '150px',
    sortName: 'active',
    selector: (row) => {
      return (
        <Badge color={row?.active === true ? '' : 'danger'} className={row?.active === true ? 'custom-badge' : ''} pill>
          {row.active ? 'Active' : 'InActive'}
        </Badge>
      );
    },
  },
  {
    name: 'Actions',
    allowOverflow: true,
    cell: (row) => {
      return row?.writePermission ? (
        <div className="d-flex">
          <Link to={`edit/${row?.id}`} className="text-decoration-none">
            <Edit2 size={16} className="me-2 cursor-pointer icon-color-cust" />
          </Link>
          <Trash2 size={16} color="red" className="cursor-pointer icon-color-cust" onClick={() => showAlert(row?.id)} />
        </div>
      ) : (
        <div></div>
      );
    },
  },
];
