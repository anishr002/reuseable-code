// ** React Imports
import 'cleave.js/dist/addons/cleave-phone.us';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
// ** Reactstrap Imports
import { Button, Card, CardBody, CardHeader, CardText, Col, Form, FormFeedback, Input, Label, Row } from 'reactstrap';

import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import { useEffect } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import Select from 'react-select';
import * as Yup from 'yup';
import {
  addAdminStaffAPI,
  editAdminStaffAPI,
  getAdminStaffRolesAPI,
  getSingleAdminStaffDetailestAPI,
} from '../../../redux/adminStaffManagment';

const validationSchema = (_isEdit) => {
  const baseSchema = {
    first_name: Yup.string().trim().required('First name is required'),
    last_name: Yup.string().trim().required('Last name is required'),
    admin_role: Yup.object().nullable().required('Please select role type'),
    admin_status: Yup.object().nullable().required('Please select status'),
    email: Yup.string().trim().email('Please enter a valid email address').required('Email is required'),
  };

  return Yup.object().shape(baseSchema);
};

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { AdminRoles, singleAdminStaffDetailes } = useSelector(
    (state) => state?.root?.AdminStaffManagment?.AdminStaffManagmentData,
  );

  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const isEditRoute = () => location.pathname.includes('edit');

  const initialValues = {
    admin_status: { value: true, label: 'Active' },
    admin_role: null,
    email: '',
    first_name: '',
    last_name: '',
  };

  const schema = validationSchema(id);

  const {
    control,
    handleSubmit,
    formState: { errors },
    setValue,
  } = useForm({
    resolver: yupResolver(schema),
    values: initialValues,
  });

  useEffect(() => {
    id && dispatch(getSingleAdminStaffDetailestAPI(id));
    if (!isEditRoute()) {
      initialValues.password = '';
      dispatch(getAdminStaffRolesAPI());
    }
  }, [id]);

  const activeStatusOptions = [
    { value: true, label: 'Active' },
    { value: false, label: 'InActive' },
  ];

  const statusOptions = AdminRoles?.role_list
    ?.filter((i) => i?.active)
    ?.map((item) => ({
      value: item?.id,
      label: item?.name,
    }));

  useEffect(() => {
    // initialValues.admin_status =
    if (singleAdminStaffDetailes && id) {
      const { active, email, first_name, last_name, role } = singleAdminStaffDetailes;

      initialValues.admin_status = activeStatusOptions?.find((p) => p.value === active);
      initialValues.admin_role = statusOptions?.find((p) => p.value === role);
      initialValues.email = email;
      initialValues.first_name = first_name;
      initialValues.last_name = last_name;

      Object?.entries(initialValues)?.forEach(([key, value]) => {
        setValue(key, value);
      });
    }
  }, [singleAdminStaffDetailes, AdminRoles]);

  const onSubmit = (data) => {
    const payload = { ...data, status: data?.admin_status?.value, role: data?.admin_role?.value };
    delete payload?.admin_role;
    delete payload?.admin_status;
    id && delete payload.email;

    isEditRoute() ? dispatch(editAdminStaffAPI(payload, id, navigate)) : dispatch(addAdminStaffAPI(payload, navigate));
  };
  return (
    <Card>
      <CardHeader>
        <CardText tag="h3"> {id ? 'Edit' : 'Add'} Admin</CardText>
        <Link to={`/admin/listing`}>
          {!isLoading && (
            <Button disabled={isLoading} color="primary">
              Back
            </Button>
          )}
        </Link>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="first_name">
                    First Name {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="first_name"
                    id="first_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.first_name}
                        placeholder="First Name"
                        {...field}
                      />
                    )}
                  />
                  {errors.first_name && <FormFeedback>{errors.first_name.message}</FormFeedback>}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="last_name">
                    Last Name {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="last_name"
                    id="last_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.last_name}
                        placeholder="Last Name"
                        {...field}
                      />
                    )}
                  />
                  {errors.last_name && <FormFeedback>{errors.last_name.message}</FormFeedback>}
                </div>
              </Col>
            </Row>
            <Row>
              <Col md="12">
                <div className="mb-1">
                  <Label className="form-label" for="email">
                    Email {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name={`email`}
                    control={control}
                    defaultValue={''}
                    render={({ field }) => (
                      <Input
                        type="email"
                        className="form-control"
                        placeholder="demo@gmail.com"
                        {...field}
                        invalid={errors?.email?.message}
                        disabled={id ? true : false}
                      />
                    )}
                  />
                  <FormFeedback className="d-block">{errors?.email?.message}</FormFeedback>
                </div>
              </Col>
            </Row>

            <Row>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="admin_role">
                    Role {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="admin_role"
                    id="admin_role"
                    control={control}
                    defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={statusOptions}
                        className="react-select"
                        classNamePrefix="select"
                        invalid={errors.admin_role}
                        menuShouldScrollIntoView={true}
                        styles={{
                          control: (baseStyles, _state) => ({
                            ...baseStyles,
                            borderColor: errors.admin_role ? 'red' : '#d8d6de',
                          }),
                        }}
                        isSearchable
                        placeholder="Please select role"
                      />
                    )}
                  />
                  {errors && errors.admin_role && (
                    <FormFeedback className="d-block">{errors.admin_role.message}</FormFeedback>
                  )}
                </div>
              </Col>
              <Col md="6">
                <div className="mb-1">
                  <Label className="form-label" for="admin_status">
                    Status {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="admin_status"
                    id="admin_status"
                    control={control}
                    defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={activeStatusOptions}
                        className="react-select"
                        classNamePrefix="select"
                        invalid={errors.admin_status}
                        styles={{
                          control: (baseStyles, _state) => ({
                            ...baseStyles,
                            borderColor: errors.admin_status ? 'red' : '#d8d6de',
                          }),
                        }}
                        isSearchable={false}
                        placeholder="Active"
                      />
                    )}
                  />
                  {errors && errors.admin_status && (
                    <FormFeedback className="d-block">{errors.admin_status.message}</FormFeedback>
                  )}
                </div>
              </Col>
            </Row>

            <div className="d-flex justify-content-center mt-2">
              <Button color="primary" type="submit" className="d-flex">
                {isEditRoute() ? 'Save' : 'Add'}
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

export default AddEdit;
