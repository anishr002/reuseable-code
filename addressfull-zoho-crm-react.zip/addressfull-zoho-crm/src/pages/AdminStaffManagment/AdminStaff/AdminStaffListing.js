import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Button, Card, CardHeader, CardText } from 'reactstrap';
import CustomHeader from '../../../components/tableCusHeader/CustomHeader';
import { getAdminStaffListingAPI, getAdminStaffRolesAPI, setPaginationList } from '../../../redux/adminStaffManagment';
import { useDebouncedValue } from '../../../utility/hooks/useDebouncedValue';
import { columns } from './columns';

const AdminStaffListing = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(1);
  const [defaultRoleSelect, setDefaultRoleSelect] = useState(null);
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const { AdminStaffListingData, rowsPerPagesData, paginationDefaultList, AdminRoles } = useSelector(
    (state) => state?.root?.AdminStaffManagment?.AdminStaffManagmentData,
  );
  const { UserData } = useSelector((state) => state.root?.authentication);

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);
  const writePermission = UserData?.permissions?.find((item) => item?.section === 'admins')?.permissions?.write;

  const readPermission = UserData?.permissions?.find((item) => item?.section === 'admins')?.permissions?.read;

  const data = AdminStaffListingData?.admin_list?.map((i) => ({ ...i, writePermission }));

  const apiCallPagination = () => {
    let payload = {};

    if (searchValue.trim()) {
      payload.search = searchValue;
    }
    if (defaultRoleSelect && defaultRoleSelect.label !== 'ALL') {
      payload.role = defaultRoleSelect?.value;
    }

    if (!searchValue.trim() && !defaultRoleSelect?.label) {
      payload = {};
    }

    return payload;
  };

  useEffect(() => {
    readPermission && dispatch(getAdminStaffRolesAPI());
  }, []);

  const handleRoleChange = (e) => {
    setDefaultRoleSelect(e);
    const payload = { ...paginationDefaultList };
    payload.role = e.value;

    if (searchValue.trim()) {
      payload.search = searchValue;
    }

    dispatch(getAdminStaffListingAPI(payload));
  };

  useEffect(() => {
    const payload = { ...paginationDefaultList, page: currentPage, page_size: rowsPerPagesData };
    if (defaultRoleSelect) {
      payload.role = defaultRoleSelect.value;
    }
    if (searchValue.trim()) {
      payload.search = searchValue;

      dispatch(getAdminStaffListingAPI(payload));
    } else {
      delete payload?.search;

      readPermission && dispatch(getAdminStaffListingAPI(payload));
    }
  }, [debouncedValue]);

  useEffect(() => {
    setCurrentPage(AdminStaffListingData?.page_info?.current_page);
    setTotalCount(AdminStaffListingData?.page_info?.total_count);
    setRowsPerPage(rowsPerPagesData);
  }, [AdminStaffListingData]);

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Staff Listings</CardText>
        {writePermission && (
          <Button color="primary" className="d-flex ms-auto " onClick={() => navigate('add')}>
            ADD
          </Button>
        )}
      </CardHeader>

      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          responsive
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: 'Rows per page:',
            rangeSeparatorText: 'of',
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: 'All',
          }}
          paginationPerPage={paginationDefaultList?.page_size}
          paginationTotalRows={totalCount}
          paginationServer={true}
          paginationDefaultPage={paginationDefaultList.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={(page, _totalRows) => {
            setCurrentPage(page);
            dispatch(getAdminStaffListingAPI({ ...paginationDefaultList, page, ...apiCallPagination() }));
          }}
          onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
            dispatch(
              getAdminStaffListingAPI({
                ...paginationDefaultList,
                page: currentPage,
                page_size: currentRowsPerPage,
                ...apiCallPagination(),
              }),
            );
          }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          customStyles={customStyles}
          onSort={(column, order) => {
            dispatch(
              getAdminStaffListingAPI({
                page: currentPage,
                page_size: rowsPerPage,
                order_by: order,
                sort_by: column?.sortName,
              }),
              dispatch(
                setPaginationList({
                  page: currentPage,
                  page_size: rowsPerPage,
                  order_by: order,
                  sort_by: column?.sortName,
                }),
              ),
            );
          }}
          persistTableHead={true}
          subHeaderComponent={
            <CustomHeader
              searchValue={searchValue}
              handle_filter={handleFilter}
              AdminRoles={AdminRoles}
              is_filter={true}
              defaultRoleSelect={defaultRoleSelect}
              setDefaultRoleSelect={handleRoleChange}
              write_p={writePermission}
            />
          }
        />
      </div>
    </Card>
  );
};

export default AdminStaffListing;
