// ** React Imports
import InputPassword from '@components/input-password-toggle';
import 'cleave.js/dist/addons/cleave-phone.us';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch } from 'react-redux';
// ** Reactstrap Imports
import { Button, Card, CardBody, CardHeader, CardText, Col, Form, FormFeedback, Label, Row } from 'reactstrap';

import { yupResolver } from '@hookform/resolvers/yup';
import { Link, useLocation } from 'react-router-dom';
import * as Yup from 'yup';
import { changePasswordApi } from '../../../redux/authentication';

const AdminStaffChangePassword = () => {
  const dispatch = useDispatch();
  const location = useLocation();

  const validationSchema = Yup.object().shape({
    newPassword: Yup.string()
      .trim()
      .required('Please enter new password')
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,16})/,
        'Password must be 8-16 characters and include at least one uppercase letter, one lowercase letter, and one special character',
      )
      .max(16, 'Password must not exceed 16 characters'),

    confirmPassword: Yup.string()
      .trim()
      .required('Password confirmation is required')
      .oneOf([Yup.ref('newPassword'), null], 'Passwords must match'),
    currentPassword: Yup.string().trim().required('current password is required'),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      newPassword: '',
      confirmPassword: '',
      currentPassword: '',
    },
  });

  const onSubmit = (data) => {
    dispatch(changePasswordApi(data));
  };

  return (
    <Card>
      <CardHeader>
        <CardText tag="h5">Change Password</CardText>
        <Link to={`/admin/listing/edit/${location.pathname.split('/')[location.pathname.split('/').length - 1]}`}>
          <Button color="primary">Back</Button>
        </Link>
      </CardHeader>
      <CardBody>
        <Form className="" onSubmit={handleSubmit(onSubmit)}>
          <Row>
            <Col md="6" sm="12">
              <div className="mb-1">
                <Label className="form-label" for="currentPassword">
                  Current Password
                </Label>
                <Controller
                  id="currentPassword"
                  name="currentPassword"
                  control={control}
                  render={({ field }) => (
                    <InputPassword
                      autoFocus
                      className="input-group-merge"
                      inputClassName="border-less-input"
                      invalid={errors.currentPassword}
                      {...field}
                    />
                  )}
                />
                {errors.currentPassword && <FormFeedback>{errors.currentPassword.message}</FormFeedback>}
              </div>
            </Col>
          </Row>
          <Row>
            <Col md="6" sm="12">
              <div className="mb-1">
                <Label className="form-label" for="newPassword">
                  New Password
                </Label>
                <Controller
                  id="newPassword"
                  name="newPassword"
                  control={control}
                  render={({ field }) => (
                    <InputPassword
                      className="input-group-merge"
                      inputClassName="border-less-input"
                      invalid={errors.newPassword}
                      {...field}
                    />
                  )}
                />
                {errors.newPassword && <FormFeedback>{errors.newPassword.message}</FormFeedback>}
              </div>
            </Col>
          </Row>
          <Row>
            <Col md="6" sm="12">
              <div className="mb-1">
                <Label className="form-label" for="confirmPassword">
                  Confirm Password
                </Label>
                <Controller
                  id="confirmPassword"
                  name="confirmPassword"
                  control={control}
                  render={({ field }) => (
                    <InputPassword
                      className="input-group-merge"
                      inputClassName="border-less-input"
                      invalid={errors.confirmPassword}
                      {...field}
                    />
                  )}
                />
                {errors.confirmPassword && <FormFeedback>{errors.confirmPassword.message}</FormFeedback>}
              </div>
            </Col>
          </Row>
          <Row>
            <Col md="6" sm="12">
              <Button color="primary" type="submit" block>
                Reset Password
              </Button>
            </Col>
          </Row>
        </Form>
      </CardBody>
    </Card>
  );
};

export default AdminStaffChangePassword;
