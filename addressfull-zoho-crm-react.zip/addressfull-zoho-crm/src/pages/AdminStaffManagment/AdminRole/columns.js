import { Edit2, Trash2 } from 'react-feather';
import { Link } from 'react-router-dom';
import { Badge } from 'reactstrap';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { deleteRoleAPI } from '../../../redux/adminStaffManagment';
import { store } from '../../../redux/store';

const mySwal = withReactContent(Swal);

const showAlert = (_id) => {
  return mySwal
    .fire({
      title: 'Delete Role',
      html: (
        <p>
          Are you sure
          <br />
          you want to delete this role ?
        </p>
      ),
      icon: 'warning',
      showCancelButton: false,
      confirmButtonText: 'Delete',
      showCloseButton: true,
      customClass: {
        confirmButton: 'd-flex w-100 btn btn-primary btn-ripple btn-block',
      },
      buttonsStyling: false,
    })
    .then(function (result) {
      if (result.isConfirmed) {
        store.dispatch(deleteRoleAPI(_id));
      }
    });
};

export const columns = [
  {
    name: 'Role',
    minWidth: '150px',
    sortable: 'name',
    cell: (row) => row?.role_name,
  },
  {
    name: 'Status',
    sortable: 'active',
    minWidth: '150px',
    selector: (row) => {
      return (
        <Badge
          color={row?.status === 'active' ? '' : 'danger'}
          className={row?.status === 'active' ? 'custom-badge' : ''}
          pill
        >
          {row?.status === 'active' ? 'Active' : 'InActive'}
        </Badge>
      );
    },
  },
  {
    name: 'Actions',
    allowOverflow: true,
    cell: (row) => {
      return row?.writePermission ? (
        <div className="d-flex">
          <Link to={`edit/${row?.id}`} className="text-decoration-none">
            <Edit2 size={16} className="me-2 cursor-pointer icon-color-cust" />
          </Link>
          <Trash2 size={16} color="red" className="cursor-pointer icon-color-cust" onClick={() => showAlert(row?.id)} />
        </div>
      ) : (
        <div></div>
      );
    },
  },
];
