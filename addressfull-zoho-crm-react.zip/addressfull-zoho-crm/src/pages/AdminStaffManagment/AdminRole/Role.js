import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Button, Card, CardHeader, CardText } from 'reactstrap';
import { getAdminStaffRolesAPI } from '../../../redux/adminStaffManagment';
import { columns } from './columns';

const Role = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(1);
  const { AdminRoles, rowsPerPagesData } = useSelector(
    (state) => state?.root?.AdminStaffManagment?.AdminStaffManagmentData,
  );
  const { paginationDefaultRole } = useSelector((state) => state?.root?.AdminStaffManagment?.AdminStaffManagmentData);
  const { UserData } = useSelector((state) => state.root?.authentication);

  const writePermission = UserData?.permissions.find((item) => item.section === 'roles')?.permissions?.write;
  const readPermission = UserData?.permissions?.find((item) => item?.section === 'roles')?.permissions?.read;

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);

  const data = AdminRoles?.role_list?.map((item) => ({
    role_name: item?.name,
    id: item?.id,
    status: item?.active ? 'active' : 'Inactive',
    writePermission,
  }));

  useEffect(() => {
    readPermission && dispatch(getAdminStaffRolesAPI({ ...paginationDefaultRole }));
  }, []);

  useEffect(() => {
    setCurrentPage(AdminRoles?.page_info?.current_page);
    setTotalCount(AdminRoles?.page_info?.total_count);
    setRowsPerPage(rowsPerPagesData);
  }, [AdminRoles]);

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Roles</CardText>
        {writePermission && (
          <Button color="primary" className="d-flex ms-auto " onClick={() => navigate('add')}>
            ADD
          </Button>
        )}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: 'Rows per page:',
            rangeSeparatorText: 'of',
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: 'All',
          }}
          paginationPerPage={paginationDefaultRole.page_size}
          paginationTotalRows={totalCount}
          paginationServer={true}
          paginationDefaultPage={paginationDefaultRole.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={(page, _totalRows) => {
            setCurrentPage(page);
            dispatch(getAdminStaffRolesAPI({ ...paginationDefaultRole, page }));
          }}
          onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
            dispatch(
              getAdminStaffRolesAPI({ ...paginationDefaultRole, page: currentPage, page_size: currentRowsPerPage }),
            );
          }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={(column, order) => {
            dispatch(
              getAdminStaffRolesAPI({
                page: currentPage,
                page_size: rowsPerPage,
                order_by: order,
                sort_by: column?.sortable,
              }),
            );
          }}
          persistTableHead={true}
          customStyles={customStyles}
        />
      </div>
    </Card>
  );
};

export default Role;
