// ** React Imports
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
// ** Reactstrap Imports
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Input,
  Label,
  Row,
  Table,
} from 'reactstrap';

import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import 'cleave.js/dist/addons/cleave-phone.us';
import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import Select from 'react-select';
import * as Yup from 'yup';
import {
  addAdminRoleAPI,
  editAdminRoleAPI,
  getModuleListAPI,
  getRoleDetailestAPI,
} from '../../../redux/adminStaffManagment';
import { isObjEmpty } from '../../../utility/Utils';

const AddEdit = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const isEditoute = () => location.pathname.includes('edit');
  const { singleRoleDetailes, AdminModuleListing } = useSelector(
    (state) => state?.root?.AdminStaffManagment?.AdminStaffManagmentData,
  );
  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);

  const [permissions, setPermissions] = useState({});

  const initialValues = {
    role_name: '',
    status_of_role: null,
  };

  const validationSchema = Yup.object().shape({
    role_name: Yup.string().trim().required('Role is required'),
    status_of_role: Yup.object().nullable().required('Please select status'),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    // values,
    setValue,
  } = useForm({
    resolver: yupResolver(validationSchema),
    values: initialValues,
  });

  useEffect(() => {
    Promise.all([isEditoute() ? dispatch(getRoleDetailestAPI(id)) : Promise.resolve(), dispatch(getModuleListAPI())])
      .then(([_roleDetailsResponse, _moduleListResponse]) => {
        // Both API calls have completed
      })
      .catch((_error) => {
        // Handle errors if any of the API calls fail
      });
  }, []);

  useEffect(() => {
    if (!isEditoute() && AdminModuleListing?.length !== 0) {
      const initialPermissions = {};
      AdminModuleListing?.forEach((role) => {
        if (profileData?.role === 'super-admin' || profileData?.role === 'organization-admin') {
          initialPermissions[`${role?.name}`] = {
            read: false,
            read_write: false,
            not_aplicable: true,
          };
        } else {
          if (role?.permission && role?.title) {
            initialPermissions[`${role?.module}`] = {
              read: false,
              read_write: false,
              not_aplicable: true,
            };
          }
        }
      });
      setPermissions(initialPermissions);
    }
  }, [AdminModuleListing]);

  const permissionConst = {
    read: 'read',
    read_write: 'read-write',
    not_aplicable: null,
  };

  const convertToPermissionsArray = () => {
    const permissionsArray = [];

    Object.entries(permissions).forEach(([role, rolePermissions]) => {
      Object.entries(rolePermissions).forEach(([permission, value]) => {
        if (value) {
          permissionsArray.push({
            module: role,
            permission: permissionConst[`${permission}`],
          });
        }
      });
    });
    return permissionsArray;
  };

  const onSubmit = (data) => {
    const payload = {
      name: data?.role_name,
      status: data?.status_of_role?.value,
      permissions: convertToPermissionsArray(),
    };

    isEditoute() ? dispatch(editAdminRoleAPI(payload, navigate, id)) : dispatch(addAdminRoleAPI(payload, navigate));
  };

  const statusOptions = [
    { value: true, label: 'Active' },
    { value: false, label: 'InActive' },
  ];

  useEffect(() => {
    if (isEditoute()) {
      setValue(
        'status_of_role',
        singleRoleDetailes?.active ? { value: true, label: 'Active' } : { value: false, label: 'Inactive' },
      );
      setValue('role_name', singleRoleDetailes?.name);
      const initialPermissions = {};

      singleRoleDetailes?.permissions?.forEach((role) => {
        initialPermissions[`${role.module}`] = {
          read: role?.permission === 'read' ? true : false,
          read_write: role?.permission === 'read-write' ? true : false,
          not_aplicable: role?.permission === null ? true : false,
        };
      });
      setPermissions(initialPermissions);
    }
  }, [singleRoleDetailes]);

  const handleCheckboxChange = (role, permission) => {
    if (permission === 'not_aplicable') {
      setPermissions((prevPermissions) => ({
        ...prevPermissions,
        [role]: {
          read: false,
          read_write: false,
          not_aplicable: true,
        },
      }));
    } else if (permission === 'read') {
      setPermissions((prevPermissions) => ({
        ...prevPermissions,
        [role]: {
          ...prevPermissions[role],
          not_aplicable: false,
          read_write: false,
          read: true,
        },
      }));
    } else {
      setPermissions((prevPermissions) => ({
        ...prevPermissions,
        [role]: {
          ...prevPermissions[role],
          not_aplicable: false,
          read: false,
          read_write: true,
        },
      }));
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardText tag="h3"> {id ? 'Edit' : 'Add'} Role</CardText>
        <Link to={`/admin/role`}>{!isLoading && <Button color="primary">Back</Button>}</Link>
      </CardHeader>
      <CardBody>
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form className="mt-1 " onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="role_name">
                    Role{' '}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="role_name"
                    id="role_name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={errors.role_name}
                        placeholder="Role"
                        {...field}
                      />
                    )}
                  />
                  {errors.role_name && <FormFeedback>{errors.role_name.message}</FormFeedback>}
                </div>
              </Col>

              <Col md="4">
                <div className="mb-1">
                  <Label className="form-label" for="status_of_role">
                    Status {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="status_of_role"
                    id="status_of_role"
                    control={control}
                    defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={statusOptions}
                        className={`react-select 
                          ${errors.status_of_role && 'is-invalid'}`}
                        classNamePrefix="select"
                        invalid={errors.status_of_role}
                        isSearchable={false}
                        placeholder="Select Status"
                      />
                    )}
                  />
                  {errors && errors.status_of_role && (
                    <FormFeedback className="d-block">{errors.status_of_role.message}</FormFeedback>
                  )}
                </div>
              </Col>
            </Row>
            <Row className="mt-2">
              <Col xs={12} className="mt-1">
                <CardText tag="h5" className="mb-1">
                  Module Permissions
                </CardText>

                {/* <h4 className="mt-2 pt-50">Role Permissions</h4> */}
                <Table className="table-flush-spacing" responsive>
                  <tbody>
                    {AdminModuleListing?.map((role, _index) => {
                      if (role?.permission === undefined) {
                        return (
                          <tr key={role?.name}>
                            <td className="text-nowrap fw-bolder w-50">{role?.title}</td>
                            <td>
                              <div className="d-flex">
                                <div className="form-check ms-3 me-lg-3">
                                  <Input
                                    type="checkbox"
                                    id={`read-${role?.name}`}
                                    checked={isObjEmpty(permissions) ? false : permissions[role?.name]?.read}
                                    onChange={() => handleCheckboxChange(role?.name, 'read')}
                                    disabled={role?.permission === null}
                                  />
                                  <Label className="form-check-label" for={`read-${role?.name}`}>
                                    Read
                                  </Label>
                                </div>
                                <div className="form-check ms-3 me-lg-3">
                                  <Input
                                    type="checkbox"
                                    id={`read_write-${role?.name}`}
                                    checked={isObjEmpty(permissions) ? false : permissions[role?.name]?.read_write}
                                    onChange={() => handleCheckboxChange(role?.name, 'read_write')}
                                    disabled={role?.permission === null || role?.permission === 'read'}
                                  />
                                  <Label className="form-check-label" for={`write-${role?.name}`}>
                                    Read & Write
                                  </Label>
                                </div>
                                <div className="form-check ms-3 me-lg-3">
                                  <Input
                                    type="checkbox"
                                    id={`not_aplicable-${role?.name}`}
                                    checked={isObjEmpty(permissions) ? false : permissions[role?.name]?.not_aplicable}
                                    onChange={() => handleCheckboxChange(role?.name, 'not_aplicable')}
                                    disabled={role?.permission === null || role?.permission === 'read'}
                                  />
                                  <Label className="form-check-label" for={`not_aplicable-${role?.name}`}>
                                    No access
                                  </Label>
                                </div>
                              </div>
                            </td>
                          </tr>
                        );
                      }
                      if (role?.title && role?.permission) {
                        return (
                          <tr key={role?.title}>
                            <td className="text-nowrap fw-bolder w-50">{role?.title}</td>
                            <td>
                              <div className="d-flex">
                                <div className="form-check ms-3 me-lg-3">
                                  <Input
                                    type="checkbox"
                                    id={`read-${role?.module}`}
                                    checked={isObjEmpty(permissions) ? false : permissions[role?.module]?.read}
                                    onChange={() => handleCheckboxChange(role?.module, 'read')}
                                    disabled={role?.permission === null}
                                  />
                                  <Label className="form-check-label" for={`read-${role?.module}`}>
                                    Read
                                  </Label>
                                </div>
                                <div className="form-check ms-3 me-lg-3">
                                  <Input
                                    type="checkbox"
                                    id={`read_write-${role?.module}`}
                                    checked={isObjEmpty(permissions) ? false : permissions[role?.module]?.read_write}
                                    onChange={() => handleCheckboxChange(role?.module, 'read_write')}
                                    disabled={role?.permission === null || role?.permission === 'read'}
                                  />
                                  <Label className="form-check-label" for={`write-${role?.module}`}>
                                    Read & Write
                                  </Label>
                                </div>
                                <div className="form-check ms-3 me-lg-3">
                                  <Input
                                    type="checkbox"
                                    id={`not_aplicable-${role?.module}`}
                                    checked={isObjEmpty(permissions) ? false : permissions[role?.module]?.not_aplicable}
                                    onChange={() => handleCheckboxChange(role?.module, 'not_aplicable')}
                                    disabled={role?.permission === null || role?.permission === 'read'}
                                  />
                                  <Label className="form-check-label" for={`not_aplicable-${role?.module}`}>
                                    No access
                                  </Label>
                                </div>
                              </div>
                            </td>
                          </tr>
                        );
                      }
                    })}
                  </tbody>
                </Table>
              </Col>
            </Row>

            <div className="d-flex justify-content-center mt-2">
              <Button color="primary" type="submit" className="d-flex">
                {isEditoute() ? 'Save' : 'Add'}
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Card>
  );
};

export default AddEdit;
