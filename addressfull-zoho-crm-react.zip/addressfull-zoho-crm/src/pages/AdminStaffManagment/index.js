import React from 'react';
import AdminStaffListing from './AdminStaff/AdminStaffListing';

const index = () => {
  return (
    <div>
      <AdminStaffListing />
    </div>
  );
};

export default index;
