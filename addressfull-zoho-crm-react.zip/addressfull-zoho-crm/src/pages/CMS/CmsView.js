import React from 'react';

function CmsView() {
  return <div>CMS View</div>;
}

export default CmsView;
