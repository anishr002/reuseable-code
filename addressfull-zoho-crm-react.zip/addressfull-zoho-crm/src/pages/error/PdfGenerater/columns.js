import moment from 'moment';
import { useState } from 'react';
import { Tooltip } from 'reactstrap';

const Toolstip = ({ id, text }) => {
  const [tooltipOpen, setTooltipOpen] = useState(false);

  const toggle = () => {
    setTooltipOpen(!tooltipOpen);
  };

  return (
    <>
      <span id={id}>{text ?? '-'}</span>
      <Tooltip placement="right" isOpen={tooltipOpen} target={id} toggle={toggle}>
        {text ?? '-'}
      </Tooltip>
    </>
  );
};
export const columns = [
  {
    name: 'Mobile Number',
    minWidth: '180px',
    sortable: false,
    sortName: 'first_name',
    cell: (row) => `${row?.category ?? ''}`,
  },
  {
    name: 'Address',
    // sortable: true,
    minWidth: '10px',
    selector: (row, index) => (
      <>
        <Toolstip id={`tooltip-${index}`} text={row?.price} />
      </>
    ),
  },
  {
    name: 'Email',
    sortable: false,
    minWidth: '100px',
    sortName: 'email',
    selector: (row) => row?.title ?? '',
  },
];
