import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { columns } from './columns';
import { Fragment } from 'react';
import { Card, CardHeader, CardText } from 'reactstrap';
import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import { useSkin } from '@hooks/useSkin';

const PdfGenerate = () => {
  // ** Hooks
  const { skin } = useSkin();
  const [data, setData] = useState([]);
  const [isLoaded, setIsLoaded] = useState(false); // State to track page load

  useEffect(() => {
    fetch('https://fakestoreapi.com/products')
      .then((res) => res.json())
      .then((json) => {
        setData(json?.slice(0, 6));
        setIsLoaded(true); // Set isLoaded to true after data fetch
      });
  }, []);

  // Render the div after the full page load
  const renderExtraDiv = () => {
    if (!isLoaded) return null; // Render nothing if the page is not fully loaded
    return (
      <div className="extra-div" id="ad-1">
        {/* Your content goes here */}
      </div>
    );
  };

  return (
    <Fragment>
      <div className="misc-inner p-sm-7">
        <div className="w-100 text-center">
          <Card>
            <CardHeader className="border-bottom justify-content-center ">
              <CardText className="justify-content-center" tag="h3">
                <img src="https://api.uat.addressfull.com/uploads/profilePictures/Logo1.png" style={{ width: '15%' }} />
              </CardText>
            </CardHeader>
            <div className="react-dataTable react-dataTable-selectable-rows">
              <DataTable
                noHeader
                pagination={false}
                subHeader
                responsive
                paginationRowsPerPageOptions={[10, 20, 50, 100]}
                paginationServer={false}
                paginationResetDefaultPage={false}
                paginationRowsPerPageDropdown={true}
                paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
                columns={columns}
                className="react-dataTable mb-2"
                progressComponent={<Spinner />}
                sortIcon={<ChevronDown size={10} />}
                data={data}
                customStyles={customStyles}
                persistTableHead={true}
              />
            </div>
            {/* Render the extra div after the full page load */}
            {renderExtraDiv()}
          </Card>
        </div>
      </div>
    </Fragment>
  );
};

export default PdfGenerate;
