import { useSkin } from '@hooks/useSkin';
// ** Illustrations Imports
import illustrationsLight from '@src/assets/images/pages/coming-soon.svg';
import illustrationsDark from '@src/assets/images/pages/coming-soon-dark.svg';

// ** Styles
import '@styles/base/pages/page-misc.scss';

const ComingSoon = () => {
  // ** Hooks
  const { skin } = useSkin();

  const source = skin === 'dark' ? illustrationsDark : illustrationsLight;

  return (
    <div className="misc-wrapper">
      <div className="misc-inner p-sm-3">
        <div className="w-100 text-center">
          <h2 className="mb-1">We are launching soon 🚀</h2>

          <img className="img-fluid" src={source} alt="Coming soon page" />
        </div>
      </div>
    </div>
  );
};
export default ComingSoon;
