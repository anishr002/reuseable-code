import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { Badge, Card, CardHeader, CardText } from 'reactstrap';
import { columns } from './columns';

import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import CustomHeader from '../../components/tableCusHeader/CustomHeader';
import { getDashBoardTotalCountAPI } from '../../redux/dashboard';
import { useDebouncedValue } from '../../utility/hooks/useDebouncedValue';

const TotalCounts = () => {
  const dispatch = useDispatch();
  const [searchValue, setSearchValue] = useState('');
  const [data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(1);
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const { TotalUserCounts, rowsPerPagesData, paginationDefaultUsers } = useSelector((state) => state?.root?.Dashboard);
  const { UserData } = useSelector((state) => state.root?.authentication);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);
  const writePermission = UserData?.permissions?.find((item) => item?.section === 'transaction')?.permissions?.write;

  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];

  useEffect(() => {
    if (searchValue) {
      dispatch(
        getDashBoardTotalCountAPI({
          page: currentPage,
          page_size: rowsPerPagesData,
          //   order_by: '',
          //   sort_by: '',
          search: searchValue,
        }),
      );
    } else {
      const payload = { ...paginationDefaultUsers };
      delete payload?.search;
      dispatch(
        getDashBoardTotalCountAPI({
          ...payload,
          page: currentPage,
          page_size: rowsPerPage,
          //   order_by: '',
          //   sort_by: '',
        }),
      );
    }
  }, [debouncedValue]);

  useEffect(() => {
    setCurrentPage(TotalUserCounts?.pageInfo?.currentPage);
    setTotalCount(TotalUserCounts?.pageInfo?.totalCount);
    setRowsPerPage(rowsPerPagesData);
    setData(TotalUserCounts?.data?.map((i) => ({ ...i, writePermission })));
  }, [TotalUserCounts, rowsPerPagesData]);

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const apiCallPagination = () => {
    const payload = {};
    if (searchValue) {
      payload.search = searchValue;
    }
    return payload;
  };

  const displayCounts = () => {
    return (
      <Badge className="custom-badge disabled" style={{ backgroundColor: '#00B000' }} pill>
        {TotalUserCounts?.totalSumCount || 0}
      </Badge>
    );
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Total Requests Counts {displayCounts()}</CardText>
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          responsive
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: 'Rows per page:',
            rangeSeparatorText: 'of',
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: 'All',
          }}
          paginationPerPage={paginationDefaultUsers?.page_size}
          paginationTotalRows={totalCount}
          paginationServer={true}
          paginationDefaultPage={paginationDefaultUsers?.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={(page, totalRows) => {
            console.log('Page changed:', page, 'Total Rows:', totalRows);
            setCurrentPage(page);
            dispatch(
              getDashBoardTotalCountAPI({
                ...paginationDefaultUsers,
                page,
                ...apiCallPagination(),
              }),
            );
          }}
          onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
            console.log('Rows per page changed:', currentRowsPerPage, 'Current Page:', currentPage);
            dispatch(
              getDashBoardTotalCountAPI({
                ...paginationDefaultUsers,
                page: currentPage,
                page_size: currentRowsPerPage,
                ...apiCallPagination(),
              }),
            );
          }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={(column, order) => {
            dispatch(
              getDashBoardTotalCountAPI({
                page: currentPage,
                page_size: rowsPerPage,
                order_by: order,
                sort_by: column?.sortable,
              }),
            );
          }}
          persistTableHead={true}
          subHeaderComponent={
            subdomain === 'org' ? (
              <></>
            ) : (
              <CustomHeader rowsPerPage={rowsPerPage} searchValue={searchValue} handle_filter={handleFilter} />
            )
          }
          customStyles={customStyles}
        />
      </div>
    </Card>
  );
};

export default TotalCounts;
