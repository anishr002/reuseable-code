import Avatar from '@components/avatar';
import { User } from 'react-feather';
import { Badge } from 'reactstrap';

const hostname = window.location.hostname;
const subdomain = hostname.split('.')[0];

export const columns = [
  // {
  //   name: 'User',
  //   minWidth: '250px',
  //   // sortable: true,
  //   cell: (row) => {
  //     return <Link to="user-profile">{row?.id}</Link>;
  //   },
  // },
  {
    name: subdomain === 'org' ? 'Registered Number' : 'Organisation',
    sortable: subdomain === 'org' ? false : 'organizationName',
    minWidth: '250px',
    selector: (row) =>
      row?.organization_name ? (
        <div>
          <Avatar
            imgClassName="rounded cursor"
            className="me-75 mt-1 mb-1"
            img={row?.organization_profile_image ?? false}
            icon={<User />}
            color="light-primary"
            imgHeight="40"
            imgWidth="40"
            contentStyles={{ width: '40px', height: '40px' }}
          />
          {row?.organization_name}
        </div>
      ) : (
        `+${row?.country_code ?? ''} ${row?.mobile_number ?? ''}`
      ),
  },
  {
    name: 'Counts',
    sortable: 'count',
    minWidth: '150px',
    selector: (row) => {
      return (
        <Badge className="custom-badge disabled" pill>
          {row?.count}
        </Badge>
      );
    },
  },
];
