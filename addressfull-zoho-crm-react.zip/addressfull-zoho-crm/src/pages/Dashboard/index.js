import { Fragment, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  CardTitle,
  Col,
  DropdownItem,
  DropdownMenu,
  DropdownToggle,
  Row,
  UncontrolledButtonDropdown,
} from 'reactstrap';
import { getDashboardAPI } from '../../redux/dashboard';
import MonthWiseTransaction from './MonthWiseTran';
// ** Custom Components
import Avatar from '@components/avatar';
import Spinner from '@components/spinner/Loading-spinner';
import StatsHorizontal from '@components/widgets/stats/StatsHorizontal';
import { Inbox, User } from 'react-feather';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [selectedYear, setSelectedYear] = useState('2021');
  const { DashboardData, dashboardLoading } = useSelector((state) => state?.root?.Dashboard);

  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const { UserData } = useSelector((state) => state.root?.authentication);

  const writepermission = UserData?.permissions?.find((item) => item?.section === 'transactions')?.permissions?.write;

  const readpermission = UserData?.permissions?.find((item) => item?.section === 'dashboard')?.permissions?.read;

  console.log('$Ws', UserData?.permissions);

  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];
  // Get the current year
  const currentYear = new Date().getFullYear();
  // Create an array to store the last 10 years along with the current year
  const lastTenYears = [];
  for (let i = 0; i < 5; i++) {
    lastTenYears.push(currentYear - i);
  }

  useEffect(() => {
    readpermission && dispatch(getDashboardAPI({ year: lastTenYears[0] }));
    setSelectedYear(lastTenYears[0]);
  }, []);

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleYearChange = (year) => {
    setSelectedYear(year);
    setDropdownOpen(false);
    dispatch(getDashboardAPI({ year }));
  };

  const createCardBox = (title, value) => {
    return (
      <StatsHorizontal
        color="info"
        customeColor="#00B000"
        statTitle={title}
        icon={<User size={20} />}
        renderStats={<h3 className="fw-bolder mb-75">{value}</h3>}
      />
    );
  };

  const viewAllOnClick = (type) => {
    if (type === 'TotalCount') {
      navigate(`/totalcounts`);
    } else {
      navigate(`/transactions`);
    }
  };

  const reusableActivityCard = (cardTitle, firstItem, centerItem, lastItem, logoOfUser, key) => {
    return (
      <div className="employee-task d-flex justify-content-between align-items-center" key={key}>
        <div className="d-flex">
          <Avatar
            imgClassName="rounded cursor"
            className="me-75"
            img={logoOfUser || false}
            icon={<User />}
            color="light-primary"
            imgHeight="40"
            imgWidth="40"
            contentStyles={{ width: '40px', height: '40px', cursor: 'auto' }}
          />
          <div className="my-auto">
            <h6 className="mb-0">{firstItem}</h6>
            {centerItem && <small>{centerItem}</small>}
          </div>
        </div>
        <div
          className={`d-flex align-items-center w-270 ${cardTitle ? 'justify-content-end' : 'justify-content-start'} `}
          style={{ width: '270px' }}
        >
          <CardText>{lastItem}</CardText>
        </div>
      </div>
    );
  };

  return (
    <Fragment>
      {isLoading || dashboardLoading ? (
        <Spinner open={close} />
      ) : (
        <Row>
          <Col lg="4" sm="6">
            {subdomain === 'admin'
              ? createCardBox('Total Organisations', DashboardData?.total_counts_data?.total_organization)
              : createCardBox('Total User', DashboardData?.total_counts_data?.total_user)}
          </Col>
          <Col lg="4" sm="6">
            {subdomain === 'admin'
              ? createCardBox('Total Users', DashboardData?.total_counts_data?.total_user)
              : createCardBox('Total Staff', DashboardData?.total_counts_data?.total_staff)}
          </Col>
          <Col lg="4" sm="6">
            {createCardBox('Total CRM Integrated', DashboardData?.total_counts_data?.total_crm_integrated)}
          </Col>
          <Col md="12">
            <Card>
              <CardHeader>
                <div className="d-flex align-items-center">
                  <CardTitle className="mb-0 fw-bolder text-dark">Monthly Activity</CardTitle>
                </div>
                <UncontrolledButtonDropdown isOpen={dropdownOpen} toggle={toggleDropdown}>
                  <DropdownToggle className="budget-dropdown" outline color="primary" size="md" caret>
                    {selectedYear}
                  </DropdownToggle>
                  <DropdownMenu end={true}>
                    {lastTenYears?.map((item) => (
                      <DropdownItem className="w-100 text-right" key={item} onClick={() => handleYearChange(item)}>
                        {item}
                      </DropdownItem>
                    ))}
                  </DropdownMenu>
                </UncontrolledButtonDropdown>
              </CardHeader>
              <CardBody>
                <MonthWiseTransaction chart_data={DashboardData?.monthly_transaction_count || {}} />
              </CardBody>
            </Card>
          </Col>
          <Col md="6">
            <Card className="card-employee-task">
              <CardHeader>
                <CardTitle className="fw-bolder">
                  {subdomain === 'admin' ? 'Total Requests (Organisations)' : 'Total User Requests'}
                </CardTitle>
              </CardHeader>

              <CardBody>
                {DashboardData?.user_consent_count?.length > 0 ? (
                  <>
                    {DashboardData?.user_consent_count.map((i, index) =>
                      reusableActivityCard(
                        'Total Requests (Organisations)',
                        i?.organization_name ? i?.organization_name : `+${i?.country_code} ${i?.mobile_number}`,
                        '',
                        i?.count,
                        i?.organization_logo,
                        index,
                      ),
                    )}
                    <Button
                      color="primary"
                      onClick={() => {
                        viewAllOnClick('TotalCount');
                      }}
                      block
                    >
                      View all
                    </Button>
                  </>
                ) : (
                  // If DashboardData is empty or user_consent_count is empty
                  <p className="text-center m-3">
                    <Inbox />
                    <br />
                    No Data
                  </p>
                )}
              </CardBody>
            </Card>
          </Col>
          <Col md="6">
            <Card className="card-employee-task">
              <CardHeader>
                <CardTitle className="fw-bolder">{'Daily CRM Activity Log'}</CardTitle>
              </CardHeader>

              <CardBody>
                {DashboardData?.daily_activity?.length > 0 ? (
                  <>
                    {DashboardData?.daily_activity.map((i, index) =>
                      reusableActivityCard(
                        '',
                        `${i?.country_code?.includes('+') ? i?.country_code : '+' + i?.country_code} ${
                          i?.mobile_number
                        }`,
                        '',
                        i?.message,
                        '',
                        index,
                      ),
                    )}
                    {writepermission && (
                      <Button
                        color="primary"
                        onClick={() => {
                          viewAllOnClick('CRM');
                        }}
                        block
                      >
                        View all
                      </Button>
                    )}
                  </>
                ) : (
                  <p className="text-center m-3">
                    <Inbox />
                    <br />
                    No Data
                  </p>
                )}
              </CardBody>
            </Card>
          </Col>
        </Row>
      )}
    </Fragment>
  );
};

export default Dashboard;
