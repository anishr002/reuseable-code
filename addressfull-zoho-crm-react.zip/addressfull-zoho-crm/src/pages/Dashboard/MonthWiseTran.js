import React from 'react';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { Bar } from 'react-chartjs-2';
import { Inbox } from 'react-feather';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

const labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

function MonthWiseTransaction({ chart_data }) {
  const isZeroTrue = Object.values(chart_data)?.every((value) => value === 0);

  const options = {
    responsive: true,
    scales: {
      x: {
        grid: {
          color: 'transparent',
          borderColor: 'transparent',
        },
        // ticks: { color: "black" }
      },
      y: {
        min: 0,
        // max: chart_data ? roundUpToNearestTen(maxDataValue) : 100,
        grid: {
          // color: "red",
          // borderColor: "red"
        },
        // ticks: {
        //   stepSize: Math.ceil(Math.max(chart_data) / 7),
        //   // color: "red"
        // },
      },
    },
    plugins: {
      legend: {
        position: false,
      },
      title: {
        display: false,
        text: 'Chart.js Bar Chart',
      },
    },
  };
  const data = {
    labels,
    datasets: [
      {
        label: 'Transaction',
        data: chart_data ? [...Object.values(chart_data)]?.map((i) => i) : labels?.map(() => 0),
        // backgroundColor: 'rgba(53, 162, 235, 0.5)',
        maxBarThickness: 15,
        backgroundColor: '#00B000',
        borderColor: 'transparent',
        borderRadius: { topRight: 15, topLeft: 15 },
      },
    ],
  };
  return (
    <div
      style={
        !isZeroTrue
          ? { height: '300px' }
          : { height: '300px', display: 'flex', alignItems: 'center', justifyContent: 'center' }
      }
    >
      {isZeroTrue ? (
        <p className="text-center m-4">
          <Inbox />
          <br />
          No data available
        </p>
      ) : (
        <Bar data={data} options={options} height={300} width={1390} />
      )}
    </div>
  );
}

export default MonthWiseTransaction;
