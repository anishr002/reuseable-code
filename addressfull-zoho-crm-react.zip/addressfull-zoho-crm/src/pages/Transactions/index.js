import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import moment from 'moment';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import Select from 'react-select';
import { Card, CardHeader, CardText, Col, Row } from 'reactstrap';
import CustomPagination from '../../components/pagination';
import TransactionsHeader from '../../components/tableCusHeader/TransactionsHeader';
import { getTransactionsAPI, setNextPageString, setPreviousPageString } from '../../redux/transactions';
import { columns } from './columns';

const Transactions = () => {
  const dispatch = useDispatch();
  const [searchValue, setSearchValue] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [logType, setLogType] = useState(null);
  const [permissionStatus, setPermissionStatus] = useState(null);
  const [permissionStatusDropDown, setPermissionStatusDropDown] = useState([]);
  const [isDisableClear, setIsDisableClear] = useState(true);
  const [isDisableApply, setIsDisableApply] = useState(true);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);

  const {
    TransactionListData,
    rowsPerPagesData,
    paginationDefaultList,
    nextPageString,
    last_page,
    previousPageString,
  } = useSelector((state) => state?.root?.transactions?.TransactionData);
  const { UserData } = useSelector((state) => state.root?.authentication);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);
  const writepermission = UserData?.permissions?.find((item) => item?.section === 'transactions')?.permissions?.write;

  const readpermission = UserData?.permissions?.find((item) => item?.section === 'transactions')?.permissions?.read;
  const timezonesData = useSelector((state) => state?.root?.Setting?.OtherSettings);

  const data = TransactionListData?.results?.map((i) => ({ ...i, writepermission, timezone: timezonesData?.timezone }));

  useEffect(() => {
    dispatch(setNextPageString(''));
    dispatch(setPreviousPageString([]));
    readpermission && dispatch(getTransactionsAPI({ page: 1, page_size: 10 }));
  }, []);

  const handleLogType = (e) => {
    setLogType(e);
  };

  const handlePermissionStatus = (e) => {
    setPermissionStatus(e);
  };

  useEffect(() => {
    setRowsPerPage(rowsPerPagesData);
    setCurrentPage(paginationDefaultList?.page);
  }, [paginationDefaultList]);

  useEffect(() => {
    if (logType || permissionStatus || searchValue || startDate || endDate) {
      setIsDisableApply(false);
      setIsDisableClear(false);
    } else {
      setIsDisableApply(true);
      setIsDisableClear(true);
    }
  }, [logType, permissionStatus, searchValue, startDate, endDate]);

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const handlePageChange = (e) => {
    if (e.isNext && TransactionListData?.bookmark !== 'nil') {
      setCurrentPage(currentPage + 1);
      dispatch(getTransactionsAPI({ ...paginationDefaultList, page: currentPage + 1, bookmark: nextPageString }));
    } else if (e.isPrevious) {
      let myArray = previousPageString;
      myArray = myArray.slice(0, -1);
      dispatch(setPreviousPageString(currentPage - 1 === 1 ? [] : myArray));

      const latestPayload =
        currentPage - 1 === 1
          ? { page_size: 10, page: currentPage - 1 }
          : {
              ...paginationDefaultList,
              page: currentPage - 1,
              bookmark: myArray[myArray.length - 2],
            };

      dispatch(getTransactionsAPI(latestPayload));
      dispatch(getTransactionsAPI(latestPayload));
      setCurrentPage(currentPage - 1);
    }
  };

  const dependedDropDown = (item) => {
    setPermissionStatus(null);
    if (item === 'request') {
      setPermissionStatusDropDown([{ id: 'sent', name: 'Sent' }]);
    }
    if (item === 'consent') {
      setPermissionStatusDropDown([
        { id: 'approve', name: 'Approve' },
        { id: 'reject', name: 'Reject' },
        { id: 'share', name: 'Share' },
        { id: 'revoke', name: 'Revoke' },
        { id: null, name: 'ALL' },
      ]);
    }

    if (item === null) {
      setPermissionStatusDropDown([{ id: null, name: 'ALL' }]);
    }
  };

  const applyFilter = (data) => {
    dispatch(setNextPageString(''));
    dispatch(setPreviousPageString([]));

    let formattedDates = null;
    if (data?.startDate) {
      formattedDates = {
        endDate: moment(data.endDate).format('YYYY-MM-DD'),
        startDate: moment(data.startDate).format('YYYY-MM-DD'),
      };
    }
    const payload = {
      page: 1,
      page_size: 10,
    };

    if (logType) {
      payload.log_type = logType?.value;
    }

    if (permissionStatus) {
      payload.permission_status = permissionStatus?.value;
    }

    if (searchValue) {
      payload.mobile_number = searchValue;
    }
    if (formattedDates !== null) {
      payload.start_date = formattedDates?.startDate;
    }
    if (formattedDates !== null) {
      payload.end_date = formattedDates?.endDate;
    }

    dispatch(getTransactionsAPI({ page: 1, page_size: 10, ...payload }));
  };

  const clearFilter = (_fun) => {
    // setIsDisableClear(true);
    // setIsDisableApply(true);
    _fun();
    // setPaginationList({
    //   page: 1,
    //   page_size: 10,
    // });
    dispatch(setNextPageString(''));
    dispatch(setPreviousPageString([]));
    setPermissionStatus(null);
    setLogType(null);
    setSearchValue('');
    setStartDate(null);
    setEndDate(null);
    // setIsDisableClear(true);
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Transactions</CardText>
        <Row>
          <Col>
            <Select
              options={[
                { id: 'request', name: 'Request' },
                { id: 'consent', name: 'Consent' },
                { id: null, name: 'ALL' },
              ]?.map((item) => ({
                value: item?.id,
                label: item?.name,
              }))}
              className="react-select w-100"
              classNamePrefix="select"
              value={logType}
              onChange={(e) => {
                handleLogType(e);
                dependedDropDown(e?.value);
              }}
              styles={{
                control: (baseStyles, state) => ({
                  ...baseStyles,
                  borderColor: '#d8d6de',
                  minWidth: '230px',
                }),
              }}
              placeholder="Log type"
            />
          </Col>
          <Col>
            <Select
              options={permissionStatusDropDown?.map((item) => ({
                value: item?.id,
                label: item?.name,
              }))}
              className="react-select w-100"
              classNamePrefix="select"
              value={permissionStatus}
              onChange={(e) => handlePermissionStatus(e)}
              styles={{
                control: (baseStyles, state) => ({
                  ...baseStyles,
                  borderColor: '#d8d6de',
                  minWidth: '230px',
                }),
              }}
              placeholder="Permission status"
            />
          </Col>
        </Row>
      </CardHeader>

      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          responsive
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationPerPage={paginationDefaultList?.page_size}
          paginationServer={true}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          // onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
          //   console.log('Rows per page changed:', currentRowsPerPage, 'Current Page:', currentPage);
          //   dispatch(
          //     getTransactionsAPI({
          //       ...paginationDefaultList,
          //       page: currentPage,
          //       page_size: currentRowsPerPage,
          //       ...api_call_pagination(),
          //     }),
          //   );
          // }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          customStyles={customStyles}
          persistTableHead={true}
          paginationComponent={(props) => (
            <CustomPagination
              {...props}
              onPageChange={handlePageChange}
              last_page={last_page}
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
              rowsPerPage={rowsPerPage}
              previousPageString={previousPageString}
              nextPageString={nextPageString}
              totalCount={1} // Replace with the total count from your data
            />
          )}
          subHeaderComponent={
            <TransactionsHeader
              searchValue={searchValue}
              handle_filter={handleFilter}
              clearFilter={clearFilter}
              applyFilter={applyFilter}
              isDisableClear={isDisableClear}
              isDisableApply={isDisableApply}
              setStartDate={setStartDate}
              setEndDate={setEndDate}
            />
          }
        />
      </div>
    </Card>
  );
};

export default Transactions;
