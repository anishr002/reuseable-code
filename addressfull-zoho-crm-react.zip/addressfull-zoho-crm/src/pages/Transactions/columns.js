import { useState } from 'react';
import { Tooltip } from 'reactstrap';
import { convertToTimeZone } from '../../utility/Utils';
import Proptypes from 'prop-types';

const Toolstip = ({ id, text }) => {
  const [tooltipOpen, setTooltipOpen] = useState(false);

  const toggle = () => {
    setTooltipOpen(!tooltipOpen);
  };

  return (
    <>
      <span id={id}>{text ?? '-'}</span>
      <Tooltip placement="right" isOpen={tooltipOpen} target={id} toggle={toggle}>
        {text ?? '-'}
      </Tooltip>
    </>
  );
};
export const columns = [
  {
    name: 'Transaction ID',
    minWidth: '150px',
    maxWidth: '190px',
    sortable: false,
    sortName: 'first_name',
    cell: (row) => `${row?.Record?.id ?? ''}`,
  },
  {
    name: 'Transaction Type',
    // sortable: true,
    minWidth: '40px',
    maxWidth: '150px',
    selector: (row) => row?.Record?.logType,
  },
  {
    name: 'User ID',
    sortable: false,
    minWidth: '100px',
    maxWidth: '150px',
    sortName: 'email',
    selector: (row) =>
      `${row?.Record?.countryCode?.includes('+') ? row?.Record?.countryCode : '+' + row?.Record?.countryCode}  ${
        row?.Record?.mobileNumber
      }`,
  },
  {
    name: 'Messages',
    sortable: false,
    minWidth: '300px',
    maxWidth: '300px',
    selector: (row, index) => <Toolstip id={`tooltip-${index}`} text={row?.Record?.messages} />,
  },
  {
    name: 'Date & Time',
    sortable: false,
    minWidth: '150px',
    maxWidth: '150px',
    sortName: 'active',
    selector: (row) => {
      return row?.Record?.createdAt?.includes(',')
        ? row?.Record?.createdAt
        : convertToTimeZone(row?.Record?.createdAt, row?.timezone);
    },
  },
];
// ** PropTypes
Toolstip.propTypes = {
  id: Proptypes.any,
  text: Proptypes.any,
};
