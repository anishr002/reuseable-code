import { Edit2, Trash2 } from 'react-feather';
import withReactContent from 'sweetalert2-react-content';
import Swal from 'sweetalert2';
import { Link } from 'react-router-dom';
import { store } from '../../../redux/store';
import { deletePrivacyPolicyAPI } from '../../../redux/settings';

const MySwal = withReactContent(Swal);

const showAlert = (_id) => {
  return MySwal.fire({
    title: 'Delete Privacy Policy',
    html: (
      <p>
        Are you sure
        <br />
        you want to delete this privacy policy?
      </p>
    ),
    icon: 'warning',
    showCancelButton: false,
    confirmButtonText: 'Delete',
    showCloseButton: true,
    customClass: {
      confirmButton: 'd-flex w-100 btn btn-primary btn-ripple btn-block',
    },
    buttonsStyling: false,
  }).then(function (result) {
    if (result.isConfirmed) {
      store.dispatch(deletePrivacyPolicyAPI(_id));
    }
  });
};

export const columns = [
  {
    name: 'Policy Name',
    minWidth: '250px',
    sortable: 'title',
    cell: (row) => row?.title,
  },

  {
    name: 'Actions',
    allowOverflow: true,
    // omit: true,
    cell: (row) => {
      return row?.writePermisson ? (
        <div className="d-flex">
          <Link to={`${row?._id}`} className="text-decoration-none">
            <Edit2 size={16} className="me-3 cursor-pointer icon-color-cust" />
          </Link>
          <Trash2
            size={16}
            color="red"
            className="cursor-pointer icon-color-cust"
            onClick={() => showAlert(row?._id)}
          />
        </div>
      ) : (
        <div className="d-flex">
          {/* <Link to={`${row?._id}`} className="text-decoration-none"> */}
          <Edit2 size={16} className="me-3 cursor-not-allowed text-warning icon-color-cust" />
          {/* </Link> */}
          <Trash2 size={16} className="cursor-not-allowed icon-color-cust" />
        </div>
      );
    },
  },
];
