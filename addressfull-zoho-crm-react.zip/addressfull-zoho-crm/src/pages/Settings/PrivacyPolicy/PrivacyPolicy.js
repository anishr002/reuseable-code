import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Button, Card, CardHeader, CardText } from 'reactstrap';
import { getPrivacyPolicyAPI } from '../../../redux/settings';
import { columns } from './column';

const PrivacyPolicy = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(1);
  const { PrivacyPolicyData, rowsPerPagesData, paginationDefaultPolicy } = useSelector((state) => state?.root?.Setting);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { UserData } = useSelector((state) => state.root?.authentication);
  const writePermisson = UserData?.permissions?.find((item) => item?.section === 'privacy_policy_settings')?.permissions
    ?.write;
  const readpermission = UserData?.permissions?.find((item) => item?.section === 'privacy_policy_settings')?.permissions
    ?.read;

  useEffect(() => {
    readpermission && dispatch(getPrivacyPolicyAPI({ ...paginationDefaultPolicy }));
  }, []);

  useEffect(() => {
    setCurrentPage(PrivacyPolicyData?.page_info?.current_page);
    setTotalCount(PrivacyPolicyData?.page_info?.total_count);
    setRowsPerPage(rowsPerPagesData);
  }, [PrivacyPolicyData]);

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Privacy Policy </CardText>
        {/* {writePermisson && ( */}
        <Button
          color="primary"
          onClick={() => {
            if (writePermisson) navigate('add-policy');
          }}
          disabled={!writePermisson}
          className={`d-flex ms-auto`}
          style={{
            cursor: writePermisson ? 'pointer' : 'not-allowed',
            pointerEvents: 'all',
          }}
        >
          ADD
        </Button>
        {/* )} */}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: 'Rows per page:',
            rangeSeparatorText: 'of',
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: 'All',
          }}
          paginationPerPage={paginationDefaultPolicy?.page_size}
          paginationTotalRows={totalCount}
          paginationServer={true}
          paginationDefaultPage={paginationDefaultPolicy?.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={(page, totalRows) => {
            setCurrentPage(page);
            dispatch(getPrivacyPolicyAPI({ ...paginationDefaultPolicy, page }));
          }}
          onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
            dispatch(
              getPrivacyPolicyAPI({ ...paginationDefaultPolicy, page: currentPage, page_size: currentRowsPerPage }),
            );
          }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={PrivacyPolicyData?.policy_list?.map((i) => ({ ...i, writePermisson }))}
          onSort={(column, order) => {
            dispatch(
              getPrivacyPolicyAPI({
                page: currentPage,
                page_size: rowsPerPage,
                order_by: order,
                sort_by: column?.sortable,
              }),
            );
          }}
          persistTableHead={true}
          customStyles={customStyles}
        />
      </div>
    </Card>
  );
};

export default PrivacyPolicy;
