// ** React Imports
import 'cleave.js/dist/addons/cleave-phone.us';
import { Fragment, useEffect } from 'react';
import { Controller, useFieldArray, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
// ** Reactstrap Imports
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Form, FormFeedback, Input, Label, Row } from 'reactstrap';

import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import { Plus, X } from 'react-feather';
import { useNavigate, useParams } from 'react-router-dom';
import * as Yup from 'yup';
import { addPrivacyPolicyAPI, editPrivacyPolicyAPI } from '../../../redux/settings';
import { isObjEmpty } from '../../../utility/Utils';

const AddEditPolicy = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { PrivacyPolicyData } = useSelector((state) => state?.root?.Setting);

  const singlePolicyDetailes = id
    ? isObjEmpty(PrivacyPolicyData)
      ? {}
      : PrivacyPolicyData?.policy_list?.find((i) => i?._id === id)
    : {};

  const initialValues = {
    policy_name: '',
    rules_list: id
      ? isObjEmpty(singlePolicyDetailes)
        ? [{ rules: '' }]
        : singlePolicyDetailes?.sub_rules?.map((rules) => {
            return { rules: rules?.name };
          })
      : [{ rules: '' }],
  };

  const validationSchema = Yup.object().shape({
    policy_name: Yup.string()
      .trim()
      .required('Policy title is required')
      .max(30, 'Policy title must be at most 30 characters'),
    rules_list: Yup.array().of(
      Yup.object({
        rules: Yup.string()
          .trim()
          .required('Rules is required')
          .max(40, 'Rules must be at most 40 characters')
          .test('uniqueRules', 'Rules must be unique', function (value, parent) {
            const existingRules = parent?.from[1]?.value?.rules_list?.map((entry) => entry.rules);

            const uniquRulesSet = new Set(existingRules);
            const hasDuplicates = uniquRulesSet.size !== existingRules.length;

            return !hasDuplicates;
          }),
      }),
    ),
  });

  const {
    control,
    handleSubmit,
    register,
    reset,
    setValue,
    formState: { errors },
  } = useForm({
    mode: 'onChange',
    resolver: yupResolver(validationSchema),
    defaultValues: initialValues,
  });

  const {
    fields: rulesFields,
    append: appendRules,
    remove: removeRules,
  } = useFieldArray({
    name: 'rules_list',
    control,
  });

  const onSubmit = (data) => {
    const payload = { isActive: true };

    payload.title = data?.policy_name;
    payload.subRules = data?.rules_list.map((i) =>
      id
        ? {
            name: i.rules,
            description: 'Rule Description',
            isActive: true,
            id: i?.id ?? 'null',
          }
        : {
            name: i.rules,
            description: 'Rule Description',
            isActive: true,
          },
    );

    if (id) {
      dispatch(editPrivacyPolicyAPI(payload, id, navigate)).then((r) => {
        const { title, sub_rules } = singlePolicyDetailes;
        const formattedArray = sub_rules?.map((rules) => {
          return { rules: rules?.name };
        });
        initialValues.policy_name = title;
        initialValues.rules_list = formattedArray;
        if (r?.status !== 200) {
          reset(initialValues);
        }
      });
    } else {
      dispatch(addPrivacyPolicyAPI(payload, navigate));
    }
  };

  useEffect(() => {
    if (id && singlePolicyDetailes && !isObjEmpty(singlePolicyDetailes)) {
      const { title, sub_rules } = singlePolicyDetailes;

      const formattedArray = sub_rules?.map((rules) => {
        return { rules: rules?.name, id: rules?._id };
      });
      initialValues.policy_name = title;
      initialValues.rules_list = formattedArray;

      Object?.entries(initialValues)?.forEach(([key, value]) => {
        setValue(key, value);
      });
    }
  }, [singlePolicyDetailes]);

  return (
    <Fragment>
      {isLoading ? (
        <Spinner open={close} />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle tag="h4">{id ? 'Edit Policy' : 'Add Policy'}</CardTitle>
          </CardHeader>
          <CardBody className="py-2 ">
            <Form className="mt-2 pt-10" onSubmit={handleSubmit(onSubmit)}>
              <Row>
                <Col md="6">
                  <div className="mb-1 input-error-align">
                    <Label className="form-label" for="callback_url">
                      Policy Title{''}
                      <span className="text-danger" style={{ fontSize: '17px' }}>
                        *
                      </span>
                    </Label>
                    <Controller
                      id="policy_name"
                      name="policy_name"
                      control={control}
                      render={({ field }) => (
                        <Input
                          type="text"
                          className=""
                          placeholder="Add Policy Title"
                          invalid={errors.policy_name}
                          {...field}
                        />
                      )}
                    />
                    {errors.policy_name && <FormFeedback>{errors.policy_name.message}</FormFeedback>}
                  </div>
                </Col>
              </Row>
              <Row>
                <Col md="6">
                  <Label className="form-label" for="callback_url">
                    Rules{''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  {rulesFields?.map((field, index) => {
                    return (
                      <div className="mb-1" key={field?.id}>
                        <div className="d-flex">
                          <input
                            type="text"
                            name={`rules${index}`}
                            {...register(`rules_list.${index}.rules`, {
                              required: 'This is required.',
                            })}
                            className={`form-control 
                               ${errors.rules_list?.[index]?.rules?.message && 'is-invalid'}`}
                            placeholder="Add Rules"
                            disabled={id && singlePolicyDetailes?.sub_rules?.[index]?.isSync}
                          />

                          {index === 0 ? (
                            rulesFields?.length < 10 && (
                              <Button
                                className="text-decoration-underline"
                                color="default"
                                type="button"
                                onClick={() => appendRules({ rules: '' })}
                              >
                                <Plus size="15" />
                              </Button>
                            )
                          ) : !singlePolicyDetailes?.sub_rules?.[index]?.isSync ? (
                            <Button color="default" onClick={() => removeRules(index)}>
                              <X size="15" />
                            </Button>
                          ) : (
                            <Button color="default" className="invisible" onClick={() => removeRules(index)}>
                              <X size="15" />
                            </Button>
                          )}
                        </div>
                        {errors?.rules_list?.length > 1 && (
                          <FormFeedback className="d-block">{errors?.rules_list[index]?.rules?.message}</FormFeedback>
                        )}
                      </div>
                    );
                  })}
                </Col>
              </Row>

              <div className="d-flex justify-content-center mt-2">
                <Button color="primary" onClick={() => navigate(`/settings/privacy_policy_settings`)} outline>
                  Cancel
                </Button>

                <Button color="primary" type="submit" className="d-flex ms-2">
                  Save
                </Button>
              </div>
            </Form>
          </CardBody>
        </Card>
      )}
    </Fragment>
  );
};

export default AddEditPolicy;
