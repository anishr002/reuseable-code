import Spinner from '@components/spinner/Loading-spinner';
import React, { lazy, Suspense, useEffect, useState } from 'react';
import { BarChart2, Link2, PlusCircle, Pocket, Settings, Sliders } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { Card, CardHeader, Col, Nav, NavItem, NavLink, Row, TabContent, TabPane } from 'reactstrap';
import { getOtherSettings, getTemplate } from '../../../redux/settings';
import TimeZone from './TimeZone';

const EmailEditor = lazy(() => import('../EmailEditor'));
const SendNotifications = lazy(() => import('./SendNotifications'));

const General = () => {
  const dispatch = useDispatch();
  const [active, setActive] = useState('1');
  const TemplateData = useSelector((state) => state?.root?.Setting?.Templates);
  const { UserData } = useSelector((state) => state.root?.authentication);
  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];

  const readpermission = UserData?.permissions?.find((item) => item?.section === 'general_settings')?.permissions?.read;

  const toggle = (tab) => {
    if (active !== tab) {
      setActive(tab.toString());
    }
  };
  const Icon = (item) => {
    switch (item?.mail_type) {
      case 'send-otp':
        return <Pocket size="20" className="me-1" />;
      case 'new-account':
        return <PlusCircle size="20" className="me-1" />;
      case 'password-reset':
        return <Link2 size="20" className="me-1" />;
      case 'organization-registration':
        return <BarChart2 size="20" className="me-1" />;
      default:
        return <Settings size="20" className="me-1" />; // or provide a default icon or behavior
    }
  };
  useEffect(() => {
    if (readpermission) {
      dispatch(getTemplate());
      dispatch(getOtherSettings());
    }
  }, []);

  return (
    <div className="nav-vertical">
      {TemplateData?.length === 0 ? (
        <Spinner open={close} />
      ) : (
        <Row>
          <Col md="3" style={{ marginBottom: '2rem' }}>
            <Card className="h-100">
              <CardHeader>Email Templates</CardHeader>
              <Nav tabs className="nav-left my-1">
                {TemplateData?.map((item, index) => (
                  <NavItem key={item?.mail_title}>
                    <NavLink
                      active={active === (index + 1).toString()}
                      onClick={() => {
                        toggle(index + 1);
                      }}
                    >
                      {Icon(item)} {item?.mail_title}
                    </NavLink>
                  </NavItem>
                ))}
                <hr />
                <CardHeader>Others</CardHeader>
                {subdomain !== 'org' && (
                  <NavItem>
                    <NavLink
                      active={active === (TemplateData.length + 1).toString()}
                      onClick={() => {
                        toggle((TemplateData.length + 1).toString());
                      }}
                    >
                      <Sliders size="20" className="me-1" /> Other Settings
                    </NavLink>
                  </NavItem>
                )}
                <NavItem>
                  <NavLink
                    active={active === (TemplateData.length + 2).toString()}
                    onClick={() => {
                      toggle((TemplateData.length + 2).toString());
                    }}
                  >
                    <Sliders size="20" className="me-1" />
                    Time Zone Settings
                  </NavLink>
                </NavItem>
              </Nav>
            </Card>
          </Col>
          <Col md="9">
            <TabContent activeTab={active}>
              {TemplateData?.map((item, index) => (
                <TabPane key={item?.from_name} tabId={(index + 1).toString()}>
                  <Suspense fallback={<Spinner open={close} />}>
                    <EmailEditor active={active} data={item} />
                  </Suspense>
                </TabPane>
              ))}
              {subdomain !== 'org' && (
                <TabPane tabId={(TemplateData.length + 1).toString()}>
                  <Suspense fallback={<Spinner open={close} />}>
                    <SendNotifications />
                  </Suspense>
                </TabPane>
              )}

              <TabPane tabId={(TemplateData.length + 2).toString()}>
                <Suspense fallback={<Spinner open={close} />}>
                  <TimeZone />
                </Suspense>
              </TabPane>
            </TabContent>
          </Col>
        </Row>
      )}
    </div>
  );
};
export default General;
