// ** Reactstrap Imports
import { Button } from 'reactstrap';

// ** Third Party Components
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';

const MobUserAlert = () => {
  const MySwal = withReactContent(Swal);

  const handleTimeoutAlert = () => {
    let timerInterval;
    MySwal.fire({
      title: 'Data Updated By User',
      html: '*after <b></b> seconds Request will be <b>Deem Agreed</b>',
      timerProgressBar: true,
      timer: 15000,
      position: 'top',
      allowOutsideClick: false,
      icon: 'info',
      showCancelButton: true,
      showConfirmButton: true,
      confirmButtonText: 'Accept',
      cancelButtonText: 'Reject',
      customClass: {
        confirmButton: 'btn btn-primary',
        cancelButton: 'btn btn-danger ms-1',
        timerProgressBar: 'bg-primary ',
      },
      didOpen: () => {
        const timer = MySwal.getPopup().querySelector('b');
        timerInterval = setInterval(() => {
          timer.textContent = `${Math.floor(MySwal.getTimerLeft() / 1000)}`;
        }, 100);
      },
      willClose: () => {
        clearInterval(timerInterval);
      },
      buttonsStyling: false,
    }).then(function (result) {
      // if (result.value) {
      // } else if (result.dismiss === MySwal.DismissReason.cancel) {
      // }
    });
  };

  return (
    <div className="demo-inline-spacing">
      <Button color="primary" onClick={handleTimeoutAlert} outline>
        Timeout
      </Button>
    </div>
  );
};

export default MobUserAlert;
