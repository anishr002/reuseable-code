import Spinner from '@components/spinner/Loading-spinner';
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import TimezoneSelect from 'react-timezone-select';
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Label, Row } from 'reactstrap';
import { editOtherSettings } from '../../../redux/settings';

const TimeZone = () => {
  const dispatch = useDispatch();

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const data = useSelector((state) => state?.root?.Setting?.OtherSettings);
  const [selectedTimezone, setSelectedTimezone] = useState(Intl.DateTimeFormat().resolvedOptions().timeZone);

  useEffect(() => {
    if (data?.timezone) {
      setSelectedTimezone(data?.timezone);
    }
  }, [data]);

  const handleSave = () => {
    const payload = { timezone: typeof selectedTimezone === 'string' ? selectedTimezone : selectedTimezone?.value };

    dispatch(editOtherSettings(payload));
  };

  return (
    <>
      {isLoading ? (
        <Spinner open={close} />
      ) : (
        <Row>
          <Col md="12">
            <Card style={{ height: '70vh' }}>
              <CardHeader>
                <CardTitle>Time Zone Settings</CardTitle>
              </CardHeader>
              <CardBody>
                <Label className="pt-2">Time Zone</Label>
                <div className="form react-select">
                  <TimezoneSelect
                    value={selectedTimezone}
                    onChange={setSelectedTimezone}
                    className="react-select"
                    classNamePrefix="select"
                  />
                </div>
                <div className="mt-2 d-flex justify-content-center">
                  <Button color="primary" onClick={handleSave}>
                    Save
                  </Button>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      )}
    </>
  );
};

export default TimeZone;
