import Spinner from '@components/spinner/Loading-spinner';
import React, { useEffect, useState } from 'react';
import { X } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { Badge, Button, Card, CardBody, CardHeader, CardTitle, Col, Input, Label, Row } from 'reactstrap';
import { editOtherSettings } from '../../../redux/settings';
// import MobUserAlert from './MobUserAlert';
import Select from 'react-select';
import { selectThemeColors } from '../../../utility/Utils';

const EmailInput = () => {
  const [items, setItems] = useState([]);
  const [value, setValue] = useState('');
  const [error, setError] = useState(null);
  const [smsProvider, setSmsProvider] = useState(null);
  const [activityFilter, setActivityFilter] = useState(null);

  const [reminderTime, setReminderTime] = useState(null);
  const dispatch = useDispatch();
  const data = useSelector((state) => state?.root?.Setting?.OtherSettings);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { UserData } = useSelector((state) => state.root?.authentication);
  const writePermission = UserData?.permissions?.find((item) => item?.section === 'general_settings')?.permissions
    ?.write;
  const ProviderOption = [
    { value: 'aws', label: 'AWS' },
    { value: 'twilio', label: 'TWILIO' },
  ];
  // const [number, setNumber] = useState('');

  const ReminiderOption = [
    { label: 'Every Day', value: '0 0 * * *' },
    { label: 'Every Week', value: '0 0 * * 0' },
    { label: 'Every Month', value: '0 0 1 * *' },
    { label: 'Every 6 Month', value: '0 0 1 */6 *' },
  ];

  useEffect(() => {
    // dispatch(getOtherSettings());
  }, []);
  useEffect(() => {
    setItems(data?.to_email);
    setSmsProvider(ProviderOption?.find((i) => i?.value === data?.sms_service));
    setReminderTime(ReminiderOption?.find((i) => i?.value === data?.cron_execution_time));
    // setNumber(data?.token_expiration_time.replace('d', ''));
    setActivityFilter(data?.activity_filters?.filter((i) => i?.selected));
  }, [data]);
  const handleKeyDown = (evt) => {
    if (['Enter', 'Tab', ','].includes(evt.key)) {
      evt.preventDefault();

      const trimmedValue = value.trim();

      if (trimmedValue && isValid(trimmedValue)) {
        setItems([...items, trimmedValue]);
        setValue('');
      }
    }
  };

  const handleChange = (evt) => {
    setValue(evt.target.value);

    if (isValid(evt.target.value) || evt.target.value === '') {
      setError(null);
    }
  };

  const handleDelete = (item) => {
    setItems(items.filter((i) => i !== item));
  };

  // const handleChangeDays = (e) => {
  //   const { value } = e.target;

  //   if (value >= 1 && value <= 31) {
  //     setNumber(value);
  //   }
  // };

  const handlePaste = (evt) => {
    evt.preventDefault();

    const paste = evt.clipboardData.getData('text');
    const emails = paste.match(/^[^\s]+@[\w\d\.-]+\.[\w\d\.-]+$/g);

    if (emails) {
      const toBeAdded = emails.filter((email) => !isInList(email));
      setItems([...items, ...toBeAdded]);
    }
  };

  const isValid = (email) => {
    let validationError = null;

    if (isInList(email)) {
      validationError = `${email} has already been added.`;
    }

    if (!isEmail(email)) {
      validationError = `${email} is not a valid email address.`;
    }

    if (validationError) {
      setError(validationError);
      return false;
    }

    return true;
  };

  const isInList = (email) => items.includes(email);
  const isEmail = (email) => /^[^\s]+@[\w\d\.-]+\.[\w\d\.-]+$/.test(email);
  const handleSave = () => {
    const payload = {};

    if (smsProvider) {
      payload.sms_service = smsProvider?.value;
    }

    // if (number) {
    //   payload.token_expiration_time = number + 'd';
    // }

    if (reminderTime) {
      payload.cron_execution_time = reminderTime?.value;
    }
    if (activityFilter) {
      payload.activity_filters = activityFilter?.map((i) => i?.id);
    }
    payload.to_email = items;
    if (!error) {
      //   payload?.to_email =  items
      dispatch(editOtherSettings(payload));
    }
  };

  return (
    <>
      {isLoading ? (
        <Spinner open={close} />
      ) : (
        <Row>
          <Col md="12">
            <Card>
              <CardHeader>
                <CardTitle>Other Settings</CardTitle>
              </CardHeader>
              <CardBody>
                <Label>Send Email To:</Label>
                <Input
                  className={`input ${error ? 'has-error' : ''}`}
                  value={value}
                  placeholder="Type or paste email addresses and press `Enter`..."
                  onKeyDown={handleKeyDown}
                  onChange={handleChange}
                  onPaste={handlePaste}
                  disabled={!writePermission || items?.length > 4}
                />
                {error && (
                  <p className="error text-danger mt-25" style={{ fontSize: '12px' }}>
                    {error}
                  </p>
                )}
                <div className="d-flex w-100">
                  {items?.map((item) => (
                    <div className="mt-1 me-1" key={item}>
                      <Badge color="light-primary" badge="true">
                        {item}
                        <X size="20" type="button" className="ms-1" onClick={() => handleDelete(item)} />
                      </Badge>
                    </div>
                  ))}
                </div>

                <Label className="pt-2">SMS Gateway</Label>
                <Select
                  options={ProviderOption}
                  className="react-select w-100 "
                  classNamePrefix="select"
                  value={smsProvider}
                  onChange={(e) => setSmsProvider(e)}
                  styles={{
                    control: (baseStyles, state) => ({
                      ...baseStyles,
                      borderColor: '#d8d6de',
                      minWidth: '230px',
                    }),
                  }}
                  placeholder="Select Provider"
                />
                <Label className="pt-2">Notification Reminder Time</Label>
                <Select
                  options={ReminiderOption}
                  className="react-select w-100 "
                  classNamePrefix="select"
                  value={reminderTime}
                  onChange={(e) => setReminderTime(e)}
                  styles={{
                    control: (baseStyles, state) => ({
                      ...baseStyles,
                      borderColor: '#d8d6de',
                      minWidth: '230px',
                    }),
                  }}
                  placeholder="Select Option"
                />

                {/* <Label className="pt-2">Ideal Session Timeout</Label>
                <Input
                  id="exampleNumber"
                  name="number"
                  placeholder="Enter number of days (1 - 31)"
                  type="number"
                  value={number}
                  onKeyDown={(e) => {
                    if (e.key === 'Backspace') {
                      setNumber(number.slice(0, -1));
                    }

                    ['e', 'E', '+', '-', '.'].includes(e.key) && e.preventDefault();
                  }}
                  onChange={handleChangeDays}
                /> */}

                <Label className="pt-2">Activity Filter</Label>
                <Select
                  options={data?.activity_filters}
                  className="react-select w-100"
                  classNamePrefix="select"
                  value={activityFilter}
                  theme={selectThemeColors}
                  getOptionLabel={(option) => option?.title}
                  getOptionValue={(option) => option?.id}
                  onChange={(e) => setActivityFilter(e)}
                  isMulti
                  styles={{
                    control: (baseStyles, state) => ({
                      ...baseStyles,
                      borderColor: '#d8d6de',
                      minWidth: '230px',
                    }),
                  }}
                  placeholder="Select Option"
                />
                <div className="mt-2 d-flex justify-content-center">
                  <Button disabled={!writePermission} color="primary" onClick={handleSave}>
                    Save
                  </Button>
                </div>

                {/* <div>
                  <MobUserAlert />
                </div> */}
              </CardBody>
            </Card>
          </Col>
        </Row>
      )}
    </>
  );
};

export default EmailInput;
