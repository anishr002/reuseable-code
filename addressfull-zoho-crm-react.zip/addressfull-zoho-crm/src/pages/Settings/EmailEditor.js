import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import '@styles/react/libs/editor/editor.scss';
import JoditEditor from 'jodit-react';
import Proptypes from 'prop-types';
import React, { memo, useEffect, useRef } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Card, CardHeader, CardTitle, Col, Form, FormFeedback, FormGroup, Input, Label, Row } from 'reactstrap';
import * as Yup from 'yup';
import { editTemplate } from '../../redux/settings';

function EmailEditor({ data }) {
  const dispatch = useDispatch();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { UserData } = useSelector((state) => state.root?.authentication);

  const writePermission = UserData?.permissions?.find((item) => item?.section === 'general_settings')?.permissions
    ?.write;

  const editor = useRef(null);

  const validationSchema = Yup.object().shape({
    subject: Yup.string().trim().required('Subject is required'),
    content: Yup.string().trim().required('Content is required'),
  });

  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValue: {
      subject: '',
      content: '',
    },
  });

  useEffect(() => {
    setValue('subject', data?.subject);
    setValue('content', data?.body);
  }, [data]);

  const onSubmit = (value) => {
    const { subject, content } = value;
    const emailData = {
      subject,
      body: content,
    };

    dispatch(editTemplate(data?.mail_type, emailData));
  };

  return (
    <>
      {isLoading ? (
        <Spinner open={close} />
      ) : (
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Card className="px-2">
            <CardHeader className="px-0">
              <CardTitle>{data?.mail_title}</CardTitle>
            </CardHeader>
            <Row>
              <Col md={'12'}>
                <FormGroup>
                  <Label for="subject">Subject</Label>
                  <Controller
                    name="subject"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        invalid={!!errors.subject}
                        placeholder="Subject"
                        {...field}
                      />
                    )}
                  />
                  {errors.subject && <FormFeedback>{errors.subject.message}</FormFeedback>}
                </FormGroup>
              </Col>
            </Row>
            <div style={{ textAlign: 'right' }}>
              <Controller
                name="content"
                control={control}
                defaultValue=""
                render={({ field }) => (
                  <JoditEditor
                    ref={editor}
                    value={field.value}
                    config={{
                      readonly: false,
                      iframe: true,
                      editHTMLDocumentMode: true,
                      height: '450px',
                    }}
                    tabIndex={1}
                    onBlur={(e) => setValue('content', e)}
                    onChange={(e) => setValue('content', e)}
                  />
                )}
              />
              {errors.content && <FormFeedback>{errors.content.message}</FormFeedback>}
            </div>

            <div className={`d-flex justify-content-center ${writePermission ? '' : 'cursor-not-allowed'}`}>
              <Button disabled={!writePermission} className="my-2" color="primary" type="submit">
                Save
              </Button>
            </div>
          </Card>
        </Form>
      )}
    </>
  );
}

export default memo(EmailEditor);

// ** PropTypes
EmailEditor.propTypes = {
  data: Proptypes.any,
};
