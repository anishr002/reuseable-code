// ** React Imports
import 'cleave.js/dist/addons/cleave-phone.us';
import { Fragment, useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
// ** Reactstrap Imports
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Form, FormFeedback, Input, Label, Row } from 'reactstrap';

import InputPasswordToggle from '@components/input-password-toggle';
import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import { useNavigate, useParams } from 'react-router-dom';
import Select from 'react-select';
import * as Yup from 'yup';
import { addCRMDetailesAPI } from '../../redux/settings';
import { isObjEmpty } from '../../utility/Utils';

const AddEditCrm = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [selectedType, setSelectedType] = useState(null);
  // const { singleCrmDetailes } = useSelector((state) => state?.root?.Setting);
  const { id } = useParams();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const websiteRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/; // Regex pattern for a website URL
  const { CRMSettingsData } = useSelector((state) => state?.root?.Setting);
  const initialValues = {
    login_url: '',
    callback_url: '',
    consumer_key: '',
    consumer_secret: '',
    api_version: '',
    session_secret_key: '',
    auth_token: '',
    zoho_client_id: '',
    zoho_secret_key: '',
    auth_code: '',
  };
  const statusOptions = [
    // { value: 'SalesForce', label: 'SalesForce' },
    { value: 'hubspot', label: 'Hub Spot' },
    { value: 'zoho', label: 'Zoho' },
  ];

  const singleCrmDetailes = CRMSettingsData.find((i) => i?.id === id);

  const validationSchema = Yup.object().shape({
    login_url: Yup.string().trim().required('Login URL is required').matches(websiteRegex, 'Please enter a valid URL'),
    callback_url: Yup.string()
      .trim()
      .required('Callback URL is required')
      .matches(websiteRegex, 'Please enter a valid URL'),
    consumer_key: Yup.string().trim().required('key is required'),
    consumer_secret: Yup.string().trim().required('Consumer secret is required'),
    api_version: Yup.string().trim().required('API version is required'),
    session_secret_key: Yup.string().trim().required('Secrate key is required'),
  });
  const validationSchemaForHubSpot = Yup.object().shape({
    auth_token: Yup.string().trim().required('Token is required'),
  });

  const validationSchemaForZoho = Yup.object().shape({
    zoho_client_id: Yup.string().trim().required('Zoho Client ID is required'),
    zoho_secret_key: Yup.string().trim().required('Zoho Secret Key is required'),
    auth_code: Yup.string().trim().required('Authorization Code is required'),
  });

  const getValidationSchema = () => {
    if (selectedType?.label === 'SalesForce') {
      return validationSchema;
    } else if (selectedType?.label === 'Zoho') {
      return validationSchemaForZoho;
    } else {
      return validationSchemaForHubSpot;
    }
  };

  const form = useForm({
    resolver: yupResolver(getValidationSchema()),
    defaultValues: initialValues,
  });

  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors },
  } = form;

  // Update validation schema when type changes
  useEffect(() => {
    form.clearErrors();
  }, [selectedType]);

  const onSubmit = (data) => {
    let payload = { type: selectedType.value, ...data };

    if (selectedType?.value === 'SalesForce') {
      delete payload?.auth_token;
      delete payload?.zoho_client_id;
      delete payload?.zoho_secret_key;
      delete payload?.auth_code;
    } else if (selectedType?.value === 'zoho') {
      payload = {
        type: selectedType.value,
        zohoClientId: payload?.zoho_client_id,
        zohoSecretKey: payload?.zoho_secret_key,
        authCode: payload?.auth_code,
      };
    } else {
      // HubSpot
      payload = { type: selectedType.value, authToken: payload?.auth_token };
    }

    dispatch(addCRMDetailesAPI(payload, navigate));
  };

  // Function to handle Zoho configuration redirect in new tab
  const handleZohoConfiguration = () => {
    window.open('/zoho-configration', '_blank');
  };

  useEffect(() => {
    if (id && singleCrmDetailes && !isObjEmpty(singleCrmDetailes)) {
      const {
        auth_token,
        session_secret_key,
        api_version,
        consumer_secret,
        consumer_key,
        callback_url,
        login_url,
        type,
        zohoClientId,
        zohoSecretKey,
        authCode,
      } = singleCrmDetailes;
      setSelectedType(statusOptions?.find((i) => i.value === type));
      setValue(
        'SelectType',
        statusOptions?.find((i) => i.value === type),
      );
      initialValues.auth_token = auth_token;
      initialValues.session_secret_key = session_secret_key;
      initialValues.api_version = api_version;
      initialValues.consumer_secret = consumer_secret;
      initialValues.consumer_key = consumer_key;
      initialValues.callback_url = callback_url;
      initialValues.login_url = login_url;
      initialValues.zoho_client_id = zohoClientId;
      initialValues.zoho_secret_key = zohoSecretKey;
      initialValues.auth_code = authCode;

      Object?.entries(initialValues)?.forEach(([key, value]) => {
        setValue(key, value);
      });
    }
  }, [singleCrmDetailes]);

  return (
    <Fragment>
      {isLoading ? (
        <Spinner open={close} />
      ) : (
        <Card>
          <CardHeader>
            <div className="d-flex justify-content-between align-items-center w-100">
              <CardTitle tag="h4" className="mb-0">
                CRM Details
              </CardTitle>
              {selectedType?.label === 'Zoho' && (
                <Button color="primary" outline onClick={handleZohoConfiguration} style={{ whiteSpace: 'nowrap' }}>
                  Configure Zoho
                </Button>
              )}
            </div>
          </CardHeader>
          <CardBody className="py-2 my-25">
            <Form className="mt-2 pt-10" onSubmit={handleSubmit(onSubmit)}>
              <Row>
                <Col md="6">
                  <div className="mb-1 input-error-align">
                    <Label className="form-label" for="SelectType">
                      Select Type{''}
                      <span className="text-danger" style={{ fontSize: '17px' }}>
                        *
                      </span>
                    </Label>
                    <Controller
                      name="SelectType"
                      id="SelectType"
                      control={control}
                      // className="border-less-input"
                      defaultValue={null}
                      render={({ field }) => (
                        <Select
                          {...field}
                          name="SelectType"
                          options={statusOptions}
                          className="react-select"
                          classNamePrefix="select"
                          invalid={errors.SelectType}
                          defaultValue={selectedType}
                          onChange={(option) => {
                            setSelectedType(option);
                            setValue('SelectType', option);
                          }}
                          styles={{
                            control: (baseStyles, state) => ({
                              ...baseStyles,
                              borderColor: errors.SelectType ? 'red' : '#d8d6de',
                            }),
                          }}
                          isSearchable
                          placeholder="Select"
                        />
                      )}
                    />
                  </div>
                </Col>
              </Row>
              <Row>
                {selectedType?.label === 'SalesForce' ? (
                  <>
                    <Col md="6">
                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="login_url">
                          Login URL{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="login_url"
                          name="login_url"
                          control={control}
                          render={({ field }) => (
                            <Input
                              type="text"
                              autoFocus
                              className="form-control "
                              placeholder="Login URL"
                              invalid={errors.login_url}
                              {...field}
                            />
                          )}
                        />
                        {errors?.login_url && <FormFeedback>{errors.login_url.message}</FormFeedback>}
                      </div>

                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="consumer_key">
                          Consumer Key{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="consumer_key"
                          name="consumer_key"
                          control={control}
                          render={({ field }) => (
                            <InputPasswordToggle
                              className="input-group-merge"
                              inputClassName=""
                              invalid={errors.consumer_key}
                              {...field}
                            />
                          )}
                        />
                        {errors?.consumer_key && <FormFeedback>{errors?.consumer_key?.message}</FormFeedback>}
                      </div>

                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="api_version">
                          API Version{' '}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="api_version"
                          name="api_version"
                          control={control}
                          render={({ field }) => (
                            <Input
                              type="text"
                              className=""
                              placeholder="API Version"
                              invalid={errors.api_version}
                              {...field}
                            />
                          )}
                        />
                        {errors.api_version && <FormFeedback>{errors.api_version.message}</FormFeedback>}
                      </div>
                    </Col>
                    <Col md="6">
                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="callback_url">
                          Callback URL{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="callback_url"
                          name="callback_url"
                          control={control}
                          render={({ field }) => (
                            <Input
                              type="text"
                              className=""
                              placeholder="Callback URL"
                              invalid={errors.callback_url}
                              {...field}
                            />
                          )}
                        />
                        {errors.callback_url && <FormFeedback>{errors.callback_url.message}</FormFeedback>}
                      </div>
                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="consumer_secret">
                          Consumer Secret{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="consumer_secret"
                          name="consumer_secret"
                          control={control}
                          render={({ field }) => (
                            <InputPasswordToggle
                              className="input-group-merge"
                              inputClassName=""
                              invalid={errors.consumer_secret}
                              {...field}
                            />
                          )}
                        />
                        {errors.consumer_secret && <FormFeedback>{errors.consumer_secret.message}</FormFeedback>}
                      </div>
                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="session_secret_key">
                          Session Secret Key{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="session_secret_key"
                          name="session_secret_key"
                          control={control}
                          render={({ field }) => (
                            <InputPasswordToggle
                              className="input-group-merge"
                              inputClassName=""
                              invalid={errors.session_secret_key}
                              {...field}
                            />
                          )}
                        />
                        {errors.session_secret_key && <FormFeedback>{errors.session_secret_key.message}</FormFeedback>}
                      </div>
                    </Col>
                  </>
                ) : selectedType === null ? (
                  <></>
                ) : selectedType?.label === 'Zoho' ? (
                  <>
                    <Col md="6">
                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="zoho_client_id">
                          Zoho Client ID{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="zoho_client_id"
                          name="zoho_client_id"
                          control={control}
                          render={({ field }) => (
                            <InputPasswordToggle
                              className="input-group-merge"
                              inputClassName=""
                              invalid={errors.zoho_client_id}
                              {...field}
                            />
                          )}
                        />
                        {errors.zoho_client_id && <FormFeedback>{errors.zoho_client_id.message}</FormFeedback>}
                      </div>

                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="zoho_secret_key">
                          Zoho Secret Key{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="zoho_secret_key"
                          name="zoho_secret_key"
                          control={control}
                          render={({ field }) => (
                            <InputPasswordToggle
                              className="input-group-merge"
                              inputClassName=""
                              invalid={errors.zoho_secret_key}
                              {...field}
                            />
                          )}
                        />
                        {errors.zoho_secret_key && <FormFeedback>{errors.zoho_secret_key.message}</FormFeedback>}
                      </div>
                    </Col>
                    <Col md="6">
                      <div className="mb-1 input-error-align">
                        <Label className="form-label" for="auth_code">
                          Authorization Code{''}
                          <span className="text-danger" style={{ fontSize: '17px' }}>
                            *
                          </span>
                        </Label>
                        <Controller
                          id="auth_code"
                          name="auth_code"
                          control={control}
                          render={({ field }) => (
                            <InputPasswordToggle
                              className="input-group-merge"
                              inputClassName=""
                              invalid={errors.auth_code}
                              {...field}
                            />
                          )}
                        />
                        {errors.auth_code && <FormFeedback>{errors.auth_code.message}</FormFeedback>}
                      </div>
                    </Col>
                  </>
                ) : (
                  <Col md="6">
                    <div className="mb-1 input-error-align">
                      <Label className="form-label" for="x-cdata-authtoken">
                        x-cdata-authtoken{''}
                        <span className="text-danger" style={{ fontSize: '17px' }}>
                          *
                        </span>
                      </Label>
                      <Controller
                        id="auth_token"
                        name="auth_token"
                        control={control}
                        render={({ field }) => (
                          <InputPasswordToggle
                            className="input-group-merge"
                            inputClassName=""
                            invalid={errors.auth_token}
                            {...field}
                            // disabled={id}
                          />
                        )}
                      />
                      {errors.auth_token && <FormFeedback>{errors.auth_token.message}</FormFeedback>}
                    </div>
                  </Col>
                )}
              </Row>
              <div className="d-flex justify-content-center">
                <Button
                  color="primary"
                  className="d-flex ms-auto"
                  onClick={() => navigate(`/settings/crm_settings`)}
                  outline
                >
                  Cancel
                </Button>
                {selectedType && (
                  <Button color="primary" type="submit" className="d-flex ms-2">
                    Save
                  </Button>
                )}
              </div>
            </Form>
          </CardBody>
        </Card>
      )}
    </Fragment>
  );
};

export default AddEditCrm;
