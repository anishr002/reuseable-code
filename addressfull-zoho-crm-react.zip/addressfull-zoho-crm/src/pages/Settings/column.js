import { Edit2 } from 'react-feather';
import { Link } from 'react-router-dom';

export const columns = [
  {
    name: 'Type',
    minWidth: '250px',
    sortable: 'type',
    cell: (row) => row?.type,
  },
  {
    name: 'Login URL',
    sortable: 'loginurl',
    minWidth: '250px',
    selector: (row) => row.login_url ?? '-',
  },
  {
    name: 'Callback URL',
    sortable: 'calbackurl',
    minWidth: '150px',
    selector: (row) => row.callbackURL ?? '-',
  },
  {
    name: 'API Version',
    sortable: 'apiverion',
    minWidth: '150px',
    selector: (row) => row.API_Version ?? '-',
  },
  {
    name: 'Actions',
    allowOverflow: true,
    cell: (row) => {
      return row?.writePermission ? (
        <div className="d-flex">
          <Link to={`edit-crm/${row?.id}`} className="text-decoration-none">
            <Edit2 size={16} className="me-3 cursor-pointer icon-color-cust" />
          </Link>
        </div>
      ) : (
        <div className="d-flex">
          <Edit2 size={16} className="me-3 cursor-not-allowed text-warning icon-color-cust" />
        </div>
      );
    },
  },
];
