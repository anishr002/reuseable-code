// ** React Imports
import { Link, useLocation, useNavigate } from 'react-router-dom';
// ** Custom Components
import InputPassword from '@components/input-password-toggle';
import Spinners from '@components/spinner/Fallback-spinner';

// ** Reactstrap Imports
import { yupResolver } from '@hookform/resolvers/yup';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { Button, Card, CardBody, CardTitle, Form, FormFeedback, Input, Label, Spinner } from 'reactstrap';
import * as Yup from 'yup';
// ** Styles
import '@styles/react/pages/page-authentication.scss';
import { useEffect, useState } from 'react';
import { changePasswordApi, checkTokenExpiryApi } from '../../redux/authentication';
import themeConfig from '../../utility/configs/themeConfig';

function ResetPassword() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [isAccepted, setIsAccepted] = useState(false);

  const queryParams = new URLSearchParams(location.search);
  const token = queryParams.get('token');
  const isAddedBySuperAdmin = queryParams.get('isAddedByAdmin');

  const [newLoading, setNewLoading] = useState(true);
  const validationSchema = Yup.object().shape({
    new_password: Yup.string()
      .trim()
      .required('Password is required')
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,16})/,
        'Password must be 8-16 characters and include at least one uppercase letter, one lowercase letter, and one special character',
      )
      .max(16, 'Password must not exceed 16 characters'),

    confirm_password: Yup.string()
      .trim()
      .required('Password confirmation is required')
      .oneOf([Yup.ref('new_password'), null], 'Passwords must match'),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      new_password: '',
      confirm_password: '',
    },
  });

  useEffect(() => {
    if (token) {
      dispatch(checkTokenExpiryApi(token, navigate)).then((result) => {
        if (result?.status) {
          setNewLoading(false);
        }
      });
    } else {
      setNewLoading(false);
    }
  }, [token]);
  const onSubmit = (data) => {
    if (isAddedBySuperAdmin) {
      if (Object.values(data).every((field) => field?.length > 0) && isAccepted) {
        dispatch(
          changePasswordApi(
            { password: data?.new_password, confirm_password: data?.confirm_password },
            token,
            navigate,
          ),
        );
      }
    } else if (Object.values(data).every((field) => field?.length > 0)) {
      dispatch(
        changePasswordApi({ password: data?.new_password, confirm_password: data?.confirm_password }, token, navigate),
      );
    }
  };

  return newLoading ? (
    <Spinners />
  ) : (
    <div className="auth-wrapper auth-basic px-2">
      <div className="auth-inner my-2">
        <Card className="mb-0">
          <CardBody>
            <Link className="brand-logo" to="/" onClick={(e) => e.preventDefault()}>
              <img src={themeConfig.app.appLogoImage} alt="logo" style={{ width: '40%' }} />
              {/* <h2 className="brand-text text-primary ms-1">AddressFull</h2> */}
            </Link>
            <CardTitle tag="h4" className="mb-1">
              {location?.pathname.includes('/set-password') ? 'Set up your password' : 'Reset Password'}
            </CardTitle>
            <Form className="auth-reset-password-form mt-2" onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-1">
                <Label className="form-label" for="new_password">
                  New Password {''}
                  <span className="text-danger" style={{ fontSize: '17px' }}>
                    *
                  </span>
                </Label>
                <Controller
                  id="new_password"
                  name="new_password"
                  control={control}
                  render={({ field }) => (
                    <InputPassword autoFocus className="input-group-merge" invalid={errors.new_password} {...field} />
                  )}
                />
                {errors.new_password && <FormFeedback>{errors.new_password.message}</FormFeedback>}
              </div>
              <div className="mb-1">
                <Label className="form-label" for="confirm_password">
                  Confirm {''}
                  <span className="text-danger" style={{ fontSize: '17px' }}>
                    *
                  </span>
                </Label>
                <Controller
                  id="confirm_password"
                  name="confirm_password"
                  control={control}
                  render={({ field }) => (
                    <InputPassword className="input-group-merge" invalid={errors.confirm_password} {...field} />
                  )}
                />
                {errors.confirm_password && <FormFeedback>{errors.confirm_password.message}</FormFeedback>}
              </div>
              {/* Terms and Conditions Checkbox */}

              {isAddedBySuperAdmin && (
                <div className="mb-1">
                  <Input
                    type="checkbox"
                    id="terms"
                    checked={isAccepted}
                    onChange={(e) => setIsAccepted(e.target.checked)}
                  />
                  <Label for="terms" className="form-check-label ms-1">
                    I accept the{' '}
                    <Link to="https://addressfull.com/terms-of-use-organisation-platform/" target="_blank">
                      Terms and Conditions
                    </Link>
                  </Label>
                </div>
              )}

              {isAddedBySuperAdmin ? (
                <Button color="primary" type="submit" disabled={!isAccepted || isLoading} block>
                  {isLoading ? (
                    <div>
                      Set new Password <Spinner size="sm" className="ms-1" />
                    </div>
                  ) : (
                    'Set new Password'
                  )}
                </Button>
              ) : (
                <Button color="primary" type="submit" disabled={isLoading} block>
                  {isLoading ? (
                    <div>
                      Set new Password <Spinner size="sm" className="ms-1" />
                    </div>
                  ) : (
                    'Set new Password'
                  )}
                </Button>
              )}
            </Form>
            <p className="text-center mt-2">
              <Link to="login">
                <span className="align-middle">Cancel</span>
              </Link>
            </p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

export default ResetPassword;
