// ** React Imports
import { Link, useNavigate } from 'react-router-dom';
// ** Icons Imports
import { ChevronLeft } from 'react-feather';
// ** Reactstrap Imports
import { Button, Card, CardBody, CardText, CardTitle, Form, FormFeedback, Input, Label, Spinner } from 'reactstrap';
// ** Styles
import { yupResolver } from '@hookform/resolvers/yup';
import '@styles/react/pages/page-authentication.scss';
import { useEffect } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { useLocation } from 'react-router-dom/dist';
import * as Yup from 'yup';
import { forgotPasswordApi } from '../../redux/authentication';
import themeConfig from '../../utility/configs/themeConfig';

const ForgotPassword = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const location = useLocation();

  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];

  const validationSchema = Yup.object().shape({
    login_email: Yup.string().trim().email('Please enter a valid email address').required('Email is required'),
  });
  const {
    control,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      login_email: '',
    },
  });

  const onSubmit = (data) => {
    if (Object.values(data).every((field) => field?.length > 0)) {
      dispatch(
        forgotPasswordApi(
          {
            email: data?.login_email,
            role_type: subdomain === 'org' ? 'organization-admin' : 'super-admin',
          },
          navigate,
        ),
      );
    }
  };

  useEffect(() => {
    const tokenExist = localStorage.getItem('accessToken');
    if (tokenExist) {
      const rootPath = location.pathname.split('/');
      navigate(-1);
    }
  }, []);

  // const handleKeyPress = (e) => {
  //   if (e.key === 'Enter') {
  //     handleSubmit(onSubmit)();
  //   }
  // };

  return (
    <div className="auth-wrapper auth-basic px-2">
      <div className="auth-inner my-2">
        <Card className="mb-0">
          <CardBody>
            <Link className="brand-logo" to="/" onClick={(e) => e.preventDefault()}>
              <img src={themeConfig.app.appLogoImage} alt="logo" style={{ width: '40%' }} />
              {/* <h2 className="brand-text text-primary ms-1">AddressFull</h2> */}
            </Link>
            <CardTitle tag="h4" className="mb-1">
              Forgot Password?
            </CardTitle>
            <CardText className="mb-2">
              Enter your email and we'll send you instructions to reset your password
            </CardText>
            <Form className="auth-forgot-password-form mt-2" onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-1">
                <Label className="form-label" for="login_email">
                  Email {''}
                  <span className="text-danger" style={{ fontSize: '17px' }}>
                    *
                  </span>
                </Label>
                <Controller
                  id="login_email"
                  name="login_email"
                  control={control}
                  render={({ field }) => (
                    <Input
                      autoFocus
                      type="email"
                      placeholder="info@example.com"
                      invalid={errors.login_email}
                      {...field}
                      // onKeyPress={handleKeyPress}
                    />
                  )}
                />
                {errors.login_email && <FormFeedback>{errors.login_email.message}</FormFeedback>}
              </div>
              <Button color="primary" type="submit" disabled={!isValid} block>
                {isLoading ? (
                  <div>
                    Sending reset link <Spinner size="sm" className="ms-1" />
                  </div>
                ) : (
                  'Send reset link'
                )}
              </Button>
            </Form>
            <p className="text-center mt-2">
              <Link to="login">
                <ChevronLeft className="rotate-rtl me-25" size={14} />
                <span className="align-middle">Back to login</span>
              </Link>
            </p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default ForgotPassword;
