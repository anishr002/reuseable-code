// ** React Imports
import { Link, useNavigate } from 'react-router-dom';
// ** Reactstrap Imports
import { Button, Card, CardBody, CardText, CardTitle, Form, FormFeedback, Spinner } from 'reactstrap';
// ** Custom Components
import InputPasswordToggle from '@components/input-password-toggle';
import { Controller, useForm } from 'react-hook-form';
// ** Styles
import { yupResolver } from '@hookform/resolvers/yup';
import '@styles/react/pages/page-authentication.scss';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as Yup from 'yup';
import { resendOtpAPI, verifyOtpApi } from '../../redux/authentication';
import themeConfig from '../../utility/configs/themeConfig';

const validationSchema = Yup.object().shape({
  login_otp: Yup.string().required('Code is required'),
});

const VerifyOTP = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loginEmail } = useSelector((state) => state?.root?.authentication);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      login_otp: '',
    },
  });

  const onSubmit = async (data) => {
    if (Object.values(data).every((field) => field?.length > 0)) {
      dispatch(verifyOtpApi({ otp: data?.login_otp }, navigate));
    }
  };

  useEffect(() => {
    const tokenExist = localStorage.getItem('accessToken');
    if (tokenExist) {
      navigate('/');
    } else {
      !loginEmail && navigate(`/login`);
    }
  }, []);

  function maskEmail(email) {
    // Split the email address into local part and domain
    const [localPart, domain] = email.split('@');

    // Get the first three characters of the local part
    const maskedLocalPart = localPart.slice(0, 3);

    // Get the domain part as is
    const maskedDomain = domain;

    // Construct the masked email
    const maskedEmail = `${maskedLocalPart}********${maskedDomain}`;

    return maskedEmail;
  }
  return (
    <div className="auth-wrapper auth-basic px-2">
      <div className="auth-inner my-2">
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Card className="mb-0">
            <CardBody>
              <Link className="brand-logo" to="/" onClick={(e) => e.preventDefault()}>
                <img src={themeConfig.app.appLogoImage} alt="logo" style={{ width: '40%' }} />
                {/* <h2 className="brand-text text-primary ms-1">AddressFull</h2> */}
              </Link>
              <CardTitle tag="h2" className="fw-bolder mb-1">
                Verification Code
              </CardTitle>
              <CardText className="mb-2">
                A verification code has been sent by Email to <span className="fw-bolder">{maskEmail(loginEmail)}</span>
              </CardText>

              <div className="mb-1">
                {/* <Label for="otp">
                  Enter Verification Code
                  <span className="text-danger" style={{ fontSize: '17px' }}>
                    *
                  </span>
                </Label> */}
                <Controller
                  id="login_otp"
                  name="login_otp"
                  control={control}
                  render={({ field }) => (
                    <InputPasswordToggle
                      autoFocus
                      className="input-group-merge"
                      invalid={errors.login_otp}
                      {...field}
                      placeholder="Enter the Code"
                      // onKeyDown={(e) => {
                      //   if (e.key === 'Enter') {
                      //     console.log('eeee');
                      //   } else {
                      //     // Prevent non-numeric input
                      //     if (!((e.key >= '0' && e.key <= '9') || e.key === 'Backspace')) {
                      //       e.preventDefault();
                      //     }
                      //   }
                      // }}
                    />
                  )}
                />
                {errors.login_otp && <FormFeedback>{errors.login_otp.message}</FormFeedback>}
              </div>
              <Button disabled={isLoading} color="primary" type="submit" block>
                Submit
                {isLoading && <Spinner size="sm" className="ms-1" />}
              </Button>
              <p className="text-center mt-2">
                <span>Didn't receive an email? </span>
                <Button
                  color="default"
                  className="btn btn-link"
                  onClick={(_e) => dispatch(resendOtpAPI({ email: loginEmail }))}
                >
                  <span>Resend</span>
                </Button>
              </p>
            </CardBody>
          </Card>
        </Form>
      </div>
    </div>
  );
};

export default VerifyOTP;
