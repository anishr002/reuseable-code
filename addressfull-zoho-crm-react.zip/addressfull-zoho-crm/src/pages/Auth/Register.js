// ** React Imports
import { Link, useNavigate } from 'react-router-dom';
// ** Icons Imports
import { ChevronLeft } from 'react-feather';
// ** Reactstrap Imports
import { Button, Card, CardBody, CardText, CardTitle, Form, FormFeedback, Input, Label, Spinner } from 'reactstrap';
// ** Styles
import { yupResolver } from '@hookform/resolvers/yup';
import '@styles/react/pages/page-authentication.scss';
import { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import * as Yup from 'yup';
import { registerApi } from '../../redux/authentication';
import themeConfig from '../../utility/configs/themeConfig';

const ForgotPassword = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];
  
  const [isAccepted, setIsAccepted] = useState(false);

  const validationSchema = Yup.object().shape({
    email: Yup.string().trim().email('Please enter a valid email address').required('Email is required'),
  });
  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      email: '',
    },
  });

  useEffect(() => {
    if (subdomain !== 'org') {
      navigate('/login');
    }
  }, []);

  const onSubmit = (data) => {
    if (Object.values(data).every((field) => field?.length > 0) && isAccepted) {
      dispatch(registerApi({ email: data?.email }, navigate));
    }
  };

  return (
    <div className="auth-wrapper auth-basic px-2">
      <div className="auth-inner my-2">
        <Card className="mb-0">
          <CardBody>
            <Link className="brand-logo" to="/" onClick={(e) => e.preventDefault()}>
              <img src={themeConfig.app.appLogoImage} alt="logo" style={{ width: '40%' }} />
              {/* <h2 className="brand-text text-primary ms-1">AddressFull</h2> */}
            </Link>
            <CardTitle tag="h4" className="mb-1">
              Register
            </CardTitle>
            <CardText className="mb-2">Enter your email and we'll send you instructions</CardText>
            <Form className="auth-forgot-password-form mt-2" onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-1">
                <Label className="form-label" for="login_email">
                  Email {''}
                  <span className="text-danger" style={{ fontSize: '17px' }}>
                    *
                  </span>
                </Label>
                <Controller
                  id="email"
                  name="email"
                  control={control}
                  render={({ field }) => (
                    <Input autoFocus type="email" placeholder="info@example.com" invalid={errors.email} {...field} />
                  )}
                />
                {errors.email && <FormFeedback>{errors.email.message}</FormFeedback>}
                <small className="text-muted">
                  <strong>We recommend using a generic company email</strong>
                </small>
              </div>
              {/* Terms and Conditions Checkbox */}
              <div className="mb-1">
                <Input
                  type="checkbox"
                  id="terms"
                  checked={isAccepted}
                  onChange={(e) => setIsAccepted(e.target.checked)}
                />
                <Label for="terms" className="form-check-label ms-1">
                  I accept the{' '}
                  <Link to="https://addressfull.com/terms-of-use-organisation-platform/" target="_blank">
                    Terms and Conditions
                  </Link>
                </Label>
              </div>
              <Button color="primary" type="submit" disabled={!isAccepted || isLoading} block>
                {isLoading ? (
                  <div>
                    Sign up <Spinner size="sm" className="ms-1" />
                  </div>
                ) : (
                  'Sign up'
                )}
              </Button>
            </Form>
            <p className="text-center mt-2">
              <Link to="login">
                <ChevronLeft className="rotate-rtl me-25" size={14} />
                <span className="align-middle">Back to login</span>
              </Link>
            </p>
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default ForgotPassword;
