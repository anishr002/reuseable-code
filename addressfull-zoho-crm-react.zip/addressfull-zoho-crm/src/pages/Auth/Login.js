import { Link, useNavigate } from 'react-router-dom';
// ** Custom Hooks
// ** Third Party Components
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
// ** Custom Components
import InputPasswordToggle from '@components/input-password-toggle';
import { yupResolver } from '@hookform/resolvers/yup';
import toast from 'react-hot-toast';
import * as Yup from 'yup';
import { loginAPI } from '../../redux/authentication';
import themeConfig from '../../utility/configs/themeConfig';

// ** Reactstrap Imports
import { Button, Card, CardBody, Form, FormFeedback, Input, Label, Spinner } from 'reactstrap';

// ** Styles
import '@styles/react/pages/page-authentication.scss';
import { useEffect } from 'react';
import CustomToast, { ErrorCss } from '../../utility/toast/CustomToast';

const Login = () => {
  // ** Hooks
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];

  const validationSchema = Yup.object().shape({
    login_email: Yup.string().trim().email('Please enter a valid email address').required('Email is required'),
    login_password: Yup.string().trim().required('Password is required'),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: {
      login_email: '',
      login_password: '',
    },
  });

  useEffect(() => {
    const tokenExist = localStorage.getItem('accessToken');
    if (tokenExist) {
      navigate('/');
    } else {
      const flag = localStorage.getItem('flag');

      if (flag) {
        toast(
          <CustomToast message={'Unauthorized because multiple device login detected'} type={'error'} />,
          ErrorCss(),
        );
        localStorage.removeItem('flag');
      }
    }
  }, []);

  const onSubmit = (data) => {
    if (Object.values(data).every((field) => field?.length > 0)) {
      dispatch(
        loginAPI(
          {
            email: data.login_email,
            password: data.login_password,
            role_type: subdomain === 'org' ? 'organization-admin' : 'super-admin',
          },
          navigate,
        ),
      );
    }
  };

  return (
    <div className="auth-wrapper auth-basic">
      <div className="auth-inner">
        <Form className="auth-login-form" onSubmit={handleSubmit(onSubmit)}>
          <Card className="mb-0">
            <CardBody>
              <Link className="brand-logo" to="/" onClick={(e) => e.preventDefault()}>
                <img src={themeConfig.app.appLogoImage} alt="logo" style={{ width: '40%' }} />
              </Link>

              <div className="mb-1">
                <Label className="form-label" for="login_email">
                  Email {''}
                  <span className="text-danger" style={{ fontSize: '17px' }}>
                    *
                  </span>
                </Label>
                <Controller
                  id="login_email"
                  name="login_email"
                  control={control}
                  render={({ field }) => (
                    <Input
                      autoFocus
                      type="email"
                      placeholder="info@example.com"
                      invalid={errors.login_email}
                      {...field}
                    />
                  )}
                />
                {errors.login_email && <FormFeedback>{errors.login_email.message}</FormFeedback>}
              </div>
              <div className="mb-1">
                <div className="d-flex justify-content-between">
                  <Label className="form-label" for="login_password">
                    Password {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Link to={`/forgot-password`}>
                    <small>Forgot Password?</small>
                  </Link>
                </div>
                <Controller
                  id="login_password"
                  name="login_password"
                  control={control}
                  render={({ field }) => (
                    <InputPasswordToggle className="input-group-merge" invalid={errors.login_password} {...field} />
                  )}
                />
                {errors.login_password && <FormFeedback>{errors.login_password.message}</FormFeedback>}
              </div>
              {/* <div className="form-check mb-1">
                <Input type="checkbox" id="remember-me" />
                <Label className="form-check-label" for="remember-me">
                  Remember Me
                </Label>
              </div> */}
              <Button type="submit" color="primary" disabled={isLoading} block>
                Sign in
                {isLoading && <Spinner size="sm" className="ms-1" />}
              </Button>
              {subdomain === 'org' && (
                <p className="text-center mt-2">
                  <span className="me-25">New on our platform?</span>
                  <Link to={`/register`}>
                    <span>Create an account</span>
                  </Link>
                </p>
              )}
            </CardBody>
          </Card>
        </Form>
      </div>
    </div>
  );
};

export default Login;
