import React, { useMemo, useState } from 'react';
import { Button, Card, CardBody } from 'reactstrap';
import themeConfig from '../../utility/configs/themeConfig';
import { Link } from 'react-router-dom';
import '@styles/react/pages/page-authentication.scss';

const ZohoCallback = () => {
  const authCode = useMemo(() => {
    const params = new URLSearchParams(window.location.search);
    return params.get('code') || '';
  }, []);

  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    if (!authCode) return;
    try {
      await navigator.clipboard.writeText(authCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch (e) {
      // no-op
    }
  };

  return (
    <div className="auth-wrapper auth-basic">
      <div className="auth-inner" style={{ maxWidth: 620, width: '100%' }}>
        <Card className="mb-0">
          <CardBody>
            <Link className="brand-logo" to="#" onClick={(e) => e.preventDefault()}>
              <img src={themeConfig.app.appLogoImage} alt="logo" style={{ width: '25%' }} />
            </Link>
            <h4 className="mb-2">Zoho Authorization Code</h4>
            {authCode ? (
              <>
                <div className="d-flex align-items-center w-100" style={{ gap: 8 }}>
                  <code
                    style={{
                      padding: 6,
                      background: '#f5f5f5',
                      borderRadius: 4,
                      display: 'block',
                      width: '100%',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      fontSize: 12,
                    }}
                  >
                    {authCode}
                  </code>
                  <Button color="primary" size="sm" onClick={handleCopy}>
                    Copy
                  </Button>
                  {copied && <span className="ms-1">Copied!</span>}
                </div>
                <div className="text-muted mt-1" style={{ fontSize: 12 }}>
                  Use this authorization code to configure Zoho CRM.
                </div>
              </>
            ) : (
              <div>No authorization code found in URL.</div>
            )}
          </CardBody>
        </Card>
      </div>
    </div>
  );
};

export default ZohoCallback;
