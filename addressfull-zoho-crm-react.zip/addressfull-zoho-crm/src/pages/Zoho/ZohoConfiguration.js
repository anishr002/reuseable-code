import React, { useState } from 'react';
import { Button, Card, CardBody, Form, Input, Label } from 'reactstrap';
import themeConfig from '../../utility/configs/themeConfig';
import { Link } from 'react-router-dom';
import '@styles/react/pages/page-authentication.scss';

const ZohoConfiguration = () => {
  const [zohoClientKey, setZohoClientKey] = useState('');

  // ✅ Use environment variables from Vite
  const redirectUri = import.meta.env.VITE_ZOHO_REDIRECT_URI;
  const zohoAuthUrl = import.meta.env.VITE_ZOHO_AUTH_URL;

  const handleSubmit = (e) => {
    e.preventDefault();

    const scope = 'ZohoCRM.modules.ALL,ZohoCRM.settings.ALL';

    const authUrl = `${zohoAuthUrl}?scope=${encodeURIComponent(scope)}&client_id=${encodeURIComponent(
      zohoClientKey,
    )}&response_type=code&access_type=offline&redirect_uri=${encodeURIComponent(redirectUri)}`;

    window.location.href = authUrl;
  };

  return (
    <div className="auth-wrapper auth-basic">
      <div className="auth-inner">
        <Form className="auth-login-form" onSubmit={handleSubmit}>
          <Card className="mb-0">
            <CardBody>
              <Link className="brand-logo" to="#" onClick={(e) => e.preventDefault()}>
                <img src={themeConfig.app.appLogoImage} alt="logo" style={{ width: '40%' }} />
              </Link>

              <h4 className="mb-2">Configure Zoho</h4>

              <div className="mb-1">
                <Label className="form-label" for="zohoClientKey">
                  Zoho Client ID{' '}
                  <span className="text-danger" style={{ fontSize: '17px' }}>
                    *
                  </span>
                </Label>
                <Input
                  id="zohoClientKey"
                  type="text"
                  placeholder="Enter Client ID"
                  required
                  value={zohoClientKey}
                  onChange={(e) => setZohoClientKey(e.target.value)}
                />
              </div>

              <Button type="submit" color="primary" block>
                Configure
              </Button>
            </CardBody>
          </Card>
        </Form>
      </div>
    </div>
  );
};

export default ZohoConfiguration;
