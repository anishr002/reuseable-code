// ** React Imports
import AvtarUser from '@assets/images/portrait/avatar-blank.png';
import 'cleave.js/dist/addons/cleave-phone.us';
import { Fragment, useEffect, useState } from 'react';
import { Controller, useFieldArray, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
// ** Reactstrap Imports
import { Button, CardBody, CardHeader, CardTitle, Col, Form, FormFeedback, Input, Label, Row } from 'reactstrap';

import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import { isObjEmpty } from '@utils';
import { Plus, X } from 'react-feather';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import { useNavigate, useParams } from 'react-router-dom';
import Select from 'react-select';
import * as Yup from 'yup';
import {
  addOrganizationsBySuperAdminAPI,
  editOrganizationsBySuperAdminAPI,
  getSingleOrganizationsDetailsAPI,
  setOrganizationsManTab,
  setPaginationOrgManagment,
} from '../../../redux/organizationManagment';
import { onSetLogo } from '../../../utility/Utils';

const Details = ({ OrganizationManTab }) => {
  const { singleOrgnizationDetails } = useSelector((state) => state?.root.OrganizationManagment);
  const { id } = useParams();
  const [imageObj, setImageObj] = useState('');
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [countryD, setCountryD] = useState([]);
  const { paginationDefaultOrgManagment } = useSelector((state) => state?.root?.OrganizationManagment);
  const { organization_types } = useSelector((state) => state?.root?.Setting?.OtherSettings);
  const { PrivacyPolicyData } = useSelector((state) => state?.root?.Setting);
  const [statusOptions, setStatusOptions] = useState(null);
  const [policyOption, setPolicyOption] = useState(null);
  const [rulesOption, setRulesOption] = useState(null);

  // ** States
  const [avatar, setAvatar] = useState('');
  const phoneRegex = /^[0-9]{10}$/;
  const websiteRegex = /^(https?:\/\/)?([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(:[0-9]{1,5})?(\/.*)?$/;

  const validationSchema = Yup.object().shape({
    name: Yup.string()
      .trim()
      .required('Organization name is required')
      .matches(/^[a-zA-Z0-9\s\-\&\'\#]+$/, "Organization name can contain only letters, numbers, spaces and #-'&"),
    registered_number: Yup.string().trim().required('Registration number is required'),
    contact_number: Yup.array().of(
      Yup.object({
        contact_number: Yup.string()
          .trim()
          .matches(/^\+\d{11,}$/, 'Please enter a valid phone number with country code')
          .min(10, 'Phone number must be at least 10 characters')
          .required('Number is required'),
      }),
    ),
    date_of_incorporation: Yup.string().trim().required('Date is required'),
    type: Yup.object().nullable().required('Please select organization type'),
    legal_status: Yup.string().trim().required('Please enter legal status'),
    privacy_policy: Yup.object().nullable().required('Please select privacy policy'),
    policy_rules: Yup.object().nullable().required('Please select policy rules'),
    office_address: Yup.string().trim().required('Office address is required'),
    is_authorized: Yup.object().nullable().required('verification is required'),
    // is_trusted: Yup.object().nullable().required('Please select organization option'),

    email_id: Yup.array().of(
      Yup.object({
        email: Yup.string()
          .trim()
          .email('Please enter a valid email address')
          .required('Email is required')
          .test('uniqueEmail', 'Email must be unique', function (_value, parent) {
            // 'this.parent' refers to the entire form data
            const existingEmails = parent?.from[1]?.value?.email_id?.map((entry) => entry.email);

            const uniqueEmailSet = new Set(existingEmails);
            const hasDuplicates = uniqueEmailSet.size !== existingEmails.length;

            return !hasDuplicates;
          }),
      }),
    ),
    website: Yup.string().required('Website URL is required').matches(websiteRegex, 'Please enter a valid URL'),
    twitter: Yup.string()
      .trim()
      .nullable()
      .test('validTwitterUrl', 'Please enter a valid Twitter URL', function (value) {
        // Allow an empty Twitter URL or validate the URL format
        return !value || /^(https?:\/\/)?(www\.)?x\.com\/[a-zA-Z0-9_]+\/?$/.test(value);
      }),

    linkedin: Yup.string()
      .trim()
      .nullable()
      .test('validLinkedInUrl', 'Please enter a valid LinkedIn URL', function (value) {
        // Allow an empty LinkedIn URL or validate the URL format
        return !value || /^(https?:\/\/)?(www\.)?linkedin\.com\/in\/[a-zA-Z0-9_-]+\/?$/.test(value);
      }),
    description: Yup.string().required('Description is required'),
  });

  const initialValues = {
    name: '',
    registered_number: '',
    is_authorized: id ? null : { value: 'ad', lable: '90' },
    // is_trusted: null,
    date_of_incorporation: '',
    type: null,
    privacy_policy: null,
    policy_rules: null,
    legal_status: '',
    office_address: '',
    email_id: [{ email: '' }],
    website: '',
    description: '',
    contact_number: [{ contact_number: '' }],
    twitter: '',
    linkedin: '',
  };
  const {
    control,
    handleSubmit,
    register,
    reset,
    watch,
    setValue,
    clearErrors,
    getValues,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(validationSchema),
    defaultValues: initialValues,
    mode: 'onChange',
  });

  const {
    fields: emailFields,
    append: appendEmail,
    remove: removeEmail,
  } = useFieldArray({
    name: 'email_id',
    control,
  });

  const {
    fields: numberFields,
    append: appendNumber,
    remove: removeNumber,
  } = useFieldArray({
    name: 'contact_number',
    control,
  });

  const watchCheckboxValues = watch('email_id', {});

  useEffect(() => {
    id && dispatch(getSingleOrganizationsDetailsAPI(id));
  }, [id]);

  useEffect(() => {
    if (OrganizationManTab === '1') {
      setStatusOptions(organization_types?.map((item) => ({ value: item?.name, label: item?.title })));

      if (PrivacyPolicyData) {
        setPolicyOption(PrivacyPolicyData?.policy_list?.map((i) => ({ value: i?._id, label: i?.title })));
      }
    }

    if (OrganizationManTab === '2') {
      reset();
    }
  }, [OrganizationManTab, organization_types, PrivacyPolicyData]);

  const dependedDropDown = (item) => {
    if (item?.value !== getValues()?.privacy_policy?.value) {
      setValue('policy_rules', null);
      setRulesOption(null);
    }
    clearErrors('policy_rules');
    const CheckOption = PrivacyPolicyData?.policy_list?.find((i) => i?._id === item?.value);
    setRulesOption(CheckOption?.sub_rules.map((i) => ({ value: i?._id, label: i.name })));
  };

  const onSubmit = (data) => {
    const payload = {
      ...data,
      contact_number: data?.contact_number?.map((i) => i.contact_number),
      email_id: data?.email_id?.map((i) => i.email),
      type: data?.type?.value,
      policy_id: data?.privacy_policy?.value,
      sub_rule_ids: [data?.policy_rules?.value],
    };
    payload['imageObj'] = imageObj;
    if (!data?.twitter) {
      delete payload?.twitter;
    }
    if (!data?.linkedin) {
      delete payload?.linkedin;
    }

    if (id) {
      payload['is_authorized'] = data?.is_authorized?.value;
    } else {
      delete payload?.is_authorized;
    }

    const countryCode = (coun, numb) => numb?.substring(0, coun.dialCode.length);
    const phoneNumber = (coun, number) => number?.substring(coun.dialCode.length);

    payload.contact_number = payload.contact_number?.map(
      (i, index) =>
        `+${countryCode(countryD[index], i?.replace('+', ''))}|${phoneNumber(countryD[index], i?.replace('+', ''))}`,
    );
    delete payload?.policy_rules;
    delete payload?.privacy_policy;

    if (id) {
      dispatch(editOrganizationsBySuperAdminAPI(payload, id, navigate));
    } else {
      dispatch(
        setPaginationOrgManagment({
          ...paginationDefaultOrgManagment,
          order_by: 'desc',
          sort_by: 'created_at',
        }),
      );
      dispatch(addOrganizationsBySuperAdminAPI(payload, navigate));
    }
    dispatch(setOrganizationsManTab('1'));
  };

  const handleImgReset = () => {
    setAvatar('');
    setImageObj(null);
  };

  useEffect(() => {
    if (singleOrgnizationDetails && !isObjEmpty(singleOrgnizationDetails) && id) {
      Object.entries(initialValues)?.forEach(([key, _value]) => {
        const formattedArray = singleOrgnizationDetails?.email_id?.map((email) => {
          return { email };
        });
        if (key === 'privacy_policy') {
          setValue(
            key,
            PrivacyPolicyData?.policy_list
              ?.map((i) => ({ value: i?._id, label: i?.title }))
              ?.find((i) => i?.value === singleOrgnizationDetails?.policy_id),
          );
        } else if (key === 'status') {
          setValue(key, singleOrgnizationDetails[`${key}`] ? 'Active' : 'InActive');
        } else if (key === 'is_authorized') {
          setValue(key, {
            value: singleOrgnizationDetails[`${key}`] === true ? 'yes' : 'no',
            label: singleOrgnizationDetails[`${key}`] === true ? 'Verified' : 'Not verified',
          });
        } else if (key === 'email_id') {
          setValue(key, formattedArray);
        } else if (key === 'date_of_incorporation') {
          setValue(key, singleOrgnizationDetails[`${key}`]?.split('T')[0]);
        } else if (key === 'type') {
          setValue(
            key,
            statusOptions?.find((i) => i.value === singleOrgnizationDetails[`${key}`]),
          );
        } else if (key === 'contact_number') {
          const newCont = [];
          singleOrgnizationDetails?.contact_number?.map((contactNumber) => {
            newCont.push({
              dialCode: contactNumber?.replace('+', '')?.split('|')?.[0],
            });
          });
          setValue(
            key,
            singleOrgnizationDetails?.contact_number?.map((contactNumber) => {
              return { contact_number: contactNumber?.replace(/[+|]/g, '') };
            }),
          );
          setCountryD(newCont);
        } else {
          setValue(key, singleOrgnizationDetails[`${key}`]);
        }
      });
      const validatePolicyName = PrivacyPolicyData?.policy_list.find(
        (i) => i?._id === singleOrgnizationDetails?.policy_id,
      );
      const CheckOption = PrivacyPolicyData?.policy_list?.find((i) => i?._id === validatePolicyName?._id);
      setRulesOption(CheckOption?.sub_rules.map((i) => ({ value: i?._id, label: i.name })));
      setValue(
        'policy_rules',
        CheckOption?.sub_rules
          .map((i) => ({ value: i?._id, label: i.name }))
          ?.find((i) => i.value === singleOrgnizationDetails?.sub_rule_ids[0]),
      );

      const formattedArray1 = singleOrgnizationDetails?.email_id?.map((email) => {
        return { email };
      });

      setValue('email_id', formattedArray1);

      setAvatar(singleOrgnizationDetails?.profile_picture);
      setImageObj(singleOrgnizationDetails?.profile_picture);
    }
  }, [singleOrgnizationDetails]);

  const handleImageError = (e) => {
    // Replace the broken image with a default avatar or placeholder
    e.target.src = AvtarUser;
  };

  return (
    <Fragment>
      <CardHeader>
        <CardTitle tag="h4">{id ? 'Edit Details' : 'Add  Details'}</CardTitle>
      </CardHeader>
      <CardBody className="my-25">
        {isLoading ? (
          <Spinner open={close} />
        ) : (
          <Form className="mt-2 pt-10" onSubmit={handleSubmit(onSubmit)}>
            <Row>
              <Col md="6">
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="registered_number">
                    Registration Number {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="registered_number"
                    id="registered_number"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        autoComplete="off"
                        className="form-control "
                        invalid={errors.registered_number}
                        placeholder="1 234 567 8900"
                        {...field}
                        disabled={id}
                      />
                    )}
                  />
                  {errors.registered_number && <FormFeedback>{errors.registered_number.message}</FormFeedback>}
                </div>
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="name">
                    Organisation Name {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="name"
                    name="name"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className="form-control"
                        placeholder="Enter organisation name"
                        invalid={errors.name}
                        {...field}
                      />
                    )}
                  />
                  {errors.name && <FormFeedback>{errors.name.message}</FormFeedback>}
                </div>
                <div className="mb-1" style={{ height: '115px' }}>
                  <Label className="form-label" for="office_address">
                    Office Address {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="office_address"
                    name="office_address"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="textarea"
                        className=""
                        placeholder="Enter office address"
                        invalid={errors.office_address}
                        {...field}
                        style={{
                          resize: 'none',
                          height: 'calc(3rem * 1.8)', // Adjust as needed for the desired row height
                          overflowY: 'auto',
                        }}
                      />
                      // <Autocomplete
                      //   apiKey={''}
                      //   onPlaceSelected={(place) => {
                      //     console.log(place);
                      //   }}
                      // />
                    )}
                  />
                  {errors.office_address && <FormFeedback>{errors.office_address.message}</FormFeedback>}
                </div>
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="website">
                    Website URL {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="website"
                    name="website"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className=""
                        placeholder="Enter website URL"
                        invalid={errors.website}
                        {...field}
                      />
                    )}
                  />
                  {errors.website && <FormFeedback>{errors.website.message}</FormFeedback>}
                </div>
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="twitter">
                    Twitter URL
                  </Label>
                  <Controller
                    id="twitter"
                    name="twitter"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className=""
                        placeholder="Enter twitter URL"
                        invalid={errors.twitter}
                        {...field}
                      />
                    )}
                  />
                  {errors.twitter && <FormFeedback>{errors.twitter.message}</FormFeedback>}
                </div>

                <div className="mb-1">
                  <Label className="form-label" for="email">
                    Email{' '}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  {emailFields?.map((field, index) => {
                    return (
                      <Controller
                        key={field?.id}
                        name={`email_id[${index}].email`}
                        control={control}
                        render={(props) => (
                          <div className="mb-1" key={field?.id}>
                            <div className="d-flex">
                              <input
                                type="email"
                                autoComplete="off"
                                name={`email_id[${index}].email`}
                                {...register(`email_id.[${index}].email`, {
                                  required: 'This is required.',
                                })}
                                value={getValues()?.email_id?.[index]?.email}
                                onChange={(e) => props?.field.onChange(e)}
                                className={`form-control 
                               ${errors.email_id?.[index]?.email?.message && 'is-invalid'}`}
                                placeholder="tom@yopmail.com"
                                disabled={id && index === 0}
                              />

                              {index > 0 ? (
                                <Button color="default" onClick={() => removeEmail(index)}>
                                  <X size="15" />
                                </Button>
                              ) : (
                                emailFields?.length < 5 && (
                                  <Button
                                    className="text-decoration-underline"
                                    color="default"
                                    type="button"
                                    onClick={() => appendEmail({ email: '' })}
                                  >
                                    <Plus size="15" />
                                  </Button>
                                )
                              )}
                            </div>
                            <FormFeedback className="d-block">{errors?.email_id?.[index]?.email?.message}</FormFeedback>
                          </div>
                        )}
                      />
                    );
                  })}
                </div>

                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="type">
                    Policy {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="privacy_policy"
                    id="privacy_policy"
                    control={control}
                    className=""
                    // defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={policyOption}
                        className="react-select"
                        classNamePrefix="select"
                        onChange={(e) => {
                          dependedDropDown(e);
                          field.onChange(e);
                        }}
                        invalid={errors.privacy_policy}
                        styles={{
                          control: (baseStyles, _state) => ({
                            ...baseStyles,
                            borderColor: errors.privacy_policy ? 'red' : '#d8d6de',
                          }),
                        }}
                        isSearchable
                        placeholder="Please Select Policy"
                        isDisabled={singleOrgnizationDetails?.policy_id}
                      />
                    )}
                  />
                  {errors && errors.privacy_policy && (
                    <FormFeedback className="d-block">{errors.privacy_policy.message}</FormFeedback>
                  )}
                </div>

                {getValues()?.privacy_policy && (
                  <div className="mb-1 input-error-align">
                    <Label className="form-label" for="type">
                      Rules {''}
                      <span className="text-danger" style={{ fontSize: '17px' }}>
                        *
                      </span>
                    </Label>
                    <Controller
                      name="policy_rules"
                      id="policy_rules"
                      control={control}
                      className=""
                      render={({ field }) => (
                        <Select
                          {...field}
                          options={rulesOption}
                          className="react-select"
                          classNamePrefix="select"
                          invalid={errors.policy_rules}
                          styles={{
                            control: (baseStyles, _state) => ({
                              ...baseStyles,
                              borderColor: errors.policy_rules ? 'red' : '#d8d6de',
                            }),
                          }}
                          isSearchable
                          placeholder="Please select policy rules"
                          isDisabled={singleOrgnizationDetails?.policy_id}
                        />
                      )}
                    />
                    {errors && errors.policy_rules && (
                      <FormFeedback className="d-block">{errors.policy_rules.message}</FormFeedback>
                    )}
                  </div>
                )}
              </Col>
              <Col md="6">
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="date_of_incorporation">
                    Date of Incorporation {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="date_of_incorporation"
                    name="date_of_incorporation"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="date"
                        className=""
                        placeholder="Enter date of incorporation"
                        invalid={errors.date_of_incorporation}
                        {...field}
                      />
                    )}
                  />
                  {errors.date_of_incorporation && <FormFeedback>{errors.date_of_incorporation.message}</FormFeedback>}
                </div>
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="type">
                    Organisation Type {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="type"
                    id="type"
                    control={control}
                    className=""
                    // defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={statusOptions}
                        className="react-select"
                        classNamePrefix="select"
                        invalid={errors.type}
                        styles={{
                          control: (baseStyles, _state) => ({
                            ...baseStyles,
                            borderColor: errors.type ? 'red' : '#d8d6de',
                          }),
                        }}
                        isSearchable
                        placeholder="Please Select Organisation Type"
                      />
                    )}
                  />
                  {errors && errors.type && <FormFeedback className="d-block">{errors.type.message}</FormFeedback>}
                </div>
                <div className="mb-1" style={{ height: '115px' }}>
                  <Label className="form-label" for="description">
                    Organisation Description {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="description"
                    name="description"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="textarea"
                        className=""
                        placeholder="Enter organisation description"
                        invalid={errors.description}
                        {...field}
                        style={{
                          resize: 'none',
                          height: 'calc(3rem * 1.8)', // Adjust as needed for the desired row height
                          overflowY: 'auto',
                        }}
                      />
                    )}
                  />
                  {errors.description && <FormFeedback>{errors.description.message}</FormFeedback>}
                </div>
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="legal_status">
                    Legal Status {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    id="legal_status"
                    name="legal_status"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className=""
                        placeholder="Select legal status"
                        invalid={errors.legal_status}
                        {...field}
                      />
                    )}
                  />
                  {errors.legal_status && <FormFeedback>{errors.legal_status.message}</FormFeedback>}
                </div>
                <div className="mb-1 input-error-align">
                  <Label className="form-label" for="linkedin">
                    LinkedIn URL
                  </Label>
                  <Controller
                    id="linkedin"
                    name="linkedin"
                    control={control}
                    render={({ field }) => (
                      <Input
                        type="text"
                        className=""
                        placeholder="Enter linkedin URL"
                        invalid={errors.linkedin}
                        {...field}
                      />
                    )}
                  />
                  {errors.linkedin && <FormFeedback>{errors.linkedin.message}</FormFeedback>}
                </div>
                {/* <div className="mb-1 ">
                  <Label className="form-label" for="type">
                    Trusted Organisation
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  <Controller
                    name="is_trusted"
                    id="is_trusted"
                    control={control}
                    className=""
                    // defaultValue={null}
                    render={({ field }) => (
                      <Select
                        {...field}
                        options={[
                          { value: 'yes', label: 'Trusted' },
                          { value: 'no', label: 'Not trusted' },
                        ]}
                        className="react-select"
                        classNamePrefix="select"
                        invalid={errors.is_trusted && true}
                        styles={{
                          control: (baseStyles, state) => ({
                            ...baseStyles,
                            borderColor: errors.is_trusted && true ? 'red' : '#d8d6de',
                          }),
                        }}
                        isSearchable
                        placeholder="Please Select "
                      />
                    )}
                  />
                  {errors && errors?.is_trusted && (
                    <FormFeedback className="d-block">{errors?.is_trusted?.message}</FormFeedback>
                  )}
                </div> */}
                <div className="mb-1 ">
                  <Label className="form-label" for="contact_number">
                    Contact Number {''}
                    <span className="text-danger" style={{ fontSize: '17px' }}>
                      *
                    </span>
                  </Label>
                  {numberFields.map((item, index) => (
                    <Controller
                      key={item?.id}
                      name={`contact_number[${index}].contact_number`}
                      control={control}
                      render={(props) => (
                        <div className="mb-1">
                          <div className="d-flex">
                            <PhoneInput
                              key={item?.id}
                              as={<input />}
                              ref={props?.field?.ref}
                              name={`contact_number[${index}].contact_number`}
                              onChange={(phone, { country }) => {
                                const conpy = [...countryD];
                                conpy[index] = country;
                                setCountryD(conpy);
                                props.field.onChange(phone);
                                numberFields[index] = {
                                  contact_number: phone,
                                  id: item?.id,
                                };
                              }}
                              inputProps={{
                                id: `contact_number${index}`,
                                name: `contact_number[${index}].contact_number`,
                                // required: true,
                                autoComplete: 'none',
                              }}
                              value={item?.contact_number}
                              specialLabel=""
                              className="w-100"
                              inputClassName="form-control"
                              dropdownClass="react-select"
                              styles={{ width: '100%' }}
                              disableDialCodePrefill={true}
                              disabled={index === 0 && id}
                            />
                            {index > 0 ? (
                              <Button color="default" onClick={() => removeNumber(index)}>
                                <X size="15" />
                              </Button>
                            ) : (
                              numberFields?.length < 5 && (
                                <Button
                                  className="text-decoration-underline"
                                  color="default"
                                  type="button"
                                  onClick={() => appendNumber({ contact_number: '' })}
                                >
                                  <Plus size="15" />
                                </Button>
                              )
                            )}
                          </div>
                          <FormFeedback className="d-block">
                            {errors?.contact_number?.[index]?.contact_number?.message}
                          </FormFeedback>
                        </div>
                      )}
                      rules={{
                        required: 'Phone number is required',
                        validate: (value) => value?.match(phoneRegex) || 'Phone number must be at least 10 digits',
                      }}
                    />
                  ))}
                </div>

                {id && (
                  <div className="mb-1 ">
                    <Label className="form-label" for="type">
                      Organisation Verification {''}
                      <span className="text-danger" style={{ fontSize: '17px' }}>
                        *
                      </span>
                    </Label>
                    <Controller
                      name="is_authorized"
                      id="is_authorized"
                      control={control}
                      className=""
                      // defaultValue={null}
                      render={({ field }) => (
                        <Select
                          {...field}
                          options={[
                            { value: 'yes', label: 'Verified' },
                            { value: 'no', label: 'Not verified' },
                          ]}
                          className="react-select"
                          classNamePrefix="select"
                          invalid={errors.is_authorized}
                          styles={{
                            control: (baseStyles, _state) => ({
                              ...baseStyles,
                              borderColor: errors.is_authorized ? 'red' : '#d8d6de',
                            }),
                          }}
                          isSearchable
                          placeholder="Please Select "
                        />
                      )}
                    />
                    {errors && errors.is_authorized && (
                      <FormFeedback className="d-block">{errors.is_authorized.message}</FormFeedback>
                    )}
                  </div>
                )}
              </Col>
            </Row>

            <Row className="mt-3">
              <Col sm="4">
                <div className="border-end pe-3 d-flex align-item-center mt-75 ">
                  <div className="me-2">
                    <img
                      className="rounded-circle me-100"
                      src={avatar || AvtarUser}
                      alt="Generic_placeholder_image"
                      height="100"
                      width="100"
                      onError={handleImageError}
                    />
                  </div>
                  <div className="d-flex flex-column justify-content-center ms-1 ">
                    <Button tag={Label} className="mb-75  py-1 px-2" size="sm" color="primary" outline>
                      Upload Logo
                      <Input
                        type="file"
                        onChange={(e) => onSetLogo(e, setImageObj, setAvatar)}
                        hidden
                        accept="image/*"
                      />
                    </Button>
                    {avatar && (
                      <Button color="flat-danger" size="sm" onClick={handleImgReset}>
                        Remove
                      </Button>
                    )}
                  </div>
                </div>
              </Col>
              <Col sm="8">
                <div className="ms-2">
                  <CardTitle>Image Specifications</CardTitle>
                  <ol>
                    <li>Min. 400 x 400px</li>
                    <li>Max. 100KB</li>
                    <li>Your face or company logo</li>
                  </ol>
                </div>
              </Col>
            </Row>
            <div className="d-flex justify-content-center mt-2">
              <Button color="primary" type="submit" className="d-flex">
                Save
              </Button>
            </div>
          </Form>
        )}
      </CardBody>
    </Fragment>
  );
};

export default Details;
