import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button } from 'reactstrap';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Details from './Details';
import Documents from './Documents';
import { setOrganizationsManTab } from '../../../redux/organizationManagment';
import { useNavigate } from 'react-router';
import { useParams } from 'react-router-dom/dist';
import { getOtherSettings } from '../../../redux/settings';

const OrganizationManagmentTab = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { OrganizationManTab } = useSelector((state) => state?.root?.OrganizationManagment);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { id } = useParams();

  useEffect(() => {
    dispatch(getOtherSettings());
  }, []);

  return (
    <Card>
      <div className="d-flex">
        <Nav tabs className="mt-2 mx-2 h4">
          <NavItem>
            <NavLink active={OrganizationManTab === '1'} onClick={() => dispatch(setOrganizationsManTab('1'))}>
              Details
            </NavLink>
          </NavItem>
          <NavItem>
            <NavLink
              active={OrganizationManTab === '2'}
              disabled={!id}
              onClick={() => dispatch(setOrganizationsManTab('2'))}
            >
              Documents
            </NavLink>
          </NavItem>
        </Nav>
        {!isLoading && OrganizationManTab !== '2' && (
          <div className="ms-auto">
            <Button
              className="d-flex mx-2 mt-2"
              color="primary"
              onClick={() => {
                navigate(-1);
              }}
            >
              Back
            </Button>
          </div>
        )}
      </div>

      <TabContent className="py-50" activeTab={OrganizationManTab}>
        <TabPane tabId="1">
          <Details OrganizationManTab={OrganizationManTab} />
        </TabPane>
        <TabPane tabId="2">
          <Documents />
        </TabPane>
      </TabContent>
    </Card>
  );
};

export default OrganizationManagmentTab;
