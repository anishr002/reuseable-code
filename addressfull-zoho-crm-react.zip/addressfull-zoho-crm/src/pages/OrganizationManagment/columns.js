import { store } from '@store/store';
import { CheckCircle, Edit2, Trash2, XCircle } from 'react-feather';
import { Link } from 'react-router-dom';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { deleteOrganizationsBySuperAdminAPI } from '../../redux/organizationManagment';
import { convertToTimeZone } from '../../utility/Utils';

const MySwal = withReactContent(Swal);

const showAlert = (_id) => {
  return MySwal.fire({
    title: 'Remove Organisation',
    html: (
      <p>
        Are you sure?
        <br />
        You want to remove this Organisation
      </p>
    ),
    icon: 'warning',
    showCancelButton: false,
    confirmButtonText: 'Remove',
    showCloseButton: true,
    customClass: {
      confirmButton: 'd-flex w-100 btn btn-primary btn-ripple btn-block',
    },
    buttonsStyling: false,
  }).then(function (result) {
    if (result.isConfirmed) {
      store.dispatch(deleteOrganizationsBySuperAdminAPI(_id));
    }
  });
};

export const columns = [
  {
    name: 'Organisation Name',
    minWidth: '180px',
    sortable: 'name',
    cell: (row) => row?.organization_name,
  },
  {
    name: 'Reg. No',
    sortable: 'registered_number',
    minWidth: '130px',
    selector: (row) => row.registered_number,
  },
  {
    name: 'Email',
    sortable: false,
    minWidth: '250px',
    selector: (row) => row?.primary_email,
  },
  {
    name: 'Contact',
    sortable: false,
    minWidth: '100px',
    selector: (row) => row?.contact_number?.[0]?.replace('|', ' '),
  },
  {
    name: 'Registration Date',
    sortable: 'date_of_incorporation',
    minWidth: '170px',
    selector: (row) => convertToTimeZone(row.date_of_incorporation, row?.timezone),
  },
  {
    name: 'Status',
    sortable: false,
    minWidth: '100px',
    selector: (row) => {
      return row?.is_authorized === true ? <CheckCircle color="green" /> : <XCircle color="red" />;
    },
  },
  {
    name: 'Actions',
    allowOverflow: true,
    minWidth: '150px',

    cell: (row) => {
      return (
        <div className="d-flex">
          {/* <img src={verified} className="me-2" style={{ width: '16px', height: '16px' }} /> */}
          <Link to={`edit/${row?.id}`} className="text-decoration-none icon-color-cust">
            <Edit2 size={16} className="me-2 cursor-pointer icon-color-cust" />
          </Link>
          <Trash2 size={16} color="red" className="cursor-pointer icon-color-cust" onClick={() => showAlert(row?.id)} />
        </div>
      );
    },
  },
];
