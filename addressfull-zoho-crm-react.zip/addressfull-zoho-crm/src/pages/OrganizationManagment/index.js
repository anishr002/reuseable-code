import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Button, Card, CardHeader, CardText } from 'reactstrap';
import CustomHeader from '../../components/tableCusHeader/CustomHeader';
import { getOrganizationManagmentListAPI } from '../../redux/organizationManagment';
import { useDebouncedValue } from '../../utility/hooks/useDebouncedValue';
import { columns } from './columns';

const OrganizationManagment = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchValue, setSearchValue] = useState('');
  const [data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(1);
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const { OrganizationManData, rowsPerPagesData, paginationDefaultOrgManagment } = useSelector(
    (state) => state?.root?.OrganizationManagment,
  );
  const { UserData } = useSelector((state) => state.root?.authentication);

  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);
  const writePermission = UserData?.permissions?.find((item) => item?.section === 'organizations')?.permissions?.write;
  const readpermission = UserData?.permissions?.find((item) => item?.section === 'organizations')?.permissions?.read;

  const timezonesData = useSelector((state) => state?.root?.Setting?.OtherSettings);

  useEffect(() => {
    if (searchValue && readpermission) {
      dispatch(
        getOrganizationManagmentListAPI({
          page: currentPage,
          page_size: rowsPerPagesData,
          order_by: 'desc',
          sort_by: 'created_at',
          search: searchValue,
        }),
      );
    } else {
      const payload = { ...paginationDefaultOrgManagment };
      delete payload?.search;

      readpermission &&
        dispatch(
          getOrganizationManagmentListAPI({
            ...payload,
            page: currentPage,
            page_size: rowsPerPage,
          }),
        );
    }
  }, [debouncedValue]);

  useEffect(() => {
    setCurrentPage(OrganizationManData?.page_info?.current_page);
    setTotalCount(OrganizationManData?.page_info?.total_count);
    setRowsPerPage(rowsPerPagesData);
    setData(OrganizationManData?.organization_list?.map((i) => ({ ...i, timezone: timezonesData?.timezone })));
  }, [OrganizationManData]);

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const apiCallPagination = () => {
    const payload = {};
    if (searchValue) {
      payload.search = searchValue;
    }
    return payload;
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Organisations</CardText>
        {writePermission && (
          <Button color="primary" className="d-flex ms-auto " onClick={() => navigate('add')}>
            ADD
          </Button>
        )}
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          responsive
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: 'Rows per page:',
            rangeSeparatorText: 'of',
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: 'All',
          }}
          paginationPerPage={paginationDefaultOrgManagment?.page_size}
          paginationTotalRows={totalCount}
          paginationServer={true}
          paginationDefaultPage={paginationDefaultOrgManagment?.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={(page, totalRows) => {
            console.log('Page changed:', page, 'Total Rows:', totalRows);
            setCurrentPage(page);
            dispatch(
              getOrganizationManagmentListAPI({
                ...paginationDefaultOrgManagment,
                page,
                ...apiCallPagination(),
              }),
            );
          }}
          onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
            console.log('Rows per page changed:', currentRowsPerPage, 'Current Page:', currentPage);
            dispatch(
              getOrganizationManagmentListAPI({
                ...paginationDefaultOrgManagment,
                page: currentPage,
                page_size: currentRowsPerPage,
                ...apiCallPagination(),
              }),
            );
          }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={(column, order) => {
            dispatch(
              getOrganizationManagmentListAPI({
                page: currentPage,
                page_size: rowsPerPage,
                order_by: order,
                sort_by: column?.sortable,
              }),
            );
          }}
          persistTableHead={true}
          subHeaderComponent={
            <CustomHeader rowsPerPage={rowsPerPage} searchValue={searchValue} handle_filter={handleFilter} />
          }
          customStyles={customStyles}
        />
      </div>
    </Card>
  );
};

export default OrganizationManagment;
