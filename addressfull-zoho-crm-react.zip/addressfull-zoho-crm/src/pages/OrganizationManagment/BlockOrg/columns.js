import Avatar from '@components/avatar';
import { User } from 'react-feather';
export const columns = [
  {
    name: 'Organisation',
    minWidth: '200px',
    sortable: false, //organization_name
    cell: (row) => (
      <div>
        <Avatar
          imgClassName="rounded cursor"
          className="me-75 mt-1 mb-1"
          img={row?.organization_profile_image ?? false}
          icon={<User />}
          color="light-primary"
          imgHeight="40"
          imgWidth="40"
          contentStyles={{ width: '40px', height: '40px' }}
        />
        {row?.organization_name}
      </div>
    ),
  },
  {
    name: 'Reason',
    minWidth: '130px',
    sortable: false,
    selector: (row) => row.block_reason,
  },
  {
    name: 'Blocked by User',
    minWidth: '130px',
    sortable: false,
    selector: (row) =>
      `${row?.countryCode?.includes('+') ? row?.countryCode : '+' + row?.countryCode}  ${row?.mobileNumber}`,
  },
];
