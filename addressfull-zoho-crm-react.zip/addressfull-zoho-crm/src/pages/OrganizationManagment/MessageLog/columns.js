import { FileText } from 'react-feather';
import { Badge } from 'reactstrap';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import { convertToTimeZone } from '../../../utility/Utils';
const mySwal = withReactContent(Swal);

const showAlert = (row) => {
  return mySwal
    .fire({
      title: 'Attempt Logs',
      html: (
        <ol className="text-start list-group list-group-numbered" style={{ maxHeight: '300px', overflowY: 'auto' }}>
          {row?.attempt_logs?.map(
            (_attempt, index) =>
              index % 2 === 0 && (
                <li
                  className="list-group-item d-flex justify-content-between align-items-start"
                  key={row.attempt_logs[index]}
                >
                  <div className="ms-2 me-auto">
                    <div className="fw-bold">{row.attempt_logs[index]}</div>
                    {row.attempt_logs[index + 1]}
                  </div>
                </li>
              ),
          )}
        </ol>
      ),
      // icon: 'warning',
      showClass: {
        popup: `
      animate__animated
      animate__fadeIn
      animate__faster
    `,
      },
      hideClass: {
        popup: `
      animate__animated
      animate__fadeOut
      animate__faster
    `,
      },
      showCancelButton: false,
      confirmButtonText: 'Close',
      showCloseButton: true,
      customClass: {
        confirmButton: 'd-flex w-100 btn btn-primary btn-ripple btn-block',
      },
      buttonsStyling: false,
    })
    .then(function (_result) {
      // if (result.isConfirmed) {
      //   store.dispatch(deleteRoleAPI(_id));
      // }
    });
};

export const columns = [
  {
    name: 'Mobile Number',
    minWidth: '130px',
    sortable: false, //organization_name
    cell: (row) =>
      `${row?.country_code?.includes('+') ? row?.country_code : '+' + row?.country_code}  ${row?.mobile_number}`,
  },
  {
    name: 'Attempt Count',
    minWidth: '130px',
    sortable: false,
    selector: (row) => row.try_count ?? 0,
  },
  {
    name: 'Failed Count',
    minWidth: '130px',
    sortable: false,
    selector: (row) => row.fail_count ?? 0,
  },
  {
    name: 'Date & Time',
    minWidth: '150px',
    sortable: 'created_at',
    selector: (row) => {
      return row?.created_at?.includes(',') ? row?.created_at : convertToTimeZone(row?.created_at, row?.timezone);
    },
  },
  {
    name: 'Status',
    minWidth: '130px',
    sortable: 'status',
    selector: (row) => {
      return (
        <Badge
          color={row?.status === 'Pending' ? 'warning' : row?.status === 'Success' ? '' : 'danger'}
          className={row?.status === 'Success' ? 'custom-badge' : ''}
          pill
        >
          {row?.status}
        </Badge>
      );
    },
  },

  {
    name: 'Logs',
    allowOverflow: true,
    cell: (row) => {
      return row?.attempt_logs?.length > 1 ? (
        <div className="d-flex">
          <FileText size={20} color="blue" className="cursor-pointer icon-color-cust" onClick={() => showAlert(row)} />
        </div>
      ) : (
        <div className="d-flex">N/A</div>
      );
    },
  },
];
