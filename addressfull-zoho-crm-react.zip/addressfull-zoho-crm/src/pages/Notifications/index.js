import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { Card, CardHeader, CardText } from 'reactstrap';
import { getNotificationAPI } from '../../redux/organizationMain';
import { columns } from './columns';

const Notifications = () => {
  const dispatch = useDispatch();
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(1);
  const { NotificationData, rowsPerPagesData } = useSelector((state) => state?.root?.Organization);
  const { paginationDefaultList } = useSelector((state) => state?.root?.Organization?.OrganizationDetailes);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);
  const timezonesData = useSelector((state) => state?.root?.Setting?.OtherSettings);

  const data = NotificationData?.notification_list?.map((i) => ({ ...i, timezone: timezonesData?.timezone }));

  useEffect(() => {
    setCurrentPage(NotificationData?.page_info?.current_page);
    setTotalCount(NotificationData?.page_info?.total_count);
    setRowsPerPage(rowsPerPagesData);
  }, [NotificationData]);

  useEffect(() => {
    dispatch(getNotificationAPI(currentPage, rowsPerPage));
  }, []);

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Notifications</CardText>
      </CardHeader>

      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader={false}
          responsive
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: 'Rows per page:',
            rangeSeparatorText: 'of',
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: 'All',
          }}
          paginationPerPage={rowsPerPagesData}
          paginationTotalRows={totalCount}
          paginationServer={true}
          paginationDefaultPage={paginationDefaultList?.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={(page, totalRows) => {
            console.log('Page changed:', page, 'Total Rows:', totalRows);
            setCurrentPage(page);
            dispatch(getNotificationAPI(page, rowsPerPagesData));
          }}
          onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
            console.log('Rows per page changed:', currentRowsPerPage, 'Current Page:', currentPage);
            dispatch(getNotificationAPI(currentPage, currentRowsPerPage));
          }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          customStyles={customStyles}
          persistTableHead={true}
        />
      </div>
    </Card>
  );
};

export default Notifications;
