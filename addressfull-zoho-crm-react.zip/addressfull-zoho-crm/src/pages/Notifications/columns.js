import { convertToTimeZone } from '../../utility/Utils';

export const columns = [
  {
    name: 'Action',
    minWidth: '250px',
    sortable: false,
    cell: (row) => <p>{row?.message}</p>,
  },
  // {
  //   name: 'User Name',
  //   // sortable: true,
  //   minWidth: '250px',
  //   selector: (row) => row?.userType,
  // },
  {
    name: 'Date & Time',
    sortable: false,
    minWidth: '150px',
    selector: (row) => convertToTimeZone(row?.default_request_date, row?.timezone),
  },
];
