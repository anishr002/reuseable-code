import { Badge } from 'reactstrap';
import { Link } from 'react-router-dom';

// function maskPhoneNumber(phoneNumber) {
//   // Remove non-numeric characters from the phone number
//   const numericPhoneNumber = phoneNumber.replace(/\D/g, '');

//   // Get the total length of the numeric phone number
//   const totalLength = numericPhoneNumber.length;

//   // Calculate the number of asterisks needed
//   const asterisksCount = Math.max(0, totalLength - 3);

//   // Construct the masked phone number with asterisks
//   const maskedPhoneNumber = '*'.repeat(asterisksCount) + numericPhoneNumber.slice(-3);

//   return maskedPhoneNumber;
// }

export const columns = [
  // {
  //   name: 'User',
  //   minWidth: '250px',
  //   // sortable: true,
  //   cell: (row) => {
  //     return <Link to="user-profile">{row?.id}</Link>;
  //   },
  // },
  {
    name: 'Registered Number',
    sortable: 'mobile_number',
    minWidth: '250px',
    selector: (row) => `+${row?.country_code ?? ''} ${row?.mobile_number ?? ''}`,
  },
  {
    name: 'Actions',
    sortable: false,
    minWidth: '150px',
    selector: (row) => {
      return (
        <Badge
          color={row?.write_p ? 'info' : 'secondary'}
          className={` ${!row?.write_p ? 'disabled' : 'cursor-pointer'}`}
          pill
        >
          {/* Apply a specific style to the Link based on the condition */}
          <Link to={`${row?.id}?${row?.mobile_number}`} style={{ pointerEvents: !row?.write_p ? 'none' : 'auto' }}>
            {row?.isUserConnected ? 'Re-request' : 'Request'}
          </Link>
        </Badge>
      );
    },
  },
];
