import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import React, { Fragment } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown } from 'react-feather';
import { useSelector } from 'react-redux';
import Select from 'react-select';
import { Card, CardHeader, CardText, Col, Row } from 'reactstrap';
import CustomPagination from '../../../components/pagination';
import TransactionsHeader from '../../../components/tableCusHeader/TransactionsHeader';

import { columns } from './columns';

const UserTransactions = ({
  handle_filter,
  searchValue,
  handle_filterdate,
  handlePageChange,
  last_page,
  currentPage,
  setCurrentPage,
  rowsPerPage,
  previousPageString,
  nextPageString,
  totalCount,
  data,
  paginationDefaultList,
  permissionsStatus,
  handlePermissionStatus,
  handleLogType,
  logType,
  depended_dropDown,
  permissionsStatusDropDown,
  applyFilter,
  clearFilter,
  isDisableClear,
  isDisableApply,
  setEndDate,
  setStartDate,
}) => {
  const { isLoading } = useSelector((state) => state?.root?.appLoading);

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Transactions Listings</CardText>
        <Row>
          <Col>
            <Select
              options={[
                { id: 'request', name: 'Request' },
                { id: 'consent', name: 'Consent' },
                { id: null, name: 'ALL' },
              ]?.map((item) => ({
                value: item?.id,
                label: item?.name,
              }))}
              className="react-select w-100"
              classNamePrefix="select"
              value={logType}
              onChange={(e) => {
                handleLogType(e);
                depended_dropDown(e?.value);
              }}
              styles={{
                control: (baseStyles, _state) => ({
                  ...baseStyles,
                  borderColor: '#d8d6de',
                  minWidth: '230px',
                }),
              }}
              placeholder="Log type"
            />
          </Col>
          <Col>
            <Select
              options={permissionsStatusDropDown?.map((item) => ({
                value: item?.id,
                label: item?.name,
              }))}
              className="react-select w-100"
              classNamePrefix="select"
              value={permissionsStatus}
              onChange={(e) => handlePermissionStatus(e)}
              styles={{
                control: (baseStyles, _state) => ({
                  ...baseStyles,
                  borderColor: '#d8d6de',
                  minWidth: '230px',
                }),
              }}
              placeholder="Permission status"
            />
          </Col>
        </Row>
      </CardHeader>

      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          subHeader
          responsive
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationPerPage={paginationDefaultList?.page_size}
          paginationServer={true}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          customStyles={customStyles}
          persistTableHead={true}
          paginationComponent={(props) => (
            <CustomPagination
              {...props}
              onPageChange={handlePageChange}
              last_page={last_page}
              currentPage={currentPage}
              setCurrentPage={setCurrentPage}
              rowsPerPage={rowsPerPage}
              previousPageString={previousPageString}
              nextPageString={nextPageString}
              totalCount={totalCount}
            />
          )}
          subHeaderComponent={
            <TransactionsHeader
              handle_filterdate={handle_filterdate}
              searchValue={searchValue}
              handle_filter={handle_filter}
              clearFilter={clearFilter}
              applyFilter={applyFilter}
              isDisableClear={isDisableClear}
              isDisableApply={isDisableApply}
              setStartDate={setStartDate}
              setEndDate={setEndDate}
            />
          }
        />
      </div>
    </Card>
  );
};

export default UserTransactions;
