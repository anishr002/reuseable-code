import moment from 'moment';
import { useState } from 'react';
import { Tooltip } from 'reactstrap';

const Toolstip = ({ id, text }) => {
  const [tooltipOpen, setTooltipOpen] = useState(false);

  const toggle = () => {
    setTooltipOpen(!tooltipOpen);
  };

  return (
    <>
      <span id={id}>{text ?? '-'}</span>
      <Tooltip placement="right" isOpen={tooltipOpen} target={id} toggle={toggle}>
        {text ?? '-'}
      </Tooltip>
    </>
  );
};
export const columns = [
  {
    name: 'Transaction ID',
    minWidth: '180px',
    sortable: true,
    sortName: 'first_name',
    cell: (row) => `${row?.Record?.id ?? ''}`,
  },
  {
    name: 'Transaction Type',
    // sortable: true,
    minWidth: '10px',
    selector: (row) => row?.Record?.logType,
  },
  {
    name: 'User ID',
    sortable: true,
    minWidth: '100px',
    sortName: 'email',
    selector: (row) =>
      `${row?.Record?.countryCode?.includes('+') ? row?.Record?.countryCode : '+' + row?.Record?.countryCode}  ${
        row?.Record?.mobileNumber
      }`,
  },
  {
    name: 'messages',
    sortable: false,
    // minWidth: '200px',
    selector: (row, index) => <Toolstip id={`tooltip-${index}`} text={row?.Record?.messages} />,
  },
  {
    name: 'Date & Time',
    sortable: true,
    minWidth: '150px',
    sortName: 'active',
    selector: (row) => {
      return row?.Record?.createdAt?.includes(',')
        ? row?.Record?.createdAt
        : moment(row?.Record?.createdAt).format('DD-MM-YYYY');
    },
  },
];
