// ** React Imports
import { Fragment, useRef, useState } from 'react';

// ** Reactstrap Imports
import { Button, CardBody, ListGroup, ListGroupItem } from 'reactstrap';

// ** Third Party Imports
import { countries } from 'countries-list';
import { isValidNumber, parsePhoneNumber } from 'libphonenumber-js';
import { DownloadCloud, FileText, X } from 'react-feather';
import toast from 'react-hot-toast';
import { useDispatch } from 'react-redux';
import { checkUserExcelValidationAPI } from '../../redux/organizatinUsers';
import { convertExcelToJson, downloadDemoFile } from '../../utility/Utils';
import CustomToast, { ErrorCss, SuccessCss } from '../../utility/toast/CustomToast';

const FileUpload = (props) => {
  // ** State
  const [files, setFiles] = useState([]);
  const dispatch = useDispatch();
  const [jsonData, setJsonData] = useState(null);
  const fileInputRef = useRef(null);

  const renderFilePreview = (file) => {
    if (file.type.startsWith('image')) {
      return <img className="rounded" alt={file.name} src={URL.createObjectURL(file)} height="28" width="28" />;
    } else {
      return <FileText size="28" />;
    }
  };

  const handleRemoveFile = (_file) => {
    setFiles([]);
    setJsonData(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = null;
    }
  };

  const renderFileSize = (size) => {
    if (Math.round(size / 100) / 10 > 1000) {
      return `${(Math.round(size / 100) / 10000).toFixed(1)} mb`;
    } else {
      return `${(Math.round(size / 100) / 10).toFixed(1)} kb`;
    }
  };

  const fileList = files.map((file, index) => (
    <ListGroupItem key={`${file.name}-${index}`} className="d-flex align-items-center justify-content-between">
      <div className="file-details d-flex align-items-center">
        <div className="file-preview me-1">{renderFilePreview(file)}</div>
        <div>
          <p className="file-name mb-0 text-break">{file.name}</p>
          <p className="file-size mb-0">{renderFileSize(file.size)}</p>
        </div>
      </div>
      <Button color="danger" outline size="sm" className="btn-icon" onClick={() => handleRemoveFile(file)}>
        <X size={14} />
      </Button>
    </ListGroupItem>
  ));

  const handleUploade = async () => {
    const payload = {
      singleItem: 'false',
      mobile_numbers: jsonData,
    };

    dispatch(checkUserExcelValidationAPI(payload)).then((result) => {
      if (result.status === 200) {
        // if (result?.openReqPopup === false) {
        toast(<CustomToast message={result?.message} type={'success'} />, SuccessCss());
        // }
      }
      props?.setShow(false);
    });
  };

  const handleFileChange = async (e) => {
    setFiles([]);
    const file = e.target.files[0];

    // Check if the file type is allowed
    const allowedFileTypes = ['.xlsx', '.xls', '.csv'];
    const fileType = file.name.slice(file.name.lastIndexOf('.'));
    if (!allowedFileTypes.includes(fileType)) {
      toast(<CustomToast message={'Only .xlsx, .xls, or .csv files are allowed'} type={'error'} />, ErrorCss());
      return;
    }

    try {
      const data = await convertExcelToJson(file);

      if (convertData(data)?.IS_VALIDATE) {
        // toast(<CustomToast message={'File Imported Successfully !!'} type={'success'} />, SuccessCss());
        setJsonData(convertData(data)?.data);
        setFiles([file]);
      } else {
        const longError = convertData(data)?.errors.join(', ')?.length;
        toast(<CustomToast message={'File cannot be uploaded due to invalid data.'} type={'error'} />, ErrorCss());

        setFiles([]);
        setJsonData(null);

        if (fileInputRef.current) {
          fileInputRef.current.value = null;
        }
      }
    } catch (error) {
      console.error('Error converting Excel to JSON:', error);
    }
  };

  // Define the function to get phone code by numeric country code
  function getPhoneCodeByNumericCountryCode(numericCountryCode) {
    for (const countryCode in countries) {
      if (countries.hasOwnProperty(countryCode)) {
        const countryData = countries[countryCode];
        if (countryData.phone && countryData.phone.length > 0 && countryData.phone[0] === numericCountryCode) {
          return { ...countryData, NAME_CODE: countryCode };
        }
      }
    }
    return null;
  }

  // Define the function to check if the country code is valid
  function isValidCountryCode(countryCode) {
    return getPhoneCodeByNumericCountryCode(countryCode);
  }

  // Define the function to check if the mobile number is valid
  function isValidMobileNumber(countryCode, mobileNumber) {
    try {
      const phoneNumber =
        isValidCountryCode(countryCode) !== null
          ? parsePhoneNumber(String(mobileNumber), isValidCountryCode(countryCode)?.NAME_CODE)
          : false;

      if (phoneNumber) {
        const phoneNumberRegex = /^.{7,16}$/;
        return (
          isValidNumber({ phone: phoneNumber?.nationalNumber, country: phoneNumber?.country }) ||
          phoneNumberRegex.test(String(phoneNumber?.nationalNumber))
        );
      }

      return false; // Return false if no valid phoneNumber object exists
    } catch (error) {
      console.error('Error validating mobile number:', error);
      return false; // Gracefully return false if an error occurs
    }
  }

  // Define the function to convert the data
  function convertData(data) {
    const convertedData = [];
    const errors = [];
    let firstRow = true;
    let secondRow = false;

    // Track the first row title and second row name
    let firstRowTitle = '';
    let secondRowName = '';

    if (data[0]?.length === 0) {
      errors.push(`File is Invalid`);
    }

    for (let i = 1; i < data.length; i++) {
      if (data[0]?.length !== 2) {
        errors.push(`Only two rows are allowed`);
        break;
      }
      const [countryCode, mobileNumber] = data[i];

      // First row title validation
      if (firstRow) {
        firstRowTitle = data[0][0];
        firstRow = false;
        if (data[0][0] !== 'Country Code') {
          errors.push(`First row title should be 'Country Code'`);
        }
        // continue;
      }

      // Second row name validation
      if (!secondRow) {
        secondRowName = data[0][1];
        secondRow = true;
        if (data[0][1] !== 'Mobile Number') {
          errors.push(`Second row name should be 'Mobile Number'`);
        }
        // continue;
      }

      // Check if space character is present in fields
      if (/\D/.test(countryCode)) {
        errors.push(`Row ${i + 1}, ${countryCode}: invalid country code `);
        break;
      }
      // // Check if space character is present in fields
      if (/\D/.test(mobileNumber)) {
        errors.push(`Row ${i + 1}, ${mobileNumber}: invalid mobile number `);
        break;
      }

      if (!isValidCountryCode(countryCode)) {
        errors.push(`${countryCode}: Invalid country code`);
      }
      if (!isValidMobileNumber(countryCode, mobileNumber)) {
        // console.log('####2', countryCode, mobileNumber);
        errors.push(`${mobileNumber}: Invalid mobile number`);
      }

      // Add the data to the converted data
      convertedData.push(`${countryCode}|${mobileNumber}`);
    }

    if (errors.length > 0) {
      console.error('Conversion Errors:', errors);
      return { IS_VALIDATE: false, errors };
    }

    return { data: convertedData, IS_VALIDATE: true };
  }

  return (
    <CardBody>
      <div>
        <Button color="primary" onClick={() => downloadDemoFile()}>
          Sample File
        </Button>
      </div>
      <div className="py-1">Note: Use a single quote to add a zero before a number.</div>
      <div className="dropzone" onClick={() => fileInputRef.current.click()}>
        <input
          type="file"
          accept=".xlsx, .xls, .csv"
          onChange={handleFileChange}
          style={{ display: 'none' }}
          ref={fileInputRef}
        />
        <div className="d-flex align-items-center justify-content-center flex-column">
          <DownloadCloud size={64} />
          <h5>Click to Import Excel or CSV file</h5>
          <em className="ms-2">(Accepted file types: .xlsx, .xls, .csv)</em>
        </div>
      </div>
      {files.length ? (
        <Fragment>
          <ListGroup className="my-2">{fileList}</ListGroup>
          <div className="d-flex justify-content-end">
            <Button onClick={handleUploade} color="primary">
              Request Details
            </Button>
          </div>
        </Fragment>
      ) : null}
    </CardBody>
  );
};

export default FileUpload;
