import Avatar from '@components/avatar';
import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Card, CardBody, CardHeader, CardTitle, Col, Row } from 'reactstrap';

const UserProfile = () => {
  return (
    <div>
      <Card>
        <CardHeader>
          <div className="d-flex align-items-center">
            <CardTitle className="mb-0 fw-bolder">User Detail</CardTitle>
          </div>
          <Link to={`/organization-users`}>
            <Button color="primary">Back</Button>
          </Link>
        </CardHeader>
        <CardBody>
          <Row>
            <Col md="7">
              <Row className="mb-1">
                <Col md="12">
                  <div className="user-avatar-section">
                    <div className="d-flex align-items-center flex-column">
                      <Avatar
                        initials
                        color={'light-primary'}
                        className="rounded mt-3 mb-2"
                        content={'Ramesh Gagal'}
                        contentStyles={{
                          borderRadius: 0,
                          fontSize: 'calc(48px)',
                          width: '100%',
                          height: '100%',
                        }}
                        style={{
                          height: '80px',
                          width: '80px',
                        }}
                      />
                    </div>
                  </div>
                </Col>
              </Row>
              <Row className="mb-1">
                <Col md="12">
                  <div className="d-flex align-items-center flex-column">
                    <h4 className="fw-bolder border-bottom pb-50 mb-1">Details</h4>
                    <ul className="list-unstyled">
                      <li className="mb-75">
                        <span className="fw-bolder me-2">User Name:</span>
                        <span>{'Ramesh Gagal'}</span>
                      </li>
                      <li className="mb-75">
                        <span className="fw-bolder me-2">User Id:</span>
                        <span>{'12132CTC1'}</span>
                      </li>
                      <li className="mb-75">
                        <span className="fw-bolder me-2">Contact:</span>
                        <span>{'(909) 838 3333'}</span>
                      </li>
                    </ul>
                  </div>
                </Col>
              </Row>
            </Col>
            <Col md="5" className="">
              <Card className="w-100 shadow-none border-1">
                <CardHeader>History</CardHeader>
                <CardBody>
                  <p>Cras justo odio</p>
                  <p>Dapibus ac facilisis in</p>
                  <p>Morbi leo risus</p>
                  <p>Porta ac consectetur ac</p>
                  <p>consectetur adipisicing elit. Veniam, nulla.</p>
                  <Link to={`/transactions`}>
                    <Button color="primary" block>
                      View all
                    </Button>
                  </Link>
                </CardBody>
              </Card>
            </Col>
          </Row>
        </CardBody>
      </Card>
    </div>
  );
};

export default UserProfile;
