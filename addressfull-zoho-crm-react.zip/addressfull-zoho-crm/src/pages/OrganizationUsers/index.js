import React from 'react';
import UsersListing from './Users';

const index = () => {
  return (
    <div>
      <UsersListing />
    </div>
  );
};

export default index;
