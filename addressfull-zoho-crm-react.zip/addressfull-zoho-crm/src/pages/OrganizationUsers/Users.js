import Spinner from '@components/spinner/Loading-spinner';
import { yupResolver } from '@hookform/resolvers/yup';
import React, { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { PhoneInput } from 'react-international-phone';
import 'react-international-phone/style.css';
import { useDispatch, useSelector } from 'react-redux';
import {
  Button,
  Card,
  CardBody,
  CardHeader,
  CardText,
  Col,
  Form,
  FormFeedback,
  Label,
  Modal,
  ModalBody,
  ModalHeader,
  Row,
} from 'reactstrap';
import * as Yup from 'yup';
import { checkUserExcelValidationAPI } from '../../redux/organizatinUsers';
import CustomToast, { ErrorCss, SuccessCss } from '../../utility/toast/CustomToast';
import FileUpload from './FileUpload';
import Request from './Request';
// import { getTransactionsHistoryAPI, setNextPageString, setPreviousPageString } from '../../redux/transactions';
import { isObjEmpty } from '../../utility/Utils';
import MobileUsers from './MobileUser/MobileUser';

function Userslisting() {
  const dispatch = useDispatch();
  const [countryD, setCountryD] = useState({});
  const [show, setShow] = useState(false);
  const [requestModel, setRequestModel] = useState(false);
  const [userId, setUserId] = useState(null);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { UserData } = useSelector((state) => state.root?.authentication);
  const { profileData } = useSelector((state) => state?.root.Organization.OrganizationDetailes);
  const writePermission = UserData?.permissions?.find((item) => item?.section === 'users')?.permissions?.write;

  const phoneRegex = /^[0-9]{10}$/;
  const hostname = window.location.hostname;
  const subdomain = hostname.split('.')[0];

  const validationSchema = Yup.object().shape({
    phone_number: Yup.string()
      .trim()
      .matches(/^\+\d{11,}$/, 'Please enter a valid phone number with country code')
      .min(10, 'Phone number must be at least 10 characters')
      .required('Phone number is required'),
  });

  const initialValues = {
    phone_number: '',
  };

  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitSuccessful },
    reset,
  } = useForm({
    resolver: yupResolver(validationSchema),
    values: initialValues,
    // mode: 'onChange',
  });

  useEffect(() => {
    if (!requestModel) {
      setUserId(null);
    }

    if (profileData && !isObjEmpty(profileData)) {
      setValue(
        'phone_number',
        profileData?.contact_number
          ? profileData?.contact_number?.[0]?.split('|')?.[0]?.replace(/[+|]/g, '')
          : profileData?.org_country?.split('|')?.[0]?.replace(/[+|]/g, ''),
      );
    }
  }, [requestModel, profileData]);

  useEffect(() => {
    if (isSubmitSuccessful) {
      reset({
        phone_number: profileData?.contact_number
          ? profileData?.contact_number?.[0]?.split('|')?.[0]?.replace(/[+|]/g, '')
          : profileData?.org_country?.split('|')?.[0]?.replace(/[+|]/g, ''),
      });
    }
  }, [isSubmitSuccessful, reset]);

  const onSubmit = (data) => {
    const payloadSingleMobile = {
      singleItem: 'true',
      mobile_numbers: [],
    };

    const countryCode = (coun, numb) => numb?.substring(0, coun.dialCode.length);
    const phoneNumber = (coun, number) => number?.substring(coun.dialCode.length);

    payloadSingleMobile.mobile_numbers = [
      `${countryCode(countryD?.country, data?.phone_number?.replace('+', ''))}|${phoneNumber(
        countryD?.country,
        data?.phone_number?.replace('+', ''),
      )}`,
    ];

    dispatch(checkUserExcelValidationAPI(payloadSingleMobile)).then((result) => {
      if (result.status === 200) {
        setRequestModel(result?.openReqPopup);
        setUserId(result?.userId);

        if (result?.openReqPopup === false) {
          toast(<CustomToast message={result?.message} type={'success'} />, SuccessCss());
        }
      } else {
        toast(<CustomToast message={result?.message} type={'error'} />, ErrorCss());
      }
    });
  };

  return subdomain === 'admin' ? (
    <MobileUsers />
  ) : isLoading ? (
    <Spinner open={close} />
  ) : (
    <Card>
      <CardHeader className="border-bottom">
        <CardText tag="h3">Send User Requests</CardText>
        {/* Button styled to look like a file input */}
        <div className={`${writePermission ? '' : 'cursor-not-allowed'}`}>
          <Button color="primary" onClick={() => setShow(true)} disabled={!writePermission}>
            Multiple User Requests
          </Button>
        </div>
      </CardHeader>

      <CardBody>
        <Form onSubmit={handleSubmit(onSubmit)}>
          <Row className="d-flex  m-1">
            <Col md="4">
              <div className="mb-1">
                <Label className="form-label" for="phone_number">
                  Unique Identifier Mobile Number
                </Label>

                <Controller
                  name="phone_number"
                  id="phone_number"
                  className="form-control"
                  control={control}
                  render={(props) => (
                    <div>
                      <PhoneInput
                        as={<input />}
                        ref={props.field.ref}
                        onChange={(e, country) => {
                          props.field.onChange(e);
                          setCountryD(country);
                        }}
                        name="phone_number"
                        inputProps={{
                          id: 'phone_number',
                          name: 'phone_number',
                          // required: true,
                          autoComplete: 'none',
                        }}
                        country={''}
                        value={props?.field?.value}
                        specialLabel=""
                        inputClassName="form-control"
                        dropdownClass="react-select"
                        inputStyle={{ width: '100%' }}
                        // disableDialCodePrefill={true}
                      />
                    </div>
                  )}
                  rules={{
                    required: 'Phone number is required',
                    validate: (value) => value?.match(phoneRegex) || 'Phone number must be at least 10 digits',
                  }}
                />
                <FormFeedback className="d-block">{errors?.phone_number?.message}</FormFeedback>
              </div>
            </Col>
            <Col md="4">
              <div className={`mt-2 ${writePermission ? '' : 'cursor-not-allowed'}`}>
                <Button type="submit" color="primary" disabled={!writePermission}>
                  Request Details
                </Button>
              </div>
            </Col>
          </Row>
        </Form>
      </CardBody>

      <Modal
        isOpen={show}
        toggle={() => setShow(!show)}
        className="modal-dialog-centered"
        onClosed={() => setShow(false)}
      >
        <ModalHeader toggle={() => setShow(!show)}> Multiple User Requests</ModalHeader>

        <h2 className="text-center mb-1"> </h2>
        <ModalBody className="px-sm-5 mx-50 pb-5">
          <FileUpload setShow={setShow} />
        </ModalBody>
      </Modal>

      <Modal
        isOpen={requestModel}
        toggle={() => setRequestModel(!requestModel)}
        className="modal-dialog-centered"
        onClosed={() => setRequestModel(false)}
        scrollable={true}
        // size="lg"
        // fullscreen={true}
      >
        <ModalHeader toggle={() => setRequestModel(!requestModel)}></ModalHeader>

        <h2 className="text-center mb-1"> </h2>
        <ModalBody className="px-sm-5 mx-50 pb-5">
          <Request userId={userId} setRequestModel={setRequestModel} />
        </ModalBody>
      </Modal>
    </Card>
  );
}

export default Userslisting;
