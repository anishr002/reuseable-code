import { Input } from 'reactstrap';
import { activeDeactiveUserApi } from '../../../redux/organizatinUsers';
import { store } from '../../../redux/store';
import { convertToTimeZone } from '../../../utility/Utils';

export const columns = [
  // {
  //   name: 'User',
  //   minWidth: '250px',
  //   // sortable: true,
  //   cell: (row) => {
  //     return <Link to="user-profile">{row?.id}</Link>;
  //   },
  // },
  {
    name: 'Registration Number',
    sortable: false,
    minWidth: '250px',
    selector: (row) => `+${row?.countryCode ?? ''} ${row?.mobileNumber ?? ''}`,
  },
  {
    name: 'Date & Time Created',
    sortable: false,
    minWidth: '150px',
    sortName: false,
    selector: (row) => {
      return row?.created_at?.includes(',') ? row?.created_at : convertToTimeZone(row?.created_at, row?.timezone);
    },
  },
  {
    name: 'Status On/Off',
    sortable: false,
    minWidth: '150px',
    selector: (row) => {
      return (
        <div className={`form-switch form-check-${row?.active ? 'custom-badge' : 'danger'} `}>
          <Input
            type="switch"
            className="cursor-pointer"
            id="switch-primary"
            name="primary"
            checked={row?.active}
            onChange={(_e) =>
              store.dispatch(
                activeDeactiveUserApi(
                  {
                    role: null,
                    status: !row?.active,
                  },
                  row?.id,
                ),
              )
            }
          />
        </div>
      );
    },
  },
];
