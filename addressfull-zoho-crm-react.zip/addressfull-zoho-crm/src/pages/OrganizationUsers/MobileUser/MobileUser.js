import Spinner from '@components/spinner/Loading-spinner';
import { customStyles } from '@utils';
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { ChevronDown, Search } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { Card, CardHeader, CardText, Input, InputGroup, InputGroupText } from 'reactstrap';
import { getOrganizationUsersAPI } from '../../../redux/organizatinUsers';
import { useDebouncedValue } from '../../../utility/hooks/useDebouncedValue';
import { columns } from './columns';

const MobileUsers = () => {
  const dispatch = useDispatch();
  const [searchValue, setSearchValue] = useState('');
  const [data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(1);
  const debouncedValue = useDebouncedValue(searchValue, 400);
  const { OrganizationUsersData, rowsPerPagesData, paginationDefaultUsers } = useSelector(
    (state) => state?.root?.organizationUsers,
  );
  const { UserData } = useSelector((state) => state.root?.authentication);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const [rowsPerPage, setRowsPerPage] = useState(rowsPerPagesData);
  const writePermission = UserData?.permissions?.find((item) => item?.section === 'users')?.permissions?.write;
  const readpermission = UserData?.permissions?.find((item) => item?.section === 'dashboard')?.permissions?.read;
  const timezonesData = useSelector((state) => state?.root?.Setting?.OtherSettings);
  useEffect(() => {
    if (searchValue.trim() && readpermission) {
      dispatch(
        getOrganizationUsersAPI({
          page: currentPage,
          page_size: rowsPerPagesData,
          order_by: paginationDefaultUsers?.order_by,
          sort_by: paginationDefaultUsers?.sort_by,
          search: searchValue,
        }),
      );
    } else {
      const payload = { ...paginationDefaultUsers };
      delete payload?.search;
      readpermission &&
        dispatch(
          getOrganizationUsersAPI({
            ...payload,
            page: currentPage,
            page_size: rowsPerPage,
          }),
        );
    }
  }, [debouncedValue]);

  useEffect(() => {
    setCurrentPage(OrganizationUsersData?.page_info?.current_page);
    setTotalCount(OrganizationUsersData?.page_info?.total_count);
    setRowsPerPage(rowsPerPagesData);
    setData(
      OrganizationUsersData?.admin_list?.map((i) => ({ ...i, writePermission, timezone: timezonesData?.timezone })),
    );
  }, [OrganizationUsersData, rowsPerPagesData]);

  const handleFilter = (e) => {
    const value = e.target.value;
    setSearchValue(value);
  };

  const apiCallPagination = () => {
    const payload = {};
    if (searchValue) {
      payload.search = searchValue;
    }
    return payload;
  };

  return (
    <Card>
      <CardHeader className="border-bottom ">
        <CardText tag="h3">Mobile Users</CardText>
        <div className="d-flex align-items-center ">
          <InputGroup className="input-group-merge ">
            <InputGroupText>
              <Search size={14} />
            </InputGroupText>
            <Input
              className="dataTable-filter"
              prefix="ok"
              type="text"
              bsSize="md"
              id="search-input"
              value={searchValue}
              onChange={handleFilter}
              placeholder="Search"
            />
          </InputGroup>
        </div>
      </CardHeader>
      <div className="react-dataTable react-dataTable-selectable-rows">
        <DataTable
          noHeader
          pagination
          responsive
          paginationRowsPerPageOptions={[10, 20, 50, 100]}
          paginationComponentOptions={{
            rowsPerPageText: 'Rows per page:',
            rangeSeparatorText: 'of',
            noRowsPerPage: false,
            selectAllRowsItem: false,
            selectAllRowsItemText: 'All',
          }}
          paginationPerPage={paginationDefaultUsers?.page_size}
          paginationTotalRows={totalCount}
          paginationServer={true}
          paginationDefaultPage={paginationDefaultUsers?.page}
          paginationResetDefaultPage={false}
          paginationRowsPerPageDropdown={true}
          paginationRowsPerPageDropdownOptions={[10, 20, 50, 100]}
          onChangePage={(page, totalRows) => {
            console.log('Page changed:', page, 'Total Rows:', totalRows);
            setCurrentPage(page);
            dispatch(
              getOrganizationUsersAPI({
                ...paginationDefaultUsers,
                page,
                ...apiCallPagination(),
              }),
            );
          }}
          onChangeRowsPerPage={(currentRowsPerPage, currentPage) => {
            console.log('Rows per page changed:', currentRowsPerPage, 'Current Page:', currentPage);
            dispatch(
              getOrganizationUsersAPI({
                ...paginationDefaultUsers,
                page: currentPage,
                page_size: currentRowsPerPage,
                ...apiCallPagination(),
              }),
            );
          }}
          columns={columns}
          className="react-dataTable mb-2"
          progressPending={isLoading}
          progressComponent={<Spinner open={close} />}
          sortIcon={<ChevronDown size={10} />}
          data={data}
          onSort={(column, order) => {
            dispatch(
              getOrganizationUsersAPI({
                page: currentPage,
                page_size: rowsPerPage,
                order_by: order,
                sort_by: column?.sortable,
              }),
            );
          }}
          persistTableHead={true}
          customStyles={customStyles}
        />
      </div>
    </Card>
  );
};

export default MobileUsers;
