import Spinner from '@components/spinner/Loading-spinner';
import React, { useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { useDispatch, useSelector } from 'react-redux';
import { Button, CardBody, CardHeader, CardTitle, Col, Input, Label, Row } from 'reactstrap';
import { organizationUsersDataRequestAPI } from '../../redux/organizatinUsers';

const Request = (props) => {
  const dispatch = useDispatch();
  const { transactionHistorty } = useSelector((state) => state?.root?.transactions?.TransactionData);
  const { isLoading } = useSelector((state) => state?.root?.appLoading);
  const { control, handleSubmit, getValues, setValue, watch } = useForm();

  const [checkBoxes, setCheckBoxes] = useState([
    { id: 'email', label: 'Email', value: true },
    { id: 'address', label: 'Address', value: true },
    { id: 'mobile', label: 'MobileNumber', value: true },
    { id: 'twitter', label: 'Twitter', value: true },
    { id: 'linkedin', label: 'LinkedIn', value: true },
  ]);
  const [isDisabledRequest, setIsDisabledRequest] = useState([]);

  const watchCheckboxValues = watch('checkboxValues', {});
  const hasTruthyValue = (obj) => Object.values(obj).some(Boolean);

  const sendUserRequest = (data) => {
    const selectedCheckboxes = Object.entries(data.checkboxValues)
      .filter(([_key, value]) => value)
      .map(([key]) => key);
    const payLoad = { client_id: props?.userId, request_details: selectedCheckboxes };

    if (hasTruthyValue(getValues()?.checkboxValues)) {
      dispatch(organizationUsersDataRequestAPI(payLoad));
      props.setRequestModel(false);
    }
  };

  useEffect(() => {
    // const result = checkBoxes.map((i) =>
    //   transactionHistorty?.labels?.length === 0
    //     ? { ...i, value: true }
    //     : transactionHistorty?.labels?.includes(i?.id)
    //     ? { ...i, value: true }
    //     : i,
    // );
    // setCheckBoxes(result);
    // result?.map((i) => setValue(`checkboxValues.${i.label}`, i.value));
    setIsDisabledRequest(['']);
  }, [transactionHistorty]);

  const handleChange = (e, lab) => {
    const result = checkBoxes.map((i) => (i.id === lab ? { ...i, value: e.target.checked } : i));
    setValue(e.target.name, e.target.checked);

    if (hasTruthyValue(getValues()?.checkboxValues ?? {})) {
      setIsDisabledRequest(['']);
    } else {
      setIsDisabledRequest([]);
    }

    setCheckBoxes(result);
  };

  return (
    <div>
      {isLoading ? (
        <Spinner open={close} />
      ) : (
        <div>
          <CardHeader>
            <div className="d-flex align-items-center">
              <CardTitle className="mb-0 fw-bolder">Request Detail</CardTitle>
            </div>
          </CardHeader>
          <CardBody>
            <form onSubmit={handleSubmit(sendUserRequest)}>
              <Row>
                <Col md="8">
                  <div className="d-grid">
                    {checkBoxes.map((checkbox) => (
                      <div key={checkbox.id} className="form-check form-check-inline mt-1">
                        <Controller
                          name={`checkboxValues.${checkbox.label}`}
                          control={control}
                          defaultValue={checkbox?.value}
                          render={({ field }) => (
                            <>
                              <Input
                                type="checkbox"
                                id={`checkbox-${checkbox.id}`}
                                name={`checkboxValues.${checkbox.label}`}
                                {...field}
                                checked={checkbox?.value}
                                onChange={(e) => handleChange(e, checkbox?.id)}
                              />
                              <Label for={`checkbox-${checkbox.id}`}>{checkbox.label}</Label>
                            </>
                          )}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="d-flex justify-content-end  mt-2">
                    <Button color="primary" type="submit" disabled={isDisabledRequest?.length === 0}>
                      Request
                    </Button>
                  </div>
                </Col>
              </Row>
            </form>
          </CardBody>
        </div>
      )}
    </div>
  );
};

export default Request;
