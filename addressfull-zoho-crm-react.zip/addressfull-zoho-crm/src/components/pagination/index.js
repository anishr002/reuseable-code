import React from 'react';
import ReactPaginate from 'react-paginate';

// ** Custom Pagination
const CustomPagination = ({
  _pageCount,
  onPageChange,
  currentPage,
  _previousPageString,
  _nextPageString,
  last_page,
}) => {
  return (
    <div className="pagination justify-content-center ">
      <ReactPaginate
        previousLabel={<i className="fa fa-chevron-left" />}
        nextLabel={<i className="fa fa-chevron-right" />}
        forcePage={currentPage - 1}
        pageCount={currentPage}
        pageRangeDisplayed={0}
        marginPagesDisplayed={0}
        breakLabel="..."
        activeClassName="active"
        pageClassName="page-item"
        breakClassName="page-item"
        nextLinkClassName="page-link"
        pageLinkClassName="page-link"
        breakLinkClassName="page-link"
        previousLinkClassName="page-link"
        onClick={onPageChange}
        previousClassName={`page-item prev-item ${currentPage === 1 ? 'disabled' : ''}`}
        nextClassName={`page-item  next-item ${last_page ? 'disabled' : ''}`}
        // nextClassName="page-item next-item"
        // previousClassName="page-item prev-item"
        disabledClassName=""
        containerClassName="pagination justify-content-center"
        // disableInitialCallback
      />
    </div>
  );
};

export default CustomPagination;
