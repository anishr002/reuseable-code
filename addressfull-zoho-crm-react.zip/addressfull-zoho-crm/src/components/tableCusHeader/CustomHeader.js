import { Search } from 'react-feather';
import Select from 'react-select';
import PropTypes from 'prop-types';
import { Col, Input, InputGroup, InputGroupText, Row } from 'reactstrap';

const CustomHeader = ({
  searchValue,
  handle_filter,
  is_filter,
  AdminRoles,
  setDefaultRoleSelect,
  defaultRoleSelect,
}) => {
  return (
    <div className="invoice-list-table-header w-100 mr-1 ml-50 mt-2 mb-75">
      <Row>
        <Col md="4" className="d-flex align-items-center p-0"></Col>
        <Col
          md="8"
          className="d-flex align-items-sm-center justify-content-xl-end justify-content-start flex-xl-nowrap flex-wrap flex-sm-row flex-column "
        >
          <Row>
            <Col md={is_filter ? '6' : '12'}>
              <div className="d-flex align-items-center ">
                <InputGroup className="input-group-merge ">
                  <InputGroupText>
                    <Search size={14} />
                  </InputGroupText>
                  <Input
                    className="dataTable-filter"
                    prefix="ok"
                    type="text"
                    bsSize="md"
                    id="search-input"
                    value={searchValue}
                    onChange={handle_filter}
                    placeholder="Search"
                    // disabled={write_p !== undefined && write_p === false}
                  />
                </InputGroup>
              </div>
            </Col>
            {is_filter && AdminRoles?.length !== 0 && (
              <Col md="6">
                <Select
                  options={[{ id: null, name: 'ALL' }, ...AdminRoles?.role_list]?.map((item) => ({
                    value: item?.id,
                    label: item?.name,
                  }))}
                  className="react-select w-100"
                  classNamePrefix="select"
                  value={defaultRoleSelect}
                  onChange={(e) => setDefaultRoleSelect(e)}
                  styles={{
                    control: (baseStyles, _state) => ({
                      ...baseStyles,
                      borderColor: '#d8d6de',
                      minWidth: '230px',
                    }),
                  }}
                  placeholder="Select Role"
                  // isDisabled={write_p !== undefined && write_p === false}
                />
              </Col>
            )}
          </Row>
        </Col>
      </Row>
    </div>
  );
};

export default CustomHeader;

CustomHeader.propTypes = {
  searchValue: PropTypes.any,
  handle_filter: PropTypes.any,
  is_filter: PropTypes.any,
  AdminRoles: PropTypes.any,
  setDefaultRoleSelect: PropTypes.any,
  defaultRoleSelect: PropTypes.any,
};
