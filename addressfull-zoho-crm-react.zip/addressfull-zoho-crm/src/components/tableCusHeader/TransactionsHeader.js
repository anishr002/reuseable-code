import '@styles/react/libs/flatpickr/flatpickr.scss';
import React, { useEffect, useRef, useState } from 'react';
import Flatpickr from 'react-flatpickr';
import { Button, Col, Input, InputGroup, InputGroupText, Row } from 'reactstrap';

import { yupResolver } from '@hookform/resolvers/yup';
import PropTypes from 'prop-types';
import { Calendar, Search } from 'react-feather';
import { Controller, useForm } from 'react-hook-form';
import { useSelector } from 'react-redux';
import * as yup from 'yup';
import { convertToTimeZone } from '../../utility/Utils';

const TransactionsHeader = ({
  searchValue,
  handle_filter,
  applyFilter,
  clearFilter,
  isDisableClear,
  isDisableApply,
  setEndDate,
  setStartDate,
}) => {
  const [defaultStartDate, setDefaultStartDate] = useState(new Date());
  const flatpickrRef = useRef(null); // Use a ref to hold the Flatpickr instance
  const flatpickrRefStart = useRef(null); // Use a ref to hold the Flatpickr instance

  const timezonesData = useSelector((state) => state?.root?.Setting?.OtherSettings);

  useEffect(() => {
    if (timezonesData?.timezone) {
      const defaultStartDateInTimeZone = convertToTimeZone(new Date(), 'America/Juneau');
      // const parsedDate = moment(defaultStartDateInTimeZone, 'DD/MM/YYYY').toDate();
      setDefaultStartDate(defaultStartDateInTimeZone);
    }
  }, [timezonesData]);
  const schema = yup.object().shape({
    startDate: yup
      .date()
      .nullable()
      .test('startDate-validation', 'Start date must be equal or before the end date', function (startDate) {
        const { endDate } = this.parent; // Access sibling field
        if (startDate && endDate) {
          return startDate <= endDate;
        }
        return true; // Valid if one of the fields is null
      })
      .test('startDate-required', 'Start date is required when end date is selected', function (startDate) {
        const { endDate } = this.parent;
        if (endDate) {
          return !!startDate;
        }
        return true; // Pass if both are null
      }),

    endDate: yup
      .date()
      .nullable()
      .test('endDate-validation', 'End date must be equal or after the start date', function (endDate) {
        const { startDate } = this.parent; // Access sibling field
        if (startDate && endDate) {
          return endDate >= startDate;
        }
        return true; // Valid if one of the fields is null
      })
      .test('endDate-required', 'End date is required when start date is selected', function (endDate) {
        const { startDate } = this.parent;
        if (startDate) {
          return !!endDate;
        }
        return true; // Pass if both are null
      }),
  });

  const {
    control,
    handleSubmit,
    formState: { errors },
    reset,
    getValues,
  } = useForm({
    resolver: yupResolver(schema),
    mode: 'onChange',
  });

  const onSubmit = (data) => {
    applyFilter(data);
  };

  const searchIcon = <Search size={14} />;
  return (
    <div className="w-100 mr-1 ml-50">
      <form onSubmit={handleSubmit(onSubmit)}>
        <Row className="my-1 ps-0 pe-0 ">
          <Col md="3" className="ps-0 pe-0 input_group-trans">
            <InputGroup className="shadow-none">
              <Controller
                control={control}
                name="startDate"
                render={({ field }) => (
                  <div ref={field?.ref}>
                    <Flatpickr
                      {...field}
                      id="abc"
                      placeholder="Start date"
                      dateformat="MMMM d, yyyy"
                      defaultDate={defaultStartDate}
                      options={{
                        altInput: true,
                        altFormat: 'F j, Y',
                        dateFormat: 'Y-m-d',
                        clickOpens: true,
                        defaultDate: defaultStartDate,
                        // allowInput: true, // Allows manual input
                        onReady: function (_selectedDates, _dateStr, instance) {
                          const clearButton = document.createElement('span');
                          clearButton.className = 'clear-button';
                          clearButton.innerHTML = 'Clear';
                          clearButton.style.padding = '5px';
                          clearButton.style.marginLeft = '10px';
                          clearButton.style.cursor = 'pointer';
                          clearButton.onclick = function () {
                            // field.onChange(null);
                            instance.close();
                            reset({ startDate: null, endDate: getValues()?.endDate });
                            setStartDate(null);
                          };
                          instance.calendarContainer.appendChild(clearButton);
                        },
                        onChange: function (selectedDates, _dateStr, _instance) {
                          setStartDate(selectedDates[0]);
                        },
                      }}
                      ref={(node) => {
                        if (node && node.flatpickr) {
                          flatpickrRefStart.current = node.flatpickr;
                        }
                      }}
                    />
                  </div>
                )}
              />
              <InputGroupText
                addontype="append"
                onClick={() => {
                  if (flatpickrRefStart.current) {
                    flatpickrRefStart.current.open(); // Open the calendar when the icon is clicked
                  }
                }}
                style={{ cursor: 'pointer' }}
              >
                <Calendar size={16} />
              </InputGroupText>
            </InputGroup>
            {errors?.startDate && <p className="text-danger">{errors.startDate.message}</p>}
          </Col>
          <Col md="3" className="ps-0 pe-0 input_group-trans">
            <InputGroup className="shadow-none">
              <Controller
                control={control}
                name="endDate"
                render={({ field }) => (
                  <>
                    <div ref={field?.ref}>
                      <Flatpickr
                        placeholder="End date"
                        {...field}
                        dateformat="MMMM d, yyyy"
                        //   className={` ${errors.endDate ? 'is-invalid' : ''}`}
                        options={{
                          altInput: true,
                          altFormat: 'F j, Y',
                          dateFormat: 'Y-m-d',
                          clickOpens: true,
                          onReady: function (_selectedDates, _dateStr, instance) {
                            const clearButton = document.createElement('span');
                            clearButton.className = 'clear-button';
                            clearButton.innerHTML = 'Clear';
                            clearButton.style.padding = '5px';
                            clearButton.style.marginLeft = '10px';
                            clearButton.style.cursor = 'pointer';
                            clearButton.onclick = function () {
                              // field.onChange(null);
                              instance.close();
                              reset({ endDate: null, startDate: getValues()?.startDate });
                              setEndDate(null);
                            };
                            instance.calendarContainer.appendChild(clearButton);
                          },
                          onChange: function (selectedDates, _dateStr, _instance) {
                            setEndDate(selectedDates[0]);
                          },
                        }}
                        ref={(node) => {
                          if (node && node.flatpickr) {
                            flatpickrRef.current = node.flatpickr;
                          }
                        }}
                      />
                    </div>
                    <InputGroupText
                      addontype="append"
                      onClick={() => {
                        if (flatpickrRef.current) {
                          flatpickrRef.current.open(); // Open the calendar when the icon is clicked
                        }
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <Calendar size={16} />
                    </InputGroupText>
                  </>
                )}
              />
            </InputGroup>
            {errors?.endDate && <p className="text-danger">{errors.endDate.message}</p>}
          </Col>

          {searchValue !== undefined && (
            <Col md="3" className="ps-0 pe-0 input_group-trans">
              <div className="d-flex align-items-center">
                <InputGroup className="input-group-merge">
                  <InputGroupText>{searchIcon}</InputGroupText>
                  <Input
                    className="dataTable-filter"
                    type="text"
                    bsSize="md"
                    id="search-input"
                    value={searchValue}
                    onChange={handle_filter}
                    placeholder="Search with mobile"
                  />
                </InputGroup>
              </div>
            </Col>
          )}
          <Col md="3" className="ps-0 pe-0 input_group-trans">
            <Button type="submit" color="primary" className="me-1" disabled={isDisableApply}>
              Apply Filter
            </Button>
            <Button type="submit" color="primary" onClick={() => clearFilter(reset)} disabled={isDisableClear}>
              Clear
            </Button>
          </Col>
        </Row>
      </form>
    </div>
  );
};

export default React.memo(TransactionsHeader);

TransactionsHeader.propTypes = {
  searchValue: PropTypes.any,
  handle_filter: PropTypes.any,
  applyFilter: PropTypes.any,
  clearFilter: PropTypes.any,
  isDisableClear: PropTypes.any,
  isDisableApply: PropTypes.any,
  setEndDate: PropTypes.any,
  setStartDate: PropTypes.any,
};
