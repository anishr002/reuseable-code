import axiosInstance from "./axiosInstance";

export const fetchOrders = async () => {
  const response = await axiosInstance.get("/orders");
  return response.data;
};
