import axios from "axios";

const axiosInstance = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
  headers: { "Content-Type": "application/json" },
});

axiosInstance.interceptors.request.use((config) => {
  const token =
    typeof window !== "undefined"
      ? localStorage.getItem("picpax_auth_token")
      : null;
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Token is invalid or expired, clear storage
      if (typeof window !== "undefined") {
        localStorage.removeItem("picpax_auth_token");
        localStorage.removeItem("picpax_user");

        // Only redirect if not already on a login page
        const currentPath = window.location.pathname;
        if (
          !currentPath.includes("/login") &&
          !currentPath.includes("/admin/login")
        ) {
          // For admin routes, redirect to admin login
          if (currentPath.startsWith("/admin/")) {
            window.location.href = "/admin/login";
          } else {
            // Determine redirect based on stored role:
            // - role contains 'admin' => /admin/login
            // - role === 'doctor' => /login
            // - otherwise => /staff/login
            const storedUser = localStorage.getItem("picpax_user");
            let role = "";
            try {
              role = storedUser ? JSON.parse(storedUser).role || "" : "";
            } catch (e) {
              role = (storedUser || "").toString();
            }
            const roleStr = (role || "").toString().toLowerCase().trim();
            if (roleStr.includes("admin")) {
              window.location.href = "/admin/login";
            } else if (roleStr === "doctor") {
              window.location.href = "/login";
            } else {
              window.location.href = "/staff/login";
            }
          }
        }
      }
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
