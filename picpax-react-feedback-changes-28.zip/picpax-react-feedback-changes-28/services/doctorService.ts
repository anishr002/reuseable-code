import axiosInstance from "./axiosInstance";

// ===============
// Types & Interfaces
// ===============
export interface CreateDoctorInput {
  title: string;
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  gender: string;
  medical_speciality: string;
  clinic_practice: string;
  clinic_name: string;
  emirates_states: string;
  medical_license: string;
  years_of_experience: number | string;
  commission: number | string;
  bio?: string;
  villa_apartment: string;
  area_street: string;
  nearby_landmark?: string;
  password: string;
  password_confirmation: string;
  // Optional, in case backend supports it
  contact_number?: string | null;
  country: string; // Add this field
  status: string; // Add this line
}

export interface CountryWithStates {
  country_code: string;
  country_name: string;
  states: string[];
}

export interface CountriesWithStatesResponse {
  success: boolean;
  message: string;
  data: CountryWithStates[];
}

export type SortOrder = "asc" | "desc";

export interface DoctorListFilters {
  // Common search filters (pass-through to API)
  name?: string;
  email?: string;
  first_name?: string;
  last_name?: string;
  phone_number?: string;
  medical_speciality?: string;
  clinic_name?: string;
  emirates_states?: string;
  status?: string; // Active | Inactive | Suspended
  // Generic search term if supported by API
  search?: string;
  // Sorting & pagination
  sort_by?: string;
  sort_order?: SortOrder;
  per_page?: number;
  page?: number;
}

export interface DoctorListItem {
  id: string;
  title: string | null;
  first_name: string;
  last_name: string;
  full_name: string;
  email: string;
  phone_number: string;
  commission: string;
  medical_speciality: string;
  clinic_name: string | null;
  address: string | null;
  villa_apartment: string | null;
  area_street: string | null;
  nearby_landmark: string | null;
  emirates_states: string | null;
  status: string; // Active | Inactive | Suspended
  documents_count: number;
  created_at: string;
}

export interface DoctorDocument {
  id: string;
  name: string;
  original_name: string;
  url: string;
  size: string;
  mime_type: string;
  collection: string;
  uploaded_at: string;
}

export interface DoctorDetail {
  id: string;
  title: string | null;
  first_name: string;
  last_name: string;
  full_name: string;
  email: string;
  phone_number: string;
  contact_number: string | null;
  gender: string | null;
  medical_speciality: string;
  medical_license: string | null;
  years_of_experience: string | number | null;
  commission: string | number;
  clinic_practice: string | null;
  clinic_name: string | null;
  bio: string | null;
  address: string | null;
  villa_apartment: string | null;
  area_street: string | null;
  nearby_landmark: string | null;
  emirates_states: string | null;
  status: string;
  created_at: string;
  updated_at: string;
  email_verified_at: string | null;
  documents: DoctorDocument[];
}

export interface PaginationMeta {
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
  from: number;
  to: number;
}

export interface DoctorsSummary {
  total_active: number;
  total_inactive: number;
  total_suspended: number;
  filtered_count: number;
  total: number;
}

export interface DoctorsListApiResponse {
  success: boolean;
  message: string;
  data: {
    doctors: DoctorListItem[];
    pagination: PaginationMeta;
    summary: DoctorsSummary;
    // backend may also return filters; allow passthrough if needed
    [key: string]: any;
  };
}

export interface DoctorDetailApiResponse {
  success: boolean;
  message: string;
  data: DoctorDetail;
}

export interface CreateDoctorApiResponse {
  success: boolean;
  message: string;
  // Some APIs return the created resource ID or 201 – keep it flexible
  data: any;
}

export interface UpdateDoctorPayload {
  title?: string;
  first_name?: string;
  last_name?: string;
  // email intentionally optional (commented in user payload)
  email?: string;
  phone_number?: string;
  gender?: string;
  medical_speciality?: string;
  clinic_practice?: string;
  clinic_name?: string;
  emirates_states?: string;
  // medical_license optional (commented in user payload example)
  medical_license?: string;
  years_of_experience?: number;
  commission?: number;
  bio?: string;
  villa_apartment?: string;
  area_street?: string;
  nearby_landmark?: string;
  password?: string;
  password_confirmation?: string;
  status?: "active" | "inactive" | "suspended" | string;
}

export interface UpdateDoctorApiResponse {
  success: boolean;
  message: string;
  data: {
    uuid: string;
    title: string | null;
    first_name: string;
    last_name: string;
    email: string;
    phone_number: string;
    gender: string | null;
    medical_speciality: string;
    medical_license: string | null;
    years_of_experience: number | null;
    commission: number | string;
    clinic_practice: string | null;
    clinic_name: string | null;
    bio: string | null;
    villa_apartment: string | null;
    area_street: string | null;
    nearby_landmark: string | null;
    emirates_states: string | null;
    status: string;
  };
}

export interface DeleteDoctorApiResponse {
  success: boolean;
  message: string;
  data: any[];
}
export interface DocumentUploadResponse {
  success: boolean;
  message: string;
  data: {
    files: Array<{
      id: string;
      name: string;
      url: string;
      uploaded_at: string;
      file_size: string;
    }>;
  };
}
// ===============
// Helpers
// ===============
const buildSearchParams = (filters: Record<string, any> = {}): string => {
  const params = new URLSearchParams();
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      params.append(key, String(value));
    }
  });
  return params.toString();
};

const toFormData = (obj: Record<string, any>): FormData => {
  const fd = new FormData();
  Object.entries(obj).forEach(([key, value]) => {
    if (value === undefined || value === null) return;

    // Arrays (including File[])
    if (Array.isArray(value)) {
      value.forEach((v, idx) => {
        if (v instanceof Blob) {
          fd.append(`${key}[${idx}]`, v);
        } else if (typeof v === "object") {
          // Flatten simple objects in arrays
          Object.entries(v).forEach(([k, val]) => {
            if (val !== undefined && val !== null) {
              if (val instanceof Blob) {
                fd.append(`${key}[${idx}][${k}]`, val);
              } else {
                fd.append(`${key}[${idx}][${k}]`, String(val));
              }
            }
          });
        } else {
          fd.append(`${key}[${idx}]`, String(v));
        }
      });
      return;
    }

    // Files/Blobs
    if (value instanceof Blob) {
      fd.append(key, value);
      return;
    }

    // Simple values
    fd.append(key, String(value));
  });
  return fd;
};

// ===============
// Service Functions
// ===============

/**
 * Create a doctor using multipart/form-data
 * Endpoint: POST /doctor
 */
export const createDoctor = async (
  payload: FormData | CreateDoctorInput
): Promise<CreateDoctorApiResponse> => {
  try {
    const formData =
      payload instanceof FormData
        ? payload
        : toFormData(payload as Record<string, any>);

    const response = await axiosInstance.post<CreateDoctorApiResponse>(
      "/doctor",
      formData,
      { headers: { "Content-Type": "multipart/form-data" } }
    );
    return response.data;
  } catch (error: any) {
    if (error.response) throw error;
    if (error.request)
      throw new Error("No response from server. Please try again.");
    throw new Error("An error occurred. Please try again.");
  }
};

/**
 * List doctors with searching, sorting and pagination support
 * Endpoint: GET /doctors
 */
export const getDoctors = async (
  filters: DoctorListFilters = {}
): Promise<DoctorsListApiResponse> => {
  try {
    const qs = buildSearchParams(filters as Record<string, any>);
    const url = qs ? `/doctors?${qs}` : "/doctors";
    const response = await axiosInstance.get<DoctorsListApiResponse>(url);
    return response.data;
  } catch (error: any) {
    if (error.response) throw error;
    if (error.request)
      throw new Error("No response from server. Please try again.");
    throw new Error("An error occurred. Please try again.");
  }
};

/**
 * Get a single doctor by UUID
 * Endpoint: GET /doctor/:id
 */
export const getDoctor = async (
  id: string
): Promise<DoctorDetailApiResponse> => {
  try {
    const response = await axiosInstance.get<DoctorDetailApiResponse>(
      `/doctor/${id}`
    );
    return response.data;
  } catch (error: any) {
    if (error.response) throw error;
    if (error.request)
      throw new Error("No response from server. Please try again.");
    throw new Error("An error occurred. Please try again.");
  }
};

/**
 * Update a doctor by UUID using JSON payload
 * Endpoint: PUT /doctor/:id
 */
export const updateDoctor = async (
  id: string,
  payload: UpdateDoctorPayload
): Promise<UpdateDoctorApiResponse> => {
  try {
    const response = await axiosInstance.put<UpdateDoctorApiResponse>(
      `/doctor/${id}`,
      payload
    );
    return response.data;
  } catch (error: any) {
    if (error.response) throw error;
    if (error.request)
      throw new Error("No response from server. Please try again.");
    throw new Error("An error occurred. Please try again.");
  }
};

/**
 * Delete a doctor by UUID
 * Endpoint: DELETE /doctor/:id
 */
export const deleteDoctor = async (
  id: string
): Promise<DeleteDoctorApiResponse> => {
  try {
    const response = await axiosInstance.delete<DeleteDoctorApiResponse>(
      `/doctor/${id}`
    );
    return response.data;
  } catch (error: any) {
    if (error.response) throw error;
    if (error.request)
      throw new Error("No response from server. Please try again.");
    throw new Error("An error occurred. Please try again.");
  }
};

export const getCountriesWithStates =
  async (): Promise<CountriesWithStatesResponse> => {
    try {
      const response = await axiosInstance.get<CountriesWithStatesResponse>(
        "/countries-with-states"
      );
      return response.data;
    } catch (error: any) {
      if (error.response) throw error;
      if (error.request)
        throw new Error("No response from server. Please try again.");
      throw new Error("An error occurred. Please try again.");
    }
  };

export const uploadDoctorDocuments = async (
  formData: FormData
): Promise<DocumentUploadResponse> => {
  try {
    const response = await axiosInstance.post<DocumentUploadResponse>(
      "/doctor/documents",
      formData,
      { headers: { "Content-Type": "multipart/form-data" } }
    );
    return response.data;
  } catch (error: any) {
    if (error.response) throw error;
    if (error.request)
      throw new Error("No response from server. Please try again.");
    throw new Error("An error occurred. Please try again.");
  }
};

// Add this to your doctorService file
export const deleteDoctorDocument = async (
  documentId: string
): Promise<any> => {
  try {
    const endpoint = `/doctor/document/${documentId}`;
    console.log("Delete Doctor Document API Call:", endpoint);
    const response = await axiosInstance.delete(endpoint);
    console.log("Delete Doctor Document API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Delete Doctor Document API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

// Optional default export for ergonomic imports
const doctorService = {
  createDoctor,
  getDoctors,
  getDoctor,
  updateDoctor,
  deleteDoctor,
};

export default doctorService;
