"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  getPendingUserCommission,
  updatePendingUserCommission,
  type PendingUser,
} from "@/lib/doctorApi";

// Zod schema for commission validation
const commissionSchema = z.object({
  product_commission: z
    .string()
    .min(1, "Product commission is required")
    .refine((val) => {
      const num = parseFloat(val);
      return !isNaN(num) && num >= 0 && num <= 100;
    }, "Product commission must be between 0 and 100"),
  lab_test_commission: z
    .string()
    .min(1, "Lab test commission is required")
    .refine((val) => {
      const num = parseFloat(val);
      return !isNaN(num) && num >= 0 && num <= 100;
    }, "Lab test commission must be between 0 and 100"),
});

type CommissionFormValues = z.infer<typeof commissionSchema>;

interface CommissionUpdateModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: PendingUser | null;
  onCommissionUpdated: () => void;
}

export function CommissionUpdateModal({
  isOpen,
  onClose,
  user,
  onCommissionUpdated,
}: CommissionUpdateModalProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(false);

  const form = useForm<CommissionFormValues>({
    resolver: zodResolver(commissionSchema),
    defaultValues: {
      product_commission: "",
      lab_test_commission: "",
    },
  });

  // Load user commission data when modal opens
  useEffect(() => {
    const loadUserCommission = async () => {
      if (isOpen && user) {
        setIsLoadingData(true);
        try {
          const response = await getPendingUserCommission(user.id);
          const userData = response.data;

          form.reset({
            product_commission: userData.product_commission || "",
            lab_test_commission: userData.lab_test_commission || "",
          });
        } catch (error: any) {
          console.error("Error loading user commission:", error);
          toast({
            variant: "destructive",
            title: "Error",
            description:
              error.response?.data?.message ||
              "Failed to load user commission data",
          });
        } finally {
          setIsLoadingData(false);
        }
      }
    };

    if (isOpen) {
      loadUserCommission();
    }
  }, [isOpen, user, form, toast]);

  // Reset form when modal closes
  useEffect(() => {
    if (!isOpen) {
      form.reset({
        product_commission: "",
        lab_test_commission: "",
      });
    }
  }, [isOpen, form]);

  const onSubmit = async (data: CommissionFormValues) => {
    if (!user) return;

    setIsLoading(true);
    try {
      await updatePendingUserCommission(user.id, data);

      toast({
        title: "Success",
        description: "Commission updated successfully",
      });

      onCommissionUpdated();
      onClose();
    } catch (error: any) {
      console.error("Error updating commission:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message || "Failed to update commission",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Update Commission</DialogTitle>
          <DialogDescription>
            Update commission rates for {user?.first_name} {user?.last_name}
          </DialogDescription>
        </DialogHeader>

        {isLoadingData ? (
          <div className="flex justify-center items-center py-8">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-muted-foreground">
                Loading commission data...
              </p>
            </div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="product_commission"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Product Commission (%)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        placeholder="Enter product commission"
                        {...field}
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="lab_test_commission"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Lab Test Commission (%)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        step="0.01"
                        placeholder="Enter lab test commission"
                        {...field}
                        disabled={isLoading}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleClose}
                  disabled={isLoading}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Updating...
                    </>
                  ) : (
                    "Update Commission"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
