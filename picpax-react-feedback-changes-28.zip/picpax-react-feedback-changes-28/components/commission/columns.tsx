"use client"

import type { ColumnDef } from "@tanstack/react-table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { DataTableColumnHeader } from "./data-table-column-header"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { MoreHorizontal, Eye, DollarSign, TrendingUp, Calendar, User, Building, Percent } from "lucide-react"

export type Commission = {
  id: string
  doctorName: string
  doctorClinic: string
  totalOrders: number
  completedOrders: number
  totalRevenue: number
  totalCommission: number
  commissionRate: number
  monthlyCommission: number
  status: "Active" | "Inactive"
  lastPayout: string
  nextPayout: string
  pendingCommission: number
  averageOrderValue: number
  conversionRate: number
  joinDate: string
}

export const columns: ColumnDef<Commission>[] = [
  {
    accessorKey: "doctorName",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Doctor" />,
    cell: ({ row }) => {
      const commission = row.original
      const getInitials = (name: string) => {
        return name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase()
      }

      return (
        <div className="flex items-center space-x-3 min-w-[250px]">
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarFallback className="text-xs font-semibold bg-blue-600 text-white">
              {getInitials(commission.doctorName)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-sm truncate">{commission.doctorName}</div>
            <div className="text-xs text-muted-foreground truncate flex items-center gap-1">
              <Building className="h-3 w-3" />
              {commission.doctorClinic}
            </div>
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "commissionRate",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Rate" />,
    cell: ({ row }) => {
      const rate = row.getValue("commissionRate") as number
      return (
        <div className="min-w-[80px]">
          <div className="flex items-center gap-1">
            <Percent className="h-3 w-3 text-muted-foreground" />
            <span className="font-medium text-sm">{rate}%</span>
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "totalRevenue",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Total Revenue" />,
    cell: ({ row }) => {
      const revenue = row.getValue("totalRevenue") as number
      return (
        <div className="min-w-[100px] text-right">
          <div className="font-medium text-sm">${revenue.toLocaleString()}</div>
        </div>
      )
    },
  },
  {
    accessorKey: "totalCommission",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Total Commission" />,
    cell: ({ row }) => {
      const commission = row.getValue("totalCommission") as number
      return (
        <div className="min-w-[120px] text-right">
          <div className="font-bold text-green-600 text-sm">${commission.toLocaleString()}</div>
        </div>
      )
    },
  },
  {
    accessorKey: "monthlyCommission",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Monthly" />,
    cell: ({ row }) => {
      const monthly = row.getValue("monthlyCommission") as number
      return (
        <div className="min-w-[100px] text-right">
          <div className="font-medium text-blue-600 text-sm">${monthly.toLocaleString()}</div>
        </div>
      )
    },
  },
  {
    accessorKey: "pendingCommission",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Pending" />,
    cell: ({ row }) => {
      const pending = row.getValue("pendingCommission") as number
      return (
        <div className="min-w-[100px] text-right">
          <div className="font-medium text-yellow-600 text-sm">${pending.toLocaleString()}</div>
        </div>
      )
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Status" />,
    cell: ({ row }) => {
      const status = row.getValue("status") as string
      const getStatusColor = (status: string) => {
        switch (status) {
          case "Active":
            return "bg-green-600 hover:bg-green-700"
          case "Inactive":
            return "bg-gray-600 hover:bg-gray-700"
          default:
            return "bg-gray-600 hover:bg-gray-700"
        }
      }
      
      return (
        <div className="min-w-[100px]">
          <Badge
            variant="default"
            className={`text-xs ${getStatusColor(status)}`}
          >
            {status}
          </Badge>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: "nextPayout",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Next Payout" />,
    cell: ({ row }) => {
      const payout = row.getValue("nextPayout") as string
      return (
        <div className="min-w-[100px]">
          <div className="flex items-center gap-1 text-sm">
            <Calendar className="h-3 w-3 text-muted-foreground" />
            <span>{payout}</span>
          </div>
        </div>
      )
    },
  },
  {
    id: "actions",
    cell: ({ row, table }) => {
      const commission = row.original
      const onViewCommissionDetails = (table.options.meta as { onViewCommissionDetails?: (commission: Commission) => void })?.onViewCommissionDetails

      return (
        <div className="min-w-[40px]">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-7 w-7 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[160px]">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => onViewCommissionDetails?.(commission)}>
                <Eye className="mr-2 h-4 w-4" />
                View Details
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                console.log("Process payout:", commission.doctorName)
              }} disabled={commission.pendingCommission === 0}>
                <DollarSign className="mr-2 h-4 w-4" />
                Process Payout
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                console.log("Generate report:", commission.doctorName)
              }}>
                <TrendingUp className="mr-2 h-4 w-4" />
                Generate Report
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => {
                console.log("Edit commission rate:", commission.doctorName)
              }}>
                <Percent className="mr-2 h-4 w-4" />
                Edit Rate
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )
    },
  },
]