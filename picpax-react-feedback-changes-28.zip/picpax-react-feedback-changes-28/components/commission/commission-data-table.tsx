"use client";

import * as React from "react";
import {
  type ColumnDef,
  type ColumnFiltersState,
  type SortingState,
  type VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { DataTablePagination } from "@/components/patients/data-table-pagination";
import { DataTableViewOptions } from "@/components/patients/data-table-view-options";
import { ExportButton } from "@/components/ui/export-button";
import { Loader2, Search, X } from "lucide-react";
import {
  getCommissions,
  type Commission,
  getDoctors,
  type Doctor,
} from "@/lib/orderService";
import { DirhamIcon } from "../ui/DirhamIcon";
import { DateRangeFilter } from "@/components/admin/DateRangeFilter";
import { DoctorFilter } from "@/components/admin/DoctorFilter";

interface CommissionDataTableApiProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  canExport?: any;
  isAdmin?: boolean;
  onSummaryUpdate?: (summary: any) => void; // Add this
}

export function CommissionDataTableApi<TData, TValue>({
  columns,
  canExport,
  isAdmin = false,
  onSummaryUpdate, // Add this
}: CommissionDataTableApiProps<TData, TValue>) {
  const [data, setData] = React.useState<TData[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});
  const [pagination, setPagination] = React.useState({
    pageIndex: 0,
    pageSize: 10,
  });

  // API pagination state
  const [apiPagination, setApiPagination] = React.useState({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
  });

  const [summary, setSummary] = React.useState({
    total_orders: "0",
    total_commission_amount: 0,
    completed_commissions_count: 0,
    pending_commissions_count: 0,
  });

  // Admin-only filter states
  const [dateRange, setDateRange] = React.useState<{
    from: Date;
    to: Date;
  } | null>(null);
  const [selectedDoctor, setSelectedDoctor] = React.useState("all");
  const [doctors, setDoctors] = React.useState<Doctor[]>([]);

  // Status filter state - Single select instead of multi-select
  const [selectedStatus, setSelectedStatus] = React.useState<string>("all");

  // Load doctors for admin filter
  const loadDoctors = React.useCallback(async () => {
    if (!isAdmin) return;

    try {
      const response = await getDoctors();
      setDoctors(response.data.doctors);
    } catch (error) {
      console.error("Failed to load doctors:", error);
    }
  }, [isAdmin]);

  const fetchCommissions = React.useCallback(async () => {
    setIsLoading(true);
    try {
      const sortBy = sorting.length > 0 ? sorting[0].id : "created_at";
      const sortDirection =
        sorting.length > 0 ? (sorting[0].desc ? "desc" : "asc") : "desc";

      const searchFilter = columnFilters.find(
        (filter) => filter.id === "patient_name"
      );

      // Build query parameters with new filters
      const params: any = {
        page: pagination.pageIndex + 1,
        per_page: pagination.pageSize,
        sort_by: sortBy,
        sort_direction: sortDirection,
      };

      // Add search filter only for non-admin users
      if (!isAdmin && searchFilter?.value) {
        params.search = searchFilter.value as string;
      }

      // Add status filter - using single select state
      if (selectedStatus && selectedStatus !== "all") {
        params.status = selectedStatus;
      }

      // Add admin-only filters
      if (isAdmin) {
        // Date range filter
        if (dateRange?.from && dateRange?.to) {
          params.start_date = dateRange.from.toISOString().split("T")[0];
          params.end_date = dateRange.to.toISOString().split("T")[0];
        }

        // Doctor filter
        if (selectedDoctor && selectedDoctor !== "all") {
          params.doctor_id = selectedDoctor;
        }
      }

      console.log("Fetching commissions with params:", params);
      const response: any = await getCommissions(params);

      if (response.success) {
        setData(response.data.commissions as TData[]);
        setApiPagination(response.data.pagination);
        setSummary(response.data.summary);

        // Notify parent about summary update
        if (onSummaryUpdate) {
          onSummaryUpdate(response.data.summary);
        }
      }
    } catch (error) {
      console.error("Error fetching commissions:", error);
    } finally {
      setIsLoading(false);
    }
  }, [
    pagination,
    sorting,
    columnFilters,
    dateRange,
    selectedDoctor,
    selectedStatus,
    isAdmin,
  ]);
  const exportFilters = React.useMemo(() => {
    // For commissions, we want filters at root level, not nested
    const rootLevelFilters: Record<string, any> = {};

    // Status filter (applies to both admin and non-admin)
    if (selectedStatus && selectedStatus !== "all") {
      rootLevelFilters.status = selectedStatus;
    }

    // Admin-only filters
    if (isAdmin) {
      // Date range
      if (dateRange?.from && dateRange?.to) {
        rootLevelFilters.start_date = dateRange.from
          .toISOString()
          .split("T")[0];
        rootLevelFilters.end_date = dateRange.to.toISOString().split("T")[0];
      }

      // Doctor filter
      if (selectedDoctor && selectedDoctor !== "all") {
        rootLevelFilters.doctor_id = selectedDoctor;
      }
    } else {
      // Non-admin search filter
      const searchFilter = columnFilters.find(
        (filter) => filter.id === "patient_name"
      );
      if (searchFilter?.value) {
        rootLevelFilters.search = searchFilter.value as string;
      }
    }

    return rootLevelFilters;
  }, [selectedStatus, dateRange, selectedDoctor, isAdmin, columnFilters]);

  React.useEffect(() => {
    fetchCommissions();
    if (isAdmin) {
      loadDoctors();
    }
  }, [fetchCommissions, loadDoctors, isAdmin]);

  const table = useReactTable({
    data,
    columns,
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    onPaginationChange: setPagination,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
      pagination,
    },
    pageCount: apiPagination.last_page,
  });

  // Determine if any filters are active
  const isFiltered =
    (!isAdmin && table.getState().columnFilters.length > 0) ||
    (isAdmin && (dateRange || selectedDoctor !== "all")) ||
    selectedStatus !== "all";

  const handlePaginationChange = (page: number, pageSize: number) => {
    setPagination({
      pageIndex: page - 1,
      pageSize: pageSize,
    });
  };

  const handleDateRangeChange = (range: { from: Date; to: Date } | null) => {
    setDateRange(range);
  };

  const handleDoctorChange = (doctorId: string) => {
    setSelectedDoctor(doctorId);
  };

  // Single select status handler
  const handleStatusChange = (status: string) => {
    setSelectedStatus(status);
  };

  const resetAllFilters = () => {
    table.resetColumnFilters();
    setSelectedStatus("all");
    if (isAdmin) {
      setDateRange(null);
      setSelectedDoctor("all");
    }
  };

  // Status Filter Component with proper UI matching DoctorFilter
  const StatusFilter = () => {
    return (
      <div className="space-y-2">
        <Select value={selectedStatus} onValueChange={handleStatusChange}>
          <SelectTrigger className="w-full md:w-[200px] focus:ring-0 focus:ring-offset-0 focus:outline-none">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Status</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
          </SelectContent>
        </Select>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {/* Filters Section - Wider Layout */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        {/* Left side - Filters with increased width */}
        <div className="flex flex-wrap gap-3 items-center w-full sm:w-auto">
          {/* First position: Search for non-admin, Doctor Filter for admin */}
          {isAdmin ? (
            <div className="w-full sm:w-[220px]">
              {" "}
              {/* Increased from 200px */}
              <DoctorFilter
                onDoctorChange={handleDoctorChange}
                selectedDoctor={selectedDoctor}
              />
            </div>
          ) : (
            <div className="relative w-full sm:w-[220px]">
              {" "}
              {/* Increased from 200px */}
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                value={
                  (table
                    .getColumn("patient_name")
                    ?.getFilterValue() as string) ?? ""
                }
                onChange={(event) =>
                  table
                    .getColumn("patient_name")
                    ?.setFilterValue(event.target.value)
                }
                className="h-9 w-full pl-8"
              />
            </div>
          )}

          {/* Status Filter */}
          <div className="w-full sm:w-[220px]">
            {" "}
            {/* Increased from 200px */}
            <StatusFilter />
          </div>

          {/* Admin Filters - Date Range Filter with more width */}
          {isAdmin && (
            <div className="w-full sm:w-[280px]">
              {" "}
              {/* Significantly increased for date range */}
              <DateRangeFilter
                onDateRangeChange={handleDateRangeChange}
                selectedRange={dateRange}
              />
            </div>
          )}
        </div>

        {/* Right side - Reset Button and View Options */}
        <div className="flex gap-2 items-center w-full sm:w-auto mt-3 sm:mt-0">
          {isFiltered && (
            <Button
              variant="ghost"
              onClick={resetAllFilters}
              className="h-9 px-3"
            >
              Reset All
              <X className="ml-2 h-4 w-4" />
            </Button>
          )}{" "}
          {canExport && (
            <ExportButton
              data={data}
              filename="commission_report"
              title="Export"
              useApiExport={true}
              entity="commissions"
              filters={exportFilters} // Pass the current filters
              useCustomFilterStructure={true} // Add this flag
            />
          )}
          <DataTableViewOptions table={table} />
        </div>
      </div>

      {/* Summary Cards - Tighter spacing */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-blue-50 p-3 rounded-lg border">
          <div className="text-xl font-bold text-blue-600 flex items-center">
            <DirhamIcon className="h-4 w-4 mr-1" />
            {summary.total_commission_amount}
          </div>
          <div className="text-xs text-blue-600 font-medium">
            Total Commission
          </div>
        </div>
        <div className="bg-green-50 p-3 rounded-lg border">
          <div className="text-xl font-bold text-green-600">
            {summary.total_orders}
          </div>
          <div className="text-xs text-green-600 font-medium">Total Orders</div>
        </div>
        <div className="bg-orange-50 p-3 rounded-lg border">
          <div className="text-xl font-bold text-orange-600">
            {summary?.completed_commissions_count}
          </div>
          <div className="text-xs text-orange-600 font-medium">Completed</div>
        </div>
        <div className="bg-purple-50 p-3 rounded-lg border">
          <div className="text-xl font-bold text-purple-600">
            {summary.pending_commissions_count}
          </div>
          <div className="text-xs text-purple-600 font-medium">Pending</div>
        </div>
      </div>

      {/* Data Table */}
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder
                        ? null
                        : flexRender(
                            header.column.columnDef.header,
                            header.getContext()
                          )}
                    </TableHead>
                  );
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  <div className="flex items-center justify-center">
                    <Loader2 className="h-6 w-6 animate-spin mr-2" />
                    Loading commission...
                  </div>
                </TableCell>
              </TableRow>
            ) : table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow
                  key={row.id}
                  data-state={row.getIsSelected() && "selected"}
                >
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>
                      {flexRender(
                        cell.column.columnDef.cell,
                        cell.getContext()
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columns.length}
                  className="h-24 text-center"
                >
                  No commissions found.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <DataTablePagination
        table={table}
        pagination={apiPagination}
        onPaginationChange={handlePaginationChange}
      />
    </div>
  );
}
