"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUpDown, Eye } from "lucide-react";
import { DirhamIcon } from "../ui/DirhamIcon";
import { convertToDubaiDate } from "../convertToDubaiTime";
import Link from "next/link";

export type CommissionOrder = {
  id: string;
  order_id: string;
  patient_name: string;
  doctor_name?: string; // Optional for admin view
  order_total: number;
  commission: number;
  status: string;
  order_date: string;
  commission_rate: number;
  order_status: string;
  patient_id?: string;
  doctor_id?: string;
};

// Base columns that work for both admin and doctor
const baseCommissionColumns: ColumnDef<CommissionOrder>[] = [
  {
    accessorKey: "order_id",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Order ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      return <div className="font-medium">{row.getValue("order_id")}</div>;
    },
  },
  {
    accessorKey: "patient_name",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Patient
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      return <div className="font-medium">{row.getValue("patient_name")}</div>;
    },
  },
  {
    accessorKey: "order_total",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Order Total
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const amount = Number.parseFloat(row.getValue("order_total"));
      return (
        <div className="font-medium">
          <DirhamIcon />
          {amount.toFixed(2)}
        </div>
      );
    },
  },
  {
    accessorKey: "commission",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Commission
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const amount = Number.parseFloat(row.getValue("commission"));
      const status = row.getValue("status") as string;

      // Check if status is refunded to show red color
      const isRefunded = status.toLowerCase() === "refunded";

      return (
        <div
          className={`font-bold ${
            isRefunded ? "text-red-600" : "text-green-600"
          }`}
        >
          <DirhamIcon />
          {amount.toFixed(2)}
        </div>
      );
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Status
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      const getVariant = (status: string) => {
        switch (status.toLowerCase()) {
          case "completed":
            return "default";
          case "paid":
            return "default";
          case "processing":
            return "secondary";
          case "open":
            return "outline";
          case "refunded":
            return "destructive";
          default:
            return "outline";
        }
      };

      const getColor = (status: string) => {
        switch (status.toLowerCase()) {
          case "completed":
            return "bg-green-500 hover:bg-green-600";
          case "paid":
            return "bg-blue-500 hover:bg-blue-600";
          case "processing":
            return "bg-orange-500 hover:bg-orange-600";
          case "open":
            return "bg-gray-500 hover:bg-gray-600";
          case "refunded":
            return "bg-red-500 hover:bg-red-600";
          default:
            return "bg-gray-500 hover:bg-gray-600";
        }
      };

      return (
        <Badge variant={getVariant(status)} className={getColor(status)}>
          {status}
        </Badge>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    accessorKey: "order_date",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Order Date
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      );
    },
    cell: ({ row }) => {
      return (
        <div className="text-sm">
          {convertToDubaiDate(row.getValue("order_date"))}
        </div>
      );
    },
  },
];

// Doctor name column for admin view only - NOW AS A LINK
const doctorNameColumn: ColumnDef<CommissionOrder> = {
  accessorKey: "doctor_name",
  header: ({ column }) => {
    return (
      <Button
        variant="ghost"
        onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
        className="h-8 p-0 hover:bg-transparent"
      >
        Doctor
        <ArrowUpDown className="ml-2 h-4 w-4" />
      </Button>
    );
  },
  cell: ({ row }) => {
    const order: any = row.original;
    const doctorName = row.getValue("doctor_name") as string;
    const doctorId = order?.doctor_id;

    // If we have both doctor name and ID, make it a clickable link
    if (doctorName && doctorId) {
      return (
        <Link
          href={`/admin/doctors/${doctorId}`}
          className="font-medium text-blue-600 hover:text-blue-800 hover:underline transition-colors"
        >
          {doctorName}
        </Link>
      );
    }

    // Fallback to plain text if no ID or name
    return (
      <div className="font-medium text-muted-foreground">
        {doctorName || "N/A"}
      </div>
    );
  },
  filterFn: (row, id, value) => {
    return value === "all" || row.getValue(id) === value;
  },
};

// Create actions column factory function to handle different base paths
const createActionsColumn = (
  isAdmin: boolean = false
): ColumnDef<CommissionOrder> => ({
  id: "actions",
  enableHiding: false,
  cell: ({ row }) => {
    const order: any = row.original;
    const basePath = isAdmin ? "/admin" : "";

    return (
      <div className="flex space-x-2">
        {order?.patient_id && (
          <Link href={`${basePath}/patients/${order?.patient_id}`}>
            <Button variant="outline" size="sm">
              View Patient
            </Button>
          </Link>
        )}
        {/* {isAdmin && order?.doctor_id && (
          <Link href={`${basePath}/doctors/${order?.doctor_id}`}>
            <Button variant="outline" size="sm">
              View Doctor
            </Button>
          </Link>
        )} */}
      </div>
    );
  },
});

// Export function to create columns based on view type
export function getCommissionColumns(
  isAdmin: boolean = false
): ColumnDef<CommissionOrder>[] {
  const columns = [...baseCommissionColumns];

  // Add doctor name column for admin view
  if (isAdmin) {
    columns.splice(1, 0, doctorNameColumn); // Insert after patient_name column
  }

  // Add actions column at the end with the correct base path
  columns.push(createActionsColumn(isAdmin));

  return columns;
}

// Default export for backward compatibility (doctor view)
export const commissionColumns = getCommissionColumns(false);
