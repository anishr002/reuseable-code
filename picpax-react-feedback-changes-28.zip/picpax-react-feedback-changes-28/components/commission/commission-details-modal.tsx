"use client"

import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  DollarSign, 
  TrendingUp, 
  Calendar, 
  User, 
  Building,
  Percent,
  ShoppingCart,
  Activity,
  CheckCircle,
  Clock,
  AlertCircle,
  Target,
  BarChart3,
  Download
} from "lucide-react"
import type { Commission } from "./columns"

interface CommissionDetailsModalProps {
  commission: Commission | null
  isOpen: boolean
  onClose: () => void
}

export function CommissionDetailsModal({ commission, isOpen, onClose }: CommissionDetailsModalProps) {
  if (!commission) return null

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Active":
        return <CheckCircle className="h-4 w-4" />
      case "Inactive":
        return <Clock className="h-4 w-4" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active":
        return "bg-green-600 hover:bg-green-700"
      case "Inactive":
        return "bg-gray-600 hover:bg-gray-700"
      default:
        return "bg-gray-600 hover:bg-gray-700"
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Commission Details - {commission.doctorName}
              </DialogTitle>
              <DialogDescription>
                Complete commission information and performance metrics
              </DialogDescription>
            </div>
            <Badge variant="default" className={`flex items-center gap-1 ${getStatusColor(commission.status)}`}>
              {getStatusIcon(commission.status)}
              {commission.status}
            </Badge>
          </div>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          {/* Commission Summary */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Building className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Clinic</span>
              </div>
              <p className="text-sm text-muted-foreground ml-6">{commission.doctorClinic}</p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Percent className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Commission Rate</span>
              </div>
              <p className="text-sm font-medium ml-6">{commission.commissionRate}%</p>
            </div>
          </div>

          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="performance">Performance</TabsTrigger>
              <TabsTrigger value="payouts">Payouts</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="h-5 w-5 text-green-600" />
                    <h4 className="font-medium">Total Commission</h4>
                  </div>
                  <div className="text-2xl font-bold text-green-600">${commission.totalCommission.toLocaleString()}</div>
                  <p className="text-sm text-muted-foreground">All time earnings</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="h-5 w-5 text-blue-600" />
                    <h4 className="font-medium">Monthly Commission</h4>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">${commission.monthlyCommission.toLocaleString()}</div>
                  <p className="text-sm text-muted-foreground">This month</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="h-5 w-5 text-yellow-600" />
                    <h4 className="font-medium">Pending Payout</h4>
                  </div>
                  <div className="text-2xl font-bold text-yellow-600">${commission.pendingCommission.toLocaleString()}</div>
                  <p className="text-sm text-muted-foreground">Awaiting payout</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <ShoppingCart className="h-5 w-5 text-purple-600" />
                    <h4 className="font-medium">Total Orders</h4>
                  </div>
                  <div className="text-2xl font-bold text-purple-600">{commission.totalOrders}</div>
                  <p className="text-sm text-muted-foreground">
                    {commission.completedOrders} completed
                  </p>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="performance" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Target className="h-5 w-5" />
                    <h4 className="font-medium">Conversion Rate</h4>
                  </div>
                  <div className="text-2xl font-bold text-green-600">{commission.conversionRate}%</div>
                  <p className="text-sm text-muted-foreground">
                    {commission.completedOrders}/{commission.totalOrders} orders completed
                  </p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart3 className="h-5 w-5" />
                    <h4 className="font-medium">Average Order Value</h4>
                  </div>
                  <div className="text-2xl font-bold text-blue-600">${commission.averageOrderValue}</div>
                  <p className="text-sm text-muted-foreground">Per order average</p>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-3">Performance Metrics</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Total Revenue Generated</span>
                    <span className="font-medium">${commission.totalRevenue.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Commission Efficiency</span>
                    <span className="font-medium">
                      {((commission.totalCommission / commission.totalRevenue) * 100).toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Member Since</span>
                    <span className="font-medium">{new Date(commission.joinDate).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="payouts" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="h-5 w-5" />
                    <h4 className="font-medium">Last Payout</h4>
                  </div>
                  <div className="text-lg font-bold">{commission.lastPayout}</div>
                  <p className="text-sm text-muted-foreground">Previous payout date</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Activity className="h-5 w-5" />
                    <h4 className="font-medium">Next Payout</h4>
                  </div>
                  <div className="text-lg font-bold">{commission.nextPayout}</div>
                  <p className="text-sm text-muted-foreground">Scheduled payout date</p>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-3">Payout Schedule</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Payout Frequency:</span>
                    <span className="font-medium">Monthly</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Minimum Threshold:</span>
                    <span className="font-medium">$50</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Processing Time:</span>
                    <span className="font-medium">3-5 business days</span>
                  </div>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="analytics" className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-3">Commission Analytics</h4>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Monthly Growth</span>
                    <Badge variant="default" className="bg-green-600">+12.5%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Peak Performance</span>
                    <span className="font-medium">December 2023</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Best Performing Month</span>
                    <span className="font-medium text-green-600">$624.50</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">Average Monthly Commission</span>
                    <span className="font-medium">${commission.monthlyCommission}</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium mb-3">Rankings</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Overall Ranking:</span>
                    <Badge variant="default">#2</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Revenue Ranking:</span>
                    <Badge variant="default">#3</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Conversion Ranking:</span>
                    <Badge variant="default" className="bg-green-600">#1</Badge>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
          <Button>
            Process Payout
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}