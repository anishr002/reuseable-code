"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Package, Plus, BarChart3 } from "lucide-react";
import Link from "next/link";
import { AddPatientModal } from "./add-patient-modal";

export function QuickStartCard() {
  const [isAddPatientModalOpen, setIsAddPatientModalOpen] = useState(false);

  const quickActions = [
    {
      title: "Add New Patient",
      description: "Register a new patient",
      icon: Users,
      action: () => setIsAddPatientModalOpen(true),
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      title: "Create Order",
      description: "Start a new prescription",
      icon: Package,
      href: "/orders/create",
      color: "bg-primary hover:bg-primary/90",
    },
    {
      title: "View Analytics",
      description: "Check your performance",
      icon: BarChart3,
      href: "/commission",
      color: "bg-secondary hover:bg-secondary/90",
    },
  ];

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Quick Actions
          </CardTitle>
          <CardDescription>
            Get started with common portal tasks
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 md:grid-cols-3">
            {quickActions.map((action) => (
              <div key={action.title}>
                {action.href ? (
                  <Link href={action.href}>
                    <Button
                      variant="outline"
                      className="h-auto p-4 flex flex-col items-center space-y-2 w-full hover:shadow-md transition-shadow bg-transparent"
                    >
                      <div
                        className={`p-2 rounded-lg text-white ${action.color}`}
                      >
                        <action.icon className="h-5 w-5" />
                      </div>
                      <div className="text-center">
                        <div className="font-medium text-sm">
                          {action.title}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {action.description}
                        </div>
                      </div>
                    </Button>
                  </Link>
                ) : (
                  <Button
                    variant="outline"
                    className="h-auto p-4 flex flex-col items-center space-y-2 w-full hover:shadow-md transition-shadow bg-transparent"
                    onClick={action.action}
                  >
                    <div
                      className={`p-2 rounded-lg text-white ${action.color}`}
                    >
                      <action.icon className="h-5 w-5" />
                    </div>
                    <div className="text-center">
                      <div className="font-medium text-sm">{action.title}</div>
                      <div className="text-xs text-muted-foreground">
                        {action.description}
                      </div>
                    </div>
                  </Button>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <AddPatientModal
        isOpen={isAddPatientModalOpen}
        onClose={() => setIsAddPatientModalOpen(false)}
        isDoctorDashboard={true}
      />
    </>
  );
}
