"use client";

import type React from "react";

import {
  Home,
  Users,
  Package,
  DollarSign,
  FileText,
  LogOut,
  Settings,
  UserCog,
  Shield,
  Users2,
  User,
  Clock,
  Archive,
} from "lucide-react";
import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/lib/auth-context";
import { AdminProfileModal } from "./admin-profile-modal";

const adminMenuItems = [
  {
    title: "Dashboard",
    url: "/admin/dashboard",
    icon: Home,
    requiredPermissions: [], // always show
  },
  {
    title: "Doctors Management",
    url: "/admin/doctors",
    icon: UserCog,
    requiredPermissions: ["doctor_read"], // always show
  },
  {
    title: "Pending Users Management",
    url: "/admin/pending-users",
    icon: Clock,
    requiredPermissions: ["pendingUser_read"], // 👈 specific permission required
  },
  {
    title: "Draft Orders Management",
    url: "/admin/draft-orders",
    icon: FileText,
    requiredPermissions: ["draftOrder_read"], // always show
  },
  {
    title: "Orders Management",
    url: "/admin/orders",
    icon: FileText,
    requiredPermissions: ["order_read"], // always show
  },
  {
    title: "Commission Tracking",
    url: "/admin/commission",
    icon: DollarSign,
    requiredPermissions: ["commission_read"], // specific permission required
  },

  {
    title: "Product Management",
    url: "/admin/products",
    icon: Package,
    requiredPermissions: ["product_read"], // always show
  },
  {
    title: "Staff Management",
    url: "/admin/staff",
    icon: Users2,
    requiredPermissions: ["role_read", "staff_read"], // 👈 staff perms
  },
  {
    title: "Patients Management",
    url: "/admin/patients",
    icon: User,
    requiredPermissions: ["patient_read"], // always show
  },
  {
    title: "System Settings",
    url: "/admin/settings",
    icon: Settings,
    requiredPermissions: ["generalSetting_read", "notificationSetting_read"], // always show
  },
  // System Logs - Only for super admin (handled separately)
  {
    title: "System Logs",
    url: "/admin/system-logs",
    icon: Archive,
    requiredPermissions: ["super_admin_only"], // special marker for super admin only
  },
];

export function AdminSidebar({
  ...props
}: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout, startRouting } = useAuth();
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);

  // 🔹 load user data from localStorage
  const [userData, setUserData] = useState<{
    permissions: string[];
    role: string;
  }>({ permissions: [], role: "" });

  useEffect(() => {
    const storedUser = localStorage.getItem("picpax_user");
    if (storedUser) {
      const parsed = JSON.parse(storedUser);
      setUserData({
        permissions: parsed.permission || [],
        role: parsed.role || "",
      });
    }
  }, []);

  // Prefetch admin routes to speed up navigation
  useEffect(() => {
    adminMenuItems.forEach((item) => {
      router.prefetch(item.url);
    });
  }, [router]);

  if (!user) return null;

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  // 🔹 check if menu item should be shown
  const hasPermission = (requiredPermissions: string[]) => {
    if (requiredPermissions.length === 0) return true; // always show

    // Special case for System Logs - only show for super admin
    if (requiredPermissions.includes("super_admin_only")) {
      return userData.role === "super admin";
    }

    return requiredPermissions.some((perm) =>
      userData.permissions.includes(perm)
    );
  };

  return (
    <>
      <Sidebar {...props}>
        <SidebarHeader className="border-b border-gray-200 p-3 sm:p-4">
          <div className="flex items-center justify-center">
            <img
              src="/images/logo.png"
              alt="PicPax"
              className="h-6 sm:h-8 w-auto object-contain"
            />
          </div>
          <div className="flex items-center justify-center mt-2">
            <Badge variant="secondary" className="text-xs">
              <Shield className="h-3 w-3 mr-1" />
              Admin Portal
            </Badge>
          </div>
        </SidebarHeader>

        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Admin Navigation</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminMenuItems
                  .filter((item) => hasPermission(item.requiredPermissions))
                  .map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        isActive={pathname === item.url}
                      >
                        <Link href={item.url} onClick={() => startRouting()}>
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        <SidebarFooter className="border-t border-gray-200 p-4">
          <div
            className="flex items-center gap-3 mb-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
            onClick={() => setIsProfileModalOpen(true)}
          >
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs font-semibold bg-red-600 text-white">
                {getInitials(user.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-muted-foreground truncate">
                {user.email}
              </p>
            </div>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full bg-transparent"
            onClick={logout}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </SidebarFooter>

        <SidebarRail />
      </Sidebar>

      <AdminProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </>
  );
}
