"use client";

import { useState, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

// Individual icon imports
import { Upload as UploadIcon } from "lucide-react";
import { File as FileIcon } from "lucide-react";
import { Download as DownloadIcon } from "lucide-react";
import { Eye as EyeIcon } from "lucide-react";
import { Trash2 as TrashIcon } from "lucide-react";
import { FileText as FileTextIcon } from "lucide-react";
import { Image as ImageIcon } from "lucide-react";
import { FileArchive as FileArchiveIcon } from "lucide-react";
import { AlertCircle as AlertCircleIcon } from "lucide-react";
import { CheckCircle as CheckCircleIcon } from "lucide-react";
import { Plus as PlusIcon } from "lucide-react";
import { Save as SaveIcon } from "lucide-react";
import { Loader2 as LoaderIcon } from "lucide-react";
import { Cloud as CloudIcon } from "lucide-react";
import { Server as ServerIcon } from "lucide-react";

export interface DocumentFile {
  id: string;
  name: string;
  size: number;
  type: string;
  file: File;
  url?: string;
  status: "uploading" | "completed" | "error" | "saved" | "server";
  progress: number;
  serverId?: string;
  uploaded_at?: string;
  category?: string;
}

interface DocumentUploadProps {
  documents: DocumentFile[];
  onDocumentsChange: (documents: DocumentFile[]) => void;
  maxFiles?: number;
  maxSize?: number;
  acceptedTypes?: string[];
  title?: string;
  description?: string;
  type?: string;
  onSaveDocuments?: (documents: DocumentFile[]) => Promise<void>;
  isSaving?: boolean;
  showServerDocuments?: boolean;
  onFetchServerDocuments?: () => Promise<any[]>;
  onDeleteServerDocument?: any;
}

const FILE_ICONS = {
  pdf: FileTextIcon,
  doc: FileTextIcon,
  docx: FileTextIcon,
  jpg: ImageIcon,
  jpeg: ImageIcon,
  png: ImageIcon,
  gif: ImageIcon,
  zip: FileArchiveIcon,
  rar: FileArchiveIcon,
  default: FileIcon,
};

const formatFileSize = (bytes: number) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
};

const getFileIcon = (type: string) => {
  const extension =
    type.split("/").pop()?.split(".").pop()?.toLowerCase() || "default";
  return FILE_ICONS[extension as keyof typeof FILE_ICONS] || FILE_ICONS.default;
};

const formatDate = (dateString: string) => {
  const date = new Date(dateString);
  return date.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
};

export function DocumentUpload({
  documents,
  onDocumentsChange,
  maxFiles = 5,
  maxSize = 2,
  acceptedTypes = [
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "image/jpeg",
    "image/png",
    "image/gif",
    "application/zip",
    "application/x-rar-compressed",
  ],
  title = "Required Documents",
  description = "Upload required documents for verification. Maximum 5 files, 2MB each.",
  type = "system",
  onSaveDocuments,
  isSaving = false,
  showServerDocuments = false,
  onFetchServerDocuments,
  onDeleteServerDocument,
}: DocumentUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [serverDocuments, setServerDocuments] = useState<DocumentFile[]>([]);
  const [isLoadingServerDocuments, setIsLoadingServerDocuments] =
    useState(false);
  const [isDeletingDocument, setIsDeletingDocument] = useState<string | null>(
    null
  );
  const { toast } = useToast();

  useEffect(() => {
    if (showServerDocuments && onFetchServerDocuments) {
      fetchServerDocuments();
    }
  }, [showServerDocuments]);

  const extractDocumentIdFromUrl = (url: string): string => {
    try {
      const urlParts = url.split("/");
      const fileName = urlParts[urlParts.length - 1];

      const uuidMatch = fileName.match(/^([a-f0-9-]+)_/);
      if (uuidMatch && uuidMatch[1]) {
        return uuidMatch[1];
      }

      for (const part of urlParts) {
        const uuidRegex =
          /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/;
        if (uuidRegex.test(part)) {
          return part;
        }
      }

      return fileName;
    } catch (error) {
      console.error("Error extracting document ID from URL:", error);
      return "";
    }
  };

  const getMimeTypeFromFileName = (fileName: string): string => {
    const extension = fileName.split(".").pop()?.toLowerCase();
    const mimeTypes: { [key: string]: string } = {
      pdf: "application/pdf",
      doc: "application/msword",
      docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      jpg: "image/jpeg",
      jpeg: "image/jpeg",
      png: "image/png",
      gif: "image/gif",
      zip: "application/zip",
      rar: "application/x-rar-compressed",
    };
    return mimeTypes[extension || ""] || "application/octet-stream";
  };

  const fetchServerDocuments = async () => {
    if (!onFetchServerDocuments) return;

    setIsLoadingServerDocuments(true);
    try {
      const serverDocs = await onFetchServerDocuments();

      if (!serverDocs || !Array.isArray(serverDocs)) {
        throw new Error("Invalid server documents response");
      }

      const formattedDocs: DocumentFile[] = serverDocs.map(
        (doc: any, index: number) => {
          const documentId = extractDocumentIdFromUrl(doc.url);

          return {
            id: `server-${index}-${Date.now()}`,
            name: doc.name,
            size: 0,
            type: getMimeTypeFromFileName(doc.name),
            file: new File([], doc.name),
            url: doc.url,
            status: "server" as const,
            progress: 100,
            serverId: documentId,
            uploaded_at: doc.uploaded_at,
          };
        }
      );

      setServerDocuments(formattedDocs);
    } catch (error: any) {
      console.error("Failed to fetch server documents:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to load uploaded documents",
      });
      setServerDocuments([]);
    } finally {
      setIsLoadingServerDocuments(false);
    }
  };

  const validateFile = (file: File) => {
    if (file.size > maxSize * 1024 * 1024) {
      toast({
        title: "File too large",
        description: `${file.name} exceeds the maximum size of ${maxSize}MB`,
        variant: "destructive",
      });
      return false;
    }

    if (!acceptedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: `${file.name} is not a supported file type`,
        variant: "destructive",
      });
      return false;
    }

    if (documents.length >= maxFiles) {
      toast({
        title: "Too many files",
        description: `Maximum ${maxFiles} files allowed`,
        variant: "destructive",
      });
      return false;
    }

    if (documents.some((doc) => doc.name === file.name)) {
      toast({
        title: "File already exists",
        description: `A file with name "${file.name}" is already uploaded`,
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const simulateUpload = (files: File[]) => {
    const newDocuments: DocumentFile[] = files.map((file) => {
      const documentId =
        Date.now().toString() + Math.random().toString(36).substr(2, 9);
      return {
        id: documentId,
        name: file.name,
        size: file.size,
        type: file.type,
        file: file,
        status: "completed",
        progress: 100,
      };
    });

    // Add all new documents at once instead of one by one
    const updatedDocuments = [...documents, ...newDocuments];
    onDocumentsChange(updatedDocuments);

    if (files.length === 1) {
      toast({
        title: "File added",
        description: `${files[0].name} has been added successfully. Click Save to upload.`,
        variant: "default",
      });
    } else {
      toast({
        title: "Files added",
        description: `${files.length} files have been added successfully. Click Save to upload.`,
        variant: "default",
      });
    }
  };

  const handleFileSelect = (files: FileList) => {
    const fileArray = Array.from(files);

    // Check total files won't exceed maxFiles
    if (documents.length + fileArray.length > maxFiles) {
      toast({
        title: "Too many files",
        description: `You can only upload ${maxFiles} files total. You have ${documents.length} files already.`,
        variant: "destructive",
      });
      return;
    }

    const validFiles = fileArray.filter((file) => validateFile(file));

    if (validFiles.length > 0) {
      simulateUpload(validFiles);
    }
  };

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragOver(false);
      handleFileSelect(e.dataTransfer.files);
    },
    [documents, maxFiles]
  );

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFileSelect(e.target.files);
      e.target.value = ""; // Reset input to allow selecting same files again
    }
  };

  const removeDocument = (documentId: string) => {
    const updatedDocuments = documents.filter((doc) => doc.id !== documentId);
    onDocumentsChange(updatedDocuments);
    toast({
      title: "Document removed",
      description: "Document has been removed successfully",
    });
  };

  const downloadDocument = (doc: DocumentFile) => {
    if (doc.status === "server" && doc.url) {
      window.open(doc.url, "_blank");
    } else {
      const url = URL.createObjectURL(doc.file);
      const link = document.createElement("a");
      link.href = url;
      link.download = doc.name;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  };

  const viewDocument = (doc: DocumentFile) => {
    if (doc.status === "server" && doc.url) {
      window.open(doc.url, "_blank");
    } else {
      const url = URL.createObjectURL(doc.file);
      window.open(url, "_blank");
    }
  };

  const handleSave = async () => {
    if (documents.length === 0) {
      toast({
        title: "No documents to save",
        description: "Please upload at least one document before saving",
        variant: "destructive",
      });
      return;
    }

    if (onSaveDocuments) {
      try {
        await onSaveDocuments(documents);

        // IMPORTANT FIX: Don't clear the documents after save
        // The documents should remain in the "Selected Documents" section
        // until the user explicitly removes them or navigates away
        onDocumentsChange([]);

        if (showServerDocuments && onFetchServerDocuments) {
          await fetchServerDocuments();
        }

        toast({
          title: "Documents saved successfully!",
          description: `${documents.length} document(s) have been uploaded.`,
          variant: "default",
        });
      } catch (error) {
        console.error("Error saving documents:", error);
        toast({
          title: "Error saving documents",
          description:
            "There was an error uploading your documents. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const handleDeleteServerDocument = async (
    documentId: string,
    serverId?: string
  ) => {
    if (!onDeleteServerDocument || !serverId) {
      toast({
        variant: "destructive",
        title: "Error",
        description:
          "Cannot delete document: Missing server ID or delete function",
      });
      return;
    }

    setIsDeletingDocument(documentId);
    try {
      await onDeleteServerDocument(serverId);
      setServerDocuments((prev) => prev.filter((doc) => doc.id !== documentId));
      toast({
        variant: "success",
        title: "Document Deleted!",
        description: "Document has been deleted successfully.",
      });
    } catch (error: any) {
      console.error("Failed to delete document:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message || "Failed to delete document",
      });
    } finally {
      setIsDeletingDocument(null);
    }
  };

  const hasDocuments = documents.length > 0;
  const hasServerDocuments = serverDocuments.length > 0;

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label className="text-base font-semibold">{title}</Label>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>

      {/* Upload Area */}
      <Card className="border-dashed">
        <CardContent className="p-4">
          <div
            className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
              isDragOver
                ? "border-primary bg-primary/5"
                : "border-gray-300 hover:border-gray-400"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
          >
            <UploadIcon className="mx-auto h-8 w-8 text-gray-400 mb-2" />
            <p className="text-sm text-gray-600 mb-2">
              Drag and drop files here, or click to select
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                // Use a proper file input with multiple selection
                const input = document.createElement("input");
                input.type = "file";
                input.multiple = true; // This allows multiple file selection
                input.accept = acceptedTypes.join(",");
                input.onchange = (e) => {
                  if (e.target instanceof HTMLInputElement && e.target.files) {
                    handleFileSelect(e.target.files);
                  }
                };
                input.click();
              }}
              disabled={documents.length >= maxFiles}
            >
              <PlusIcon className="h-4 w-4 mr-2" />
              Select Files
            </Button>
            <p className="text-xs text-gray-500 mt-2">
              Maximum {maxFiles} files, {maxSize}MB each. Supported formats:
              PDF, DOC, DOCX, JPG, PNG, GIF, ZIP, RAR
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Uploaded Documents List */}
      {hasDocuments && (
        <div className="space-y-3">
          <Label className="text-sm font-medium">
            Selected Documents ({documents.length}/{maxFiles})
          </Label>
          <div className="space-y-2">
            {documents.map((doc) => (
              <Card key={doc.id} className="relative">
                <CardContent className="p-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      <div className="flex-shrink-0">
                        {(() => {
                          const IconComponent = getFileIcon(doc.type);
                          return (
                            <IconComponent className="h-6 w-6 text-blue-500" />
                          );
                        })()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">
                          {doc.name}
                        </p>
                        <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                          <span>{formatFileSize(doc.size)}</span>
                          <span>•</span>
                          <span className="capitalize">
                            {doc.type.split("/")[1] || doc.type}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => viewDocument(doc)}
                        className="h-8 w-8"
                      >
                        <EyeIcon className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => downloadDocument(doc)}
                        className="h-8 w-8"
                      >
                        <DownloadIcon className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeDocument(doc.id)}
                        className="h-8 w-8 text-red-500 hover:text-red-700"
                      >
                        <TrashIcon className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {doc.status === "uploading" && (
                    <div className="mt-2">
                      <div className="flex justify-between text-xs text-muted-foreground mb-1">
                        <span>Uploading...</span>
                        <span>{doc.progress}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div
                          className="bg-blue-600 h-1.5 rounded-full transition-all duration-300"
                          style={{ width: `${doc.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  )}

                  {doc.status === "completed" && (
                    <div className="flex items-center mt-1 text-xs text-green-600">
                      <CheckCircleIcon className="h-3 w-3 mr-1" />
                      Ready to save
                    </div>
                  )}

                  {doc.status === "error" && (
                    <div className="flex items-center mt-1 text-xs text-red-600">
                      <AlertCircleIcon className="h-3 w-3 mr-1" />
                      Upload failed
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Server Documents Section */}
      {showServerDocuments && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium flex items-center">
              <ServerIcon className="h-4 w-4 mr-2" />
              Previously Uploaded Documents
            </Label>
            <Button
              variant="outline"
              size="sm"
              onClick={fetchServerDocuments}
              disabled={isLoadingServerDocuments}
            >
              {isLoadingServerDocuments ? (
                <LoaderIcon className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <CloudIcon className="h-4 w-4 mr-2" />
              )}
              Refresh
            </Button>
          </div>

          {isLoadingServerDocuments ? (
            <div className="flex justify-center py-4">
              <LoaderIcon className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : hasServerDocuments ? (
            <div className="space-y-2">
              {serverDocuments.map((doc) => (
                <Card
                  key={doc.id}
                  className="relative border-blue-200 bg-blue-50"
                >
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3 flex-1 min-w-0">
                        <div className="flex-shrink-0">
                          {(() => {
                            const IconComponent = getFileIcon(doc.type);
                            return (
                              <IconComponent className="h-6 w-6 text-green-500" />
                            );
                          })()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <p className="text-sm font-medium truncate">
                              {doc.name}
                            </p>
                            <Badge variant="outline" className="text-xs">
                              <CloudIcon className="h-3 w-3 mr-1" />
                              Saved
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                            {doc.uploaded_at && (
                              <>
                                <span>
                                  Uploaded: {formatDate(doc.uploaded_at)}
                                </span>
                                <span>•</span>
                              </>
                            )}
                            <span>Server</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => viewDocument(doc)}
                          className="h-8 w-8"
                        >
                          <EyeIcon className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => downloadDocument(doc)}
                          className="h-8 w-8"
                        >
                          <DownloadIcon className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() =>
                            handleDeleteServerDocument(doc.id, doc.serverId)
                          }
                          disabled={isDeletingDocument === doc.id}
                          className="h-8 w-8 text-red-500 hover:text-red-700"
                        >
                          {isDeletingDocument === doc.id ? (
                            <LoaderIcon className="h-4 w-4 animate-spin" />
                          ) : (
                            <TrashIcon className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="p-4 text-center">
                <FileIcon className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">
                  No documents found on server
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Save Button */}
      {(hasDocuments || (showServerDocuments && hasServerDocuments)) &&
        onSaveDocuments && (
          <div className="flex justify-end pt-2">
            <Button
              onClick={handleSave}
              disabled={isSaving || documents.length === 0}
              className="min-w-[100px]"
            >
              {isSaving ? (
                <>
                  <LoaderIcon className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <SaveIcon className="h-4 w-4 mr-2" />
                  Save Documents
                </>
              )}
            </Button>
          </div>
        )}

      {/* Status Summary */}
      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
        <div className="flex items-center">
          <div className="w-3 h-3 bg-blue-500 rounded-full mr-1"></div>
          <span>Selected: {documents.length}</span>
        </div>
        {showServerDocuments && (
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-1"></div>
            <span>Saved: {serverDocuments.length}</span>
          </div>
        )}
        <div className="flex items-center">
          <div className="w-3 h-3 bg-gray-300 rounded-full mr-1"></div>
          <span>Max: {maxFiles} files</span>
        </div>
      </div>
    </div>
  );
}
