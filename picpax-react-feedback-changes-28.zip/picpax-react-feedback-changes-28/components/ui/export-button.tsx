"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Download, FileText, File, CloudDownload } from "lucide-react";
import { DataExporter } from "@/lib/export-utils";
import { useToast } from "@/hooks/use-toast";
import { exportData, exportDoctors } from "@/lib/doctorApi";

interface ExportButtonProps {
  data?: any[]; // Optional for client-side export
  filename?: string;
  title?: string;
  className?: string;
  // New props for API-based export
  entity?: string; // Entity type: 'doctors', 'patients', 'staff', 'products'
  useApiExport?: boolean; // Flag to use API export instead of client-side
  // Additional filters for API export
  filters?: Record<string, any>; // Optional filters to include in export
  useCustomFilterStructure?: boolean; // Add this
  // Add new props for search and sorting
  search?: string;
  sort_by?: string;
  sort_order?: string;
  // Add doctor_id specifically for doctor-related exports
  doctor_id?: string;
}

export function ExportButton({
  data = [],
  filename = "export",
  title = "Export Data",
  className = "",
  entity = "doctors",
  useApiExport = false,
  filters = {},
  useCustomFilterStructure = false, // Add this with default
  search = "",
  sort_by = "",
  sort_order = "",
  doctor_id = "", // Add doctor_id prop
}: ExportButtonProps) {
  const [isExporting, setIsExporting] = useState(false);
  const { toast } = useToast();

  // Client-side export function
  const handleClientExport = async (format: "csv" | "excel") => {
    if (data.length === 0) {
      toast({
        title: "No data to export",
        description: "There is no data available to export.",
        variant: "destructive",
      });
      return;
    }

    setIsExporting(true);

    try {
      const timestampedFilename = DataExporter.getTimestampedFilename(filename);

      if (format === "csv") {
        DataExporter.exportToCSV(data, timestampedFilename);
        toast({
          title: "Export successful",
          description: `Data exported as ${timestampedFilename}.csv`,
        });
      } else {
        DataExporter.exportToExcel(data, timestampedFilename);
        toast({
          title: "Export successful",
          description: `Data exported as ${timestampedFilename}.xlsx`,
        });
      }
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Failed to export data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  // API-based export function
  const handleApiExport = async (format: "csv" | "excel") => {
    setIsExporting(true);
    console.log(filters, useCustomFilterStructure, "sssssssssssss");
    try {
      let response: any;

      // Use specific entity export with format and filters
      if (entity) {
        response = await exportData(
          entity,
          format,
          filters,
          useCustomFilterStructure,
          search,
          sort_by,
          sort_order,
          doctor_id // Pass doctor_id
        ); // Pass the flag
      }

      console.log("Export API Response:", response); // Debug log

      if (response && response.success) {
        // Handle different response structures
        let fileUrl: string;
        let downloadFilename: string;

        // Check for different possible response structures
        if (response.data?.export?.file_url) {
          // Structure 1: response.data.export.file_url
          fileUrl = response.data.export.file_url;
          downloadFilename =
            response.data.export.filename ||
            `${filename}_${new Date().getTime()}.${format}`;
        } else if (response.data?.file_url) {
          // Structure 2: response.data.file_url
          fileUrl = response.data.file_url;
          downloadFilename =
            response.data.filename ||
            `${filename}_${new Date().getTime()}.${format}`;
        } else if (response.export?.file_url) {
          // Structure 3: response.export.file_url
          fileUrl = response.export.file_url;
          downloadFilename =
            response.export.filename ||
            `${filename}_${new Date().getTime()}.${format}`;
        } else if (response.file_url) {
          // Structure 4: response.file_url
          fileUrl = response.file_url;
          downloadFilename =
            response.filename ||
            `${filename}_${new Date().getTime()}.${format}`;
        } else {
          throw new Error("No file URL found in response");
        }

        // Create download link for the file
        const link = document.createElement("a");
        link.href = fileUrl;
        link.download = downloadFilename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        toast({
          title: "Export successful",
          description: `File "${downloadFilename}" is being downloaded.`,
        });
      } else {
        throw new Error(
          response?.message ||
            "Export failed - API returned unsuccessful response"
        );
      }
    } catch (error: any) {
      console.error("Export error:", error);
      toast({
        title: "Export failed",
        description:
          error.message || "Failed to export data. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsExporting(false);
    }
  };

  // Main export handler
  const handleExport = async (format: "csv" | "excel") => {
    if (useApiExport) {
      await handleApiExport(format);
    } else {
      await handleClientExport(format);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={className}
          disabled={isExporting}
        >
          <Download className="h-4 w-4 mr-2" />
          {isExporting ? "Exporting..." : title}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuItem onClick={() => handleExport("csv")}>
          <FileText className="h-4 w-4 mr-2" />
          Export as CSV
          <span className="ml-auto text-xs text-muted-foreground">.csv</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleExport("excel")}>
          <File className="h-4 w-4 mr-2" />
          Export as Excel
          <span className="ml-auto text-xs text-muted-foreground">.xlsx</span>
        </DropdownMenuItem>

        {/* Show API export indicator */}
        {useApiExport && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              disabled
              className="text-xs text-muted-foreground"
            >
              <CloudDownload className="h-3 w-3 mr-1" />
              Server-side export
            </DropdownMenuItem>
            {Object.keys(filters).length > 0 && (
              <DropdownMenuItem
                disabled
                className="text-xs text-muted-foreground"
              >
                With {Object.keys(filters).length} filter
                {Object.keys(filters).length !== 1 ? "s" : ""}
              </DropdownMenuItem>
            )}
          </>
        )}

        {/* Show client-side data count */}
        {!useApiExport && data && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              disabled
              className="text-xs text-muted-foreground"
            >
              {data.length} record{data.length !== 1 ? "s" : ""} available
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
