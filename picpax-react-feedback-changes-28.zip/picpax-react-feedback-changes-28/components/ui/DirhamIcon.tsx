import Image from "next/image";
import dirham from "../../public/images/UAE_Dirham_Symbol.svg.svg";

export const DirhamIcon = ({ className = "", width = 16, height = 16 }) => {
  return (
    <span className={`inline-flex items-center ${className}`}>
      <Image
        src={dirham}
        alt="UAE Dirham Symbol"
        width={width}
        height={height}
        className="inline-block"
      />
    </span>
  );
};
