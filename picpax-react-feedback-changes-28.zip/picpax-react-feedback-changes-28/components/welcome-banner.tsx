"use client"

import { useEffect, useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, X } from "lucide-react"
import { useAuth } from "@/lib/auth-context"

export function WelcomeBanner() {
  const [showWelcome, setShowWelcome] = useState(false)
  const { user } = useAuth()

  useEffect(() => {
    // Check if this is a fresh login
    const justLoggedIn = sessionStorage.getItem("picpax_just_logged_in")
    if (justLoggedIn === "true") {
      setShowWelcome(true)
      sessionStorage.removeItem("picpax_just_logged_in")
    }
  }, [])

  if (!showWelcome || !user) return null

  return (
    <Card className="mb-6 border-green-200 bg-green-50">
      <CardContent className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-3">
          <CheckCircle className="h-5 w-5 text-green-600" />
          <div>
            <h3 className="font-medium text-green-900">Welcome to PicPax Portal!</h3>
            <p className="text-sm text-green-700">
              Successfully logged in as {user.name}. You now have access to all portal features.
            </p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowWelcome(false)}
          className="text-green-600 hover:text-green-700 hover:bg-green-100"
        >
          <X className="h-4 w-4" />
        </Button>
      </CardContent>
    </Card>
  )
}
