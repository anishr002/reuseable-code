"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Package,
  DollarSign,
  Calendar,
  User,
  Mail,
  MapPin,
  Phone,
  FileText,
  X,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  Printer,
} from "lucide-react";
import type { Order } from "./columns";
import { DirhamIcon } from "../ui/DirhamIcon";
import { useState, useEffect } from "react";
import axiosInstance from "@/services/axiosInstance";
import { useToast } from "@/hooks/use-toast";
import { convertToDubaiDate } from "../convertToDubaiTime";

interface OrderDetailsModalProps {
  order: any;
  isOpen: boolean;
  onClose: () => void;
  orderType?: "draft" | "regular";
}

interface PdfResponse {
  success: boolean;
  message: string;
  data: {
    pdf: {
      filename: string;
      file_url: string;
      file_size: string;
    };
  };
}

export function OrderDetailsModal({
  order,
  isOpen,
  onClose,
  orderType = "regular",
}: OrderDetailsModalProps) {
  const [orderDetails, setOrderDetails] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isPrinting, setIsPrinting] = useState(false);
  const { toast } = useToast();
  console.log(orderDetails, "orderDetailsorderDetails");
  // Fetch order details when modal opens
  useEffect(() => {
    const fetchOrderDetails = async () => {
      if (!order || !isOpen) return;

      setIsLoading(true);
      try {
        let response;
        if (orderType === "draft") {
          response = await axiosInstance.get(`/draft-order/${order?.draft_id}`);
        } else {
          response = await axiosInstance.get(`/order/${order?.order_Id}`);
        }

        if (response.data.success) {
          setOrderDetails(response.data.data);
        }
      } catch (error) {
        console.error("Error fetching order details:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchOrderDetails();
  }, [order, isOpen, orderType]);

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setOrderDetails(null);
    }
  }, [isOpen]);

  const handlePrint = async () => {
    try {
      setIsPrinting(true);

      let endpoint;
      let orderId;

      if (orderType === "draft") {
        // Use draft order ID for draft orders
        orderId = order?.draft_id;
        endpoint = `/order/${orderId}/pdf`;
      } else {
        // Use order_Id for regular orders
        orderId = order?.order_Id;
        endpoint = `/order/${orderId}/pdf`;
      }

      // Check if we have a valid order ID
      if (!orderId) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Order ID is missing. Cannot generate PDF.",
        });
        return;
      }

      const response = await axiosInstance.get(endpoint);

      if (response.data.success) {
        const data: PdfResponse = response.data;

        if (data.data.pdf.file_url) {
          // Open the PDF in a new tab for printing/download
          window.open(data.data.pdf.file_url, "_blank");
          toast({
            title: "Success",
            description: "PDF generated successfully!",
          });
        } else {
          throw new Error("PDF URL not found in response");
        }
      } else {
        throw new Error(response.data.message || "Failed to generate PDF");
      }
    } catch (error: any) {
      console.error("Error generating PDF:", error);

      // Check for specific error types
      if (error.response?.status === 403) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to generate PDFs for orders.",
        });
      } else if (error.response?.status === 404) {
        toast({
          variant: "destructive",
          title: "Not Found",
          description: "Order not found or PDF generation service unavailable.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description:
            error.response?.data?.message ||
            "Failed to generate PDF. Please try again.",
        });
      }
    } finally {
      setIsPrinting(false);
    }
  };

  if (!order) return null;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Completed":
        return <CheckCircle className="h-4 w-4" />;
      case "Processing":
        return <Clock className="h-4 w-4" />;
      case "Pending":
        return <AlertCircle className="h-4 w-4" />;
      case "Cancelled":
        return <XCircle className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-green-600 hover:bg-green-700";
      case "Processing":
        return "bg-blue-600 hover:bg-blue-700";
      case "Pending":
        return "bg-yellow-600 hover:bg-yellow-700";
      case "Cancelled":
        return "bg-red-600 hover:bg-red-700";
      default:
        return "bg-gray-600 hover:bg-gray-700";
    }
  };

  const getInitials = (name: string) => {
    return name
      ?.split(" ")
      ?.map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  // Get products from order details or fallback to basic order data
  const getProducts = () => {
    if (orderDetails) {
      if (orderType === "draft") {
        return (
          orderDetails.items?.map((item: any) => ({
            product_name: item.product_name,
            variant_name: item.variant_name || item.name,
            quantity: Number(item?.quantity) || 0,
            price: Number(item?.price) || 0,
            sku: item.sku || "",
            image: item.image || null,
            variant_id: item.variant_id || null,
          })) || []
        );
      } else {
        return (
          orderDetails.line_items?.map((item: any) => ({
            product_name: item.title,
            variant_name: item.variant_title || "",
            quantity: Number(item.quantity) || 0,
            price: Number(item.price) || 0,
            sku: item.sku || "",
            image: item.image || null,
            variant_id: item.variant_id || null,
          })) || []
        );
      }
    }
    // fallback
    return order.products || [];
  };

  // Get total amount from order details or fallback to basic order data
  const getTotalAmount = () => {
    if (orderDetails) {
      if (orderType === "draft") {
        return parseFloat(orderDetails.total || "0");
      } else {
        return parseFloat(orderDetails.total_price || "0");
      }
    }
    return order.amount || 0;
  };

  // Get commission from order details or fallback to basic order data
  const getCommission = () => {
    if (orderDetails) {
      return parseFloat(orderDetails.commission || "0");
    }
    return order.commission || 0;
  };

  // Get order date from order details or fallback to basic order data
  const getOrderDate = () => {
    if (orderDetails) {
      return orderDetails.order_date;
    }
    return order.date;
  };

  // Get patient phone from order details
  const getPatientPhone = () => {
    if (orderDetails?.patient?.phone_number) {
      return orderDetails.patient.phone_number;
    }
    return "+1 (555) 123-4567"; // Fallback as in original
  };

  // Get patient address from order details
  const getPatientAddress = () => {
    if (orderDetails?.shipping_address) {
      const address = orderDetails.shipping_address;
      if (orderType === "draft") {
        return address.address || "123 Patient St, City, State";
      } else {
        return address.address1 || "123 Patient St, City, State";
      }
    }
    return "123 Patient St, City, State"; // Fallback as in original
  };

  // Get sub_total from order details - handle both draft and regular orders
  const getSubTotal = () => {
    if (orderDetails) {
      if (orderType === "draft") {
        // For draft orders, use sub_total key
        return parseFloat(orderDetails.sub_total || "0");
      } else {
        // For regular orders, use subtotal_price key
        return parseFloat(orderDetails.subtotal_price || "0");
      }
    }
    return 0;
  };

  // Get total_tax from order details
  const getTotalTax = () => {
    if (orderDetails) {
      if (orderType === "draft") {
        return parseFloat(orderDetails.total_tax || "0");
      } else {
        return parseFloat(orderDetails.total_tax || "0");
      }
    }
    return 0;
  };

  // Get shipping amount from order details
  const getShippingAmount = () => {
    if (orderDetails?.shipping_amount?.price) {
      return parseFloat(orderDetails.shipping_amount.price);
    }
    return null; // Return null if no shipping amount
  };

  // Get shipping title from order details
  const getShippingTitle = () => {
    if (orderDetails?.shipping_amount?.title) {
      return orderDetails.shipping_amount.title;
    }
    return "Shipping"; // Default title
  };

  // Get discount amount from order details
  const getDiscountAmount = () => {
    if (orderDetails?.discount_total) {
      return parseFloat(orderDetails.discount_total);
    }
    return null; // Return null if no discount
  };

  const products: any = getProducts();
  const totalAmount = getTotalAmount();
  const commission = getCommission();
  const orderDate = getOrderDate();
  const patientPhone = getPatientPhone();
  const patientAddress = getPatientAddress();
  const subTotal = getSubTotal();
  const totalTax = getTotalTax();
  const shippingAmount = getShippingAmount();
  const shippingTitle = getShippingTitle();
  const discountAmount = getDiscountAmount();
  console.log(products, "products12333");

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                {orderType === "draft" ? "Draft Order" : "Order"} Details -{" "}
                {order.id}
              </DialogTitle>
              <DialogDescription>
                Complete {orderType === "draft" ? "draft order" : "order"}{" "}
                information and details
              </DialogDescription>
            </div>
            <Badge
              variant="default"
              className={`flex items-center gap-1 ${getStatusColor(
                order.status
              )}`}
            >
              {getStatusIcon(order.status)}
              {order.status}
            </Badge>
          </div>
        </DialogHeader>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : (
          <div className="grid gap-6 py-4">
            {/* Order Summary */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Order Date</span>
                </div>
                <p className="text-sm text-muted-foreground ml-6">
                  {orderDate}
                </p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <DirhamIcon className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Total Amount</span>
                </div>
                <p className="text-sm font-medium ml-6">
                  <DirhamIcon />
                  {totalAmount.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Doctor Information */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <User className="h-5 w-5" />
                Doctor Information
              </h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback className="text-sm font-semibold bg-blue-600 text-white">
                      {getInitials(order.doctorName)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{order.doctorName}</p>
                    <p className="text-sm text-muted-foreground">
                      {order.doctorClinic}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Patient Information */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <User className="h-5 w-5" />
                Patient Information
              </h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="font-medium">{order.patientName}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <Mail className="h-3 w-3 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        {order.patientEmail}
                      </span>
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-1">
                      <Phone className="h-3 w-3 text-muted-foreground" />
                      <span className="text-sm">{patientPhone}</span>
                    </div>
                    <div className="flex items-center gap-1 mt-1">
                      <MapPin className="h-3 w-3 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        {patientAddress}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Products Information */}
            <div className="space-y-3">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Package className="h-5 w-5" />
                Products Ordered
              </h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="space-y-2">
                  {products?.map((product: any, index: any) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-2 bg-white rounded border"
                    >
                      <div className="flex items-center gap-2">
                        <Package className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">
                          {product?.product_name}
                        </span>
                        {product?.variant_name && (
                          <span className="text-sm text-muted-foreground">
                            ({product.variant_name})
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-4">
                        <span className="text-sm text-muted-foreground">
                          Qty: {product?.quantity}
                        </span>
                        <span className="text-sm font-medium">
                          <DirhamIcon />
                          {(product?.price * product?.quantity).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Order Summary Section */}
                <div className="mt-4 space-y-2 border-t pt-4">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Sub Total:</span>
                    <Badge variant="outline" className="text-sm">
                      <DirhamIcon />
                      {subTotal.toLocaleString()}
                    </Badge>
                  </div>

                  {/* Shipping Amount - Only show if not null */}
                  {shippingAmount !== null && shippingAmount > 0 && (
                    <div className="flex justify-between items-center">
                      <span className="font-medium flex items-center gap-1">
                        {shippingTitle}:
                      </span>
                      <Badge variant="outline" className="text-sm">
                        <DirhamIcon />
                        {shippingAmount.toLocaleString()}
                      </Badge>
                    </div>
                  )}

                  <div className="flex justify-between items-center">
                    <span className="font-medium">Total Tax:</span>
                    <Badge variant="outline" className="text-sm">
                      <DirhamIcon />
                      {totalTax.toLocaleString()}
                    </Badge>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t">
                    <span className="font-medium">Commission:</span>
                    <Badge variant="secondary" className="text-green-600">
                      <DirhamIcon />
                      {commission.toLocaleString()}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Timeline */}
            {orderType !== "draft" &&
              orderDetails?.events &&
              orderDetails.events.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <Clock className="h-5 w-5" />
                    Order Timeline
                  </h3>
                  {orderDetails?.events &&
                    orderDetails.events.length > 0 &&
                    orderDetails?.events?.map((event: any, index: any) => {
                      return (
                        <div className="space-y-2" key={index}>
                          <div className="flex items-center gap-3 p-2 bg-green-50 rounded">
                            <CheckCircle className="h-4 w-4 text-green-600" />
                            <div>
                              <p className="text-sm font-medium">
                                {event?.event_name}
                              </p>
                              <p className="text-xs text-muted-foreground">
                                {convertToDubaiDate(event?.shopify_created_at)}
                              </p>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              )}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          {orderType !== "draft" && (
            <Button
              onClick={handlePrint}
              disabled={isPrinting || isLoading}
              className="flex items-center gap-2"
            >
              <Printer className="h-4 w-4" />
              {isPrinting ? "Generating PDF..." : "Print Order"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
