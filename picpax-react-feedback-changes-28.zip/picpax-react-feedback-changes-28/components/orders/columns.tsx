"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { DirhamIcon } from "@/components/ui/DirhamIcon";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "./data-table-column-header";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  convertToDubaiDate,
  convertToDubaiTime,
} from "@/components/convertToDubaiTime";
import {
  MoreHorizontal,
  Eye,
  Package,
  DollarSign,
  User,
  Mail,
  Calendar,
  MapPin,
  CheckCircle,
  Trash2,
  Loader2,
} from "lucide-react";

export type Order = {
  id: string;
  doctorName: string;
  doctorClinic: string;
  patientName: string;
  patientEmail: string;
  amount: number;
  status: any;
  date: string;
  products: string[];
  commission: number;
  doctorId: string;
  patientId: string;
  products_count?: any;
  draft_id?: any;
  order_Id?: any;
};

// Add this interface for table meta
interface TableMeta {
  onViewOrderDetails?: (order: Order) => void;
  onCreateOrder?: (order: Order) => void;
  onDeleteDraftOrder?: (order: Order) => void;
  canViewDetails?: boolean;
  canCreateOrder?: boolean;
  canDeleteDraft?: boolean;
  isCreatingOrder?: boolean;
  isDeletingOrder?: boolean;
}

export const columns: ColumnDef<Order>[] = [
  {
    accessorKey: "id",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Order ID" />
    ),
    cell: ({ row }) => {
      const order = row.original;
      return (
        <div className="font-mono text-sm font-medium min-w-[100px]">
          {order.id}
        </div>
      );
    },
    enableSorting: true,
    enableHiding: true,
  },
  {
    accessorKey: "doctorName",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Doctor" />
    ),
    cell: ({ row }) => {
      const order = row.original;
      const getInitials = (name: string) => {
        if (!name) return "DR";
        return name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase();
      };

      return (
        <div className="flex items-center space-x-3 min-w-[200px]">
          <Avatar className="h-7 w-7 flex-shrink-0">
            <AvatarFallback className="text-xs font-semibold bg-blue-600 text-white">
              {getInitials(order.doctorName)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-sm truncate">
              {order.doctorName || "Unknown Doctor"}
            </div>
            <div className="text-xs text-muted-foreground truncate">
              {order.doctorClinic || "No Clinic"}
            </div>
          </div>
        </div>
      );
    },
    enableSorting: true,
    enableHiding: true,
  },
  {
    accessorKey: "patientName",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Patient" />
    ),
    cell: ({ row }) => {
      const order = row.original;
      return (
        <div className="min-w-[180px] space-y-1">
          <div className="flex items-center space-x-1 text-sm">
            <User className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="font-medium truncate">{order.patientName}</span>
          </div>
          <div className="flex items-center space-x-1 text-xs">
            <Mail className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span
              className="truncate text-muted-foreground"
              title={order.patientEmail}
            >
              {order.patientEmail}
            </span>
          </div>
        </div>
      );
    },
    enableSorting: true,
    enableHiding: true,
  },
  {
    accessorKey: "products",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Products" />
    ),
    cell: ({ row }) => {
      const order = row.original;
      const products = order.products || [];
      return (
        <div className="min-w-[150px]">
          <div className="flex items-center space-x-1 mb-1">
            <Package className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="text-xs text-muted-foreground">
              {order?.products_count} item
              {order?.products_count !== 1 ? "s" : ""}
            </span>
          </div>
          <div className="text-sm">
            {products.slice(0, 2).join(", ")}
            {products.length > 2 && (
              <span className="text-xs text-muted-foreground">
                +{products.length - 2} more
              </span>
            )}
          </div>
        </div>
      );
    },
    enableSorting: false,
    enableHiding: true,
  },
  {
    accessorKey: "amount",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Amount" />
    ),
    cell: ({ row }) => {
      const amount = parseFloat(row.getValue("amount") || "0");
      return (
        <div className="text-right min-w-[80px]">
          <div className="font-medium text-sm">
            <DirhamIcon className="inline-block mr-1" />
            {amount.toLocaleString()}
          </div>
        </div>
      );
    },
    enableSorting: true,
    enableHiding: true,
  },
  {
    accessorKey: "commission",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Commission" />
    ),
    cell: ({ row }) => {
      const commission = parseFloat(row.getValue("commission") || "0");
      return (
        <div className="text-right min-w-[90px]">
          <div className="font-medium text-green-600 text-sm">
            <DirhamIcon className="inline-block mr-1" />
            {commission.toLocaleString()}
          </div>
        </div>
      );
    },
    enableSorting: true,
    enableHiding: true,
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      const getStatusColor = (status: string) => {
        switch (status) {
          case "Completed":
            return "bg-green-600 hover:bg-green-700";
          case "Processing":
            return "bg-blue-600 hover:bg-blue-700";
          case "Open":
            return "bg-blue-600 hover:bg-blue-700";
          case "Draft":
            return "bg-yellow-600 hover:bg-yellow-700";
          case "Pending":
            return "bg-yellow-600 hover:bg-yellow-700";
          case "Cancelled":
            return "bg-red-600 hover:bg-red-700";
          default:
            return "bg-gray-600 hover:bg-gray-700";
        }
      };

      return (
        <div className="min-w-[100px]">
          <Badge
            variant="default"
            className={`text-xs ${getStatusColor(status)}`}
          >
            {status}
          </Badge>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
    enableSorting: true,
    enableHiding: true,
  },
  {
    accessorKey: "date",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Date" />
    ),
    cell: ({ row }) => {
      const date = row.getValue("date") as string;
      return (
        <div className="flex items-center space-x-1 text-sm min-w-[90px]">
          <Calendar className="h-3 w-3 text-muted-foreground flex-shrink-0" />
          <span>{convertToDubaiDate(date)}</span>
        </div>
      );
    },
    enableSorting: true,
    enableHiding: true,
  },
  {
    id: "actions",
    cell: ({ row, table }) => {
      const order = row.original;
      // Safely access the meta property
      const meta = table.options.meta as TableMeta | undefined;
      const onViewOrderDetails = meta?.onViewOrderDetails;
      const onCreateOrder = meta?.onCreateOrder;
      const onDeleteDraftOrder = meta?.onDeleteDraftOrder;
      const canViewDetails = meta?.canViewDetails;
      const canCreateOrder = meta?.canCreateOrder;
      const canDeleteDraft = meta?.canDeleteDraft;
      const isCreatingOrder = meta?.isCreatingOrder;
      const isDeletingOrder = meta?.isDeletingOrder;

      return (
        <div className="min-w-[40px]">
          {(canViewDetails || canCreateOrder || canDeleteDraft) && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="h-7 w-7 p-0">
                  <span className="sr-only">Open menu</span>
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[160px]">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>

                {/* View Details Action */}
                {canViewDetails && (
                  <DropdownMenuItem
                    onClick={() => onViewOrderDetails?.(order)}
                    disabled={!onViewOrderDetails}
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    View Details
                  </DropdownMenuItem>
                )}

                {/* Create Order Action */}
                {canCreateOrder && (
                  <DropdownMenuItem
                    onClick={() => onCreateOrder?.(order)}
                    disabled={!onCreateOrder || isCreatingOrder}
                    className="text-green-600"
                  >
                    {isCreatingOrder ? (
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    ) : (
                      <CheckCircle className="mr-2 h-4 w-4" />
                    )}
                    {isCreatingOrder ? "Creating..." : "Create Order"}
                  </DropdownMenuItem>
                )}

                {/* Delete Draft Action */}
                {canDeleteDraft && (
                  <>
                    {(canViewDetails || canCreateOrder) && (
                      <DropdownMenuSeparator />
                    )}
                    <DropdownMenuItem
                      onClick={() => onDeleteDraftOrder?.(order)}
                      disabled={!onDeleteDraftOrder || isDeletingOrder}
                      className="text-red-600"
                    >
                      {isDeletingOrder ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="mr-2 h-4 w-4" />
                      )}
                      {isDeletingOrder ? "Deleting..." : "Delete Draft"}
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      );
    },
    enableHiding: false,
    enableSorting: false,
  },
];
