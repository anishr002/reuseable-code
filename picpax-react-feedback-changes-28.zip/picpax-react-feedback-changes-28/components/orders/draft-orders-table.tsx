"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ExportButton } from "@/components/ui/export-button"
import { Edit, Trash2, Send, Eye, Download } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface DraftOrder {
  id: string
  firstname: string
  lastname: string
  email: string
  phone: string
  u_id: string // user/doctor ID
  coupon?: string
  admin?: string
  items: string
  tags?: string
  billing_address?: string
  shipping_address?: string
  noteattributes?: string
  notes?: string
  status: 0 | 1 // 0=pending, 1=confirmed
  created_at: string
}

interface DraftOrdersTableProps {
  draftOrders: DraftOrder[]
}

export function DraftOrdersTable({ draftOrders }: DraftOrdersTableProps) {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState<string | null>(null)

  const handleSendOrder = async (draftId: string) => {
    setIsLoading(draftId)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    toast({
      variant: "success",
      title: "Draft Order Sent",
      description: "The draft order has been sent to the patient successfully.",
    })

    setIsLoading(null)
  }

  const handleDeleteDraft = async (draftId: string) => {
    setIsLoading(draftId)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 500))

    toast({
      variant: "default",
      title: "Draft Deleted",
      description: "The draft order has been deleted.",
    })

    setIsLoading(null)
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Draft Orders</CardTitle>
            <CardDescription>Manage your pending and unfinished orders</CardDescription>
          </div>
          <ExportButton 
            data={draftOrders} 
            filename="draft_orders_report" 
            title="Export"
          />
        </div>
      </CardHeader>
      <CardContent>
        {draftOrders.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Edit className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <p>No draft orders found</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Patient</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {draftOrders.map((draft) => (
                <TableRow key={draft.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">
                        {draft.firstname} {draft.lastname}
                      </div>
                      <div className="text-sm text-muted-foreground">ID: {draft.id}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="text-sm">{draft.email}</div>
                      <div className="text-sm text-muted-foreground">{draft.phone}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{draft.items}</div>
                  </TableCell>
                  <TableCell>
                    <Badge variant={draft.status === 1 ? "default" : "secondary"}>
                      {draft.status === 1 ? "Confirmed" : "Pending"}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{draft.created_at}</div>
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm" disabled={isLoading === draft.id}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" disabled={isLoading === draft.id}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSendOrder(draft.id)}
                        disabled={isLoading === draft.id}
                        className="text-green-600 hover:text-green-700"
                      >
                        <Send className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteDraft(draft.id)}
                        disabled={isLoading === draft.id}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  )
}
