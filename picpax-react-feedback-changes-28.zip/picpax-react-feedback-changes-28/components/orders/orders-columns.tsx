"use client"

import type { ColumnDef } from "@tanstack/react-table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowUpDown, Eye, FileText, Package, MoreHorizontal } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import Link from "next/link"

export type Order = {
  id: string
  order_id: string
  patientName: string
  patientId: string
  orderedBy: string
  orderedById: string
  products: Array<{ name: string; quantity: number; price: number }>
  total: number
  commission: number
  status: string
  createdAt: string
  shopifyOrderId: string | null
}

interface OrdersColumnsProps {
  onViewOrder: (order: Order) => void
}

export const createOrdersColumns = ({ onViewOrder }: OrdersColumnsProps): ColumnDef<Order>[] => [
  {
    accessorKey: "order_id",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Order ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const order = row.original
      return (
        <div className="space-y-1">
          <div className="font-medium">{order.order_id || "N/A"}</div>
          <div className="text-xs text-muted-foreground">Internal: {order.id || "N/A"}</div>
          {order.shopifyOrderId && <div className="text-xs text-muted-foreground">Shopify: {order.shopifyOrderId}</div>}
        </div>
      )
    },
  },
  {
    accessorKey: "patientName",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Patient
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const order = row.original
      return (
        <Link href={`/patients/${order.patientId || ""}`} className="hover:underline font-medium">
          {order.patientName || "Unknown Patient"}
        </Link>
      )
    },
  },
  {
    accessorKey: "orderedBy",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Ordered By
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const order = row.original
      const orderedById = order.orderedById || ""
      const isDoctor = orderedById.startsWith("doc_")
      return (
        <div className="space-y-1">
          <div className="font-medium">{order.orderedBy || "Unknown"}</div>
          <Badge variant={isDoctor ? "default" : "secondary"} className="text-xs">
            {isDoctor ? "Doctor" : "Staff"}
          </Badge>
        </div>
      )
    },
  },
  {
    accessorKey: "products",
    header: "Products",
    cell: ({ row }) => {
      const order = row.original
      const products = order.products || []
      return (
        <div className="space-y-1">
          {products.length > 0 ? (
            products.slice(0, 2).map((product, index) => (
              <div key={index} className="text-sm">
                {product.name || "Unknown Product"} × {product.quantity || 0}
              </div>
            ))
          ) : (
            <div className="text-sm text-muted-foreground">No products</div>
          )}
          {products.length > 2 && <div className="text-xs text-muted-foreground">+{products.length - 2} more</div>}
        </div>
      )
    },
  },
  {
    accessorKey: "total",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Total
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const amount = Number.parseFloat(row.getValue("total")) || 0
      return <div className="font-medium">${amount.toFixed(2)}</div>
    },
  },
  {
    accessorKey: "commission",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Commission
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const amount = Number.parseFloat(row.getValue("commission")) || 0
      return <div className="font-bold text-green-600">${amount.toFixed(2)}</div>
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Status
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const status = (row.getValue("status") as string) || "Unknown"
      const getStatusColor = (status: string) => {
        switch (status) {
          case "Completed":
            return "bg-primary hover:bg-primary/90"
          case "Processing":
            return "bg-blue-500 hover:bg-blue-500/90"
          case "Draft":
            return "bg-gray-500 hover:bg-gray-500/90"
          default:
            return "bg-gray-400 hover:bg-gray-400/90"
        }
      }
      return <Badge className={getStatusColor(status)}>{status}</Badge>
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: "createdAt",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Date
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      return <div className="text-sm">{row.getValue("createdAt") || "N/A"}</div>
    },
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const order = row.original

      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onViewOrder(order)}>
              <Eye className="mr-2 h-4 w-4" />
              View Details
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href={`/patients/${order.patientId || ""}`}>
                <FileText className="mr-2 h-4 w-4" />
                View Patient
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href={`/orders/create?patientId=${order.patientId || ""}`}>
                <Package className="mr-2 h-4 w-4" />
                Reorder
              </Link>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      )
    },
  },
]

// Default export for backward compatibility
export const ordersColumns: ColumnDef<Order>[] = createOrdersColumns({
  onViewOrder: () => {},
})
