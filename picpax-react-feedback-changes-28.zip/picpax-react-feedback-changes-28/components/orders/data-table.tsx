"use client";

import * as React from "react";
import {
  type ColumnDef,
  type ColumnFiltersState,
  type SortingState,
  type VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DataTablePagination } from "./data-table-pagination";
import { DataTableViewOptions } from "./data-table-view-options";
import { DataTableFacetedFilter } from "./data-table-faceted-filter";
import { ExportButton } from "@/components/ui/export-button";
import { Search, X, FileText, Package } from "lucide-react";

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  onViewOrderDetails?: (order: TData) => void;
  onSearch?: (search: string) => void;
  search?: string;
  onPaginationChange?: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  onSort?: (sort_by: string, sort_order: string) => void;
  pagination?: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  };
  isLoading?: boolean;
  entity?: any;
  canExport?: any;
  canViewDetails?: any;
  canCreateOrder?: any;
  onCreateOrder?: any;
  onDeleteDraftOrder?: (order: TData) => void; // Add this
  canDeleteDraft?: any;
}

export function DataTable<TData, TValue>({
  columns,
  data,
  onViewOrderDetails,
  onSearch,
  search,
  onPaginationChange,
  onPageSizeChange,
  onSort,
  pagination,
  isLoading = false,
  canExport,
  entity,
  canViewDetails,
  onCreateOrder,
  canCreateOrder,
  onDeleteDraftOrder,
  canDeleteDraft,
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = React.useState<SortingState>([]);
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    []
  );
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({});
  const [rowSelection, setRowSelection] = React.useState({});
  const [searchValue, setSearchValue] = React.useState("");

  // Use refs to track if we're currently handling search/sort to prevent loops
  const isHandlingSearch = React.useRef(false);
  const isHandlingSort = React.useRef(false);
  // Track previous sorting to avoid calling onSort when nothing meaningful changed
  const prevSortingRef = React.useRef<SortingState>(sorting);

  const areSortingsEqual = (a: SortingState, b: SortingState) => {
    try {
      return JSON.stringify(a) === JSON.stringify(b);
    } catch (e) {
      return false;
    }
  };

  const table = useReactTable({
    data,
    columns,
    manualPagination: true,
    manualSorting: true,
    manualFiltering: true,
    onSortingChange: (updater) => {
      const newSorting =
        typeof updater === "function" ? updater(sorting) : updater;
      setSorting(newSorting);
      // Debug logging: show incoming vs previous sorting
      // (remove or toggle this later)
      // eslint-disable-next-line no-console
      console.log("DataTable:onSortingChange", {
        newSorting,
        prevSorting: prevSortingRef.current,
      });

      // Handle sort immediately without useEffect, but only when it actually changed
      if (!onSort || isHandlingSort.current) {
        // update prevSortingRef so future changes compare against latest
        prevSortingRef.current = newSorting;
        // eslint-disable-next-line no-console
        console.log(
          "DataTable:onSortingChange - skipping onSort because no onSort or already handling sort"
        );
        return;
      }

      // If the sorting didn't change meaningfully, skip calling onSort to avoid loops
      if (areSortingsEqual(newSorting, prevSortingRef.current)) {
        // eslint-disable-next-line no-console
        console.log(
          "DataTable:onSortingChange - sorting equal to previous, skipping onSort"
        );
        return;
      }

      isHandlingSort.current = true;
      if (newSorting.length > 0) {
        const sort = newSorting[0];
        // eslint-disable-next-line no-console
        console.log("DataTable:onSortingChange - calling onSort", {
          id: sort.id,
          order: sort.desc ? "desc" : "asc",
        });
        onSort(sort.id, sort.desc ? "desc" : "asc");
      } else {
        // Handle reset to default sort
        // eslint-disable-next-line no-console
        console.log(
          "DataTable:onSortingChange - calling onSort reset to updated_at desc"
        );
        onSort("updated_at", "desc");
      }

      // store the sorting we just triggered to avoid duplicate calls
      prevSortingRef.current = newSorting;

      // Reset the flag after a short delay
      setTimeout(() => {
        isHandlingSort.current = false;
      }, 100);
    },
    onColumnFiltersChange: setColumnFilters,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    // Keep pagination state in sync with parent-controlled `pagination` prop
    // so UI elements like the Rows per page select show the correct value.
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
      pagination: {
        pageIndex: Math.max(0, (pagination?.current_page || 1) - 1),
        pageSize: pagination?.per_page || 10,
      },
    },
    meta: {
      onViewOrderDetails,
      onCreateOrder,
      canViewDetails,
      canCreateOrder,
      onDeleteDraftOrder, // Add this
      canDeleteDraft,
    },
    pageCount: pagination?.last_page || 1,
  });

  // Handle search with debounce - but only trigger if value actually changed
  // Track previous search to avoid calling onSearch on mount or when props re-render
  const prevSearchRef = React.useRef(searchValue);
  const mountedRef = React.useRef(false);
  // When parent controls search, sync it without invoking onSearch again
  const skipNextSyncRef = React.useRef(false);
  // Track last search value we told parent about to avoid duplicates
  const lastSearchCalledRef = React.useRef<string | null>(null);

  React.useEffect(() => {
    if (typeof search === "undefined") return;
    // If parent updates search (e.g., clearing when switching views), sync local input
    // but avoid triggering the onSearch effect because parent already ran fetchOrders
    if (search !== searchValue) {
      skipNextSyncRef.current = true;
      setSearchValue(search);
      prevSearchRef.current = search;
      // Parent already initiated the search for this value
      lastSearchCalledRef.current = search;
    }
  }, [search]);

  React.useEffect(() => {
    // Ignore the initial mount (React StrictMode double-invoke can cause duplicates)
    if (!mountedRef.current) {
      mountedRef.current = true;
      prevSearchRef.current = searchValue;
      return;
    }

    // Only trigger when the search value actually changes
    if (prevSearchRef.current === searchValue) return;

    // If this change was caused by parent syncing the prop, skip calling onSearch
    if (skipNextSyncRef.current) {
      skipNextSyncRef.current = false;
      prevSearchRef.current = searchValue;
      return;
    }

    // If search is empty and previously had a value, trigger parent search to clear filters
    if (searchValue === "") {
      if (
        prevSearchRef.current !== "" &&
        onSearch &&
        !isHandlingSearch.current &&
        lastSearchCalledRef.current !== ""
      ) {
        const timeoutId = setTimeout(() => {
          isHandlingSearch.current = true;
          // Avoid duplicate identical calls
          if (lastSearchCalledRef.current !== "") {
            onSearch("");
            lastSearchCalledRef.current = "";
          }
          setTimeout(() => {
            isHandlingSearch.current = false;
          }, 100);
        }, 300);
        prevSearchRef.current = searchValue;
        return () => clearTimeout(timeoutId);
      }
      prevSearchRef.current = searchValue;
      return;
    }

    // If there's no onSearch handler, do nothing
    if (!onSearch) {
      prevSearchRef.current = searchValue;
      return;
    }
    const timeoutId = setTimeout(() => {
      if (!isHandlingSearch.current) {
        isHandlingSearch.current = true;
        // Avoid duplicate identical calls
        if (lastSearchCalledRef.current !== searchValue) {
          onSearch(searchValue);
          lastSearchCalledRef.current = searchValue;
        }
        setTimeout(() => {
          isHandlingSearch.current = false;
        }, 100);
      }
    }, 500);

    // update previous search immediately so subsequent renders won't re-trigger
    prevSearchRef.current = searchValue;

    return () => clearTimeout(timeoutId);
  }, [searchValue, onSearch]);

  const isFiltered = table.getState().columnFilters.length > 0;

  const statusOptions = [
    {
      label: "Completed",
      value: "Completed",
      icon: FileText,
    },
    {
      label: "Processing",
      value: "Processing",
      icon: Package,
    },
    {
      label: "Pending",
      value: "Pending",
      icon: FileText,
    },
    {
      label: "Cancelled",
      value: "Cancelled",
      icon: FileText,
    },
  ];

  // Handle search input change
  const handleSearchChange = (value: string) => {
    setSearchValue(value);
  };

  // Keep table pagination state in sync with parent `pagination` prop.
  // Parent may change `per_page` or `current_page` (for example when user
  // selects a new rows-per-page value). Ensure the table's internal state
  // reflects that so the UI (Rows per page select and current page index)
  // shows the correct values.
  React.useEffect(() => {
    if (!pagination) return;

    const desiredPageSize =
      pagination.per_page || table.getState().pagination.pageSize;
    if (table.getState().pagination.pageSize !== desiredPageSize) {
      table.setPageSize(desiredPageSize);
    }

    const desiredPageIndex = Math.max(0, (pagination.current_page || 1) - 1);
    if (table.getState().pagination.pageIndex !== desiredPageIndex) {
      table.setPageIndex(desiredPageIndex);
    }
    // only respond to changes in the pagination prop
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pagination?.per_page, pagination?.current_page]);

  // Handle filter reset
  const handleResetFilters = () => {
    table.resetColumnFilters();
    setSearchValue("");
    if (onSearch) {
      // Only call onSearch if previous search wasn't already empty
      if (prevSearchRef.current !== "") {
        isHandlingSearch.current = true;
        onSearch("");
        prevSearchRef.current = "";
        setTimeout(() => {
          isHandlingSearch.current = false;
        }, 100);
      }
    }
  };

  return (
    <div className="w-full">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4">
        <div className="flex flex-col sm:flex-row flex-1 items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
          <div className="relative w-full sm:w-auto">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search orders by ID, doctor, patient..."
              value={searchValue}
              onChange={(event) => handleSearchChange(event.target.value)}
              className="h-8 w-full sm:w-[200px] lg:w-[250px] pl-8"
            />
          </div>
          <div className="flex items-center space-x-2 w-full sm:w-auto">
            {/* {table.getColumn("status") && (
              <DataTableFacetedFilter
                column={table.getColumn("status")}
                title="Status"
                options={statusOptions}
              />
            )} */}
            {(isFiltered || searchValue) && (
              <Button
                variant="ghost"
                onClick={handleResetFilters}
                className="h-8 px-2 lg:px-3"
              >
                Reset
                <X className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          {canExport && (
            <ExportButton
              // For client-side export (existing data)
              data={data}
              filename="orders_report"
              title="Export"
              // For API export (new)
              useApiExport={true}
              entity={entity}
              // Pass search and sort parameters for API export
              search={searchValue}
              sort_by={sorting.length > 0 ? sorting[0].id : "updated_at"}
              sort_order={
                sorting.length > 0 ? (sorting[0].desc ? "desc" : "asc") : "desc"
              }
            />
          )}
          <DataTableViewOptions table={table} />
        </div>
      </div>
      <div className="border rounded-md mx-4 mb-4">
        <div className="w-full overflow-auto">
          <Table className="w-full">
            <TableHeader>
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    return (
                      <TableHead
                        key={header.id}
                        className="px-2 py-3 text-xs font-medium"
                      >
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </TableHead>
                    );
                  })}
                </TableRow>
              ))}
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="h-24 text-center"
                  >
                    <div className="flex justify-center items-center">
                      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
                    </div>
                  </TableCell>
                </TableRow>
              ) : table.getRowModel().rows?.length ? (
                table.getRowModel().rows.map((row) => (
                  <TableRow
                    key={row.id}
                    data-state={row.getIsSelected() && "selected"}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <TableCell key={cell.id} className="px-2 py-3">
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="h-24 text-center"
                  >
                    No results found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
      <div className="px-4">
        <DataTablePagination
          table={table}
          pagination={pagination}
          onPaginationChange={onPaginationChange}
          onPageSizeChange={onPageSizeChange}
        />
      </div>
    </div>
  );
}
