"use client";

import * as React from "react";
import { Check, ChevronsUpDown, User } from "lucide-react";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";

interface Patient {
  id: string;
  name: string;
  email: string;
  phone: string;
  age: number;
  gender: string;
  lastVisit: string;
  totalOrders: number;
  status: "Active" | "Inactive";
}

interface PatientComboboxProps {
  patients: Patient[];
  value: string;
  onValueChange: (value: string) => void;
  placeholder?: string;
}

export function PatientCombobox({
  patients,
  value,
  onValueChange,
  placeholder = "Select patient...",
}: PatientComboboxProps) {
  const [open, setOpen] = React.useState(false);

  const selectedPatient = patients.find((patient) => patient.id === value);

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between h-auto min-h-[40px] bg-transparent"
        >
          {selectedPatient ? (
            <div className="flex items-center space-x-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-semibold">
                {getInitials(selectedPatient.name)}
              </div>
              <div className="text-left">
                <div className="font-medium">{selectedPatient.name}</div>
                <div className="text-xs text-muted-foreground">
                  {selectedPatient.email}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-2 text-muted-foreground">
              <User className="h-4 w-4" />
              <span>{placeholder}</span>
            </div>
          )}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0" align="start">
        <Command>
          <CommandInput placeholder="Search..." className="h-9" />
          <CommandList>
            <CommandEmpty>No patients found.</CommandEmpty>
            <CommandGroup>
              {patients.map((patient) => (
                <CommandItem
                  key={patient.id}
                  value={`${patient.name} ${patient.email} ${patient.id}`}
                  onSelect={() => {
                    onValueChange(patient.id === value ? "" : patient.id);
                    setOpen(false);
                  }}
                  className="flex items-center space-x-3 p-3"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground text-sm font-semibold">
                    {getInitials(patient.name)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{patient.name}</span>
                      <Badge
                        variant={
                          patient.status === "Active" ? "default" : "secondary"
                        }
                        className={`text-xs ${
                          patient.status === "Active"
                            ? "bg-primary hover:bg-primary/90"
                            : ""
                        }`}
                      >
                        {patient.status}
                      </Badge>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {patient.email}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {patient.age} years • {patient.gender} •{" "}
                      {patient.totalOrders} orders
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Last visit: {patient.lastVisit}
                    </div>
                  </div>
                  <Check
                    className={cn(
                      "ml-auto h-4 w-4",
                      value === patient.id ? "opacity-100" : "opacity-0"
                    )}
                  />
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
