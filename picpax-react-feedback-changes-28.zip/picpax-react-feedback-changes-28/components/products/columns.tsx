"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "./data-table-column-header";
import {
  MoreHorizontal,
  Eye,
  RefreshCw,
  ExternalLink,
  Image as ImageIcon,
  Info, // Add this import
} from "lucide-react";
import { DirhamIcon } from "../ui/DirhamIcon";

export type Product = {
  id: string;
  shopifyId: string;
  title: string;
  description: string;
  vendor: string;
  productType: string;
  tags: string[];
  status: "active" | "draft" | "archived";
  inventory: {
    available: number;
    locations: Array<{
      name: string;
      available: number;
    }>;
  };
  pricing: {
    price: number;
    compareAtPrice: number | null;
    cost: number;
    currency: string;
  };
  variants: Array<{
    id: string;
    title: string;
    sku: string;
    price: number;
    inventory: number;
  }>;
  images: Array<{
    id: string;
    src: string;
    alt: string;
  }>;
  createdAt: string;
  updatedAt: string;
  shopifySync: {
    lastSync: string | null;
    syncStatus: "synced" | "syncing" | "not synced" | "error";
    shopifyUrl: string | null;
  };
};

export const columns: ColumnDef<Product>[] = [
  {
    accessorKey: "title",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Product" />
    ),
    cell: ({ row }) => {
      const product = row.original;
      return (
        <div className="flex items-center space-x-3 min-w-[250px]">
          <div className="w-10 h-10 bg-gray-100 rounded flex items-center justify-center flex-shrink-0 overflow-hidden border">
            {product.images &&
            product.images.length > 0 &&
            product.images[0].src ? (
              <img
                src={product.images[0].src}
                alt={product.images[0].alt ?? product.title}
                className="w-10 h-10 object-cover"
                onError={(e) => {
                  // Fallback if image fails to load
                  const target = e.target as HTMLImageElement;
                  target.style.display = "none";
                }}
              />
            ) : (
              <ImageIcon className="h-5 w-5 text-gray-400" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-sm truncate">{product.title}</div>
            <div className="text-xs text-muted-foreground truncate">
              {product.vendor} • {product.variants.length} variant
              {product.variants.length !== 1 ? "s" : ""}
            </div>
          </div>
        </div>
      );
    },
    enableSorting: true,
    enableHiding: false,
  },
  {
    accessorKey: "sku",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="SKU" />
    ),
    cell: ({ row }) => {
      const product = row.original;
      const primarySku = product.variants[0]?.sku;
      return (
        <div className="font-mono text-sm min-w-[120px]">
          {primarySku || "N/A"}
        </div>
      );
    },
    enableSorting: false,
  },
  {
    accessorKey: "productType",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Type" />
    ),
    cell: ({ row }) => {
      const productType = row.getValue("productType") as string;
      return (
        <div className="min-w-[120px]">
          {productType ? (
            <Badge variant="outline" className="text-xs">
              {productType}
            </Badge>
          ) : (
            ""
          )}
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
    enableSorting: true,
  },
  {
    accessorKey: "price",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Price" />
    ),
    cell: ({ row }) => {
      const product = row.original;
      const price = product.pricing.price;

      console.log(
        "Price in column:",
        price,
        "for product:",
        product.title,
        "Full product:",
        product
      ); // Debug log

      return (
        <div className="min-w-[100px]">
          <div className="font-medium text-sm">
            <DirhamIcon className="h-[13px] w-4 text-muted-foreground" />{" "}
            {typeof price === "number" ? price.toFixed(2) : "0.00"}
          </div>
        </div>
      );
    },
    enableSorting: true,
  },
  {
    accessorKey: "inventory",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Inventory" />
    ),
    cell: ({ row }) => {
      const product = row.original;
      const available = product.inventory.available;
      const locationsCount = product.inventory.locations.length;

      // Color code based on inventory level
      const getInventoryColor = (quantity: number) => {
        if (quantity === 0) return "text-red-600";
        if (quantity < 10) return "text-orange-600";
        return "text-green-600";
      };

      return (
        <div className="min-w-[100px]">
          <div
            className={`font-medium text-sm ${getInventoryColor(available)}`}
          >
            {available.toLocaleString()}
          </div>
          <div className="text-xs text-muted-foreground">
            {locationsCount} location
            {locationsCount !== 1 ? "s" : ""}
          </div>
        </div>
      );
    },
    enableSorting: true,
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      const getStatusVariant = (status: string) => {
        switch (status) {
          case "active":
            return "default";
          case "draft":
            return "secondary";
          case "archived":
            return "outline";
          default:
            return "outline";
        }
      };

      const getStatusColor = (status: string) => {
        switch (status) {
          case "active":
            return "bg-green-100 text-green-800 border-green-200";
          case "draft":
            return "bg-yellow-100 text-yellow-800 border-yellow-200";
          case "archived":
            return "bg-gray-100 text-gray-800 border-gray-200";
          default:
            return "bg-gray-100 text-gray-800 border-gray-200";
        }
      };

      return (
        <div className="min-w-[100px]">
          <Badge
            variant={getStatusVariant(status)}
            className={`text-xs ${getStatusColor(status)}`}
          >
            {status.charAt(0).toUpperCase() + status.slice(1)}
          </Badge>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
    enableSorting: true,
  },
  {
    accessorKey: "syncStatus",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Shopify Sync" />
    ),
    cell: ({ row }) => {
      const product = row.original;
      const syncStatus = product.shopifySync.syncStatus;

      const getSyncVariant = (syncStatus: string) => {
        const variants = {
          synced: "default" as const,
          syncing: "secondary" as const,
          not_synced: "destructive" as const,
          error: "destructive" as const,
        };
        return variants[syncStatus as keyof typeof variants] || "outline";
      };

      const getSyncDisplay = (syncStatus: string) => {
        const display = {
          synced: "Synced",
          syncing: "Syncing",
          not_synced: "Not Synced",
          error: "Error",
        };
        return display[syncStatus as keyof typeof display] || syncStatus;
      };

      return (
        <div className="flex items-center gap-2 min-w-[120px]">
          <Badge variant={getSyncVariant(syncStatus)} className="text-xs">
            {getSyncDisplay(syncStatus)}
          </Badge>
          {/* {product.shopifySync.shopifyUrl && (
            <a
              href={product.shopifySync.shopifyUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 transition-colors"
              onClick={(e) => e.stopPropagation()}
            >
              <ExternalLink className="h-3 w-3" />
            </a>
          )} */}
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
    enableSorting: true,
  },
  {
    id: "actions",
    cell: ({ row, table }) => {
      const product = row.original;
      const meta = table.options.meta as {
        onViewProductDetails?: (product: Product) => void;
        onSyncProduct?: (product: Product) => void;
        onProductInfo?: (product: Product) => void; // Add this

        canRead?: boolean;
        canUpdate?: boolean;
      };

      const {
        onViewProductDetails,
        onSyncProduct,
        onProductInfo,
        canRead,
        canUpdate,
      } = meta;

      // Only show actions if user has at least one permission
      const hasAnyPermission = canRead || canUpdate;

      if (!hasAnyPermission) {
        return null;
      }

      return (
        <div className="min-w-[40px] text-right">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="h-7 w-7 p-0"
                onClick={(e) => e.stopPropagation()}
              >
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[160px]">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>

              {/* View Details - only show if user has read permission */}
              {canRead && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onViewProductDetails?.(product);
                  }}
                  className="cursor-pointer"
                >
                  <Eye className="mr-2 h-4 w-4" />
                  View Details
                </DropdownMenuItem>
              )}

              {/* Product Info - only show if user has update permission */}
              {canUpdate && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onProductInfo?.(product);
                  }}
                  className="cursor-pointer"
                >
                  <Info className="mr-2 h-4 w-4" />
                  Product Info
                </DropdownMenuItem>
              )}

              {/* Sync Product - only show if user has update permission */}
              {canUpdate && (
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation();
                    onSyncProduct?.(product);
                  }}
                  className="cursor-pointer"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Sync Product
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      );
    },
    enableSorting: false,
    enableHiding: false,
  },
];
