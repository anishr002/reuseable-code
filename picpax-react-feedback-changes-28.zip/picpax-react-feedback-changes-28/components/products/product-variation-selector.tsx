"use client";

import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar, Clock } from "lucide-react";
import { DirhamIcon } from "../ui/DirhamIcon";
// import { DirhamIcon } from "@/components/ui/icons"; // Make sure to import the Dirham icon

export interface ProductVariation {
  id: string;
  name: string;
  duration: number;
  price: number;
  inStock: boolean;
  // basePrice is optional since API data doesn't have it
  basePrice?: number;
}

// Updated Product interface to match API structure
export interface Product {
  id: string;
  name: string;
  variations: ProductVariation[];
}

interface ProductVariationSelectorProps {
  product: Product;
  selectedVariation?: ProductVariation;
  onVariationSelect: (variation: ProductVariation) => void;
  compact?: boolean;
}

export function ProductVariationSelector({
  product,
  selectedVariation,
  onVariationSelect,
  compact = false,
}: ProductVariationSelectorProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  if (!product.variations || product.variations.length === 0) {
    return null;
  }

  const handleVariationSelect = (variationId: string) => {
    const variation = product.variations.find((v) => v.id === variationId);
    if (variation) {
      onVariationSelect(variation);
    }
  };

  // Calculate savings if basePrice is available
  const calculateSavings = (variation: ProductVariation) => {
    if (variation.basePrice && variation.basePrice > variation.price) {
      return variation.basePrice - variation.price;
    }
    return 0;
  };

  if (compact) {
    return (
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium flex items-center space-x-1">
            <Clock className="h-3 w-3" />
            <span>Variant:</span>
          </label>
          <Select
            value={selectedVariation?.id || ""}
            onValueChange={handleVariationSelect}
          >
            <SelectTrigger className="w-32 h-8 text-xs">
              <SelectValue placeholder="Select" />
            </SelectTrigger>
            <SelectContent>
              {product.variations.map((variation) => {
                const savings = calculateSavings(variation);
                const hasDiscount = savings > 0;

                return (
                  <SelectItem
                    key={variation.id}
                    value={variation.id}
                    disabled={!variation.inStock}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span>{variation.name}</span>
                      {hasDiscount && (
                        <Badge variant="secondary" className="text-xs ml-2">
                          Save <DirhamIcon className="h-3 w-3 inline ml-1" />
                          {savings.toFixed(2)}
                        </Badge>
                      )}
                      {!variation.inStock && (
                        <Badge variant="destructive" className="text-xs ml-2">
                          Out of stock
                        </Badge>
                      )}
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>
        {selectedVariation && (
          <div className="text-xs text-muted-foreground flex items-center">
            <DirhamIcon className="h-3 w-3 mr-1" />
            {selectedVariation.price.toFixed(2)} for{" "}
            {selectedVariation.duration} days
            {!selectedVariation.inStock && (
              <Badge variant="destructive" className="text-xs ml-2">
                Out of stock
              </Badge>
            )}
          </div>
        )}
      </div>
    );
  }

  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardContent className="p-3">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-800">
              Supply Variant
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="h-6 px-2 text-xs text-blue-600 hover:text-blue-800"
          >
            {isExpanded ? "Hide" : "Show"} options
          </Button>
        </div>

        {isExpanded && (
          <div className="space-y-2">
            {product.variations.map((variation) => {
              const isSelected = selectedVariation?.id === variation.id;
              const savings = calculateSavings(variation);
              const hasDiscount = savings > 0;
              const perDayPrice = variation.price / variation.duration;

              return (
                <div
                  key={variation.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? "border-blue-500 bg-blue-100"
                      : variation.inStock
                      ? "border-gray-200 hover:border-blue-300 hover:bg-blue-50"
                      : "border-gray-200 bg-gray-100 opacity-60 cursor-not-allowed"
                  }`}
                  onClick={() =>
                    variation.inStock && onVariationSelect(variation)
                  }
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="font-medium text-sm">
                          {variation.name}
                        </span>
                        {hasDiscount && (
                          <Badge
                            variant="secondary"
                            className="text-xs bg-green-100 text-green-800"
                          >
                            Save <DirhamIcon className="h-3 w-3 inline ml-1" />
                            {savings.toFixed(2)}
                          </Badge>
                        )}
                        {!variation.inStock && (
                          <Badge variant="destructive" className="text-xs">
                            Out of stock
                          </Badge>
                        )}
                        {isSelected && variation.inStock && (
                          <Badge variant="default" className="text-xs">
                            Selected
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-4 text-xs text-gray-600">
                        <span className="flex items-center">
                          <DirhamIcon className="h-3 w-3 mr-1" />
                          {variation.price.toFixed(2)} total
                        </span>
                        <span className="flex items-center">
                          ~<DirhamIcon className="h-3 w-3 mx-1" />
                          {perDayPrice.toFixed(2)}/day
                        </span>
                        <span>{variation.duration} days supply</span>
                      </div>
                    </div>
                    <div className="text-right ml-2">
                      {hasDiscount && (
                        <div className="text-xs text-gray-500 line-through flex items-center justify-end">
                          <DirhamIcon className="h-3 w-3 mr-1" />
                          {variation.basePrice!.toFixed(2)}
                        </div>
                      )}
                      <div className="text-lg font-bold text-blue-600 flex items-center justify-end">
                        <DirhamIcon className="h-4 w-4 mr-1" />
                        {variation.price.toFixed(2)}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {!isExpanded && selectedVariation && (
          <div className="text-sm text-blue-700">
            <div className="flex items-center justify-between">
              <span>{selectedVariation.name}</span>
              <span className="font-semibold flex items-center">
                <DirhamIcon className="h-3 w-3 mr-1" />
                {selectedVariation.price.toFixed(2)}
              </span>
            </div>
            <div className="text-xs text-blue-600 mt-1 flex items-center justify-between">
              <span>{selectedVariation.duration} days supply</span>
              {!selectedVariation.inStock && (
                <Badge variant="destructive" className="text-xs">
                  Out of stock
                </Badge>
              )}
            </div>
          </div>
        )}

        {!isExpanded && !selectedVariation && (
          <div className="text-sm text-blue-700">
            Select a supply duration option
          </div>
        )}
      </CardContent>
    </Card>
  );
}
