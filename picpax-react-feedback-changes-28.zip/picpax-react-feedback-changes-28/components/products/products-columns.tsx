"use client"

import type { ColumnDef } from "@tanstack/react-table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowUpDown, Eye, Sun, Moon, Info } from "lucide-react"

export type Product = {
  id: string
  item_id: string
  name: string
  price: number
  category: string
  inStock: boolean
  type_am: boolean
  type_pm: boolean
  description: string
}

export const productsColumns: ColumnDef<Product>[] = [
  {
    accessorKey: "item_id",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Item ID
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const product = row.original
      return (
        <div className="space-y-1">
          <div className="font-medium">{product.item_id}</div>
          <div className="text-xs text-muted-foreground">ID: {product.id}</div>
        </div>
      )
    },
  },
  {
    accessorKey: "name",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Product Name
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const product = row.original
      return (
        <div className="space-y-1">
          <div className="font-medium">{product.name}</div>
          <div className="text-xs text-muted-foreground line-clamp-2">{product.description}</div>
        </div>
      )
    },
  },
  {
    accessorKey: "category",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Category
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const category = row.getValue("category") as string
      return <Badge variant="outline">{category}</Badge>
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: "price",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Price
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const amount = Number.parseFloat(row.getValue("price"))
      return <div className="font-medium">${amount.toFixed(2)}</div>
    },
  },
  {
    accessorKey: "timing",
    header: "Timing",
    cell: ({ row }) => {
      const product = row.original
      return (
        <div className="flex space-x-1">
          {product.type_am && (
            <Badge variant="outline" className="text-orange-600">
              <Sun className="h-3 w-3 mr-1" />
              AM
            </Badge>
          )}
          {product.type_pm && (
            <Badge variant="outline" className="text-blue-600">
              <Moon className="h-3 w-3 mr-1" />
              PM
            </Badge>
          )}
        </div>
      )
    },
  },
  {
    accessorKey: "inStock",
    header: ({ column }) => {
      return (
        <Button
          variant="ghost"
          onClick={() => column.toggleSorting(column.getIsSorted() === "asc")}
          className="h-8 p-0 hover:bg-transparent"
        >
          Stock
          <ArrowUpDown className="ml-2 h-4 w-4" />
        </Button>
      )
    },
    cell: ({ row }) => {
      const inStock = row.getValue("inStock") as boolean
      return <Badge variant={inStock ? "default" : "destructive"}>{inStock ? "In Stock" : "Out of Stock"}</Badge>
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const product = row.original

      return (
        <div className="flex space-x-2">
          <Button variant="outline" size="sm">
            <Eye className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm">
            <Info className="h-4 w-4" />
          </Button>
        </div>
      )
    },
  },
]
