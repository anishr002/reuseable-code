"use client"

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Package, Clock, Sun, Moon } from "lucide-react"

interface ProductInfo {
  id: string
  product_id: string // FK to products.item_id
  dose: string
  ingredients: string
  created_at: string
  updated_at: string
}

interface Product {
  id: string
  item_id: string
  name: string
  price: number
  category: string
  inStock: boolean
  type_am: boolean
  type_pm: boolean
  description: string
}

interface ProductInfoModalProps {
  product: Product | null
  productInfo: ProductInfo | null
  isOpen: boolean
  onClose: () => void
}

export function ProductInfoModal({ product, productInfo, isOpen, onClose }: ProductInfoModalProps) {
  if (!product) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Package className="h-5 w-5" />
            <span>{product.name}</span>
          </DialogTitle>
          <DialogDescription>Detailed product information and dosage guidelines</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Product Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div>
                <div className="text-sm font-medium">Product ID</div>
                <div className="text-sm text-muted-foreground">{product.item_id}</div>
              </div>
              <div>
                <div className="text-sm font-medium">Category</div>
                <Badge variant="outline">{product.category}</Badge>
              </div>
              <div>
                <div className="text-sm font-medium">Price</div>
                <div className="text-lg font-bold text-green-600">${product.price}</div>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <div className="text-sm font-medium">Availability</div>
                <Badge variant={product.inStock ? "default" : "destructive"}>
                  {product.inStock ? "In Stock" : "Out of Stock"}
                </Badge>
              </div>
              <div>
                <div className="text-sm font-medium">Timing</div>
                <div className="flex space-x-2">
                  {product.type_am && (
                    <Badge variant="outline" className="text-orange-600">
                      <Sun className="h-3 w-3 mr-1" />
                      Morning
                    </Badge>
                  )}
                  {product.type_pm && (
                    <Badge variant="outline" className="text-blue-600">
                      <Moon className="h-3 w-3 mr-1" />
                      Evening
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Product Description */}
          <div className="space-y-2">
            <h4 className="font-semibold">Description</h4>
            <p className="text-sm text-muted-foreground">{product.description}</p>
          </div>

          {/* Detailed Product Info */}
          {productInfo && (
            <>
              <Separator />
              <div className="space-y-4">
                <h4 className="font-semibold flex items-center space-x-2">
                  <Clock className="h-4 w-4" />
                  <span>Dosage & Ingredients</span>
                </h4>

                <div className="space-y-3">
                  <div>
                    <div className="text-sm font-medium">Recommended Dose</div>
                    <div className="text-sm text-muted-foreground bg-gray-50 p-3 rounded-lg">{productInfo.dose}</div>
                  </div>

                  <div>
                    <div className="text-sm font-medium">Ingredients</div>
                    <div className="text-sm text-muted-foreground bg-gray-50 p-3 rounded-lg">
                      {productInfo.ingredients}
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Usage Guidelines */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h5 className="font-medium text-blue-900 mb-2">Usage Guidelines</h5>
            <div className="text-sm text-blue-800 space-y-1">
              {product.type_am && product.type_pm && <p>• Can be taken both morning and evening</p>}
              {product.type_am && !product.type_pm && <p>• Best taken in the morning</p>}
              {!product.type_am && product.type_pm && <p>• Best taken in the evening</p>}
              <p>• Follow dosage instructions carefully</p>
              <p>• Consult with healthcare provider if needed</p>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
