"use client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Package,
  DollarSign,
  Calendar,
  Settings,
  RefreshCw,
  ExternalLink,
  MapPin,
  Tag,
  Activity,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
} from "lucide-react";
import type { Product } from "./columns";
import { useEffect, useState } from "react";
import { getProductById, postSyncProduct } from "@/lib/productService";
import { DirhamIcon } from "../ui/DirhamIcon";

interface ProductDetailsModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isDoctor?: boolean;
}

export function ProductDetailsModal({
  product,
  isOpen,
  onClose,
  isDoctor,
}: ProductDetailsModalProps) {
  const [fullProduct, setFullProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setFullProduct(null);
      setIsLoading(false);
    }
  }, [isOpen]);

  // Load product details only when modal opens and product is available
  useEffect(() => {
    let mounted = true;

    const loadProductDetails = async () => {
      if (!isOpen || !product || fullProduct) return;

      setIsLoading(true);
      try {
        const resp: any = await getProductById(product.id);

        if (mounted && resp && resp.success) {
          const apiProduct: any = resp.data.product;

          // Transform the detailed API response to match our Product type
          // Transform the detailed API response to match our Product type
          const transformedProduct: any = {
            id: apiProduct.id,
            shopifyId: String(apiProduct.product_id),
            title: apiProduct.title,
            description: apiProduct.body_html || "",
            vendor: apiProduct.vendor,
            productType: apiProduct.product_type || "",
            tags: apiProduct.tags
              ? apiProduct.tags
                  .split(",")
                  .map((t: string) => t.trim())
                  .filter(Boolean)
              : [],
            status: apiProduct.status as Product["status"],
            inventory: {
              available: apiProduct.inventory_locations?.[0]?.available || 0,
              locations:
                apiProduct.inventory_locations?.map((location: any) => ({
                  name: location.location_name,
                  available: location.available,
                })) || [],
            },
            pricing: {
              price: Number(apiProduct.variants?.[0]?.price || 0),
              compareAtPrice: apiProduct.variants?.[0]?.compare_at_price
                ? Number(apiProduct.variants[0].compare_at_price)
                : null,
              cost: 0, // Not available in the response
              currency: "AED",
            },
            variants:
              apiProduct.variants?.map((variant: any, index: number) => ({
                id: variant.id,
                title: variant.title,
                sku: variant.sku,
                price: variant.price,
                inventory: variant.inventory_summary?.total_available || 0,
                // Include location data from API
                inventory_levels: variant.inventory_levels,
                location: variant.location,
              })) || [],
            images:
              apiProduct.images?.map((image: any) => ({
                id: image.id,
                src: image.src,
                alt: image.alt || apiProduct.title,
              })) || [],
            createdAt: apiProduct.created_at,
            updatedAt: apiProduct.updated_at,
            shopifySync: {
              lastSync: apiProduct.updated_at,
              syncStatus:
                apiProduct.sync_status as Product["shopifySync"]["syncStatus"],
              // Use the shopify_product_url from the API response
              shopifyUrl: resp.data.shopify_product_url || null,
            },
          };

          setFullProduct(transformedProduct);
        }
      } catch (err) {
        console.error("Failed to load full product:", err);
        // Fallback to the basic product data if detailed load fails
        if (mounted) {
          setFullProduct(product);
        }
      } finally {
        if (mounted) setIsLoading(false);
      }
    };

    loadProductDetails();

    return () => {
      mounted = false;
    };
  }, [isOpen, product, fullProduct]);

  const current = fullProduct || product;
  if (!current) return null;

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "active":
        return <CheckCircle className="h-4 w-4" />;
      case "draft":
        return <Clock className="h-4 w-4" />;
      case "archived":
        return <XCircle className="h-4 w-4" />;
      default:
        return <Package className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-600 hover:bg-green-700";
      case "draft":
        return "bg-yellow-600 hover:bg-yellow-700";
      case "archived":
        return "bg-gray-600 hover:bg-gray-700";
      default:
        return "bg-gray-600 hover:bg-gray-700";
    }
  };

  const getSyncBadge = (syncStatus: string) => {
    const variants = {
      synced: "default" as const,
      syncing: "secondary" as const,
      not_synced: "destructive" as const,
      error: "destructive" as const,
    };
    return variants[syncStatus as keyof typeof variants] || "outline";
  };

  const getSyncIcon = (syncStatus: string) => {
    switch (syncStatus) {
      case "synced":
        return <CheckCircle className="h-4 w-4" />;
      case "syncing":
        return <RefreshCw className="h-4 w-4 animate-spin" />;
      case "not_synced":
        return <AlertCircle className="h-4 w-4" />;
      case "error":
        return <XCircle className="h-4 w-4" />;
      default:
        return <RefreshCw className="h-4 w-4" />;
    }
  };

  const handleSync = async () => {
    setIsSyncing(true);
    try {
      const resp = await postSyncProduct(current.shopifyId);
      if (resp && resp.success) {
        // Refresh the product data after sync
        const refreshed: any = await getProductById(current.id);
        if (refreshed && refreshed.success) {
          const apiRefreshed: any = refreshed.data.product;
          const transformedProduct: Product = {
            id: apiRefreshed.id,
            shopifyId: String(apiRefreshed.product_id),
            title: apiRefreshed.title,
            description: apiRefreshed.body_html || "",
            vendor: apiRefreshed.vendor,
            productType: apiRefreshed.product_type || "",
            tags: apiRefreshed.tags
              ? apiRefreshed.tags
                  .split(",")
                  .map((t: string) => t.trim())
                  .filter(Boolean)
              : [],
            status: apiRefreshed.status as Product["status"],
            inventory: {
              available: apiRefreshed.inventory_locations?.[0]?.available || 0,
              locations:
                apiRefreshed.inventory_locations?.map((location: any) => ({
                  name: location.location_name,
                  available: location.available,
                })) || [],
            },
            pricing: {
              price: Number(apiRefreshed.variants?.[0]?.price || 0),
              compareAtPrice: apiRefreshed.variants?.[0]?.compare_at_price
                ? Number(apiRefreshed.variants[0].compare_at_price)
                : null,
              cost: 0,
              currency: "AED",
            },
            variants:
              apiRefreshed.variants?.map((variant: any, index: number) => ({
                id: variant.id,
                title: variant.title,
                sku: variant.sku,
                price: variant.price,
                inventory: variant.inventory_summary?.total_available || 0,
                inventory_levels: variant.inventory_levels,
                location: variant.location,
              })) || [],
            images:
              apiRefreshed.images?.map((image: any) => ({
                id: image.id,
                src: image.src,
                alt: image.alt || apiRefreshed.title,
              })) || [],
            createdAt: apiRefreshed.created_at,
            updatedAt: apiRefreshed.updated_at,
            shopifySync: {
              lastSync: apiRefreshed.updated_at,
              syncStatus:
                apiRefreshed.sync_status as Product["shopifySync"]["syncStatus"],
              // Use the shopify_product_url from the API response
              shopifyUrl: refreshed.data.shopify_product_url || null,
            },
          };
          setFullProduct(transformedProduct);
        }
      }
    } catch (err) {
      console.error("Sync error", err);
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Product Details - {current.title}
              </DialogTitle>
              <DialogDescription>
                Complete product information and management options
              </DialogDescription>
            </div>
            <div className="flex items-center gap-2">
              <Badge
                variant="default"
                className={`flex items-center gap-1 ${getStatusColor(
                  current.status
                )}`}
              >
                {getStatusIcon(current.status)}
                {current.status}
              </Badge>
            </div>
          </div>
        </DialogHeader>

        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <RefreshCw className="h-8 w-8 animate-spin text-muted-foreground" />
            <span className="ml-2">Loading product details...</span>
          </div>
        ) : (
          <div className="grid gap-6 py-4">
            {/* Product Summary */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Created</span>
                </div>
                <p className="text-sm text-muted-foreground ml-6">
                  {new Date(current.createdAt).toLocaleDateString()}
                </p>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">Price</span>
                </div>
                <p className="text-sm font-medium ml-6">
                  <DirhamIcon className="h-4 w-4 text-muted-foreground" />
                  {current.pricing.price}
                  {current.pricing.compareAtPrice && (
                    <span className="text-xs text-muted-foreground line-through ml-2">
                      <DirhamIcon className="h-4 w-4 text-muted-foreground" />
                      {current.pricing.compareAtPrice}
                    </span>
                  )}
                </p>
              </div>
            </div>

            <Tabs defaultValue="basic" className="w-full">
              <TabsList
                className={`grid w-full ${
                  isDoctor ? "grid-cols-3" : "grid-cols-4"
                }`}
              >
                <TabsTrigger value="basic">Basic Info</TabsTrigger>
                <TabsTrigger value="inventory">Inventory</TabsTrigger>
                <TabsTrigger value="pricing">Pricing</TabsTrigger>
                {!isDoctor && (
                  <TabsTrigger value="sync">Shopify Sync</TabsTrigger>
                )}
              </TabsList>

              <TabsContent value="basic" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Product Information</h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="font-medium">Title:</span>{" "}
                        {current.title}
                      </div>
                      <div>
                        <span className="font-medium">Vendor:</span>{" "}
                        {current.vendor}
                      </div>
                      <div>
                        <span className="font-medium">Type:</span>{" "}
                        {current.productType}
                      </div>
                      <div>
                        <span className="font-medium">SKU:</span>{" "}
                        {current.variants[0]?.sku || "N/A"}
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Additional Details</h4>
                    <div className="space-y-2 text-sm">
                      <div>
                        <span className="font-medium">Variants:</span>{" "}
                        {current.variants.length}
                      </div>
                      <div>
                        <span className="font-medium">Images:</span>{" "}
                        {current.images.length}
                      </div>
                      <div>
                        <span className="font-medium">Last Updated:</span>{" "}
                        {new Date(current.updatedAt).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <div
                    className="text-sm text-muted-foreground prose prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: current.description }}
                  />
                </div>

                <div>
                  <h4 className="font-medium mb-2">Tags</h4>
                  <div className="flex flex-wrap gap-1">
                    {current.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        <Tag className="h-3 w-3 mr-1" />
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="inventory" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className="h-5 w-5" />
                      <h4 className="font-medium">Total Inventory</h4>
                    </div>
                    <div className="text-2xl font-bold text-green-600">
                      {current.inventory.available}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Units available
                    </p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="h-5 w-5" />
                      <h4 className="font-medium">Locations</h4>
                    </div>
                    <div className="text-2xl font-bold text-blue-600">
                      {current.inventory.locations.length}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Inventory locations
                    </p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Inventory by Location</h4>
                  <div className="space-y-2">
                    {current.inventory.locations.map((location, index) => (
                      <div
                        key={index}
                        className="flex justify-between items-center p-2 bg-white rounded border"
                      >
                        <span className="font-medium">{location.name}</span>
                        <Badge variant="outline">
                          {location.available} units
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Variants Inventory</h4>
                  <div className="space-y-2">
                    {current.variants.map((variant: any, index) => (
                      <div
                        key={variant.id}
                        className="flex justify-between items-center p-2 bg-white rounded border"
                      >
                        <div>
                          <span className="font-medium">{variant.title}</span>
                          <span className="text-sm text-muted-foreground ml-2">
                            (SKU: {variant.sku})
                          </span>
                          {variant.location && (
                            <div className="text-xs text-muted-foreground mt-1">
                              Location: {variant.location.location_name}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="font-medium">
                            <DirhamIcon className="h-4 w-4 text-muted-foreground" />{" "}
                            {variant.price}
                          </span>
                          <Badge variant="outline">
                            {variant.inventory} units
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="pricing" className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Selling Price</h4>
                    <div className="text-2xl font-bold text-green-600">
                      <DirhamIcon className="h-4 w-4 text-muted-foreground" />{" "}
                      {current.pricing.price}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Compare Price</h4>
                    <div className="text-2xl font-bold text-gray-600">
                      {current.pricing.compareAtPrice
                        ? `AED ${current.pricing.compareAtPrice}`
                        : "N/A"}
                    </div>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Cost</h4>
                    <div className="text-2xl font-bold text-red-600">
                      <DirhamIcon className="h-4 w-4 text-muted-foreground" />{" "}
                      {current.pricing.cost}
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Variants Pricing</h4>
                  <div className="space-y-2">
                    {current.variants.map((variant: any, index) => (
                      <div
                        key={variant.id}
                        className="flex justify-between items-center p-3 bg-white rounded border"
                      >
                        <div>
                          <span className="font-medium">{variant.title}</span>
                          <span className="text-sm text-muted-foreground ml-2">
                            SKU: {variant.sku}
                          </span>
                          {variant.location && (
                            <div className="text-xs text-muted-foreground mt-1">
                              Location: {variant.location.location_name}
                            </div>
                          )}
                        </div>
                        <span className="font-bold text-lg">
                          <DirhamIcon className="h-4 w-4 text-muted-foreground" />{" "}
                          {variant.price}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="sync" className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      {getSyncIcon(current.shopifySync.syncStatus)}
                      <h4 className="font-medium">Sync Status</h4>
                    </div>
                    <Badge
                      variant={getSyncBadge(current.shopifySync.syncStatus)}
                      className="mb-2"
                    >
                      {current.shopifySync.syncStatus === "synced"
                        ? "Synced"
                        : current.shopifySync.syncStatus === "syncing"
                        ? "Syncing"
                        : current.shopifySync.syncStatus === "not synced"
                        ? "Not Synced"
                        : "Error"}
                    </Badge>
                    {current.shopifySync.lastSync && (
                      <p className="text-sm text-muted-foreground">
                        Last sync:{" "}
                        {new Date(
                          current.shopifySync.lastSync
                        ).toLocaleString()}
                      </p>
                    )}
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Settings className="h-5 w-5" />
                      <h4 className="font-medium">Shopify Integration</h4>
                    </div>
                    <div className="text-sm">
                      <div>
                        <span className="font-medium">Shopify ID:</span>{" "}
                        {current.shopifyId}
                      </div>
                      {current.shopifySync.shopifyUrl && (
                        <div className="mt-2">
                          <a
                            href={current.shopifySync.shopifyUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
                          >
                            <ExternalLink className="h-3 w-3" />
                            View on Shopify
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
