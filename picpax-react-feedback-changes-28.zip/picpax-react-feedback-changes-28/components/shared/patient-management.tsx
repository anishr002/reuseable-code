"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Users, UserCheck, UserX } from "lucide-react";
import { DataTable } from "@/components/patients/data-table";
import { AddPatientModal } from "@/components/add-patient-modal";
import { useAuth } from "@/lib/auth-context";
import { mockPatients, mockDoctors } from "@/lib/mock-data";
import type { Patient } from "@/components/patients/columns";
// import type { AdminPatient } from "@/components/admin/patients/columns"

interface PatientManagementProps {
  userRole?: "admin" | "doctor" | "staff";
  userId?: string;
  className?: string;
}

export function PatientManagement({
  userRole,
  userId,
  className = "",
}: PatientManagementProps) {
  const { user } = useAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);

  // Determine role and filter patients based on role
  const role = userRole || user?.role || "doctor";
  const currentUserId = userId || user?.id || "";

  // Filter patients based on user role
  let patients = mockPatients;

  if (role === "doctor") {
    // Doctors can only see their own patients
    patients = mockPatients.filter((p) => p.parent_id === currentUserId);
  } else if (role === "staff") {
    // Staff can see patients of their doctor (parent_id)
    const staffDoctor = mockDoctors.find((d) => d.id === currentUserId);
    if (staffDoctor) {
      patients = mockPatients.filter(
        (p) => p.parent_id === staffDoctor.parent_id || staffDoctor.id
      );
    }
  }
  // Admin can see all patients

  const activePatients = patients.filter((p) => p.status === "Active").length;
  const inactivePatients = patients.filter(
    (p) => p.status === "Inactive"
  ).length;
  const totalOrders = patients.reduce((sum, p) => sum + p.totalOrders, 0);

  const getPageTitle = () => {
    switch (role) {
      case "admin":
        return "Patient Management";
      case "doctor":
        return "My Patients";
      case "staff":
        return "Patients";
      default:
        return "Patient Management";
    }
  };

  const getPageDescription = () => {
    switch (role) {
      case "admin":
        return "Manage all patients across the system";
      case "doctor":
        return "Manage your patient records and information";
      case "staff":
        return "Manage patient records and information";
      default:
        return "Manage patient records and information";
    }
  };

  const canAddPatient = role === "admin" || role === "doctor";

  return (
    <div className={`space-y-4 sm:space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
            {getPageTitle()}
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            {getPageDescription()}
          </p>
        </div>
        {canAddPatient && (
          <Button
            className="bg-primary hover:bg-primary/90 w-full sm:w-auto"
            onClick={() => setIsAddDialogOpen(true)}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Patient
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Patients
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{patients.length}</div>
            <p className="text-xs text-muted-foreground">
              All registered patients
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Active Patients
            </CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {activePatients}
            </div>
            <p className="text-xs text-muted-foreground">Currently active</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Inactive Patients
            </CardTitle>
            <UserX className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-muted-foreground">
              {inactivePatients}
            </div>
            <p className="text-xs text-muted-foreground">Need follow-up</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <Badge variant="outline" className="text-xs">
              {totalOrders}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">
              {totalOrders}
            </div>
            <p className="text-xs text-muted-foreground">All patient orders</p>
          </CardContent>
        </Card>
      </div>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Patient Records</CardTitle>
          <CardDescription>
            {role === "admin"
              ? "Comprehensive view of all patients with advanced filtering and sorting capabilities"
              : "Comprehensive view of your patients with advanced filtering and sorting capabilities"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <DataTable
              columns={
                role === "admin"
                  ? (
                      require("@/components/admin/patients/columns") as typeof import("@/components/admin/patients/columns")
                    ).columns
                  : (
                      require("@/components/patients/columns") as typeof import("@/components/patients/columns")
                    ).columns
              }
              data={patients}
            />
          </div>
        </CardContent>
      </Card>

      {/* Add Patient Modal */}
      {canAddPatient && (
        <AddPatientModal
          isOpen={isAddDialogOpen}
          onClose={() => setIsAddDialogOpen(false)}
        />
      )}
    </div>
  );
}
