"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Gift, X, Truck, Percent, Package } from "lucide-react";
import axiosInstance from "@/services/axiosInstance";

interface CouponApplyProps {
  onCouponApplied: (coupon: {
    code: string;
    discount: any; // Updated to handle different discount types
  }) => void;
  onCouponRemoved: () => void;
  appliedCoupon?: { code: string; discount: any } | null;
  cartItems: Array<{
    variant_id: number;
    quantity: number;
    price: string;
    name: string;
  }>;
}

export function CouponApply({
  onCouponApplied,
  onCouponRemoved,
  appliedCoupon,
  cartItems,
}: CouponApplyProps) {
  const [couponCode, setCouponCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;

    setIsLoading(true);
    setError("");

    try {
      const payload = {
        coupon: couponCode.trim(),
        items: cartItems.map((item) => ({
          variant_id: item.variant_id,
          quantity: item.quantity.toString(),
          price: item.price,
          name: item.name,
        })),
      };

      const response = await axiosInstance.post("/draft-order/coupon", payload);

      if (response.data.success) {
        onCouponApplied({
          code: couponCode.trim(),
          discount: response.data.data,
        });
        setCouponCode("");
      } else {
        setError(response.data.message || "Failed to apply coupon");
      }
    } catch (error: any) {
      console.error("Failed to apply coupon:", error);
      setError(error.response?.data?.message || "Invalid coupon code");
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemoveCoupon = () => {
    onCouponRemoved();
    setError("");
  };

  const getDiscountMessage = () => {
    if (!appliedCoupon) return null;

    const { discount } = appliedCoupon;

    switch (discount.type) {
      case "shipping":
        return {
          message: "Free shipping applied!",
          icon: <Truck className="h-3 w-3 mr-1" />,
          color: "text-blue-600",
        };
      case "order":
        const valueType = discount.applied_discount.value_type;
        const value = discount.applied_discount.value;
        const message =
          valueType === "percentage"
            ? `${value}% off applied on order total`
            : `AED ${value} off applied on order total`;
        return {
          message,
          icon: <Percent className="h-3 w-3 mr-1" />,
          color: "text-green-600",
        };
      case "line_item":
        return {
          message: "Product discount applied!",
          icon: <Package className="h-3 w-3 mr-1" />,
          color: "text-purple-600",
        };
      default:
        return null;
    }
  };

  const discountInfo = getDiscountMessage();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gift className="h-5 w-5" />
          Apply Coupon
        </CardTitle>
        <CardDescription>
          Enter your coupon code to apply discount
        </CardDescription>
      </CardHeader>
      <CardContent>
        {!appliedCoupon ? (
          <div className="space-y-4">
            <div className="flex gap-2">
              <Input
                placeholder="Enter coupon code"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleApplyCoupon()}
                className="flex-1"
              />
              <Button
                onClick={handleApplyCoupon}
                disabled={
                  !couponCode.trim() || isLoading || cartItems.length === 0
                }
                size="sm"
              >
                {isLoading ? "Applying..." : "Apply"}
              </Button>
            </div>
            {error && (
              <div className="text-sm text-red-600 bg-red-50 p-2 rounded">
                {error}
              </div>
            )}
            {cartItems.length === 0 && (
              <div className="text-sm text-muted-foreground">
                Add products to cart to apply coupon
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge
                  variant="secondary"
                  className="bg-green-50 text-green-700"
                >
                  <Gift className="h-3 w-3 mr-1" />
                  {appliedCoupon.code}
                </Badge>
                {discountInfo && (
                  <span
                    className={`text-sm ${discountInfo.color} flex items-center`}
                  >
                    {discountInfo.icon}
                    {discountInfo.message}
                  </span>
                )}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleRemoveCoupon}
                className="h-8 w-8 p-0"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
