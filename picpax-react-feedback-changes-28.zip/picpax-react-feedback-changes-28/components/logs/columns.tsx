"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { User, Settings, Calendar } from "lucide-react";
import { DataTableColumnHeader } from "./data-table-column-header";
import { convertToDubaiTime } from "../convertToDubaiTime";

export type ActivityLog = {
  uuid: string;
  module: string;
  description: string;
  event: string;
  properties: {
    old?: any;
    attributes?: any;
  };
  created_at: string;
  causer: {
    id: string;
    name: string;
  } | null;
  subject: {
    uuid: string;
    key: string;
    display_key: string;
    value: string;
  };
};

export const columns: ColumnDef<ActivityLog>[] = [
  {
    accessorKey: "subject",
    id: "subject", // This maps to "field" in API
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Field" />
    ),
    cell: ({ row }) => {
      const log = row.original;
      return (
        <div className="min-w-[150px]">
          <div className="flex items-center space-x-2">
            <Settings className="h-4 w-4 text-muted-foreground" />
            <div>
              <div className="font-medium text-sm">
                {log.subject.display_key}
              </div>
            </div>
          </div>
        </div>
      );
    },
    enableSorting: true,
  },
  {
    accessorKey: "event",
    id: "event", // This maps to "event" in API
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Event" />
    ),
    cell: ({ row }) => {
      const event = row.getValue("event") as string;

      const getEventVariant = (event: string) => {
        switch (event) {
          case "created":
            return "default";
          case "updated":
            return "secondary";
          case "deleted":
            return "destructive";
          default:
            return "outline";
        }
      };

      const getEventColor = (event: string) => {
        switch (event) {
          case "created":
            return "bg-green-100 text-green-800 border-green-200";
          case "updated":
            return "bg-blue-100 text-blue-800 border-blue-200";
          case "deleted":
            return "bg-red-100 text-red-800 border-red-200";
          default:
            return "bg-gray-100 text-gray-800 border-gray-200";
        }
      };

      return (
        <div className="min-w-[100px]">
          <Badge
            variant={getEventVariant(event)}
            className={`text-xs ${getEventColor(event)}`}
          >
            {event.charAt(0).toUpperCase() + event.slice(1)}
          </Badge>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
    enableSorting: true,
  },
  {
    accessorKey: "description",
    id: "description", // This maps to "description" in API
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Description" />
    ),
    cell: ({ row }) => {
      const log = row.original;
      return (
        <div className="min-w-[300px]">
          <div className="font-medium text-sm">{log.description}</div>
          <div className="text-xs text-muted-foreground mt-1">
            Setting: {log.subject.display_key}
          </div>
        </div>
      );
    },
    enableSorting: true,
    enableHiding: false,
  },
  {
    accessorKey: "causer",
    id: "causer", // This maps to "user" in API
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="User" />
    ),
    cell: ({ row }) => {
      const log = row.original;
      return (
        <div className="min-w-[150px]">
          <div className="flex items-center space-x-2">
            <User className="h-4 w-4 text-muted-foreground" />
            <div>
              <div className="font-medium text-sm">
                {log.causer?.name || "System"}
              </div>
            </div>
          </div>
        </div>
      );
    },
    enableSorting: true,
  },
  {
    accessorKey: "created_at",
    id: "created_at", // This maps to "date" in API
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Date & Time" />
    ),
    cell: ({ row }) => {
      const createdAt = row.getValue("created_at") as string;
      const date = new Date(createdAt);

      return (
        <div className="min-w-[180px]">
          <div className="flex items-center space-x-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <div>
              <div className="font-medium text-sm">
                {convertToDubaiTime(date).split(",")[0]} {/* Date part */}
              </div>
              <div className="text-xs text-muted-foreground">
                {convertToDubaiTime(date).split(",")[1]} {/* Time part */}
              </div>
            </div>
          </div>
        </div>
      );
    },
    enableSorting: true,
  },
  {
    accessorKey: "properties",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Changes" />
    ),
    cell: ({ row }) => {
      const log = row.original;
      const { old, attributes } = log.properties;

      return (
        <div className="min-w-[200px] max-w-[300px]">
          {log.event === "updated" && old && attributes ? (
            <div className="space-y-1">
              <div className="text-xs">
                <span className="font-medium">From:</span>{" "}
                <span className="text-red-600 line-through">
                  {old.value || "N/A"}
                </span>
              </div>
              <div className="text-xs">
                <span className="font-medium">To:</span>{" "}
                <span className="text-green-600">
                  {attributes.value || "N/A"}
                </span>
              </div>
            </div>
          ) : log.event === "created" && attributes ? (
            <div className="text-xs">
              <span className="font-medium">Set to:</span>{" "}
              <span className="text-green-600">
                {attributes.value || "N/A"}
              </span>
            </div>
          ) : (
            <div className="text-xs text-muted-foreground">No changes</div>
          )}
        </div>
      );
    },
    enableSorting: false,
  },
];
