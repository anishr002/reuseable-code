"use client";

import {
  ChevronLeftIcon,
  ChevronRightIcon,
  DoubleArrowLeftIcon,
  DoubleArrowRightIcon,
} from "@radix-ui/react-icons";
import type { Table } from "@tanstack/react-table";

import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface DataTablePaginationProps<TData> {
  table: Table<TData>;
  pagination?: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  };
  onPaginationChange?: (page: number, pageSize: number) => void;
}

export function DataTablePagination<TData>({
  table,
  pagination,
  onPaginationChange,
}: DataTablePaginationProps<TData>) {
  // Use server-side pagination if available, otherwise use client-side
  const isServerSide = !!pagination && !!onPaginationChange;

  const currentPage = isServerSide
    ? pagination.current_page
    : table.getState().pagination.pageIndex + 1;

  const pageCount = isServerSide ? pagination.last_page : table.getPageCount();

  const pageSize = isServerSide
    ? pagination.per_page
    : table.getState().pagination.pageSize;

  const totalRows = isServerSide
    ? pagination.total
    : table.getFilteredRowModel().rows.length;

  const handlePageSizeChange = (value: string) => {
    const newPageSize = Number(value);

    if (isServerSide && onPaginationChange) {
      // For server-side: reset to first page when changing page size
      onPaginationChange(1, newPageSize);
    } else {
      // For client-side
      table.setPageSize(newPageSize);
    }
  };

  const handleFirstPage = () => {
    if (isServerSide && onPaginationChange) {
      onPaginationChange(1, pageSize);
    } else {
      table.setPageIndex(0);
    }
  };

  const handlePreviousPage = () => {
    if (isServerSide && onPaginationChange) {
      onPaginationChange(Math.max(1, currentPage - 1), pageSize);
    } else {
      table.previousPage();
    }
  };

  const handleNextPage = () => {
    if (isServerSide && onPaginationChange) {
      onPaginationChange(Math.min(pageCount, currentPage + 1), pageSize);
    } else {
      table.nextPage();
    }
  };

  const handleLastPage = () => {
    if (isServerSide && onPaginationChange) {
      onPaginationChange(pageCount, pageSize);
    } else {
      table.setPageIndex(pageCount - 1);
    }
  };

  const canPreviousPage = isServerSide
    ? currentPage > 1
    : table.getCanPreviousPage();
  const canNextPage = isServerSide
    ? currentPage < pageCount
    : table.getCanNextPage();

  return (
    <div className="flex items-center justify-between px-2">
      <div className="flex-1 text-sm text-muted-foreground">
        {table.getFilteredSelectedRowModel().rows.length} of{" "}
        {totalRows.toLocaleString()} row(s) selected.
      </div>
      <div className="flex items-center space-x-6 lg:space-x-8">
        <div className="flex items-center space-x-2">
          <p className="text-sm font-medium">Rows per page</p>
          <Select value={`${pageSize}`} onValueChange={handlePageSizeChange}>
            <SelectTrigger className="h-8 w-[70px]">
              <SelectValue placeholder={pageSize} />
            </SelectTrigger>
            <SelectContent side="top">
              {[10, 20, 30, 40, 50].map((pageSize) => (
                <SelectItem key={pageSize} value={`${pageSize}`}>
                  {pageSize}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex w-[100px] items-center justify-center text-sm font-medium">
          Page {currentPage} of {pageCount}
        </div>
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            className="hidden h-8 w-8 p-0 lg:flex bg-transparent"
            onClick={handleFirstPage}
            disabled={!canPreviousPage}
          >
            <span className="sr-only">Go to first page</span>
            <DoubleArrowLeftIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            className="h-8 w-8 p-0 bg-transparent"
            onClick={handlePreviousPage}
            disabled={!canPreviousPage}
          >
            <span className="sr-only">Go to previous page</span>
            <ChevronLeftIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            className="h-8 w-8 p-0 bg-transparent"
            onClick={handleNextPage}
            disabled={!canNextPage}
          >
            <span className="sr-only">Go to next page</span>
            <ChevronRightIcon className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            className="hidden h-8 w-8 p-0 lg:flex bg-transparent"
            onClick={handleLastPage}
            disabled={!canNextPage}
          >
            <span className="sr-only">Go to last page</span>
            <DoubleArrowRightIcon className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
