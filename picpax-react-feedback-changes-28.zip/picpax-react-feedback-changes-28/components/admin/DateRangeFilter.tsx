"use client";

import { useEffect, useState, useRef } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { CalendarIcon, ChevronDownIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Calendar } from "@/components/ui/calendar";

interface DateRangeFilterProps {
  onDateRangeChange: (range: { from: Date; to: Date } | null) => void;
  selectedRange?: { from: Date; to: Date } | null;
}

type PresetRange = {
  label: string;
  value: string;
  getRange: () => { from: Date; to: Date };
};

export function DateRangeFilter({
  onDateRangeChange,
  selectedRange,
}: DateRangeFilterProps) {
  const [date, setDate] = useState<{ from: Date; to: Date } | undefined>(
    selectedRange || undefined
  );
  const [tempDate, setTempDate] = useState<
    { from: Date; to: Date } | undefined
  >(selectedRange || undefined);
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState<string>("month_to_date");
  const [tempSelectedPreset, setTempSelectedPreset] =
    useState<string>("month_to_date");

  const initialSetupDone = useRef(false);

  const presetRanges: PresetRange[] = [
    {
      label: "Month to date",
      value: "month_to_date",
      getRange: () => {
        const today = new Date();
        const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
        return { from: firstDay, to: today };
      },
    },
    {
      label: "Today",
      value: "today",
      getRange: () => {
        const today = new Date();
        return { from: today, to: today };
      },
    },
    {
      label: "Yesterday",
      value: "yesterday",
      getRange: () => {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        return { from: yesterday, to: yesterday };
      },
    },
    {
      label: "Last 7 days",
      value: "last_7_days",
      getRange: () => {
        const today = new Date();
        const sevenDaysAgo = new Date(today);
        sevenDaysAgo.setDate(today.getDate() - 7);
        return { from: sevenDaysAgo, to: today };
      },
    },
    {
      label: "Last 30 days",
      value: "last_30_days",
      getRange: () => {
        const today = new Date();
        const thirtyDaysAgo = new Date(today);
        thirtyDaysAgo.setDate(today.getDate() - 30);
        return { from: thirtyDaysAgo, to: today };
      },
    },
    {
      label: "Last 90 days",
      value: "last_90_days",
      getRange: () => {
        const today = new Date();
        const ninetyDaysAgo = new Date(today);
        ninetyDaysAgo.setDate(today.getDate() - 90);
        return { from: ninetyDaysAgo, to: today };
      },
    },
    {
      label: "Last 365 days",
      value: "last_365_days",
      getRange: () => {
        const today = new Date();
        const yearAgo = new Date(today);
        yearAgo.setDate(today.getDate() - 365);
        return { from: yearAgo, to: today };
      },
    },
    {
      label: "Last 12 months",
      value: "last_12_months",
      getRange: () => {
        const today = new Date();
        const twelveMonthsAgo = new Date(today);
        twelveMonthsAgo.setMonth(today.getMonth() - 12);
        return { from: twelveMonthsAgo, to: today };
      },
    },
    {
      label: "Last week",
      value: "last_week",
      getRange: () => {
        const today = new Date();
        const day = today.getDay(); // 0 (Sun) to 6 (Sat)
        const lastSunday = new Date(today);
        lastSunday.setDate(today.getDate() - day - 7);
        const lastSaturday = new Date(lastSunday);
        lastSaturday.setDate(lastSunday.getDate() + 6);
        return { from: lastSunday, to: lastSaturday };
      },
    },
    {
      label: "Last month",
      value: "last_month",
      getRange: () => {
        const today = new Date();
        const firstDayLastMonth = new Date(
          today.getFullYear(),
          today.getMonth() - 1,
          1
        );
        const lastDayLastMonth = new Date(
          today.getFullYear(),
          today.getMonth(),
          0
        );
        return { from: firstDayLastMonth, to: lastDayLastMonth };
      },
    },
  ];

  // Initialize default preset
  useEffect(() => {
    if (!selectedRange && !initialSetupDone.current) {
      initialSetupDone.current = true;
      const preset = presetRanges.find((p) => p.value === "month_to_date");
      if (preset) {
        const range = preset.getRange();
        setDate(range);
        setTempDate(range);
      }
    }
  }, [selectedRange]);

  // Sync with parent prop (when external update)
  useEffect(() => {
    if (selectedRange) {
      setDate(selectedRange);
      setTempDate(selectedRange);
    }
  }, [selectedRange]);

  const handlePresetSelect = (presetValue: string) => {
    const preset = presetRanges.find((p) => p.value === presetValue);
    if (preset) {
      const range = preset.getRange();
      setTempDate(range);
      setTempSelectedPreset(presetValue);
    }
  };

  const handleCustomDateSelect = (
    range: { from: Date; to: Date } | undefined
  ) => {
    setTempDate(range);
    if (range) setTempSelectedPreset("custom");
  };

  const handleApply = () => {
    if (tempDate) {
      setDate(tempDate);
      setSelectedPreset(tempSelectedPreset); // ✅ ensure preset updates correctly
      onDateRangeChange(tempDate);
    }
    setIsCalendarOpen(false);
  };

  const handleCancel = () => {
    setTempDate(date);
    setTempSelectedPreset(selectedPreset);
    setIsCalendarOpen(false);
  };

  const getDisplayText = () => {
    const displayDate = isCalendarOpen ? tempDate : date;
    if (displayDate?.from) {
      if (displayDate.to)
        return `${format(displayDate.from, "MMM d, yyyy")} - ${format(
          displayDate.to,
          "MMM d, yyyy"
        )}`;
      return format(displayDate.from, "MMM d, yyyy");
    }

    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    return `${format(firstDay, "MMM d, yyyy")} - ${format(
      today,
      "MMM d, yyyy"
    )}`;
  };

  return (
    <Card className="w-full sm:w-[260px] max-w-full">
      <CardContent className="p-3 h-10">
        <Popover
          open={isCalendarOpen}
          onOpenChange={(open) => {
            setIsCalendarOpen(open);
            if (open) {
              // ✅ reset tempDate when reopening calendar
              setTempDate(date);
              setTempSelectedPreset(selectedPreset);
            }
          }}
        >
          <PopoverTrigger asChild>
            <div
              className={cn(
                "w-full flex items-center justify-between cursor-pointer text-sm font-normal",
                !date && "text-muted-foreground"
              )}
            >
              <div className="flex items-center gap-2 truncate">
                <CalendarIcon className="h-4 w-4 flex-shrink-0" />
                <span className="truncate">{getDisplayText()}</span>
              </div>
              <ChevronDownIcon className="h-4 w-4 opacity-50 flex-shrink-0" />
            </div>
          </PopoverTrigger>

          <PopoverContent className="w-auto p-0" align="end">
            <div className="flex">
              {/* Preset Ranges */}
              <div className="flex flex-col w-48 border-r">
                <div className="p-4 space-y-1 flex-1">
                  {presetRanges.map((preset) => (
                    <Button
                      key={preset.value}
                      variant="ghost"
                      className={cn(
                        "w-full justify-start text-sm font-normal h-8",
                        tempSelectedPreset === preset.value &&
                          "bg-accent text-accent-foreground"
                      )}
                      onClick={() => handlePresetSelect(preset.value)}
                    >
                      {preset.label}
                    </Button>
                  ))}
                </div>

                <div className="flex justify-between gap-2 p-4 border-t">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCancel}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    size="sm"
                    onClick={handleApply}
                    className="flex-1"
                    disabled={!tempDate}
                  >
                    Apply
                  </Button>
                </div>
              </div>

              {/* Calendar */}
              <div className="p-4">
                <Calendar
                  mode="range"
                  selected={tempDate}
                  onSelect={handleCustomDateSelect}
                  className="rounded-md border-0"
                  numberOfMonths={2}
                />
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </CardContent>
    </Card>
  );
}
