// components/admin/DoctorFilter.tsx
"use client";

import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { getDoctors, type Doctor } from "@/lib/orderService";
import { useToast } from "@/hooks/use-toast";

interface DoctorFilterProps {
  onDoctorChange: (doctorId: string) => void;
  selectedDoctor: string;
}

export function DoctorFilter({
  onDoctorChange,
  selectedDoctor,
}: DoctorFilterProps) {
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [doctorSearchTerm, setDoctorSearchTerm] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  // Load doctors
  const loadDoctors = async (search?: string) => {
    setLoading(true);
    try {
      const response = await getDoctors(search);
      setDoctors(response.data.doctors);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load doctors",
      });
    } finally {
      setLoading(false);
    }
  };

  // Search handler with debouncing
  useEffect(() => {
    const timer = setTimeout(() => {
      loadDoctors(doctorSearchTerm);
    }, 500);
    return () => clearTimeout(timer);
  }, [doctorSearchTerm]);

  // Load initial doctors
  useEffect(() => {
    loadDoctors();
  }, []);

  return (
    <div className="space-y-2">
      <Select value={selectedDoctor} onValueChange={onDoctorChange}>
        <SelectTrigger className="w-full md:w-[200px] focus:ring-0 focus:ring-offset-0 focus:outline-none">
          {" "}
          <SelectValue placeholder="All Doctors" />
        </SelectTrigger>
        <SelectContent>
          <div className="p-3">
            <Input
              placeholder="Search..."
              value={doctorSearchTerm}
              onChange={(e) => setDoctorSearchTerm(e.target.value)}
              className="mb-2"
            />
          </div>
          <SelectItem value="all">All Doctors</SelectItem>
          {loading ? (
            <div className="p-2 text-center text-sm text-muted-foreground">
              Loading doctors...
            </div>
          ) : doctors.length === 0 ? (
            <div className="p-2 text-center text-sm text-muted-foreground">
              No doctors found
            </div>
          ) : (
            doctors.map((doctor) => (
              <SelectItem key={doctor.id} value={doctor.id}>
                {doctor.full_name}
              </SelectItem>
            ))
          )}
        </SelectContent>
      </Select>
    </div>
  );
}
