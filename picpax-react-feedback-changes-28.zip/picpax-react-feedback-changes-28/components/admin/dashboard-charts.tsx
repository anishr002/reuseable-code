"use client";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";

const COLORS = ["#10b981", "#3b82f6", "#f59e0b", "#ef4444", "#8b5cf6"];

interface DashboardChartsProps {
  className?: string;
}

interface OrdersDistributionChartProps extends DashboardChartsProps {
  ordersData?: Array<{
    status: string;
    count: number;
    color?: string;
  }>;
}

interface DoctorActivityChartProps extends DashboardChartsProps {
  doctorActivityData?: Array<{
    name: string;
    orders: number;
    revenue: number;
  }>;
}

interface RevenueChartProps extends DashboardChartsProps {
  revenueData?: Array<{
    month: string;
    revenue: number;
    commission: number;
  }>;
}

interface CommissionTrendChartProps extends DashboardChartsProps {
  revenueData?: Array<{
    month: string;
    revenue: number;
    commission: number;
  }>;
}

// Default orders data colors mapping
const defaultOrderColors: Record<string, string> = {
  Open: "#6b7280",
  Completed: "#10b981",
  Processing: "#3b82f6",
  Pending: "#f59e0b",
};

export function RevenueChart({ className, revenueData }: RevenueChartProps) {
  // Use provided data or fallback to empty array
  const chartData = revenueData || [];

  // Filter out months with zero revenue and commission for better visualization
  const filteredData = chartData.filter(
    (item) => item.revenue > 0 || item.commission > 0
  );

  // If no data, show a message
  if (chartData.length === 0 || filteredData.length === 0) {
    return (
      <div className={className}>
        <h3 className="text-lg font-semibold mb-4">
          Revenue & Commission Trend
        </h3>
        <div className="flex items-center justify-center h-64 border rounded-lg">
          <div className="text-center text-muted-foreground">
            <p>No revenue data available</p>
            <p className="text-sm">
              Revenue and commission data will appear here
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      <h3 className="text-lg font-semibold mb-4">Revenue & Commission Trend</h3>
      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip
            formatter={(value, name) => [
              `AED ${Number(value).toLocaleString()}`,
              name === "revenue" ? "Revenue" : "Commission",
            ]}
          />
          <Area
            type="monotone"
            dataKey="revenue"
            stackId="1"
            stroke="#3b82f6"
            fill="#3b82f6"
            fillOpacity={0.6}
            name="revenue"
          />
          <Area
            type="monotone"
            dataKey="commission"
            stackId="2"
            stroke="#10b981"
            fill="#10b981"
            fillOpacity={0.4}
            name="commission"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function OrdersDistributionChart({
  className,
  ordersData,
}: OrdersDistributionChartProps) {
  // Use provided data or fallback to empty array
  const chartData = ordersData || [];

  // Ensure each data point has a color
  const dataWithColors = chartData.map((item) => ({
    ...item,
    color:
      item.color ||
      defaultOrderColors[item.status] ||
      COLORS[chartData.indexOf(item) % COLORS.length],
  }));

  // If no data, show a message
  if (chartData.length === 0) {
    return (
      <div className={className}>
        <h3 className="text-lg font-semibold mb-4">Orders Distribution</h3>
        <div className="flex items-center justify-center h-64 border rounded-lg">
          <div className="text-center text-muted-foreground">
            <p>No orders data available</p>
            <p className="text-sm">Order distribution will appear here</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      <h3 className="text-lg font-semibold mb-4">Orders Distribution</h3>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={dataWithColors}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ status, count, percent }) =>
              `${status}: ${count} (${(percent * 100).toFixed(0)}%)`
            }
            outerRadius={80}
            fill="#8884d8"
            dataKey="count"
            nameKey="status"
          >
            {dataWithColors.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export function DoctorActivityChart({
  className,
  doctorActivityData,
}: DoctorActivityChartProps) {
  // Use provided data or fallback to empty array
  const chartData = doctorActivityData || [];

  // Filter out doctors with no orders for better visualization
  const filteredData = chartData.filter((doctor) => doctor.orders > 0);

  // Transform data for better display
  const formattedData = filteredData.map((doctor) => ({
    name:
      doctor.name.length > 15
        ? doctor.name
            .split(" ")
            .map((part, index) => (index === 0 ? part : part[0] + "."))
            .join(" ")
        : doctor.name,
    fullName: doctor.name, // Keep full name for tooltips
    orders: doctor.orders,
    revenue: doctor.revenue,
  }));

  // If no data, show a message
  if (filteredData.length === 0) {
    return (
      <div className={className}>
        <h3 className="text-lg font-semibold mb-4">
          Top Doctors by Performance
        </h3>
        <div className="flex items-center justify-center h-64 border rounded-lg">
          <div className="text-center text-muted-foreground">
            <p>No doctor activity data available</p>
            <p className="text-sm">Doctor performance data will appear here</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      <h3 className="text-lg font-semibold mb-4">Top Doctors by Performance</h3>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart
          data={formattedData}
          layout="vertical" // Changed to vertical for better doctor name display
        >
          <CartesianGrid
            strokeDasharray="3 3"
            horizontal={true}
            vertical={false}
          />
          <XAxis
            type="number"
            tickFormatter={(value) => value.toLocaleString()}
          />
          <YAxis
            dataKey="name"
            type="category"
            width={80}
            tick={{ fontSize: 14 }}
          />
          <Tooltip
            formatter={(value, name) => {
              if (name === "orders") {
                return [`${value} orders`, "Orders"];
              } else if (name === "revenue") {
                return [`AED ${Number(value).toLocaleString()}`, "Revenue"];
              }
              return [value, name];
            }}
            labelFormatter={(label, payload) => {
              if (payload && payload[0]) {
                return payload[0].payload.fullName;
              }
              return label;
            }}
          />
          <Legend />
          <Bar
            dataKey="orders"
            fill="#3b82f6"
            name="Orders"
            radius={[0, 4, 4, 0]}
            barSize={20}
          />
          <Bar
            dataKey="revenue"
            fill="#10b981"
            name="Revenue"
            radius={[0, 4, 4, 0]}
            barSize={20}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function CommissionTrendChart({
  className,
  revenueData,
}: CommissionTrendChartProps) {
  // Use provided data or fallback to empty array
  const chartData = revenueData || [];

  // If no data, show a message
  if (chartData.length === 0) {
    return (
      <div className={className}>
        <h3 className="text-lg font-semibold mb-4">Commission Trend</h3>
        <div className="flex items-center justify-center h-64 border rounded-lg">
          <div className="text-center text-muted-foreground">
            <p>No commission data available</p>
            <p className="text-sm">Commission trends will appear here</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={className}>
      <h3 className="text-lg font-semibold mb-4">Commission Trend</h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis />
          <Tooltip
            formatter={(value) => [
              `AED ${Number(value).toLocaleString()}`,
              "Commission",
            ]}
          />
          <Line
            type="monotone"
            dataKey="commission"
            stroke="#10b981"
            strokeWidth={3}
            dot={{ fill: "#10b981", strokeWidth: 2, r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
