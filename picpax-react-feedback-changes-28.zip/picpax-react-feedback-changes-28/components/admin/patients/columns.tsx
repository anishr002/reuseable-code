"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "@/components/patients/data-table-column-header";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Phone,
  Mail,
  MapPin,
} from "lucide-react";

export type Patient = {
  id: string;
  parent_id: string;
  name: string;
  email: string;
  phone: string;
  addresses: string;
  age: number;
  gender: string;
  lastVisit: string;
  totalOrders: number;
  status: "Active" | "Inactive";
  doctor_name?: string;
  originalData?: any;
};

// Create a separate component for the actions cell
interface ActionsCellProps {
  patient: Patient;
  onViewDetails: (patientId: string) => void;
  onEditPatient: (patient: Patient) => void;
  onDeletePatient: (patientId: any) => void;
  canEdit?: boolean;
  canDelete?: boolean;
}

function ActionsCell({
  patient,
  onViewDetails,
  onEditPatient,
  onDeletePatient,
  canEdit = true,
  canDelete = true,
}: ActionsCellProps) {
  return (
    <div className="min-w-[40px]">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="h-7 w-7 p-0">
            <span className="sr-only">Open menu</span>
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[160px]">
          <DropdownMenuLabel>Actions</DropdownMenuLabel>
          <DropdownMenuItem onClick={() => onViewDetails(patient.id)}>
            <Eye className="mr-2 h-4 w-4" />
            View Details
          </DropdownMenuItem>

          {canEdit && (
            <DropdownMenuItem onClick={() => onEditPatient(patient)}>
              <Edit className="mr-2 h-4 w-4" />
              Edit Patient
            </DropdownMenuItem>
          )}

          {canDelete && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-red-600"
                onClick={() => onDeletePatient(patient)}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete Patient
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

// Create the columns with proper typing and permission controls
interface CreateColumnsOptions {
  canEdit?: boolean;
  canDelete?: boolean;
}

export const createColumns = (
  onViewDetails: (patientId: string) => void,
  onEditPatient: (patient: Patient) => void,
  onDeletePatient: (patientId: string) => void,
  options?: CreateColumnsOptions
): ColumnDef<Patient>[] => [
  {
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Patient" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      const getInitials = (name: string) => {
        if (!name) return "??";
        return name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase()
          .slice(0, 2);
      };

      return (
        <div className="flex items-center space-x-2 min-w-[150px]">
          <Avatar className="h-7 w-7 flex-shrink-0">
            <AvatarFallback className="text-xs font-semibold bg-primary text-primary-foreground">
              {getInitials(patient.name)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-sm truncate">{patient.name}</div>
            <div className="text-xs text-muted-foreground truncate">
              {patient.email}
            </div>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "doctor_name",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Doctor" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="text-xs min-w-[120px]">
          <div className="font-medium truncate">
            {patient.doctor_name || "Not assigned"}
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "contact",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Contact" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="min-w-[180px] space-y-1">
          <div className="flex items-center space-x-1 text-xs">
            <Phone className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate">{patient.phone || "No phone"}</span>
          </div>
          <div className="flex items-start space-x-1 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3 mt-0.5 text-muted-foreground flex-shrink-0" />
            <span className="truncate">
              {patient.addresses || "No address"}
            </span>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "age",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Info" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="text-xs space-y-1 min-w-[80px]">
          <div className="font-medium">
            {patient.age}y, {patient.gender}
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "created_at",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Created At" />
    ),
    cell: ({ row }) => {
      const lastVisit = row.getValue("created_at") as string;
      return (
        <div className="text-xs min-w-[90px]">
          <div className="font-medium">{lastVisit}</div>
        </div>
      );
    },
  },
  {
    accessorKey: "totalOrders",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Orders" />
    ),
    cell: ({ row }) => {
      const totalOrders = row.getValue("totalOrders") as number;
      return (
        <div className="text-center min-w-[60px]">
          <Badge variant="outline" className="text-xs px-2">
            {totalOrders}
          </Badge>
        </div>
      );
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <div className="min-w-[70px]">
          <Badge
            variant={status === "Active" ? "default" : "secondary"}
            className={`text-xs ${
              status === "Active" ? "bg-primary hover:bg-primary/90" : ""
            }`}
          >
            {status}
          </Badge>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <ActionsCell
          patient={patient}
          onViewDetails={onViewDetails}
          onEditPatient={onEditPatient}
          onDeletePatient={onDeletePatient}
          canEdit={options?.canEdit}
          canDelete={options?.canDelete}
        />
      );
    },
  },
];

// Default columns for backward compatibility (without action handlers)
export const columns: ColumnDef<Patient>[] = createColumns(
  () => {},
  () => {},
  () => {}
);
