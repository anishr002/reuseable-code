"use client";

import type React from "react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import {
  getPatientById,
  updatePatient,
  getDoctorsList,
  type Doctor,
} from "@/lib/doctorApi";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, RefreshCw, Loader2 } from "lucide-react";
import {
  getCountriesWithStates,
  type CountryWithStates,
} from "@/services/doctorService";

interface EditPatientModalProps {
  patient: any;
  isOpen: boolean;
  onClose: () => void;
  onPatientUpdated?: () => void;
}

export function EditAdminPatientModal({
  patient,
  isOpen,
  onClose,
  onPatientUpdated,
}: EditPatientModalProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [isLoadingDoctors, setIsLoadingDoctors] = useState(false);
  const [doctorError, setDoctorError] = useState<string>("");
  const [isLoadingCountries, setIsLoadingCountries] = useState(false);
  const [countries, setCountries] = useState<CountryWithStates[]>([]);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    age: "",
    gender: "",
    address: "",
    status: "Active",
    doctor_id: "unassigned",
    // Address fields
    country: "",
    countryName: "",
    villaApartment: "",
    areaStreet: "",
    emirate: "",
    nearbyLandmark: "",
  });

  // Initialize modal - load countries and doctors first, then patient details
  useEffect(() => {
    const initializeModal = async () => {
      if (!isOpen || !patient) return;

      try {
        setIsLoadingCountries(true);
        setIsLoadingDoctors(true);

        // Step 1: Load countries and doctors in parallel
        const [countriesResponse, doctorsResponse] = await Promise.allSettled([
          getCountriesWithStates(),
          getDoctorsList(),
        ]);

        // Handle countries response
        if (countriesResponse.status === "fulfilled") {
          setCountries((countriesResponse.value as any).data);
        } else {
          console.error("Error fetching countries:", countriesResponse.reason);
          toast({
            title: "Error",
            description: "Failed to load countries. Please try again.",
            variant: "destructive",
          });
        }

        // Handle doctors response
        if (doctorsResponse.status === "fulfilled") {
          const doctorsData = doctorsResponse.value;
          if (doctorsData.success) {
            setDoctors(doctorsData.data);
            if (doctorsData.data.length === 0) {
              setDoctorError("No doctors available.");
            }
          } else {
            setDoctorError("Failed to load doctors list.");
          }
        } else {
          console.error("Error fetching doctors:", doctorsResponse.reason);
          setDoctorError("Failed to load doctors list. Please try again.");
        }

        // Step 2: Now load patient details with countries and doctors available
        setIsFetching(true);
        const patientResponse = await getPatientById(patient.id);

        if (patientResponse.success) {
          const patientData: any = patientResponse.data;

          // Find matching doctor from doctors list
          let matchedDoctorId = "unassigned";
          if (
            patientData?.doctor_name &&
            doctorsResponse.status === "fulfilled" &&
            doctorsResponse.value.success
          ) {
            const matchedDoctor = doctorsResponse.value.data.find(
              (doctor) => doctor.name === patientData.doctor_name
            );
            if (matchedDoctor) {
              matchedDoctorId = matchedDoctor.id;
            }
          }

          // Find country code if country exists in patient data
          let countryCode = "";
          let countryName = patientData.country || "";

          if (countryName && countriesResponse.status === "fulfilled") {
            const country = (countriesResponse.value as any).data.find(
              (c: CountryWithStates) =>
                c.country_name.toLowerCase() === countryName.toLowerCase()
            );
            countryCode = country?.country_code || "";
          }

          setFormData({
            firstName: patientData.first_name || "",
            lastName: patientData.last_name || "",
            email: patientData.email || "",
            phone: patientData.phone_number || "",
            age: patientData.age?.toString() || "",
            gender: patientData.gender
              ? capitalizeFirst(patientData.gender)
              : "",
            address: patientData.address || "",
            status: patientData.status
              ? capitalizeFirst(patientData.status)
              : "Active",
            doctor_id: patientData.doctor_id || matchedDoctorId,
            // Address fields from API response
            country: countryCode,
            countryName: countryName,
            villaApartment: patientData.villa_apartment || "",
            areaStreet: patientData.area_street || "",
            emirate: patientData.emirates_states || "",
            nearbyLandmark: patientData.nearby_landmark || "",
          });
        } else {
          throw new Error(
            patientResponse.message || "Failed to fetch patient details"
          );
        }
      } catch (error: any) {
        console.error("Error initializing modal:", error);

        let errorMessage = "Failed to load patient details. Please try again.";

        if (error.response?.data?.message) {
          errorMessage = error.response.data.message;
        } else if (error.message) {
          errorMessage = error.message;
        }

        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });

        // Fallback: use the data from the table if available
        if (patient) {
          let matchedDoctorId = "unassigned";
          if (patient.doctor_name && doctors.length > 0) {
            const matchedDoctor = doctors.find(
              (doctor) => doctor.name === patient.doctor_name
            );
            if (matchedDoctor) {
              matchedDoctorId = matchedDoctor.id;
            }
          }

          setFormData({
            firstName: patient.name?.split(" ")[0] || "",
            lastName: patient.name?.split(" ").slice(1).join(" ") || "",
            email: patient.email || "",
            phone: patient.phone || "",
            age: patient.age?.toString() || "",
            gender: patient.gender ? capitalizeFirst(patient.gender) : "",
            address: patient.addresses || "",
            status: patient.status || "Active",
            doctor_id: patient.originalData?.doctor_id || matchedDoctorId,
            // Address fields
            country: "",
            countryName: patient.country || "",
            villaApartment: patient.villa_apartment || "",
            areaStreet: patient.area_street || "",
            emirate: patient.emirates_states || "",
            nearbyLandmark: patient.nearby_landmark || "",
          });
        }
      } finally {
        setIsLoadingCountries(false);
        setIsLoadingDoctors(false);
        setIsFetching(false);
      }
    };

    initializeModal();
  }, [isOpen, patient, toast]);

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        age: "",
        gender: "",
        address: "",
        status: "Active",
        doctor_id: "unassigned",
        country: "",
        countryName: "",
        villaApartment: "",
        areaStreet: "",
        emirate: "",
        nearbyLandmark: "",
      });
      setDoctors([]);
      setDoctorError("");
      setCountries([]);
    }
  }, [isOpen]);

  const getStatesForSelectedCountry = (): string[] => {
    if (!formData.country) return [];
    const selectedCountry = countries.find(
      (country) => country.country_code === formData.country
    );
    return selectedCountry?.states || [];
  };

  const getCountryNameByCode = (countryCode: string): string => {
    const country = countries.find((c) => c.country_code === countryCode);
    return country?.country_name || "";
  };

  const handleInputChange = (field: string, value: string) => {
    console.log(`Changing ${field} to:`, value);

    setFormData((prev) => {
      const newFormData = { ...prev, [field]: value };

      // Reset emirate and update country name when country changes
      if (field === "country") {
        newFormData.emirate = "";
        newFormData.countryName = getCountryNameByCode(value);
      }

      return newFormData;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // Prepare payload according to API requirements
      const payload: any = {
        first_name: formData.firstName.trim(),
        last_name: formData.lastName.trim(),
        email: formData.email.trim(),
        phone_number: formData.phone.trim(),
        age: formData.age,
        gender: formData.gender.toLowerCase(),
        status: formData.status.toLowerCase(),
        // Use individual address fields as per API response
        country: formData.countryName,
        emirates_states: formData.emirate,
        villa_apartment: formData.villaApartment,
        area_street: formData.areaStreet,
        nearby_landmark: formData.nearbyLandmark,
      };

      // Handle doctor assignment - convert "unassigned" to null for API
      if (formData.doctor_id === "unassigned") {
        payload.doctor_id = null;
      } else {
        payload.doctor_id = formData.doctor_id;
      }

      console.log("Submitting payload:", payload);

      // Make API call to update patient
      const response = await updatePatient(patient.id, payload);

      if (response.success) {
        toast({
          title: "Patient Updated",
          description: `${formData.firstName} ${formData.lastName} has been updated successfully.`,
        });

        // Notify parent component
        if (onPatientUpdated) {
          onPatientUpdated();
        }

        onClose();
      } else {
        throw new Error(response.message || "Failed to update patient");
      }
    } catch (error: any) {
      console.error("Error updating patient:", error);

      let errorMessage = "Failed to update patient. Please try again.";

      // Handle API validation errors
      if (error.response?.data?.errors) {
        const validationErrors = error.response.data.errors;
        errorMessage = Object.values(validationErrors).flat().join(", ");
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const capitalizeFirst = (str: string) => {
    if (!str) return "";
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  };

  const handleClose = () => {
    setFormData({
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      age: "",
      gender: "",
      address: "",
      status: "Active",
      doctor_id: "unassigned",
      country: "",
      countryName: "",
      villaApartment: "",
      areaStreet: "",
      emirate: "",
      nearbyLandmark: "",
    });
    setDoctors([]);
    setDoctorError("");
    setCountries([]);
    onClose();
  };

  const handleRetryDoctors = () => {
    setIsLoadingDoctors(true);
    setDoctorError("");
    getDoctorsList()
      .then((response) => {
        if (response.success) {
          setDoctors(response.data);
          if (response.data.length === 0) {
            setDoctorError("No doctors available.");
          }
        } else {
          setDoctorError("Failed to load doctors list.");
        }
      })
      .catch((error) => {
        console.error("Error fetching doctors:", error);
        setDoctorError("Failed to load doctors list. Please try again.");
      })
      .finally(() => {
        setIsLoadingDoctors(false);
      });
  };

  // Get current doctor name for display
  const getCurrentDoctorName = () => {
    if (formData.doctor_id === "unassigned" || !formData.doctor_id) {
      return "Not assigned";
    }
    const doctor = doctors.find((d) => d.id === formData.doctor_id);
    return doctor ? doctor.name : "Not assigned";
  };

  const states = getStatesForSelectedCountry();

  // Show loading state
  if (isFetching || isLoadingCountries || isLoadingDoctors) {
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Edit Patient</DialogTitle>
            <DialogDescription>Loading patient details...</DialogDescription>
          </DialogHeader>
          <div className="flex justify-center items-center py-12">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-muted-foreground">
                {isLoadingCountries
                  ? "Loading countries..."
                  : isLoadingDoctors
                  ? "Loading doctors..."
                  : "Loading patient details..."}
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!formData.firstName && !formData.lastName) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Patient</DialogTitle>
          <DialogDescription>
            Update the patient's information.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-firstName">First Name *</Label>
                <Input
                  id="edit-firstName"
                  value={formData.firstName}
                  onChange={(e) =>
                    handleInputChange("firstName", e.target.value)
                  }
                  placeholder="John"
                  className="h-9"
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-lastName">Last Name *</Label>
                <Input
                  id="edit-lastName"
                  value={formData.lastName}
                  onChange={(e) =>
                    handleInputChange("lastName", e.target.value)
                  }
                  placeholder="Doe"
                  className="h-9"
                  required
                  disabled={isLoading}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">Email *</Label>
              <Input
                id="edit-email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="john.doe@email.com"
                className="h-9"
                required
                disabled={isLoading}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-phone">Phone Number *</Label>
              <Input
                id="edit-phone"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                placeholder="+971 50 123 4567"
                className="h-9"
                required
                disabled={isLoading}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="edit-age">Age *</Label>
                <Input
                  id="edit-age"
                  type="number"
                  value={formData.age}
                  onChange={(e) => handleInputChange("age", e.target.value)}
                  placeholder="35"
                  className="h-9"
                  min="1"
                  max="120"
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-gender">Gender *</Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) => handleInputChange("gender", value)}
                  disabled={isLoading}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Doctor Selection */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="edit-doctor">Assigned Doctor</Label>
                {doctorError && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleRetryDoctors}
                    disabled={isLoadingDoctors}
                    className="h-7 text-xs"
                  >
                    <RefreshCw
                      className={`h-3 w-3 mr-1 ${
                        isLoadingDoctors ? "animate-spin" : ""
                      }`}
                    />
                    Retry
                  </Button>
                )}
              </div>

              {doctorError ? (
                <Alert variant="destructive" className="py-3">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    {doctorError}
                  </AlertDescription>
                </Alert>
              ) : (
                <Select
                  value={formData.doctor_id}
                  onValueChange={(value) =>
                    handleInputChange("doctor_id", value)
                  }
                  disabled={
                    isLoading || isLoadingDoctors || doctors.length === 0
                  }
                >
                  <SelectTrigger className="h-9">
                    <SelectValue
                      placeholder={
                        isLoadingDoctors
                          ? "Loading doctors..."
                          : doctors.length === 0
                          ? "No doctors available"
                          : getCurrentDoctorName()
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="unassigned">Not assigned</SelectItem>
                    {doctors.map((doctor) => (
                      <SelectItem key={doctor.id} value={doctor.id}>
                        {doctor.name} - {doctor.medical_speciality}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            {/* Status Dropdown */}
            <div className="space-y-2">
              <Label htmlFor="edit-status">Status *</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => handleInputChange("status", value)}
                disabled={isLoading}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Active">Active</SelectItem>
                  <SelectItem value="Inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Address Information */}
            <div className="space-y-4 border-t pt-4">
              <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                Address Information
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-country">Country *</Label>
                  <Select
                    value={formData.country}
                    onValueChange={(value) =>
                      handleInputChange("country", value)
                    }
                    disabled={isLoading}
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue placeholder="Select country" />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem
                          key={country.country_code}
                          value={country.country_code}
                        >
                          {country.country_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="edit-emirate">State/Emirate *</Label>
                  <Select
                    value={formData.emirate}
                    onValueChange={(value) =>
                      handleInputChange("emirate", value)
                    }
                    disabled={
                      !formData.country || states.length === 0 || isLoading
                    }
                  >
                    <SelectTrigger className="h-9">
                      <SelectValue
                        placeholder={
                          !formData.country
                            ? "Select country first"
                            : states.length === 0
                            ? "No states available"
                            : "Select state/emirate"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {states.map((state) => (
                        <SelectItem key={state} value={state}>
                          {state}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="edit-villaApartment">
                    Villa/Apartment Number *
                  </Label>
                  <Input
                    id="edit-villaApartment"
                    value={formData.villaApartment}
                    onChange={(e) =>
                      handleInputChange("villaApartment", e.target.value)
                    }
                    placeholder="Villa 123, Apt 4B"
                    className="h-9"
                    required
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="edit-areaStreet">Area/Street *</Label>
                  <Input
                    id="edit-areaStreet"
                    value={formData.areaStreet}
                    onChange={(e) =>
                      handleInputChange("areaStreet", e.target.value)
                    }
                    placeholder="Al Nahda, Sheikh Zayed Road"
                    className="h-9"
                    required
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="edit-nearbyLandmark">Nearby Landmark</Label>
                  <Input
                    id="edit-nearbyLandmark"
                    value={formData.nearbyLandmark}
                    onChange={(e) =>
                      handleInputChange("nearbyLandmark", e.target.value)
                    }
                    placeholder="Near Dubai Mall, Next to Metro Station"
                    className="h-9"
                    disabled={isLoading}
                  />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              className="h-9 bg-transparent"
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-primary hover:bg-primary/90 h-9"
              disabled={isLoading || isLoadingDoctors}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating Patient...
                </>
              ) : (
                "Update Patient"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
