"use client";

import type React from "react";
import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";
import { DocumentUpload } from "@/components/ui/document-upload";
import type { DocumentFile } from "@/components/ui/document-upload";
import {
  createDoctor,
  getCountriesWithStates,
  type CountryWithStates,
} from "@/services/doctorService";
import { useRouter } from "next/navigation";

interface AddDoctorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDoctorAdded?: () => void;
  isDashboard?: any;
}

interface FormErrors {
  [key: string]: string;
}

export function AddDoctorModal({
  isOpen,
  onClose,
  onDoctorAdded,
  isDashboard = false,
}: AddDoctorModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingCountries, setIsLoadingCountries] = useState(false);
  const [countries, setCountries] = useState<CountryWithStates[]>([]);
  const { toast } = useToast();
  const router = useRouter();

  const [formData, setFormData] = useState({
    title: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    gender: "",
    specialization: "",
    other_speciality: "", // Add this line

    clinicName: "",
    // clinicPractice: "",
    licenseNumber: "",
    yearsOfExperience: "",
    productCommission: "", // Reset new fields
    labtestCommission: "", // Reset new fields
    bio: "",
    country: "",
    countryName: "", // Store country name separately
    villaApartment: "",
    areaStreet: "",
    emirate: "",
    nearbyLandmark: "",
    password: "",
    passwordConfirmation: "",
    status: "active", // Add this line - default to active
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [documents, setDocuments] = useState<DocumentFile[]>([]);

  const specializations = [
    "General Practice",
    "Internal Medicine",
    "Pediatrics",
    "Cardiology",
    "Dermatology",
    "Orthopedics",
    "Neurology",
    "Psychiatry",
    "Oncology",
    "Radiology",
    "Anesthesiology",
    "Emergency Medicine",
    "Family Medicine",
    "Obstetrics & Gynecology",
    "Ophthalmology",
    "Pathology",
    "Surgery",
    "Urology",
    "Other",
  ];

  // Fetch countries and states on component mount
  useEffect(() => {
    const fetchCountries = async () => {
      setIsLoadingCountries(true);
      try {
        const response: any = await getCountriesWithStates();
        setCountries(response.data);
      } catch (error: any) {
        console.error("Error fetching countries:", error);
        toast({
          title: "Error",
          description: "Failed to load countries. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingCountries(false);
      }
    };

    if (isOpen) {
      fetchCountries();
    }
  }, [isOpen, toast]);

  const getStatesForSelectedCountry = (): string[] => {
    if (!formData.country) return [];
    const selectedCountry = countries.find(
      (country) => country.country_code === formData.country
    );
    return selectedCountry?.states || [];
  };

  const getCountryNameByCode = (countryCode: string): string => {
    const country = countries.find((c) => c.country_code === countryCode);
    return country?.country_name || "";
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => {
      const newFormData = { ...prev, [field]: value };

      // Reset emirate and update country name when country changes
      if (field === "country") {
        newFormData.emirate = "";
        newFormData.countryName = getCountryNameByCode(value);
      }
      // Clear other_speciality when switching from "Other" to another specialization
      if (field === "specialization" && value !== "Other") {
        newFormData.other_speciality = "";
      }
      return newFormData;
    });

    // Clear error when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: FormErrors = {};

    // Required fields validation
    const requiredFields = {
      title: "Title is required",
      firstName: "First name is required",
      lastName: "Last name is required",
      email: "Email is required",
      phone: "Phone number is required",
      gender: "Gender is required",
      specialization: "Specialization is required",
      clinicName: "Clinic name is required",
      // clinicPractice: "Clinic practice is required",
      licenseNumber: "License number is required",
      country: "Country is required",
      villaApartment: "Villa/Apartment is required",
      areaStreet: "Area/Street is required",
      emirate: "State/Emirate is required",
      nearbyLandmark: "Nearby Landmark is required", // Add this line

      password: "Password is required",
      passwordConfirmation: "Password confirmation is required",
      status: "Status is required", // Add this line
    };

    Object.entries(requiredFields).forEach(([field, message]) => {
      if (!formData[field as keyof typeof formData]?.trim()) {
        newErrors[field] = message;
      }
    });

    // Email validation
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address";
    }

    // Phone validation - UAE specific with format checking
    if (formData.phone) {
      const phoneWithoutSpaces = formData.phone.replace(/\s/g, "");

      // Check if phone starts with +971
      if (!phoneWithoutSpaces.startsWith("+971")) {
        newErrors.phone =
          "Phone number must start with +971 (UAE country code).";
      }
      // Check total length (+971 + 9 digits = 13 characters)
      else if (phoneWithoutSpaces.length !== 13) {
        newErrors.phone =
          "Phone number must be exactly 9 digits after +971 (e.g., +971501234567).";
      }
      // Validate that only digits follow +971
      else if (!/^\+971\d{9}$/.test(phoneWithoutSpaces)) {
        newErrors.phone = "Please enter only digits after +971 country code.";
      }
    }

    // Password validation
    if (formData.password) {
      if (formData.password.length < 8) {
        newErrors.password = "Password must be at least 8 characters long";
      }
    }

    // Password confirmation
    if (formData.password !== formData.passwordConfirmation) {
      newErrors.passwordConfirmation = "Passwords do not match";
    }

    // Years of experience validation
    if (formData.yearsOfExperience) {
      const years = parseInt(formData.yearsOfExperience);
      if (isNaN(years) || years < 0 || years > 50) {
        newErrors.yearsOfExperience =
          "Years of experience must be between 0 and 50";
      }
    }

    // Product Commission validation
    if (formData.productCommission) {
      const commission = parseFloat(formData.productCommission);
      if (isNaN(commission) || commission < 0 || commission > 100) {
        newErrors.productCommission =
          "Product commission must be between 0 and 100";
      }
    }

    // Lab Test Commission validation
    if (formData.labtestCommission) {
      const commission = parseFloat(formData.labtestCommission);
      if (isNaN(commission) || commission < 0 || commission > 100) {
        newErrors.labtestCommission =
          "Lab test commission must be between 0 and 100";
      }
    }

    // Other specialty validation - only when "Other" is selected
    if (
      formData.specialization === "Other" &&
      !formData.other_speciality?.trim()
    ) {
      newErrors.other_speciality = "Please specify your medical specialty";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Prevent form submission on Enter key in input fields
    if (e.key === "Enter" && e.target instanceof HTMLInputElement) {
      e.preventDefault();
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    e.stopPropagation(); // Prevent event bubbling

    console.log("Form submission triggered"); // Debug log

    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors in the form before submitting.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const fd = new FormData();

      // Append form data
      fd.append("title", formData.title);
      fd.append("first_name", formData.firstName);
      fd.append("last_name", formData.lastName);
      fd.append("email", formData.email);
      fd.append("phone_number", formData.phone);
      fd.append("gender", formData.gender);
      fd.append("medical_speciality", formData.specialization);
      // fd.append("clinic_practice", formData.clinicPractice);
      fd.append("clinic_name", formData.clinicName);
      fd.append("country", formData.countryName); // Send country name instead of code
      fd.append("emirates_states", formData.emirate);
      fd.append("medical_license", formData.licenseNumber);
      fd.append("status", formData.status); // Add this line

      if (formData.yearsOfExperience) {
        fd.append("years_of_experience", formData.yearsOfExperience);
      }
      // Add other_speciality only when "Other" is selected
      if (formData.specialization === "Other" && formData.other_speciality) {
        fd.append("other_speciality", formData.other_speciality);
      }

      // Append both commission fields (allow 0 values)
      if (formData.productCommission !== "") {
        fd.append("product_commission", formData.productCommission);
      }

      if (formData.labtestCommission !== "") {
        fd.append("lab_test_commission", formData.labtestCommission);
      }

      if (formData.bio) {
        fd.append("bio", formData.bio);
      }

      fd.append("villa_apartment", formData.villaApartment);
      fd.append("area_street", formData.areaStreet);

      if (formData.nearbyLandmark) {
        fd.append("nearby_landmark", formData.nearbyLandmark);
      }

      fd.append("password", formData.password);
      fd.append("password_confirmation", formData.passwordConfirmation);

      // Append documents if any
      documents.forEach((doc, index) => {
        if (doc.file) {
          fd.append(`documents[${index}]`, doc.file);
        }
        if (doc.category) {
          fd.append(`document_categories[${index}]`, doc.category);
        }
      });

      console.log("Calling createDoctor API..."); // Debug log
      console.log("Country being sent:", formData.countryName); // Debug log
      const res = await createDoctor(fd);

      toast({
        title: res?.message || "Doctor Created",
        description: `Doctor ${formData.firstName} ${formData.lastName} has been created successfully.`,
      });

      // Reset form
      setFormData({
        title: "",
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        gender: "",
        specialization: "",
        other_speciality: "", // Add this line to reset other_speciality
        clinicName: "",
        // clinicPractice: "",
        licenseNumber: "",
        yearsOfExperience: "",
        productCommission: "", // Reset new fields
        labtestCommission: "", // Reset new fields
        bio: "",
        country: "",
        countryName: "",
        villaApartment: "",
        areaStreet: "",
        emirate: "",
        nearbyLandmark: "",
        password: "",
        passwordConfirmation: "",
        status: "active",
      });

      // Reset documents and errors
      setDocuments([]);
      setErrors({});

      onDoctorAdded?.();
      if (isDashboard) {
        router.push("/admin/doctors");
        onClose();
      } else {
        onClose();
      }
    } catch (error: any) {
      console.error("Error creating doctor:", error);

      // Handle backend validation errors
      if (error?.response?.data?.errors) {
        const backendErrors = error.response.data.errors;
        const formattedErrors: FormErrors = {};

        Object.keys(backendErrors).forEach((key) => {
          formattedErrors[key] = backendErrors[key][0];
        });

        setErrors(formattedErrors);

        toast({
          title: "Validation Error",
          description: "Please check the form for errors.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description:
            error?.response?.data?.message ||
            "Failed to add doctor. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setErrors({});
    setFormData((prev) => ({
      ...prev,
      country: "",
      countryName: "",
      emirate: "",
      productCommission: "", // Reset new fields
      labtestCommission: "", // Reset new fields
      other_speciality: "", // Add this line to reset other_speciality
    }));
    onClose();
  };

  // Fix for document upload triggering form submission
  const handleDocumentUploadChange = (newDocuments: DocumentFile[]) => {
    setDocuments(newDocuments);
  };

  const states = getStatesForSelectedCountry();

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Doctor</DialogTitle>
          <DialogDescription>
            Add a new doctor to the system. All fields marked with * are
            required.
          </DialogDescription>
        </DialogHeader>

        <form
          onSubmit={handleSubmit}
          onKeyDown={handleKeyDown}
          className="space-y-6"
        >
          {/* Personal Information */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Personal Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title *</Label>
                <Select
                  value={formData.title}
                  onValueChange={(value) => handleInputChange("title", value)}
                >
                  <SelectTrigger
                    className={errors.title ? "border-red-500" : ""}
                  >
                    <SelectValue placeholder="Select title" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Mr.">Mr.</SelectItem>
                    <SelectItem value="Ms.">Ms.</SelectItem>
                    <SelectItem value="Dr.">Dr.</SelectItem>
                    <SelectItem value="Mrs.">Mrs.</SelectItem>
                    <SelectItem value="Prof.">Prof.</SelectItem>
                  </SelectContent>
                </Select>
                {errors.title && (
                  <p className="text-sm text-red-500">{errors.title}</p>
                )}
              </div>

              {/* Add Status field here */}
              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => handleInputChange("status", value)}
                >
                  <SelectTrigger
                    className={errors.status ? "border-red-500" : ""}
                  >
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
                {errors.status && (
                  <p className="text-sm text-red-500">{errors.status}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) => handleInputChange("gender", value)}
                >
                  <SelectTrigger
                    className={errors.gender ? "border-red-500" : ""}
                  >
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                {errors.gender && (
                  <p className="text-sm text-red-500">{errors.gender}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) =>
                    handleInputChange("firstName", e.target.value)
                  }
                  className={errors.firstName ? "border-red-500" : ""}
                  required
                />
                {errors.firstName && (
                  <p className="text-sm text-red-500">{errors.firstName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) =>
                    handleInputChange("lastName", e.target.value)
                  }
                  className={errors.lastName ? "border-red-500" : ""}
                  required
                />
                {errors.lastName && (
                  <p className="text-sm text-red-500">{errors.lastName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  className={errors.email ? "border-red-500" : ""}
                  required
                />
                {errors.email && (
                  <p className="text-sm text-red-500">{errors.email}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  placeholder="+971 50 123 4567"
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  className={errors.phone ? "border-red-500" : ""}
                  required
                />
                {errors.phone && (
                  <p className="text-sm text-red-500">{errors.phone}</p>
                )}
              </div>
            </div>
          </div>

          {/* Professional Information */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Professional Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="specialization">Specialization *</Label>
                <Select
                  value={formData.specialization}
                  onValueChange={(value) =>
                    handleInputChange("specialization", value)
                  }
                >
                  <SelectTrigger
                    className={errors.specialization ? "border-red-500" : ""}
                  >
                    <SelectValue placeholder="Select specialization" />
                  </SelectTrigger>
                  <SelectContent>
                    {specializations.map((spec) => (
                      <SelectItem key={spec} value={spec}>
                        {spec}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.specialization && (
                  <p className="text-sm text-red-500">
                    {errors.specialization}
                  </p>
                )}
              </div>
              {/* Add Other Specialty Input - Only shown when "Other" is selected */}
              {formData.specialization === "Other" && (
                <div className="space-y-2">
                  <Label htmlFor="other_speciality">
                    Specify Your Specialty *
                  </Label>
                  <Input
                    id="other_speciality"
                    value={formData.other_speciality}
                    onChange={(e) =>
                      handleInputChange("other_speciality", e.target.value)
                    }
                    placeholder="Enter your medical specialty"
                    className={errors.other_speciality ? "border-red-500" : ""}
                    required
                  />
                  {errors.other_speciality && (
                    <p className="text-sm text-red-500">
                      {errors.other_speciality}
                    </p>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="licenseNumber">License Number *</Label>
                <Input
                  id="licenseNumber"
                  value={formData.licenseNumber}
                  onChange={(e) =>
                    handleInputChange("licenseNumber", e.target.value)
                  }
                  className={errors.licenseNumber ? "border-red-500" : ""}
                  required
                />
                {errors.licenseNumber && (
                  <p className="text-sm text-red-500">{errors.licenseNumber}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="clinicName">Clinic Name *</Label>
                <Input
                  id="clinicName"
                  value={formData.clinicName}
                  onChange={(e) =>
                    handleInputChange("clinicName", e.target.value)
                  }
                  className={errors.clinicName ? "border-red-500" : ""}
                  required
                />
                {errors.clinicName && (
                  <p className="text-sm text-red-500">{errors.clinicName}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="yearsOfExperience">Years of Experience</Label>
                <Input
                  id="yearsOfExperience"
                  type="number"
                  min="0"
                  max="50"
                  value={formData.yearsOfExperience}
                  onChange={(e) =>
                    handleInputChange("yearsOfExperience", e.target.value)
                  }
                  className={errors.yearsOfExperience ? "border-red-500" : ""}
                />
                {errors.yearsOfExperience && (
                  <p className="text-sm text-red-500">
                    {errors.yearsOfExperience}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="productCommission">
                  Product Commission (%)
                </Label>
                <Input
                  id="productCommission"
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={formData.productCommission}
                  onChange={(e) =>
                    handleInputChange("productCommission", e.target.value)
                  }
                  placeholder="0-100"
                  className={errors.productCommission ? "border-red-500" : ""}
                  required
                />
                {errors.productCommission && (
                  <p className="text-sm text-red-500">
                    {errors.productCommission}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="labtestCommission">
                  Lab Test Commission (%)
                </Label>
                <Input
                  id="labtestCommission"
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={formData.labtestCommission}
                  onChange={(e) =>
                    handleInputChange("labtestCommission", e.target.value)
                  }
                  placeholder="0-100"
                  className={errors.labtestCommission ? "border-red-500" : ""}
                  required
                />
                {errors.labtestCommission && (
                  <p className="text-sm text-red-500">
                    {errors.labtestCommission}
                  </p>
                )}
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="bio">Bio *</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => handleInputChange("bio", e.target.value)}
                  placeholder="Brief professional biography..."
                  rows={3}
                  required
                />
              </div>
            </div>
          </div>

          {/* Address Information */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Address Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="country">Country *</Label>
                <Select
                  value={formData.country}
                  onValueChange={(value) => handleInputChange("country", value)}
                  disabled={isLoadingCountries}
                >
                  <SelectTrigger
                    className={errors.country ? "border-red-500" : ""}
                  >
                    <SelectValue
                      placeholder={
                        isLoadingCountries
                          ? "Loading countries..."
                          : "Select country"
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map((country) => (
                      <SelectItem
                        key={country.country_code}
                        value={country.country_code}
                      >
                        {country.country_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.country && (
                  <p className="text-sm text-red-500">{errors.country}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="emirate">State/Emirate *</Label>
                <Select
                  value={formData.emirate}
                  onValueChange={(value) => handleInputChange("emirate", value)}
                  disabled={!formData.country || states.length === 0}
                >
                  <SelectTrigger
                    className={errors.emirate ? "border-red-500" : ""}
                  >
                    <SelectValue
                      placeholder={
                        !formData.country
                          ? "Select country first"
                          : states.length === 0
                          ? "No states available"
                          : "Select state/emirate"
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.emirate && (
                  <p className="text-sm text-red-500">{errors.emirate}</p>
                )}
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="villaApartment">Villa/Apartment Number *</Label>
                <Input
                  id="villaApartment"
                  value={formData.villaApartment}
                  onChange={(e) =>
                    handleInputChange("villaApartment", e.target.value)
                  }
                  placeholder="Villa 123, Apt 4B"
                  className={errors.villaApartment ? "border-red-500" : ""}
                  required
                />
                {errors.villaApartment && (
                  <p className="text-sm text-red-500">
                    {errors.villaApartment}
                  </p>
                )}
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="areaStreet">Area/Street *</Label>
                <Input
                  id="areaStreet"
                  value={formData.areaStreet}
                  onChange={(e) =>
                    handleInputChange("areaStreet", e.target.value)
                  }
                  placeholder="Al Nahda, Sheikh Zayed Road"
                  className={errors.areaStreet ? "border-red-500" : ""}
                  required
                />
                {errors.areaStreet && (
                  <p className="text-sm text-red-500">{errors.areaStreet}</p>
                )}
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="nearbyLandmark">Nearby Landmark *</Label>
                <Input
                  id="nearbyLandmark"
                  value={formData.nearbyLandmark}
                  onChange={(e) =>
                    handleInputChange("nearbyLandmark", e.target.value)
                  }
                  placeholder="Near Dubai Mall, Next to Metro Station"
                  required
                />
                {errors.nearbyLandmark && (
                  <p className="text-sm text-red-500">
                    {errors.nearbyLandmark}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Account Security */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Account Security
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="password">Password *</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) =>
                    handleInputChange("password", e.target.value)
                  }
                  className={errors.password ? "border-red-500" : ""}
                  required
                />
                {errors.password && (
                  <p className="text-sm text-red-500">{errors.password}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="passwordConfirmation">Confirm Password *</Label>
                <Input
                  id="passwordConfirmation"
                  type="password"
                  value={formData.passwordConfirmation}
                  onChange={(e) =>
                    handleInputChange("passwordConfirmation", e.target.value)
                  }
                  className={
                    errors.passwordConfirmation ? "border-red-500" : ""
                  }
                  required
                />
                {errors.passwordConfirmation && (
                  <p className="text-sm text-red-500">
                    {errors.passwordConfirmation}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Document Upload Section */}
          {/* Document Upload Section */}
          <div
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
              }
            }}
          >
            <DocumentUpload
              documents={documents}
              onDocumentsChange={handleDocumentUploadChange}
              // categories={[
              //   "Medical License",
              //   "Degree Certificate",
              //   "ID Proof",
              //   "Clinic Registration",
              //   "Insurance Document",
              //   "Other",
              // ]}
              title="Required Documents"
              description="Upload required documents for doctor verification. All documents are securely stored and encrypted."
            />
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-primary hover:bg-primary/90"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Adding Doctor...
                </>
              ) : (
                "Add Doctor"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
