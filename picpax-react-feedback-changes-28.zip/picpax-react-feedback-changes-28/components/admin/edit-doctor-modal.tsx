"use client";

import type React from "react";
import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  updateDoctor,
  getCountriesWithStates,
  type CountryWithStates,
} from "@/services/doctorService";

// Interface for Doctor Form Data
interface DoctorFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  specialization: string;
  other_speciality: string; // Add this line

  licenseNumber: string;
  yearsOfExperience: string;
  productCommission: string; // New field
  labtestCommission: string; // New field
  bio: string;
  country: string;
  countryName: string;
  villaApartment: string;
  areaStreet: string;
  emirate: string;
  nearbyLandmark: string;
  status: string;
}

// Interface for Doctor (based on mockDoctors)
export interface Doctor {
  id: string;
  name: string;
  first_name: string;
  last_name: string;
  email: string;
  phone: string;
  clinic: string;
  address: string;
  status: string;
  patients: number;
  totalOrders: number;
  joinDate: string;
  commission: number;
  specialization: string;
  license: string;
  experience: string;
  education: string;
  bio: string;
  doctor: string;
  country?: string;
  emirates_states?: string;
  product_commission?: any;
  lab_test_commission?: any;
}

interface EditDoctorModalProps {
  isOpen: boolean;
  onClose: () => void;
  doctor: Doctor | null;
  onDoctorUpdated: (updatedDoctor: Doctor) => void;
}

export function EditDoctorModal({
  isOpen,
  onClose,
  doctor,
  onDoctorUpdated,
}: EditDoctorModalProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingCountries, setIsLoadingCountries] = useState(false);
  const [isLoadingDoctor, setIsLoadingDoctor] = useState(false);
  const [countries, setCountries] = useState<CountryWithStates[]>([]);
  const [formData, setFormData] = useState<DoctorFormData | null>(null);
  const [doctorDetail, setDoctorDetail] = useState<any>(null);
  const { toast } = useToast();

  const specializations = [
    "General Practice",
    "Internal Medicine",
    "Pediatrics",
    "Cardiology",
    "Dermatology",
    "Orthopedics",
    "Neurology",
    "Psychiatry",
    "Oncology",
    "Radiology",
    "Anesthesiology",
    "Emergency Medicine",
    "Family Medicine",
    "Obstetrics & Gynecology",
    "Ophthalmology",
    "Pathology",
    "Surgery",
    "Urology",
    "Other",
  ];

  // Initialize modal - load countries first, then doctor details
  useEffect(() => {
    const initializeModal = async () => {
      if (!isOpen || !doctor) return;

      try {
        setIsLoadingCountries(true);

        // Step 1: Load countries first
        const countriesResponse: any = await getCountriesWithStates();
        setCountries(countriesResponse.data);

        // Step 2: Now load doctor details with countries available
        setIsLoadingDoctor(true);
        const doctorService = (await import("@/services/doctorService"))
          .default;
        const doctorResponse = await doctorService.getDoctor(doctor.id);
        setDoctorDetail(doctorResponse.data);

        // Step 3: Set form data with both countries and doctor details
        const detailedDoctor = mapDetailToDoctor(
          doctorResponse.data,
          countriesResponse.data
        );
        setFormData(detailedDoctor);
      } catch (error: any) {
        console.error("Error initializing modal:", error);
        toast({
          title: "Error",
          description: "Failed to load doctor details. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsLoadingCountries(false);
        setIsLoadingDoctor(false);
      }
    };

    initializeModal();
  }, [isOpen, doctor, toast]);

  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setFormData(null);
      setDoctorDetail(null);
      setCountries([]);
    }
  }, [isOpen]);

  // Helper function to map doctor detail to form data with countries
  const mapDetailToDoctor = (
    d: any,
    countriesList: CountryWithStates[]
  ): DoctorFormData => {
    const address = [
      d.villa_apartment,
      d.area_street,
      d.emirates_states,
      d.nearby_landmark,
    ]
      .filter((p: any) => p && String(p).trim() !== "")
      .join(", ");

    // Find country code from country name
    const findCountryCodeByName = (countryName: string): string => {
      const country = countriesList.find(
        (c) => c.country_name.toLowerCase() === countryName?.toLowerCase()
      );
      return country?.country_code || "";
    };

    const doctorCountry = d.country || "";
    const countryCode = doctorCountry
      ? findCountryCodeByName(doctorCountry)
      : "";
    const normalizedStatus = d.status ? d.status.toLowerCase() : "active";

    return {
      firstName: d.first_name || "",
      lastName: d.last_name || "",
      email: d.email || "",
      phone: d.phone_number || "",
      specialization: d.medical_speciality || "",
      other_speciality: d.other_speciality || "", // Add this line

      licenseNumber: d.medical_license || "",
      yearsOfExperience: String(d.years_of_experience || ""),
      productCommission: String(d.product_commission || "0"), // New field
      labtestCommission: String(d.lab_test_commission || "0"), // New field
      bio: d.bio || "",
      country: countryCode,
      countryName: doctorCountry,
      villaApartment: d.villa_apartment || "",
      areaStreet: d.area_street || "",
      emirate: d.emirates_states || "",
      nearbyLandmark: d.nearby_landmark || "",
      status: normalizedStatus,
    };
  };

  const getStatesForSelectedCountry = (): string[] => {
    if (!formData?.country) return [];
    const selectedCountry = countries.find(
      (country) => country.country_code === formData.country
    );
    return selectedCountry?.states || [];
  };

  const getCountryNameByCode = (countryCode: string): string => {
    const country = countries.find((c) => c.country_code === countryCode);
    return country?.country_name || "";
  };

  const handleInputChange = (field: keyof DoctorFormData, value: string) => {
    setFormData((prev) => {
      if (!prev) return null;

      const newFormData = { ...prev, [field]: value };

      // Reset emirate and update country name when country changes
      if (field === "country") {
        newFormData.emirate = "";
        newFormData.countryName = getCountryNameByCode(value);
      }
      // Clear other_speciality when switching from "Other" to another specialization
      if (field === "specialization" && value !== "Other") {
        newFormData.other_speciality = "";
      }
      return newFormData;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData || !doctor) return;

    // Validate required fields
    if (
      !formData.firstName ||
      !formData.lastName ||
      !formData.email ||
      !formData.phone ||
      !formData.specialization ||
      !formData.licenseNumber ||
      !formData.country ||
      !formData.villaApartment ||
      !formData.areaStreet ||
      !formData.emirate ||
      !formData.status ||
      (formData.specialization === "Other" && !formData.other_speciality.trim()) // Add this validation
    ) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      const payload: any = {
        first_name: formData.firstName,
        last_name: formData.lastName,
        phone_number: formData.phone,
        medical_speciality: formData.specialization,
        // Add other_speciality only when "Other" is selected
        ...(formData.specialization === "Other" && {
          other_speciality: formData.other_speciality,
        }),
        medical_license: formData.licenseNumber,
        years_of_experience: formData.yearsOfExperience
          ? Number(formData.yearsOfExperience)
          : undefined,
        product_commission:
          formData.productCommission !== ""
            ? Number(formData.productCommission)
            : undefined,
        lab_test_commission:
          formData.labtestCommission !== ""
            ? Number(formData.labtestCommission)
            : undefined,
        bio: formData.bio,
        country: formData.countryName,
        villa_apartment: formData.villaApartment,
        area_street: formData.areaStreet,
        nearby_landmark: formData.nearbyLandmark,
        emirates_states: formData.emirate,
        status: formData.status,
      };

      if (formData.email) payload.email = formData.email;

      const res = await updateDoctor(doctor.id, payload);

      toast({
        title: res?.message || "Doctor updated successfully.",
      });

      onDoctorUpdated(doctor);
      onClose();
    } catch (error: any) {
      console.error("Error updating doctor:", error);

      // Handle backend validation errors
      if (error?.response?.data?.errors) {
        const backendErrors = error.response.data.errors;

        const errorMessages = Object.entries(backendErrors)
          .map(([field, messages]) => {
            const fieldName = field
              .replace(/_/g, " ")
              .replace(/\b\w/g, (l) => l.toUpperCase());
            const messageList = (messages as string[]).join(", ");
            return `${fieldName}: ${messageList}`;
          })
          .join("\n");

        toast({
          title: "Validation Error",
          description: errorMessages,
          variant: "destructive",
        });
      } else if (error?.response?.data?.message) {
        toast({
          title: "Error",
          description: error.response.data.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: "Failed to update doctor. Please try again.",
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setFormData(null);
    setDoctorDetail(null);
    onClose();
  };

  const states = formData ? getStatesForSelectedCountry() : [];

  // Show loading state
  if (isLoadingCountries || isLoadingDoctor) {
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Edit Doctor Information</DialogTitle>
            <DialogDescription>Loading doctor details...</DialogDescription>
          </DialogHeader>
          <div className="flex justify-center items-center py-12">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-muted-foreground">
                {isLoadingCountries
                  ? "Loading countries..."
                  : "Loading doctor details..."}
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!formData) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Doctor Information</DialogTitle>
          <DialogDescription>
            Update {doctor?.name}'s information and settings.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Personal Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) =>
                    handleInputChange("firstName", e.target.value)
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) =>
                    handleInputChange("lastName", e.target.value)
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => handleInputChange("status", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => handleInputChange("phone", e.target.value)}
                  required
                />
              </div>
            </div>
          </div>

          {/* Professional Information */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Professional Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="specialization">Specialization *</Label>
                <Select
                  value={formData.specialization}
                  onValueChange={(value) =>
                    handleInputChange("specialization", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select specialization" />
                  </SelectTrigger>
                  <SelectContent>
                    {specializations.map((spec) => (
                      <SelectItem key={spec} value={spec}>
                        {spec}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {/* Add Other Specialty Input - Only shown when "Other" is selected */}
              {formData.specialization === "Other" && (
                <div className="space-y-2">
                  <Label htmlFor="other_speciality">
                    Specify Your Specialty *
                  </Label>
                  <Input
                    id="other_speciality"
                    value={formData.other_speciality}
                    onChange={(e) =>
                      handleInputChange("other_speciality", e.target.value)
                    }
                    placeholder="Enter your medical specialty"
                    required
                  />
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="licenseNumber">License Number *</Label>
                <Input
                  id="licenseNumber"
                  value={formData.licenseNumber}
                  onChange={(e) =>
                    handleInputChange("licenseNumber", e.target.value)
                  }
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="yearsOfExperience">Years of Experience</Label>
                <Input
                  id="yearsOfExperience"
                  type="number"
                  min="0"
                  max="50"
                  value={formData.yearsOfExperience}
                  onChange={(e) =>
                    handleInputChange("yearsOfExperience", e.target.value)
                  }
                />
              </div>

              {/* New Commission Fields */}
              <div className="space-y-2">
                <Label htmlFor="productCommission">
                  Product Commission (%)
                </Label>
                <Input
                  id="productCommission"
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={formData.productCommission}
                  onChange={(e) =>
                    handleInputChange("productCommission", e.target.value)
                  }
                  placeholder="0-100"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="labtestCommission">
                  Lab Test Commission (%)
                </Label>
                <Input
                  id="labtestCommission"
                  type="number"
                  min="0"
                  max="100"
                  step="0.01"
                  value={formData.labtestCommission}
                  onChange={(e) =>
                    handleInputChange("labtestCommission", e.target.value)
                  }
                  placeholder="0-100"
                  required
                />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => handleInputChange("bio", e.target.value)}
                  placeholder="Brief professional biography..."
                  rows={3}
                />
              </div>
            </div>
          </div>

          {/* Address Information */}
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
              Address Information
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="country">Country *</Label>
                <Select
                  value={formData.country}
                  onValueChange={(value) => handleInputChange("country", value)}
                  disabled={isLoadingCountries}
                >
                  <SelectTrigger>
                    <SelectValue
                      placeholder={
                        isLoadingCountries
                          ? "Loading countries..."
                          : "Select country"
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map((country) => (
                      <SelectItem
                        key={country.country_code}
                        value={country.country_code}
                      >
                        {country.country_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="emirate">State/Emirate *</Label>
                <Select
                  value={formData.emirate}
                  onValueChange={(value) => handleInputChange("emirate", value)}
                  disabled={!formData.country || states.length === 0}
                >
                  <SelectTrigger>
                    <SelectValue
                      placeholder={
                        !formData.country
                          ? "Select country first"
                          : states.length === 0
                          ? "No states available"
                          : "Select state/emirate"
                      }
                    />
                  </SelectTrigger>
                  <SelectContent>
                    {states.map((state) => (
                      <SelectItem key={state} value={state}>
                        {state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="villaApartment">Villa/Apartment Number *</Label>
                <Input
                  id="villaApartment"
                  value={formData.villaApartment}
                  onChange={(e) =>
                    handleInputChange("villaApartment", e.target.value)
                  }
                  placeholder="Villa 123, Apt 4B"
                  required
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="areaStreet">Area/Street *</Label>
                <Input
                  id="areaStreet"
                  value={formData.areaStreet}
                  onChange={(e) =>
                    handleInputChange("areaStreet", e.target.value)
                  }
                  placeholder="Al Nahda, Sheikh Zayed Road"
                  required
                />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="nearbyLandmark">Nearby Landmark *</Label>
                <Input
                  id="nearbyLandmark"
                  value={formData.nearbyLandmark}
                  onChange={(e) =>
                    handleInputChange("nearbyLandmark", e.target.value)
                  }
                  placeholder="Near Dubai Mall, Next to Metro Station"
                  required
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex justify-end space-x-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={isLoading}
              className="bg-primary hover:bg-primary/90"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Updating Doctor...
                </>
              ) : (
                "Update Doctor"
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
