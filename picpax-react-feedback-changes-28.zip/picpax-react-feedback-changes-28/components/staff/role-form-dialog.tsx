"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Shield, Settings } from "lucide-react";
import { Role } from "@/lib/staff-types";
import { staffService } from "@/lib/staff-service";
import { useToast } from "@/hooks/use-toast";

interface RoleFormDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Role) => void;
  role?: Role | null;
  isEditing?: boolean;
}

interface ApiPermission {
  id: number;
  name: string;
  action: string;
}

interface ModulePermissions {
  name: string;
  permissions: ApiPermission[];
}

// Define role types
type RoleType = "system" | "default";

export function RoleFormDialog({
  isOpen,
  onClose,
  onSubmit,
  role,
  isEditing = false,
}: RoleFormDialogProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: role?.name || "",
    description: role?.description || "",
    type: (role?.type as any) || "default",
    selectedPermissions: Array.isArray(role?.permissions)
      ? role.permissions.map((p) => p?.id)
      : [],
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [availablePermissions, setAvailablePermissions] = useState<
    ModulePermissions[]
  >([]);
  const [actions, setActions] = useState<string[]>([]);

  // Reset form when dialog opens/closes or role changes
  useEffect(() => {
    if (isOpen) {
      setFormData({
        name: role?.name || "",
        description: role?.description || "",
        type: (role?.type as RoleType) || "default",
        selectedPermissions: Array.isArray(role?.permissions)
          ? role.permissions.map((p) => p?.id)
          : [],
      });
      loadPermissions();

      // If editing, fetch the latest role data
      if (isEditing && role?.id) {
        setIsLoading(true);
        fetchRoleDetails(role.id);
      }
    }
  }, [isOpen, role]);

  // Fetch role details from API
  const fetchRoleDetails = async (roleId: string) => {
    try {
      const roleDetails = await staffService.getRole(roleId);

      if (roleDetails) {
        setFormData({
          name: roleDetails.name || "",
          description: roleDetails.description || "",
          type: (roleDetails.type as RoleType) || "default",
          selectedPermissions: Array.isArray(roleDetails.permissions)
            ? roleDetails.permissions.map((p) => p.id)
            : [],
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load role details",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Load permissions when dialog opens
  const loadPermissions = async () => {
    try {
      setIsLoading(true);
      const response = await staffService.getPermissionsApiFormat();

      if (response.success) {
        setAvailablePermissions(response.data.permissions);
        setActions(response.data.module.actions);
      } else {
        throw new Error("Failed to fetch permissions");
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load permissions",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form
    if (!formData.name.trim() || !formData.description.trim()) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill in all required fields",
      });
      return;
    }

    if (formData.selectedPermissions.length === 0) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please select at least one permission",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      if (isEditing && role) {
        // For editing, use the API
        const updatedRole = await staffService.updateRole(role.id, {
          name: formData.name,
          description: formData.description,
          type: formData.type,
          permissionIds: formData.selectedPermissions,
        });
        onSubmit(updatedRole);
        toast({
          title: "Success",
          description: "Role updated successfully",
        });
      } else {
        // For creating, use the API
        const newRole = await staffService.createRole({
          name: formData.name,
          description: formData.description,
          type: formData.type,
          permissionIds: formData.selectedPermissions,
        });
        onSubmit(newRole);
        toast({
          title: "Success",
          description: "Role created successfully",
        });
      }
      onClose();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to save role",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePermissionToggle = (permissionId: string) => {
    setFormData((prev) => ({
      ...prev,
      selectedPermissions: prev.selectedPermissions.includes(permissionId)
        ? prev.selectedPermissions.filter((id) => id !== permissionId)
        : [...prev.selectedPermissions, permissionId],
    }));
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleTypeChange = (value: RoleType) => {
    setFormData((prev) => ({ ...prev, type: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[85vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            {isEditing ? "Edit Role" : "Create New Role"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update role information and assigned permissions"
              : "Create a new role with specific permissions"}
          </DialogDescription>
        </DialogHeader>

        {isLoading && isEditing ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading role data...</p>
            </div>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="flex flex-col flex-1 space-y-4"
          >
            {/* Basic Role Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-shrink-0">
              <div>
                <Label htmlFor="name">Role Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter role name"
                  required
                  disabled={isSubmitting || isLoading}
                />
              </div>

              <div>
                <Label htmlFor="type">Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={handleTypeChange}
                  disabled={isSubmitting || isLoading}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="system">System</SelectItem>
                    <SelectItem value="default">Default</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="md:col-span-2">
                <Label htmlFor="description">Description *</Label>
                <Input
                  id="description"
                  value={formData.description}
                  onChange={(e) =>
                    handleInputChange("description", e.target.value)
                  }
                  placeholder="Enter role description"
                  required
                  disabled={isSubmitting || isLoading}
                />
              </div>
            </div>

            {/* Permissions Section */}
            <div className="flex-1 min-h-0 flex flex-col">
              <Label className="flex items-center gap-2 flex-shrink-0">
                <Settings className="h-4 w-4" />
                Permissions ({formData.selectedPermissions.length} selected)
              </Label>

              {isLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                    <p className="text-muted-foreground">
                      Loading permissions...
                    </p>
                  </div>
                </div>
              ) : (
                <Card className="mt-2 flex-1 flex flex-col">
                  <CardContent className="p-0 flex-1 flex flex-col">
                    <div className="rounded-md border flex-1 overflow-hidden">
                      <div className="overflow-auto h-full max-h-[240px]">
                        <table className="w-full">
                          <thead className="sticky top-0 bg-background border-b">
                            <tr>
                              <th className="h-12 px-4 text-left align-middle font-medium min-w-[120px]">
                                Module
                              </th>
                              {actions.map((action) => (
                                <th
                                  key={action}
                                  className="h-12 px-4 text-center align-middle font-medium w-16 capitalize"
                                >
                                  {action}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {availablePermissions.map((module) => (
                              <tr
                                key={module.name}
                                className="border-b hover:bg-muted/50"
                              >
                                <td className="p-3 align-middle">
                                  <div className="flex items-center justify-between">
                                    <div className="font-medium capitalize text-sm">
                                      {module.name}
                                    </div>
                                  </div>
                                </td>
                                {actions.map((action) => {
                                  const permission = module.permissions.find(
                                    (p) => p.action === action.toLowerCase()
                                  );

                                  return (
                                    <td
                                      key={`${module.name}-${action}`}
                                      className="p-3 align-middle"
                                    >
                                      <div className="flex justify-center">
                                        <input
                                          type="checkbox"
                                          checked={
                                            permission
                                              ? formData.selectedPermissions.includes(
                                                  permission.id.toString()
                                                )
                                              : false
                                          }
                                          onChange={() =>
                                            permission &&
                                            handlePermissionToggle(
                                              permission.id.toString()
                                            )
                                          }
                                          disabled={!permission || isSubmitting}
                                          className="h-4 w-4"
                                        />
                                      </div>
                                    </td>
                                  );
                                })}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            <DialogFooter className="flex-shrink-0 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isSubmitting || isLoading}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={
                  isSubmitting ||
                  isLoading ||
                  formData.selectedPermissions.length === 0
                }
              >
                {isSubmitting
                  ? "Saving..."
                  : isEditing
                  ? "Update Role"
                  : "Create Role"}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
