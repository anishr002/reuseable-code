"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { User, Lock, Loader2 } from "lucide-react";
import { StaffMember, Role } from "@/lib/staff-types";
import { staffService } from "@/lib/staff-service";
import { useToast } from "@/hooks/use-toast";

interface StaffFormDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
  staff?: StaffMember | null;
  isEditing?: boolean;
}

export function StaffFormDialog({
  isOpen,
  onClose,
  onSubmit,
  staff,
  isEditing = false,
}: StaffFormDialogProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone_number: "",
    password: "",
    password_confirmation: "",
    role: "",
    department: "",
    status: "active",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingRoles, setIsLoadingRoles] = useState(false);
  const [isLoadingStaffDetails, setIsLoadingStaffDetails] = useState(false);
  const [availableRoles, setAvailableRoles] = useState<Role[]>([]);
  const [isInitialized, setIsInitialized] = useState(false);

  // Load roles when dialog opens
  useEffect(() => {
    if (isOpen) {
      loadRoles();
    }
  }, [isOpen]);

  // Initialize form data when staff prop changes or when roles are loaded
  useEffect(() => {
    if (isOpen && availableRoles.length > 0) {
      if (isEditing && staff) {
        // For editing: load staff details and set form data
        loadStaffDetails(staff.id);
      } else {
        // For new staff: set initial empty form
        setFormData({
          name: "",
          email: "",
          phone_number: "",
          password: "",
          password_confirmation: "",
          role: "",
          department: "",
          status: "active",
        });
        setIsInitialized(true);
      }
    }
  }, [isOpen, isEditing, staff, availableRoles]);

  const loadRoles = async () => {
    setIsLoadingRoles(true);
    try {
      const roles = await staffService.getRoles();
      setAvailableRoles(roles);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load roles",
      });
    } finally {
      setIsLoadingRoles(false);
    }
  };

  const loadStaffDetails = async (staffId: string) => {
    setIsLoadingStaffDetails(true);
    try {
      const staffDetails = await staffService.getStaffMember(staffId);
      if (staffDetails) {
        console.log("Staff details loaded:", staffDetails);
        console.log("Staff role:", staffDetails.role);
        console.log("Available roles:", availableRoles);

        // Find the matching role ID from available roles
        let roleId = "";
        if (staffDetails.role) {
          // Try to find by ID first
          const matchedRole = availableRoles.find(
            (role) => role.id === staffDetails.role?.id
          );

          if (matchedRole) {
            roleId = matchedRole.id;
          } else {
            // Fallback: try to find by name if ID doesn't match
            const matchedByName = availableRoles.find(
              (role) => role.name === staffDetails.role?.name
            );
            if (matchedByName) {
              roleId = matchedByName.id;
            } else {
              // Use the role ID from staff details as last resort
              roleId = staffDetails.role.id;
            }
          }
        }

        setFormData({
          name: staffDetails.name || "",
          email: staffDetails.email || "",
          phone_number: staffDetails.phone || "",
          password: "",
          password_confirmation: "",
          department: staffDetails.department || "",
          role: roleId,
          status: staffDetails.status || "active",
        });

        console.log("Form data set with role:", roleId);
        setIsInitialized(true);
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load staff details",
      });
    } finally {
      setIsLoadingStaffDetails(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Password validation for new staff only
    if (!isEditing) {
      if (!formData.password) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Password is required",
        });
        return;
      }
      if (formData.password !== formData.password_confirmation) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Passwords do not match",
        });
        return;
      }
      if (formData.password.length < 8) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Password must be at least 8 characters long",
        });
        return;
      }
    }

    setIsLoading(true);

    try {
      if (isEditing && staff) {
        // Prepare update data
        const updateData: any = {
          name: formData.name,
          email: formData.email,
          phone_number: formData.phone_number,
          department: formData.department,
          role: formData.role,
          status: formData.status,
        };

        // Include password only if provided
        if (formData.password) {
          if (formData.password !== formData.password_confirmation) {
            toast({
              variant: "destructive",
              title: "Error",
              description: "Passwords do not match",
            });
            setIsLoading(false);
            return;
          }
          if (formData.password.length < 8) {
            toast({
              variant: "destructive",
              title: "Error",
              description: "Password must be at least 8 characters long",
            });
            setIsLoading(false);
            return;
          }
          updateData.password = formData.password;
          updateData.password_confirmation = formData.password_confirmation;
        }

        const updatedStaff = await staffService.updateStaffMember(
          staff.id,
          updateData
        );
        onSubmit(updatedStaff);
        toast({
          title: "Success",
          description: "Staff member updated successfully",
        });
      } else {
        // For new staff creation
        const newStaff = await staffService.createStaffMember({
          name: formData.name,
          email: formData.email,
          phone_number: formData.phone_number,
          password: formData.password,
          password_confirmation: formData.password_confirmation,
          role: formData.role,
          department: formData.department,
          status: formData.status,
        });
        onSubmit(newStaff);
        toast({
          title: "Success",
          description: "Staff member created successfully",
        });
      }
      onClose();
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to save staff member",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      phone_number: "",
      password: "",
      password_confirmation: "",
      role: "",
      department: "",
      status: "active",
    });
    setIsInitialized(false);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  // Show loading state while roles are loading
  if (isLoadingRoles) {
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              {isEditing ? "Edit Staff Member" : "Add New Staff Member"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex items-center justify-center py-8">
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Loading roles...</span>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Show loading state while staff details are loading
  if (isEditing && isLoadingStaffDetails) {
    return (
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Edit Staff Member
            </DialogTitle>
          </DialogHeader>
          <div className="flex items-center justify-center py-8">
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Loading staff details...</span>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  // Debug information (you can remove this in production)
  console.log("Current form data:", formData);
  console.log("Available roles:", availableRoles);
  console.log("Selected role in form:", formData.role);
  console.log(
    "Matching role:",
    availableRoles.find((r) => r.id === formData.role)
  );

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[85vh] flex flex-col">
        <DialogHeader className="flex-shrink-0">
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            {isEditing ? "Edit Staff Member" : "Add New Staff Member"}
          </DialogTitle>
          <DialogDescription>
            {isEditing
              ? "Update staff member information and role assignment"
              : "Create a new staff member account with appropriate role and permissions"}
          </DialogDescription>
        </DialogHeader>

        <form
          onSubmit={handleSubmit}
          className="flex-1 flex flex-col space-y-6 overflow-hidden"
        >
          <div className="flex-1 overflow-y-auto space-y-4">
            {/* Basic Information */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-sm font-medium">
                  Full Name *
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => handleInputChange("name", e.target.value)}
                  placeholder="Enter full name"
                  required
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="email" className="text-sm font-medium">
                  Email Address *
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                  placeholder="Enter email address"
                  required
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="phone_number" className="text-sm font-medium">
                  Phone Number *
                </Label>
                <Input
                  id="phone_number"
                  value={formData.phone_number}
                  onChange={(e) =>
                    handleInputChange("phone_number", e.target.value)
                  }
                  placeholder="Enter phone number"
                  required
                  className="mt-1"
                />
              </div>

              {/* Password fields */}
              {!isEditing && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="password" className="text-sm font-medium">
                      Password *
                    </Label>
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) =>
                        handleInputChange("password", e.target.value)
                      }
                      placeholder="Enter password"
                      required={!isEditing}
                      className="mt-1"
                    />

                    <p className="text-xs text-muted-foreground mt-1">
                      Password must be at least 8 characters long
                    </p>
                  </div>

                  <div>
                    <Label
                      htmlFor="password_confirmation"
                      className="text-sm font-medium"
                    >
                      Confirm Password *
                    </Label>
                    <Input
                      id="password_confirmation"
                      type="password"
                      value={formData.password_confirmation}
                      onChange={(e) =>
                        handleInputChange(
                          "password_confirmation",
                          e.target.value
                        )
                      }
                      placeholder="Confirm password"
                      required={!isEditing}
                      className="mt-1"
                    />
                  </div>
                </div>
              )}

              <div>
                <Label htmlFor="department" className="text-sm font-medium">
                  Department
                </Label>
                <Input
                  id="department"
                  value={formData.department}
                  onChange={(e) =>
                    handleInputChange("department", e.target.value)
                  }
                  placeholder="Enter department"
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="role" className="text-sm font-medium">
                  Role *
                </Label>
                <Select
                  value={formData.role}
                  onValueChange={(value) => handleInputChange("role", value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select a role">
                      {formData.role &&
                        availableRoles.find((r) => r.id === formData.role)
                          ?.name}
                    </SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    {availableRoles.map((role) => (
                      <SelectItem key={role.id} value={role.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">{role.name}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {formData.role && (
                <div>
                  <Label className="text-sm font-medium">
                    Role Permissions
                  </Label>
                  <Card className="mt-1">
                    <CardContent className="p-3">
                      <div className="flex flex-wrap gap-1">
                        {(() => {
                          const selectedRole: any = availableRoles.find(
                            (r) => r.id === formData.role
                          );

                          if (!selectedRole) {
                            return (
                              <span className="text-sm text-muted-foreground">
                                No permissions found for this role
                              </span>
                            );
                          }

                          let permissionsArray: string[] = [];

                          if (selectedRole?.permissions) {
                            if (Array.isArray(selectedRole?.permissions)) {
                              permissionsArray = selectedRole.permissions.map(
                                (p: any) => p
                              );
                            } else if (
                              typeof selectedRole.permissions === "string"
                            ) {
                              permissionsArray = selectedRole.permissions
                                .split(",")
                                .map((perm: any) => perm.trim())
                                .filter((perm: any) => perm.length > 0);
                            }
                          }

                          return (
                            <>
                              {permissionsArray.length > 0 ? (
                                <>
                                  {permissionsArray
                                    .slice(0, 8)
                                    .map((permission, index) => (
                                      <Badge
                                        key={index}
                                        variant="secondary"
                                        className="text-xs"
                                      >
                                        {permission}
                                      </Badge>
                                    ))}
                                  {permissionsArray.length > 8 && (
                                    <Badge
                                      variant="outline"
                                      className="text-xs"
                                    >
                                      +{permissionsArray.length - 8} more
                                    </Badge>
                                  )}
                                </>
                              ) : (
                                <span className="text-sm text-muted-foreground">
                                  No permissions assigned
                                </span>
                              )}
                            </>
                          );
                        })()}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {isEditing && (
                <div>
                  <Label htmlFor="status" className="text-sm font-medium">
                    Status
                  </Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) =>
                      handleInputChange("status", value)
                    }
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                      <SelectItem value="suspended">Suspended</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          </div>

          <DialogFooter className="flex-shrink-0 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={
                isLoading ||
                !formData.name ||
                !formData.email ||
                !formData.phone_number ||
                !formData.role ||
                (!isEditing &&
                  (!formData.password || !formData.password_confirmation))
              }
            >
              {isLoading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  {isEditing ? "Updating..." : "Creating..."}
                </>
              ) : isEditing ? (
                "Update Staff"
              ) : (
                "Create Staff"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
