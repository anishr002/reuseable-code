"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { MoreHorizontal, Edit, Trash2, UserCheck, UserX, Shield } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { StaffMember } from "@/lib/staff-types"

interface StaffColumnsProps {
  onEdit: (staff: StaffMember) => void
  onDelete: (staff: StaffMember) => void
  onStatusChange: (staff: StaffMember, status: 'active' | 'inactive' | 'suspended') => void
}

export function createStaffColumns({ onEdit, onDelete, onStatusChange }: StaffColumnsProps) {
  return [
    {
      accessorKey: "name",
      header: "Staff Member",
      cell: ({ row }) => {
        const staff = row.original
        return (
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
              {staff.name.split(' ').map(n => n[0]).join('').toUpperCase()}
            </div>
            <div>
              <div className="font-medium">{staff.name}</div>
              <div className="text-sm text-muted-foreground">{staff.email}</div>
            </div>
          </div>
        )
      }
    },
    {
      accessorKey: "phone",
      header: "Contact",
      cell: ({ row }) => {
        const staff = row.original
        return (
          <div className="text-sm">
            <div>{staff.phone}</div>
            {staff.department && (
              <div className="text-muted-foreground">{staff.department}</div>
            )}
          </div>
        )
      }
    },
    {
      accessorKey: "role",
      header: "Role",
      cell: ({ row }) => {
        const staff = row.original
        return (
          <div className="space-y-1">
            <Badge variant="secondary" className="flex items-center gap-1">
              <Shield className="h-3 w-3" />
              {staff.role.name}
            </Badge>
            <div className="text-xs text-muted-foreground">
              {staff.role.permissions.length} permissions
            </div>
          </div>
        )
      }
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => {
        const staff = row.original
        const statusConfig = {
          active: { variant: "default" as const, label: "Active", icon: UserCheck },
          inactive: { variant: "secondary" as const, label: "Inactive", icon: UserX },
          suspended: { variant: "destructive" as const, label: "Suspended", icon: UserX }
        }
        
        const config = statusConfig[staff.status]
        const Icon = config.icon
        
        return (
          <Badge variant={config.variant} className="flex items-center gap-1">
            <Icon className="h-3 w-3" />
            {config.label}
          </Badge>
        )
      }
    },
    {
      accessorKey: "lastLogin",
      header: "Last Login",
      cell: ({ row }) => {
        const staff = row.original
        return staff.lastLogin ? (
          <div className="text-sm">
            {new Date(staff.lastLogin).toLocaleDateString()}
            <div className="text-muted-foreground">
              {new Date(staff.lastLogin).toLocaleTimeString()}
            </div>
          </div>
        ) : (
          <span className="text-muted-foreground text-sm">Never</span>
        )
      }
    },
    {
      accessorKey: "createdAt",
      header: "Created",
      cell: ({ row }) => {
        const staff = row.original
        return (
          <div className="text-sm">
            {new Date(staff.createdAt).toLocaleDateString()}
          </div>
        )
      }
    },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }) => {
        const staff = row.original
        
        return (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-8 w-8 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => onEdit(staff)}>
                <Edit className="mr-2 h-4 w-4" />
                Edit Staff
              </DropdownMenuItem>
              
              <DropdownMenuSeparator />
              
              {staff.status === 'active' && (
                <>
                  <DropdownMenuItem onClick={() => onStatusChange(staff, 'inactive')}>
                    <UserX className="mr-2 h-4 w-4" />
                    Mark as Inactive
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onStatusChange(staff, 'suspended')}>
                    <UserX className="mr-2 h-4 w-4" />
                    Suspend Account
                  </DropdownMenuItem>
                </>
              )}
              
              {staff.status !== 'active' && (
                <DropdownMenuItem onClick={() => onStatusChange(staff, 'active')}>
                  <UserCheck className="mr-2 h-4 w-4" />
                  Activate Account
                </DropdownMenuItem>
              )}
              
              <DropdownMenuSeparator />
              
              <DropdownMenuItem 
                onClick={() => onDelete(staff)}
                className="text-red-600"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete Staff
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )
      }
    }
  ]
}