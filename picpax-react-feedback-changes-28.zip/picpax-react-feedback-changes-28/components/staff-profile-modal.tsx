"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Lock, Eye, EyeOff, Save, CheckCircle, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { DocumentUpload } from "@/components/ui/document-upload";
import type { DocumentFile } from "@/components/ui/document-upload";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  updateUserProfile,
  fetchUserProfile,
  changePassword,
  storeDocuments,
  deleteDocument,
  getDocuments,
} from "@/lib/userService";

// Simplified Zod schema with only required fields
// Updated Zod schema without the first and last name validation
const profileSchema = z.object({
  name: z
    .string()
    .min(1, "Full name is required")
    .min(2, "Full name must be at least 2 characters"),
  email: z
    .string()
    .min(1, "Email is required")
    .email("Please enter a valid email address"),
  phone_number: z
    .string()
    .min(1, "Phone number is required")
    .refine(
      (phone) => {
        const phoneWithoutSpaces = phone.replace(/\s/g, "");
        return /^\+971\s?[1-9]\d{1,2}\s?\d{3}\s?\d{4}$/.test(
          phoneWithoutSpaces
        );
      },
      {
        message:
          "Please enter a valid UAE phone number (e.g., +971 50 123 4567)",
      }
    ),
  gender: z.string().min(1, "Gender is required"),
});

const passwordSchema = z
  .object({
    currentPassword: z
      .string()
      .min(1, "Current password is required")
      .refine((val) => val.trim().length > 0, "Password cannot be only spaces"),
    newPassword: z
      .string()
      .min(1, "New password is required")
      .refine(
        (val) => val.trim().length >= 8,
        "Password must be at least 8 characters"
      )
      .refine(
        (val) => /^(?=.*[a-zA-Z])(?=.*\d)/.test(val),
        "Password must contain at least one letter and one number"
      )
      .refine((val) => val.trim().length > 0, "Password cannot be only spaces"),
    confirmPassword: z
      .string()
      .min(1, "Please confirm your password")
      .refine((val) => val.trim().length > 0, "Password cannot be only spaces"),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type ProfileFormValues = z.infer<typeof profileSchema>;
type PasswordFormValues = z.infer<typeof passwordSchema>;

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function StaffProfileModal({ isOpen, onClose }: ProfileModalProps) {
  const { user, logout, updateUser } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");
  const [isLoading, setIsLoading] = useState(false);
  const [isSavingDocuments, setIsSavingDocuments] = useState(false);

  // Profile form
  const profileForm = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: "",
      email: "",
      phone_number: "",
      gender: "",
    },
  });

  // Password form
  const passwordForm = useForm<PasswordFormValues>({
    resolver: zodResolver(passwordSchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });

  // Password visibility states
  const [showPasswords, setShowPasswords] = useState({
    current: false,
    new: false,
    confirm: false,
  });

  // Loading states
  const [isSavingProfile, setIsSavingProfile] = useState(false);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // Documents state
  const [documents, setDocuments] = useState<DocumentFile[]>([]);

  // Fetch user profile when modal opens
  useEffect(() => {
    const fetchProfile = async () => {
      if (isOpen && user) {
        setIsLoading(true);
        try {
          const response = await fetchUserProfile();
          if (response.success) {
            const profileData = response.data;

            // Set form values with full name
            profileForm.reset({
              name:
                profileData.name ||
                `${profileData.first_name || ""} ${
                  profileData.last_name || ""
                }`.trim(),
              email: profileData.email || "",
              phone_number: profileData.phone_number || "",
              gender: profileData.gender || "",
            });
          }
        } catch (error: any) {
          console.error("Failed to fetch profile:", error);
          toast({
            variant: "destructive",
            title: "Error",
            description:
              error.response?.data?.message || "Failed to load profile data",
          });
        } finally {
          setIsLoading(false);
        }
      }
    };

    fetchProfile();
  }, [isOpen, user, profileForm, toast]);

  // Clear errors when modal closes
  useEffect(() => {
    if (!isOpen) {
      // Clear all form errors
      profileForm.clearErrors();
      passwordForm.clearErrors();

      // Reset password form to empty values
      passwordForm.reset({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });

      // Reset password visibility
      setShowPasswords({
        current: false,
        new: false,
        confirm: false,
      });

      // Reset to profile tab when modal reopens
      setActiveTab("profile");
    }
  }, [isOpen, profileForm, passwordForm]);

  // Clear errors when switching tabs
  const handleTabChange = (value: string) => {
    setActiveTab(value);

    // Clear errors of the tab we're leaving
    if (value === "profile") {
      passwordForm.clearErrors();
    } else if (value === "password") {
      profileForm.clearErrors();
    } else if (value === "documents") {
      profileForm.clearErrors();
      passwordForm.clearErrors();
    }
  };

  const getInitials = (fullName: string) => {
    const names = fullName.trim().split(/\s+/);
    if (names.length >= 2) {
      return `${names[0][0] || ""}${
        names[names.length - 1][0] || ""
      }`.toUpperCase();
    }
    return fullName.slice(0, 2).toUpperCase();
  };

  const formatPhoneNumber = (phone: string) => {
    // Remove all non-digit characters except +
    const cleaned = phone.replace(/[^\d+]/g, "");

    // If it starts with +971, format it nicely
    if (cleaned.startsWith("+971")) {
      const rest = cleaned.slice(4);
      if (rest.length <= 2) {
        return `+971 ${rest}`;
      } else if (rest.length <= 5) {
        return `+971 ${rest.slice(0, 2)} ${rest.slice(2)}`;
      } else {
        return `+971 ${rest.slice(0, 2)} ${rest.slice(2, 5)} ${rest.slice(
          5,
          9
        )}`;
      }
    }

    return phone;
  };

  const onProfileSubmit = async (data: ProfileFormValues) => {
    setIsSavingProfile(true);

    try {
      // Prepare payload with name, phone_number, gender, email
      const payload: any = {
        name: data.name.trim(),
        email: data.email.trim(),
        phone_number: data.phone_number.trim(),
        gender: data.gender,
        type: "default", // Required by API
      };

      const response = await updateUserProfile(payload);

      if (response.success) {
        // Update the user context immediately for instant UI update
        updateUser({
          name: data.name.trim(),
          email: data.email.trim(),
        });

        // Also update localStorage
        const currentUserData = localStorage.getItem("picpax_user");
        if (currentUserData) {
          const user = JSON.parse(currentUserData);
          const updatedUser = {
            ...user,
            name: data.name.trim(),
            email: data.email.trim(),
          };
          localStorage.setItem("picpax_user", JSON.stringify(updatedUser));
        }

        toast({
          variant: "success",
          title: "Profile Updated!",
          description: "Your profile has been updated successfully.",
        });
      }
    } catch (error: any) {
      console.error("Profile update error:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message ||
          "Failed to update profile. Please try again.",
      });
    } finally {
      setIsSavingProfile(false);
    }
  };

  const onPasswordSubmit = async (data: PasswordFormValues) => {
    setIsChangingPassword(true);

    try {
      // Call the change password API
      const response = await changePassword({
        current_password: data.currentPassword,
        new_password: data.newPassword,
        new_password_confirmation: data.confirmPassword,
      });

      if (response.success) {
        // Reset password form
        passwordForm.reset({
          currentPassword: "",
          newPassword: "",
          confirmPassword: "",
        });

        // Reset password visibility
        setShowPasswords({
          current: false,
          new: false,
          confirm: false,
        });

        // Clear errors after successful submission
        passwordForm.clearErrors();

        toast({
          variant: "success",
          title: "Password Changed!",
          description:
            response.message || "Your password has been updated successfully.",
        });

        // Logout user after successful password change
        setTimeout(() => {
          logout();
        }, 1500); // Small delay to show success message
      }
    } catch (error: any) {
      console.error("Password change error:", error);

      // Handle specific error cases
      let errorMessage = "Failed to change password. Please try again.";

      if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.response?.data?.errors) {
        // Handle validation errors from API
        const errors = error.response.data.errors;
        errorMessage = Object.values(errors).flat().join(", ") || errorMessage;
      }

      toast({
        variant: "destructive",
        title: "Error",
        description: errorMessage,
      });
    } finally {
      setIsChangingPassword(false);
    }
  };

  const togglePasswordVisibility = (field: "current" | "new" | "confirm") => {
    setShowPasswords((prev) => ({ ...prev, [field]: !prev[field] }));
  };

  // Handle phone number input with formatting
  const handlePhoneNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formattedPhone = formatPhoneNumber(e.target.value);
    profileForm.setValue("phone_number", formattedPhone, {
      shouldValidate: true,
    });
  };

  // Handle modal close with proper cleanup
  const handleClose = () => {
    onClose();
  };

  const handleSaveDocuments = async (documents: DocumentFile[]) => {
    setIsSavingDocuments(true);

    try {
      // Create FormData for the API call
      const formData = new FormData();

      // Append each document file
      documents.forEach((doc, index) => {
        formData.append(`document[${index}]`, doc.file);
      });

      // Call the document store API
      const response = await storeDocuments(formData);

      if (response.success) {
        // Update documents status to "saved"
        const updatedDocuments = documents.map((doc) => ({
          ...doc,
          status: "saved" as const,
        }));
        setDocuments(updatedDocuments);

        toast({
          variant: "success",
          title: "Documents Saved!",
          description:
            response.message ||
            "Your documents have been uploaded successfully.",
        });
      }
    } catch (error: any) {
      console.error("Document upload error:", error);

      // Update documents status to "error"
      const updatedDocuments = documents.map((doc) => ({
        ...doc,
        status: "error" as const,
      }));
      setDocuments(updatedDocuments);

      toast({
        variant: "destructive",
        title: "Upload Failed",
        description:
          error.response?.data?.message ||
          "Failed to upload documents. Please try again.",
      });

      // Re-throw the error to handle it in the DocumentUpload component
      throw error;
    } finally {
      setIsSavingDocuments(false);
    }
  };

  const fetchServerDocuments = async () => {
    try {
      console.log("Fetching documents from server..."); // Debug log
      const response = await getDocuments();
      console.log("Documents response:", response); // Debug log

      if (
        response.success &&
        response.data &&
        Array.isArray(response.data.documents)
      ) {
        return response.data.documents;
      } else {
        throw new Error("Invalid response format from server");
      }
    } catch (error: any) {
      console.error("Failed to fetch server documents:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message || "Failed to load uploaded documents",
      });
      return [];
    }
  };

  const deleteServerDocument = async (documentId: any) => {
    try {
      console.log("Deleting document with ID:", documentId); // Debug log
      const response = await deleteDocument(documentId);
      return response;
    } catch (error: any) {
      console.error("Failed to delete document:", error);
      throw error;
    }
  };

  if (!user) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Profile Settings</DialogTitle>
          <DialogDescription>
            Manage your account information and security
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          // Loading state when fetching profile data
          <div className="flex justify-center items-center py-12">
            <div className="flex flex-col items-center space-y-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-muted-foreground">Loading profile data...</p>
            </div>
          </div>
        ) : (
          <Tabs
            value={activeTab}
            onValueChange={handleTabChange}
            className="w-full"
          >
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="profile">Edit Profile</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="password">Change Password</TabsTrigger>
            </TabsList>

            {/* Edit Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              {/* Profile Header */}
              <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="text-lg font-semibold bg-primary text-primary-foreground">
                    {getInitials(profileForm.watch("name") || "")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-semibold">{profileForm.watch("name")}</h3>
                  <p className="text-sm text-muted-foreground">
                    {profileForm.watch("email")}
                  </p>
                </div>
              </div>

              {/* Profile Form */}
              <Form {...profileForm}>
                <form
                  onSubmit={profileForm.handleSubmit(onProfileSubmit)}
                  className="space-y-4"
                >
                  <div className="grid grid-cols-1 md:grid-cols-1 gap-4">
                    <FormField
                      control={profileForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">
                            Full Name *
                          </FormLabel>
                          <FormControl>
                            <Input
                              placeholder="Enter your full name"
                              {...field}
                              disabled={isSavingProfile}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={profileForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">
                            Email *
                          </FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder="Enter email address"
                              {...field}
                              disabled={isSavingProfile}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={profileForm.control}
                      name="phone_number"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">
                            Phone Number *
                          </FormLabel>
                          <FormControl>
                            <Input
                              placeholder="+971 50 123 4567"
                              {...field}
                              onChange={handlePhoneNumberChange}
                              disabled={isSavingProfile}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={profileForm.control}
                      name="gender"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-foreground">
                            Gender *
                          </FormLabel>
                          <Select
                            value={field.value}
                            onValueChange={field.onChange}
                            disabled={isSavingProfile}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select gender" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="male">Male</SelectItem>
                              <SelectItem value="female">Female</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-end pt-4 border-t">
                    <Button
                      type="submit"
                      disabled={isSavingProfile}
                      className="bg-primary hover:bg-primary/90"
                    >
                      {isSavingProfile ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>

            {/* Documents Tab */}
            <TabsContent value="documents" className="space-y-6">
              <DocumentUpload
                documents={documents}
                onDocumentsChange={setDocuments}
                title="Required Documents"
                description="Upload required documents for verification. Maximum 5 files, 2MB each."
                type="doctor"
                onSaveDocuments={handleSaveDocuments}
                isSaving={isSavingDocuments}
                showServerDocuments={true}
                onFetchServerDocuments={fetchServerDocuments}
                onDeleteServerDocument={deleteServerDocument}
              />
            </TabsContent>

            {/* Change Password Tab */}
            <TabsContent value="password" className="space-y-6">
              <Form {...passwordForm}>
                <form
                  onSubmit={passwordForm.handleSubmit(onPasswordSubmit)}
                  className="max-w-md mx-auto space-y-4"
                >
                  <FormField
                    control={passwordForm.control}
                    name="currentPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">
                          Current Password *
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPasswords.current ? "text" : "password"}
                              placeholder="Enter current password"
                              className="pr-10"
                              {...field}
                              disabled={isChangingPassword}
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                              onClick={() =>
                                togglePasswordVisibility("current")
                              }
                              disabled={isChangingPassword}
                            >
                              {showPasswords.current ? (
                                <EyeOff className="h-4 w-4 text-muted-foreground" />
                              ) : (
                                <Eye className="h-4 w-4 text-muted-foreground" />
                              )}
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={passwordForm.control}
                    name="newPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">
                          New Password *
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPasswords.new ? "text" : "password"}
                              placeholder="Enter new password"
                              className="pr-10"
                              {...field}
                              disabled={isChangingPassword}
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                              onClick={() => togglePasswordVisibility("new")}
                              disabled={isChangingPassword}
                            >
                              {showPasswords.new ? (
                                <EyeOff className="h-4 w-4 text-muted-foreground" />
                              ) : (
                                <Eye className="h-4 w-4 text-muted-foreground" />
                              )}
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={passwordForm.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-foreground">
                          Confirm Password *
                        </FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input
                              type={showPasswords.confirm ? "text" : "password"}
                              placeholder="Confirm new password"
                              className="pr-10"
                              {...field}
                              disabled={isChangingPassword}
                            />
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                              onClick={() =>
                                togglePasswordVisibility("confirm")
                              }
                              disabled={isChangingPassword}
                            >
                              {showPasswords.confirm ? (
                                <EyeOff className="h-4 w-4 text-muted-foreground" />
                              ) : (
                                <Eye className="h-4 w-4 text-muted-foreground" />
                              )}
                            </Button>
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="text-xs text-muted-foreground bg-blue-50 p-3 rounded-md">
                    <strong>Password Requirements:</strong>
                    <ul className="mt-1 space-y-1">
                      <li>• At least 8 characters long</li>
                      <li>• Must contain letters and numbers</li>
                      <li>• No spaces allowed</li>
                    </ul>
                  </div>

                  <div className="flex justify-end pt-4 border-t">
                    <Button
                      type="submit"
                      disabled={isChangingPassword}
                      className="bg-primary hover:bg-primary/90"
                    >
                      {isChangingPassword ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Changing...
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-2" />
                          Change Password
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
}
