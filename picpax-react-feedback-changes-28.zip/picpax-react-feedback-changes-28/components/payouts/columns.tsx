"use client"

import type { ColumnDef } from "@tanstack/react-table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { DataTableColumnHeader } from "./data-table-column-header"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { MoreHorizontal, Eye, Download, DollarSign, Calendar, CheckCircle, Clock, XCircle } from "lucide-react"

export type Payout = {
  id: string
  doctorName: string
  doctorClinic: string
  amount: number
  period: string
  status: "Completed" | "Processing" | "Pending" | "Failed"
  date: string
  transactionId: string
  commissionRate: number
  orderCount: number
}

export const columns: ColumnDef<Payout>[] = [
  {
    accessorKey: "id",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Payout ID" />,
    cell: ({ row }) => {
      const payout = row.original
      return (
        <div className="font-mono text-sm font-medium min-w-[120px]">
          {payout.id}
        </div>
      )
    },
  },
  {
    accessorKey: "doctor",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Doctor" />,
    cell: ({ row }) => {
      const payout = row.original
      const getInitials = (name: string) => {
        return name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase()
      }

      return (
        <div className="flex items-center space-x-3 min-w-[200px]">
          <Avatar className="h-7 w-7 flex-shrink-0">
            <AvatarFallback className="text-xs font-semibold bg-blue-600 text-white">
              {getInitials(payout.doctorName)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-sm truncate">{payout.doctorName}</div>
            <div className="text-xs text-muted-foreground truncate">{payout.doctorClinic}</div>
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "period",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Period" />,
    cell: ({ row }) => {
      const payout = row.original
      return (
        <div className="min-w-[100px]">
          <div className="flex items-center gap-1 text-sm">
            <Calendar className="h-3 w-3 text-muted-foreground" />
            <span>{payout.period}</span>
          </div>
        </div>
      )
    },
  },
  {
    accessorKey: "amount",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Amount" />,
    cell: ({ row }) => {
      const amount = row.getValue("amount") as number
      return (
        <div className="text-right min-w-[100px]">
          <div className="font-bold text-green-600 text-sm">${amount.toLocaleString()}</div>
        </div>
      )
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Status" />,
    cell: ({ row }) => {
      const status = row.getValue("status") as string
      const getStatusColor = (status: string) => {
        switch (status) {
          case "Completed":
            return "bg-green-600 hover:bg-green-700"
          case "Processing":
            return "bg-blue-600 hover:bg-blue-700"
          case "Pending":
            return "bg-yellow-600 hover:bg-yellow-700"
          case "Failed":
            return "bg-red-600 hover:bg-red-700"
          default:
            return "bg-gray-600 hover:bg-gray-700"
        }
      }
      
      const getStatusIcon = (status: string) => {
        switch (status) {
          case "Completed":
            return <CheckCircle className="h-3 w-3" />
          case "Processing":
            return <Clock className="h-3 w-3" />
          case "Pending":
            return <Clock className="h-3 w-3" />
          case "Failed":
            return <XCircle className="h-3 w-3" />
          default:
            return <Clock className="h-3 w-3" />
        }
      }

      return (
        <div className="min-w-[100px]">
          <Badge
            variant="default"
            className={`text-xs ${getStatusColor(status)}`}
          >
            <div className="flex items-center gap-1">
              {getStatusIcon(status)}
              {status}
            </div>
          </Badge>
        </div>
      )
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id))
    },
  },
  {
    accessorKey: "date",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Date" />,
    cell: ({ row }) => {
      const date = row.getValue("date") as string
      return (
        <div className="flex items-center space-x-1 text-sm min-w-[90px]">
          <Calendar className="h-3 w-3 text-muted-foreground flex-shrink-0" />
          <span>{date}</span>
        </div>
      )
    },
  },
  {
    accessorKey: "transactionId",
    header: ({ column }) => <DataTableColumnHeader column={column} title="Transaction ID" />,
    cell: ({ row }) => {
      const transactionId = row.getValue("transactionId") as string
      return (
        <div className="font-mono text-xs text-muted-foreground min-w-[120px]">
          {transactionId}
        </div>
      )
    },
  },
  {
    id: "actions",
    cell: ({ row, table }) => {
      const payout = row.original
      const onViewPayoutDetails = (table.options.meta as { onViewPayoutDetails?: (payout: Payout) => void })?.onViewPayoutDetails

      return (
        <div className="min-w-[40px]">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-7 w-7 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[160px]">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => onViewPayoutDetails?.(payout)}>
                <Eye className="mr-2 h-4 w-4" />
                View Details
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => {
                console.log("Download receipt:", payout.id)
              }}>
                <Download className="mr-2 h-4 w-4" />
                Download Receipt
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              {payout.status === "Failed" && (
                <DropdownMenuItem onClick={() => {
                  console.log("Retry payout:", payout.id)
                }}>
                  <DollarSign className="mr-2 h-4 w-4" />
                  Retry Payout
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )
    },
  },
]