"use client";

import type React from "react";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { createPatient } from "@/lib/doctorApi";
import {
  getCountriesWithStates,
  type CountryWithStates,
} from "@/services/doctorService";
import { useRouter } from "next/navigation";

interface AddPatientModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPatientAdded?: () => void;
  isDoctorDashboard?: any;
}

export function AddPatientModal({
  isOpen,
  onClose,
  onPatientAdded,
  isDoctorDashboard,
}: AddPatientModalProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingCountries, setIsLoadingCountries] = useState(false);
  const [countries, setCountries] = useState<CountryWithStates[]>([]);
  const Router = useRouter();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    age: "",
    gender: "",
    status: "active",
    // Address fields
    country: "",
    countryName: "",
    villaApartment: "",
    areaStreet: "",
    emirate: "",
    nearbyLandmark: "",
  });

  const [formErrors, setFormErrors] = useState({
    country: "",
    villaApartment: "",
    areaStreet: "",
    emirate: "",
  });

  // Fetch countries when modal opens
  useEffect(() => {
    if (isOpen) {
      fetchCountries();
      // Reset form errors when modal opens
      setFormErrors({
        country: "",
        villaApartment: "",
        areaStreet: "",
        emirate: "",
      });
    }
  }, [isOpen]);

  const fetchCountries = async () => {
    setIsLoadingCountries(true);
    try {
      const response: any = await getCountriesWithStates();
      setCountries(response.data);
    } catch (error: any) {
      console.error("Error fetching countries:", error);
      toast({
        title: "Error",
        description: "Failed to load countries. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoadingCountries(false);
    }
  };

  const getStatesForSelectedCountry = (): string[] => {
    if (!formData.country) return [];
    const selectedCountry = countries.find(
      (country) => country.country_code === formData.country
    );
    return selectedCountry?.states || [];
  };

  const getCountryNameByCode = (countryCode: string): string => {
    const country = countries.find((c) => c.country_code === countryCode);
    return country?.country_name || "";
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => {
      const newFormData = { ...prev, [field]: value };

      // Reset emirate and update country name when country changes
      if (field === "country") {
        newFormData.emirate = "";
        newFormData.countryName = getCountryNameByCode(value);
      }

      return newFormData;
    });

    // Clear error when user starts typing
    if (formErrors[field as keyof typeof formErrors]) {
      setFormErrors((prev) => ({ ...prev, [field]: "" }));
    }
  };

  const validateForm = () => {
    const errors = {
      country: "",
      villaApartment: "",
      areaStreet: "",
      emirate: "",
    };

    // Address validation
    if (!formData.country) {
      errors.country = "Country is required";
    }
    if (!formData.villaApartment.trim()) {
      errors.villaApartment = "Villa/Apartment is required";
    }
    if (!formData.areaStreet.trim()) {
      errors.areaStreet = "Area/Street is required";
    }
    if (!formData.emirate) {
      errors.emirate = "State/Emirate is required";
    }

    setFormErrors(errors);
    return !Object.values(errors).some((error) => error !== "");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate form before submission
    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix all required fields before submitting.",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      // Prepare address string from individual fields
      const addressString = [
        formData.villaApartment,
        formData.areaStreet,
        formData.emirate,
        formData.countryName,
        formData.nearbyLandmark && `Near ${formData.nearbyLandmark}`,
      ]
        .filter(Boolean)
        .join(", ");

      // Prepare payload according to API requirements
      const payload = {
        first_name: formData.firstName.trim(),
        last_name: formData.lastName.trim(),
        email: formData.email.trim(),
        phone_number: formData.phone.trim(),
        age: formData.age,
        gender: formData.gender.toLowerCase(),
        address: addressString, // Use the constructed address string
        status: formData.status,
        // Include individual address fields if your API supports them
        country: formData.countryName,
        emirates_states: formData.emirate,
        villa_apartment: formData.villaApartment,
        area_street: formData.areaStreet,
        nearby_landmark: formData.nearbyLandmark,
      };

      // Make API call
      const response = await createPatient(payload);

      if (response.success) {
        toast({
          title: "Patient Added",
          description: `${formData.firstName} ${formData.lastName} has been added successfully.`,
        });

        // Reset form
        setFormData({
          firstName: "",
          lastName: "",
          email: "",
          phone: "",
          age: "",
          gender: "",
          status: "active",
          country: "",
          countryName: "",
          villaApartment: "",
          areaStreet: "",
          emirate: "",
          nearbyLandmark: "",
        });

        // Reset errors
        setFormErrors({
          country: "",
          villaApartment: "",
          areaStreet: "",
          emirate: "",
        });

        // Notify parent component
        if (onPatientAdded) {
          onPatientAdded();
        }
        isDoctorDashboard && Router.push("/patients");
        onClose();
      } else {
        throw new Error(response.message || "Failed to add patient");
      }
    } catch (error: any) {
      console.error("Error adding patient:", error);

      let errorMessage = "Failed to add patient. Please try again.";

      // Handle API validation errors
      if (error.response?.data?.errors) {
        const validationErrors = error.response.data.errors;
        errorMessage = Object.values(validationErrors).flat().join(", ");
      } else if (error.response?.data?.message) {
        errorMessage = error.response.data.message;
      } else if (error.message) {
        errorMessage = error.message;
      }

      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const states = getStatesForSelectedCountry();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add New Patient</DialogTitle>
          <DialogDescription>
            Enter the patient's information to create a new record.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) =>
                    handleInputChange("firstName", e.target.value)
                  }
                  placeholder="John"
                  className="h-9"
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) =>
                    handleInputChange("lastName", e.target.value)
                  }
                  placeholder="Doe"
                  className="h-9"
                  required
                  disabled={isLoading}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                placeholder="john.doe@email.com"
                className="h-9"
                required
                disabled={isLoading}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                placeholder="+971 50 123 4567"
                className="h-9"
                required
                disabled={isLoading}
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="age">Age *</Label>
                <Input
                  id="age"
                  type="number"
                  value={formData.age}
                  onChange={(e) => handleInputChange("age", e.target.value)}
                  placeholder="35"
                  className="h-9"
                  min="1"
                  max="120"
                  required
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Select
                  value={formData.gender}
                  onValueChange={(value) => handleInputChange("gender", value)}
                  disabled={isLoading}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Status Dropdown */}
            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => handleInputChange("status", value)}
                disabled={isLoading}
              >
                <SelectTrigger className="h-9">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Address Information */}
            <div className="space-y-4 border-t pt-4">
              <h4 className="font-medium text-sm text-muted-foreground uppercase tracking-wide">
                Address Information
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="country">Country *</Label>
                  <Select
                    value={formData.country}
                    onValueChange={(value) =>
                      handleInputChange("country", value)
                    }
                    disabled={isLoading || isLoadingCountries}
                  >
                    <SelectTrigger
                      className={`h-9 ${
                        formErrors.country ? "border-destructive" : ""
                      }`}
                    >
                      <SelectValue
                        placeholder={
                          isLoadingCountries
                            ? "Loading countries..."
                            : "Select country"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {countries.map((country) => (
                        <SelectItem
                          key={country.country_code}
                          value={country.country_code}
                        >
                          {country.country_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {formErrors.country && (
                    <p className="text-sm text-destructive">
                      {formErrors.country}
                    </p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="emirate">State/Emirate *</Label>
                  <Select
                    value={formData.emirate}
                    onValueChange={(value) =>
                      handleInputChange("emirate", value)
                    }
                    disabled={
                      !formData.country || states.length === 0 || isLoading
                    }
                  >
                    <SelectTrigger
                      className={`h-9 ${
                        formErrors.emirate ? "border-destructive" : ""
                      }`}
                    >
                      <SelectValue
                        placeholder={
                          !formData.country
                            ? "Select country first"
                            : states.length === 0
                            ? "No states available"
                            : "Select state/emirate"
                        }
                      />
                    </SelectTrigger>
                    <SelectContent>
                      {states.map((state) => (
                        <SelectItem key={state} value={state}>
                          {state}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {formErrors.emirate && (
                    <p className="text-sm text-destructive">
                      {formErrors.emirate}
                    </p>
                  )}
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="villaApartment">
                    Villa/Apartment Number *
                  </Label>
                  <Input
                    id="villaApartment"
                    value={formData.villaApartment}
                    onChange={(e) =>
                      handleInputChange("villaApartment", e.target.value)
                    }
                    placeholder="Villa 123, Apt 4B"
                    className={`h-9 ${
                      formErrors.villaApartment ? "border-destructive" : ""
                    }`}
                    required
                    disabled={isLoading}
                  />
                  {formErrors.villaApartment && (
                    <p className="text-sm text-destructive">
                      {formErrors.villaApartment}
                    </p>
                  )}
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="areaStreet">Area/Street *</Label>
                  <Input
                    id="areaStreet"
                    value={formData.areaStreet}
                    onChange={(e) =>
                      handleInputChange("areaStreet", e.target.value)
                    }
                    placeholder="Al Nahda, Sheikh Zayed Road"
                    className={`h-9 ${
                      formErrors.areaStreet ? "border-destructive" : ""
                    }`}
                    required
                    disabled={isLoading}
                  />
                  {formErrors.areaStreet && (
                    <p className="text-sm text-destructive">
                      {formErrors.areaStreet}
                    </p>
                  )}
                </div>

                <div className="space-y-2 sm:col-span-2">
                  <Label htmlFor="nearbyLandmark">Nearby Landmark *</Label>
                  <Input
                    id="nearbyLandmark"
                    value={formData.nearbyLandmark}
                    onChange={(e) =>
                      handleInputChange("nearbyLandmark", e.target.value)
                    }
                    placeholder="Near Dubai Mall, Next to Metro Station"
                    className="h-9"
                    disabled={isLoading}
                    required
                  />
                </div>
              </div>
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="h-9 bg-transparent"
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-primary hover:bg-primary/90 h-9"
              disabled={isLoading}
            >
              {isLoading ? "Adding..." : "Add Patient"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
