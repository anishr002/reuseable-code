"use client";

import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Loader2, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  postProductInfo,
  getProductInfo,
  type ProductInfo,
} from "@/lib/productService";

// Zod schema for form validation
const productInfoSchema = z.object({
  dose: z.string().min(1, "Dose is required"),
  ingredients: z.string().min(1, "Ingredients are required"),
});

type ProductInfoFormValues = z.infer<typeof productInfoSchema>;

interface ProductInfoModalProps {
  product: {
    id: string;
    shopifyId: string;
    title: string;
  } | null;
  isOpen: boolean;
  onClose: () => void;
  onSave?: () => void;
}

export function ProductInfoModal({
  product,
  isOpen,
  onClose,
  onSave,
}: ProductInfoModalProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [existingInfo, setExistingInfo] = useState<ProductInfo | null>(null);

  const form = useForm<ProductInfoFormValues>({
    resolver: zodResolver(productInfoSchema),
    defaultValues: {
      dose: "",
      ingredients: "",
    },
  });

  // Fetch existing product info when modal opens
  useEffect(() => {
    if (isOpen && product) {
      fetchProductInfo();
    } else {
      // Reset form when modal closes
      form.reset();
      setExistingInfo(null);
    }
  }, [isOpen, product]);

  const fetchProductInfo = async () => {
    if (!product) return;

    try {
      setIsFetching(true);
      const response = await getProductInfo(product.id);

      if (response.success && response.data.product_info) {
        setExistingInfo(response.data.product_info);
        form.setValue("dose", response.data.product_info.dose);
        form.setValue("ingredients", response.data.product_info.ingredients);
      } else {
        // Reset form if no existing info
        form.reset({
          dose: "",
          ingredients: "",
        });
        setExistingInfo(null);
      }
    } catch (error: any) {
      console.error("Error fetching product info:", error);
      // Don't show error toast for initial fetch, just reset form
      form.reset({
        dose: "",
        ingredients: "",
      });
      setExistingInfo(null);
    } finally {
      setIsFetching(false);
    }
  };

  const onSubmit = async (data: ProductInfoFormValues) => {
    if (!product) return;

    try {
      setIsLoading(true);
      const payload = {
        product_id: product.id,
        dose: data.dose,
        ingredients: data.ingredients,
      };

      const response = await postProductInfo(payload);

      if (response.success) {
        toast({
          title: "Success",
          description: response.message || "Product info saved successfully",
        });

        setExistingInfo(response.data.product_info);
        onSave?.();
        onClose();
      } else {
        toast({
          title: "Error",
          description: response.message || "Failed to save product info",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error("Error saving product info:", error);
      toast({
        title: "Error",
        description: error?.message || "Failed to save product info",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    form.reset();
    setExistingInfo(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Info className="h-5 w-5" />
            Product Information
          </DialogTitle>
          <DialogDescription>
            {existingInfo ? "Update" : "Add"} product information for{" "}
            <strong>{product?.title}</strong>
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="dose"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Dose</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="e.g., 20g, 1 capsule, 2 tablets"
                      {...field}
                      disabled={isLoading || isFetching}
                    />
                  </FormControl>

                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="ingredients"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ingredients</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="List all ingredients separated by commas"
                      className="min-h-[100px]"
                      {...field}
                      disabled={isLoading || isFetching}
                    />
                  </FormControl>

                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={handleClose}
                disabled={isLoading}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading || isFetching}>
                {(isLoading || isFetching) && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                {isFetching
                  ? "Loading..."
                  : existingInfo
                  ? "Update Info"
                  : "Save Info"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
