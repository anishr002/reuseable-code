"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react"; // Add useEffect

interface RequestMoreDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (message: string) => void;
  user: { first_name: string; last_name: string } | null;
  isLoading?: boolean;
}

export function RequestMoreDialog({
  isOpen,
  onClose,
  onConfirm,
  user,
  isLoading = false,
}: RequestMoreDialogProps) {
  const [message, setMessage] = useState("");
  const [hasInteracted, setHasInteracted] = useState(false);

  // Reset state when dialog opens/closes
  useEffect(() => {
    if (isOpen) {
      setMessage("");
      setHasInteracted(false);
    }
  }, [isOpen]);

  const handleClose = () => {
    setMessage("");
    setHasInteracted(false);
    onClose();
  };

  const handleConfirm = () => {
    onConfirm(message.trim());
    // Clear the message after confirmation
    setMessage("");
    setHasInteracted(false);
  };

  const handleMessageChange = (value: string) => {
    // Prevent starting with whitespace
    if (value.length === 1 && value === " ") {
      return;
    }
    setMessage(value);
    setHasInteracted(true);
  };

  const isMessageEmpty = message.trim() === "";

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Request More Information</DialogTitle>
          <DialogDescription>
            Please provide additional information needed from{" "}
            {user ? `${user.first_name} ${user.last_name}` : "the user"}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="request-message" className="text-sm font-medium">
              Message <span className="text-red-500">*</span>
            </Label>
            <textarea
              id="request-message"
              value={message}
              onChange={(e) => handleMessageChange(e.target.value)}
              onBlur={() => setHasInteracted(true)}
              placeholder="Please specify what additional information or documents are required..."
              className="w-full h-32 p-2 border border-gray-300 rounded-md resize-none focus:outline-none focus:ring-2 focus:ring-blue-500 mt-1"
              required
            />
          </div>
        </div>

        <div className="flex justify-end gap-3 pt-4">
          <Button
            variant="outline"
            onClick={handleClose}
            disabled={isLoading}
            type="button"
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={isMessageEmpty || isLoading}
            type="button"
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Sending...
              </>
            ) : (
              "Send Request"
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
