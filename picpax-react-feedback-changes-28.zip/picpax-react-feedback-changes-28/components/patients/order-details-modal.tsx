"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Calendar, Package, DollarSign, User, FileText } from "lucide-react";
import { DirhamIcon } from "../ui/DirhamIcon";

interface Order {
  id: string;
  patientName: string;
  patientId: string;
  products: Array<{ name: string; quantity: number; price: number }>;
  total: number;
  commission: number;
  status: string;
  createdAt: string;
  shopifyOrderId: string | null;
}

interface OrderDetailsModalProps {
  order: Order;
  isOpen: boolean;
  onClose: () => void;
}

export function OrderDetailsModal({
  order,
  isOpen,
  onClose,
}: OrderDetailsModalProps) {
  console.log(order, "order12333");
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-primary hover:bg-primary/90";
      case "Processing":
        return "bg-blue-500 hover:bg-blue-500/90";
      case "Draft":
        return "bg-gray-500 hover:bg-gray-500/90";
      default:
        return "";
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Order Details</span>
            <Badge className={getStatusColor(order.status)}>
              {order.status}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Complete information for order {order.id}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Order Information */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Order ID</div>
                  <div className="text-sm text-muted-foreground">
                    {order.id}
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <User className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Patient</div>
                  <div className="text-sm text-muted-foreground">
                    {order.patientName}
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <div>
                  <div className="text-sm font-medium">Order Date</div>
                  <div className="text-sm text-muted-foreground">
                    {order.createdAt}
                  </div>
                </div>
              </div>
              {order.shopifyOrderId && (
                <div className="flex items-center space-x-2">
                  <Package className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Shopify Order</div>
                    <div className="text-sm text-muted-foreground">
                      {order.shopifyOrderId}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          <Separator />

          {/* Products */}
          <div className="space-y-4">
            <h4 className="font-semibold flex items-center space-x-2">
              <Package className="h-4 w-4" />
              <span>Products Ordered</span>
            </h4>
            <div className="space-y-3">
              {order.products.map((product, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div>
                    <div className="font-medium">{product.name}</div>
                    <div className="text-sm text-muted-foreground">
                      Quantity: {product.quantity}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">
                      <DirhamIcon />
                      {(product.price * product.quantity).toFixed(2)}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <DirhamIcon />
                      {product.price} each
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Order Summary */}
          <div className="space-y-4">
            <h4 className="font-semibold flex items-center space-x-2">
              <DollarSign className="h-4 w-4" />
              <span>Order Summary</span>
            </h4>
            <div className="space-y-2 bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>
                  <DirhamIcon />
                  {order?.total}
                </span>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Commission (15%):</span>
                <span>
                  {" "}
                  <DirhamIcon />
                  {order?.commission}
                </span>
              </div>
              <Separator />
              <div className="flex justify-between font-semibold">
                <span>Total:</span>
                <span>
                  {" "}
                  <DirhamIcon />
                  {order?.total}
                </span>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
