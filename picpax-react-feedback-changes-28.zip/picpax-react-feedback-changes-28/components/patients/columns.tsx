"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "./data-table-column-header";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MoreHorizontal, Eye, Edit, Trash2, Phone, Mail } from "lucide-react";
import { convertToDubaiTime } from "../convertToDubaiTime";

export type Patient = {
  id: string;
  parent_id: string;
  name: string;
  email: string;
  phone: string;
  addresses: string;
  age: number;
  gender: string;
  lastVisit: string;
  totalOrders: number;
  status: "Active" | "Inactive";
};

// Create a separate component for the actions cell
interface ActionsCellProps {
  patient: Patient;
  onViewDetails: (patientId: string) => void;
  onEditPatient: (patient: Patient) => void;
  onDeletePatient: (patientId: any) => void;
  canEdit?: boolean;
  canDelete?: boolean;
}

function ActionsCell({
  patient,
  onViewDetails,
  onEditPatient,
  onDeletePatient,
  canEdit = true,
  canDelete = true,
}: ActionsCellProps) {
  return (
    <div className="min-w-[40px]">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="h-7 w-7 p-0">
            <span className="sr-only">Open menu</span>
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[160px]">
          <DropdownMenuLabel>Actions</DropdownMenuLabel>
          <DropdownMenuItem onClick={() => onViewDetails(patient.id)}>
            <Eye className="mr-2 h-4 w-4" />
            View Details
          </DropdownMenuItem>

          {canEdit && (
            <DropdownMenuItem onClick={() => onEditPatient(patient)}>
              <Edit className="mr-2 h-4 w-4" />
              Edit Patient
            </DropdownMenuItem>
          )}

          {canDelete && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="text-red-600"
                onClick={() => onDeletePatient(patient)}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete Patient
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

// Create the columns with proper typing and permission controls
interface CreateColumnsOptions {
  canEdit?: boolean;
  canDelete?: boolean;
}

export const createColumns = (
  onViewDetails: (patientId: string) => void,
  onEditPatient: (patient: Patient) => void,
  onDeletePatient: (patientId: string) => void,
  options?: CreateColumnsOptions
): ColumnDef<Patient>[] => [
  {
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Patient" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      const getInitials = (name: string) => {
        return name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase();
      };

      return (
        <div className="flex items-center space-x-2 min-w-[150px]">
          <Avatar className="h-7 w-7 flex-shrink-0">
            <AvatarFallback className="text-xs font-semibold bg-primary text-primary-foreground">
              {getInitials(patient.name)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-sm truncate">{patient.name}</div>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "email",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Contact" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="min-w-[180px] space-y-1">
          <div className="flex items-center space-x-1 text-xs">
            <Mail className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate max-w-[140px]" title={patient.email}>
              {patient.email}
            </span>
          </div>
          <div className="flex items-center space-x-1 text-xs">
            <Phone className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate">{patient.phone}</span>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "age",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Info" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="text-xs space-y-1 min-w-[80px]">
          <div className="font-medium">
            {patient.age}y, {patient.gender}
          </div>
          <div
            className="text-muted-foreground truncate max-w-[100px]"
            title={patient.addresses}
          >
            {patient.addresses || "No address"}
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "created_at",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Created At" />
    ),
    cell: ({ row }) => {
      const lastVisit = row.getValue("created_at") as string;
      return (
        <div className="text-xs min-w-[90px]">
          <div className="font-medium">{lastVisit}</div>
        </div>
      );
    },
  },
  {
    accessorKey: "totalOrders",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Orders" />
    ),
    cell: ({ row }) => {
      const totalOrders = row.getValue("totalOrders") as number;
      return (
        <div className="text-center min-w-[60px]">
          <Badge variant="outline" className="text-xs px-2">
            {totalOrders}
          </Badge>
        </div>
      );
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <div className="min-w-[70px]">
          <Badge
            variant={status === "Active" ? "default" : "secondary"}
            className={`text-xs ${
              status === "Active" ? "bg-primary hover:bg-primary/90" : ""
            }`}
          >
            {status}
          </Badge>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <ActionsCell
          patient={patient}
          onViewDetails={onViewDetails}
          onEditPatient={onEditPatient}
          onDeletePatient={onDeletePatient}
          canEdit={options?.canEdit}
          canDelete={options?.canDelete}
        />
      );
    },
  },
];

// Default columns for backward compatibility (without action handlers)
export const columns: ColumnDef<Patient>[] = [
  {
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Patient" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      const getInitials = (name: string) => {
        return name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase();
      };

      return (
        <div className="flex items-center space-x-2 min-w-[150px]">
          <Avatar className="h-7 w-7 flex-shrink-0">
            <AvatarFallback className="text-xs font-semibold bg-primary text-primary-foreground">
              {getInitials(patient.name)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="font-medium text-sm truncate">{patient.name}</div>
            <div className="text-xs text-muted-foreground">
              #{patient.id.slice(-6)}
            </div>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "email",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Contact" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="min-w-[180px] space-y-1">
          <div className="flex items-center space-x-1 text-xs">
            <Mail className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate max-w-[140px]" title={patient.email}>
              {patient.email}
            </span>
          </div>
          <div className="flex items-center space-x-1 text-xs">
            <Phone className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate">{patient.phone}</span>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "age",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Info" />
    ),
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="text-xs space-y-1 min-w-[80px]">
          <div className="font-medium">
            {patient.age}y, {patient.gender}
          </div>
          <div
            className="text-muted-foreground truncate max-w-[100px]"
            title={patient.addresses}
          >
            {patient.addresses || "No address"}
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "lastVisit",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Last Visit" />
    ),
    cell: ({ row }) => {
      const lastVisit = row.getValue("lastVisit") as string;
      return (
        <div className="text-xs min-w-[90px]">
          <div className="font-medium">{convertToDubaiTime(lastVisit)}</div>
        </div>
      );
    },
  },
  {
    accessorKey: "totalOrders",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Orders" />
    ),
    cell: ({ row }) => {
      const totalOrders = row.getValue("totalOrders") as number;
      return (
        <div className="text-center min-w-[60px]">
          <Badge variant="outline" className="text-xs px-2">
            {totalOrders}
          </Badge>
        </div>
      );
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <div className="min-w-[70px]">
          <Badge
            variant={status === "Active" ? "default" : "secondary"}
            className={`text-xs ${
              status === "Active" ? "bg-primary hover:bg-primary/90" : ""
            }`}
          >
            {status}
          </Badge>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const patient = row.original;
      return (
        <div className="min-w-[40px]">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-7 w-7 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[160px]">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem
                onClick={() => console.log("View details:", patient.id)}
              >
                <Eye className="mr-2 h-4 w-4" />
                View Details
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={() => console.log("Edit patient:", patient)}
              >
                <Edit className="mr-2 h-4 w-4" />
                Edit Patient
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-red-600">
                <Trash2 className="mr-2 h-4 w-4" />
                Delete Patient
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      );
    },
  },
];
