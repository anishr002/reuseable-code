"use client";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Package,
  Calendar,
  User,
  Mail,
  MapPin,
  Phone,
  FileText,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  Printer,
} from "lucide-react";
import { DirhamIcon } from "../ui/DirhamIcon";
import { useState } from "react";
import axiosInstance from "@/services/axiosInstance";
import { useToast } from "@/hooks/use-toast";
import type { OrderDetail } from "@/lib/doctorApi";
import { convertToDubaiDate } from "../convertToDubaiTime";

interface OrderDetailsModalProps {
  order: any;
  isOpen: boolean;
  onClose: () => void;
}

interface PdfResponse {
  success: boolean;
  message: string;
  data: {
    pdf: {
      filename: string;
      file_url: string;
      file_size: string;
    };
  };
}

export function PatientOrderDetailsModal({
  order,
  isOpen,
  onClose,
}: OrderDetailsModalProps) {
  const [isPrinting, setIsPrinting] = useState(false);
  const { toast } = useToast();

  const handlePrint = async () => {
    try {
      setIsPrinting(true);

      // Use order.id for the PDF endpoint
      const orderId = order?.id;

      if (!orderId) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Order ID is missing. Cannot generate PDF.",
        });
        return;
      }

      const response = await axiosInstance.get(`/order/${orderId}/pdf`);

      if (response.data.success) {
        const data: PdfResponse = response.data;

        if (data.data.pdf.file_url) {
          // Open the PDF in a new tab for printing/download
          window.open(data.data.pdf.file_url, "_blank");
          toast({
            title: "Success",
            description: "PDF generated successfully!",
          });
        } else {
          throw new Error("PDF URL not found in response");
        }
      } else {
        throw new Error(response.data.message || "Failed to generate PDF");
      }
    } catch (error: any) {
      console.error("Error generating PDF:", error);

      // Check for specific error types
      if (error.response?.status === 403) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to generate PDFs for orders.",
        });
      } else if (error.response?.status === 404) {
        toast({
          variant: "destructive",
          title: "Not Found",
          description: "Order not found or PDF generation service unavailable.",
        });
      } else {
        toast({
          variant: "destructive",
          title: "Error",
          description:
            error.response?.data?.message ||
            "Failed to generate PDF. Please try again.",
        });
      }
    } finally {
      setIsPrinting(false);
    }
  };

  if (!order) return null;

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
      case "closed":
        return <CheckCircle className="h-4 w-4" />;
      case "processing":
      case "open":
        return <Clock className="h-4 w-4" />;
      case "draft":
        return <AlertCircle className="h-4 w-4" />;
      case "cancelled":
        return <XCircle className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
      case "closed":
        return "bg-green-600 hover:bg-green-700";
      case "processing":
      case "open":
        return "bg-blue-600 hover:bg-blue-700";
      case "draft":
        return "bg-yellow-600 hover:bg-yellow-700";
      case "cancelled":
        return "bg-red-600 hover:bg-red-700";
      default:
        return "bg-gray-600 hover:bg-gray-700";
    }
  };

  const getStatusText = (status: string) => {
    switch (status.toLowerCase()) {
      case "open":
        return "Processing";
      case "closed":
        return "Completed";
      default:
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };

  const getInitials = (name: string) => {
    return name
      ?.split(" ")
      ?.map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  // Get subtotal from order
  const getSubTotal = () => {
    return parseFloat(order.subtotal_price || "0");
  };

  // Get total tax from order
  const getTotalTax = () => {
    return parseFloat(order.total_tax || "0");
  };

  // Get shipping amount from order
  const getShippingAmount = () => {
    if (order?.shipping_lines && order.shipping_lines.length > 0) {
      return parseFloat(order.shipping_lines[0].price || "0");
    }
    return 0;
  };

  // Get shipping title from order
  const getShippingTitle = () => {
    if (order?.shipping_lines && order.shipping_lines.length > 0) {
      return order.shipping_lines[0].title || "Shipping";
    }
    return "Shipping";
  };

  // Get discount amount from order
  const getDiscountAmount = () => {
    if (order?.total_discounts) {
      return parseFloat(order.total_discounts);
    }
    return 0;
  };

  const subTotal = getSubTotal();
  const totalTax = getTotalTax();
  const shippingAmount = getShippingAmount();
  const shippingTitle = getShippingTitle();
  const discountAmount = getDiscountAmount();
  const totalAmount = order.total_price || "0";
  const commission = order.commission || "0";

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Order Details - {order.name}
              </DialogTitle>
              <DialogDescription>
                Complete order information and details
              </DialogDescription>
            </div>
            <Badge
              variant="default"
              className={`flex items-center gap-1 ${getStatusColor(
                order.status
              )}`}
            >
              {getStatusIcon(order.status)}
              {order.status}
            </Badge>
          </div>
        </DialogHeader>

        <div className="grid gap-6 py-4">
          {/* Order Summary */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Order Date</span>
              </div>
              <p className="text-sm text-muted-foreground ml-6">
                {formatDate(order.order_date)}
              </p>
            </div>
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <DirhamIcon className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium">Total Amount</span>
              </div>
              <p className="text-sm font-medium ml-6">
                <DirhamIcon />
                {totalAmount.toLocaleString()}
              </p>
            </div>
          </div>

          {/* Doctor Information */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <User className="h-5 w-5" />
              Doctor Information
            </h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center gap-3 mb-3">
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="text-sm font-semibold bg-blue-600 text-white">
                    {getInitials(order.doctor.full_name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{order.doctor.full_name}</p>
                  <p className="text-sm text-muted-foreground">
                    {order.doctor.email}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Patient Information */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <User className="h-5 w-5" />
              Patient Information
            </h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="font-medium">
                    {order.customer_first_name} {order.customer_last_name}
                  </p>
                  <div className="flex items-center gap-1 mt-1">
                    <Mail className="h-3 w-3 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      {order.customer_email}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <Phone className="h-3 w-3 text-muted-foreground" />
                    <span className="text-sm">
                      {order.customer_phone ||
                        order.shipping_address?.phone ||
                        "N/A"}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 mt-1">
                    <MapPin className="h-3 w-3 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      {order.shipping_address?.city || "N/A"},{" "}
                      {order.shipping_address?.country || "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Products Information */}
          <div className="space-y-3">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Package className="h-5 w-5" />
              Products Ordered
            </h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="space-y-2">
                {order.line_items.map((item: any, index: any) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-2 bg-white rounded border"
                  >
                    <div className="flex items-center gap-2">
                      <Package className="h-4 w-4 text-muted-foreground" />
                      <div>
                        <span className="font-medium">{item.title}</span>
                        {item.quantity > 1 && (
                          <span className="text-sm text-muted-foreground ml-2">
                            (Qty: {item.quantity})
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-medium">
                        <DirhamIcon />
                        {(parseFloat(item.price) * item.quantity).toFixed(2)}
                      </span>
                      {item.quantity > 1 && (
                        <div className="text-xs text-muted-foreground">
                          <DirhamIcon />
                          {parseFloat(item.price).toFixed(2)} each
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Summary Section - Same as second component */}
              <div className="mt-4 space-y-2 border-t pt-4">
                <div className="flex justify-between items-center">
                  <span className="font-medium">Sub Total:</span>
                  <Badge variant="outline" className="text-sm">
                    <DirhamIcon />
                    {subTotal.toLocaleString()}
                  </Badge>
                </div>

                {/* Shipping Amount - Only show if greater than 0 */}
                {shippingAmount > 0 && (
                  <div className="flex justify-between items-center">
                    <span className="font-medium flex items-center gap-1">
                      {shippingTitle}:
                    </span>
                    <Badge variant="outline" className="text-sm">
                      <DirhamIcon />
                      {shippingAmount.toLocaleString()}
                    </Badge>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <span className="font-medium">Total Tax:</span>
                  <Badge variant="outline" className="text-sm">
                    <DirhamIcon />
                    {totalTax.toLocaleString()}
                  </Badge>
                </div>

                <div className="flex justify-between items-center pt-2">
                  <span className="font-medium">Commission:</span>
                  <Badge variant="secondary" className="text-green-600">
                    <DirhamIcon />
                    {commission.toLocaleString()}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Order Timeline */}
          {order?.events && order.events.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Order Timeline
              </h3>
              {order?.events &&
                order.events.length > 0 &&
                order?.events?.map((event: any, index: any) => {
                  return (
                    <div className="space-y-2" key={index}>
                      <div className="flex items-center gap-3 p-2 bg-green-50 rounded">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <div>
                          <p className="text-sm font-medium">
                            {event?.event_name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {convertToDubaiDate(event?.shopify_created_at)}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <Button
            onClick={handlePrint}
            disabled={isPrinting}
            className="flex items-center gap-2"
          >
            <Printer className="h-4 w-4" />
            {isPrinting ? "Generating PDF..." : "Print Order"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
