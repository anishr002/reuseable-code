"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Calendar,
  Package,
  Eye,
  Plus,
  Search,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { OrderDetailsModal } from "./order-details-modal";
import {
  getPatientOrders,
  type PatientOrder,
  getOrderDetails,
  type OrderDetail,
} from "@/lib/doctorApi";
import { useToast } from "@/hooks/use-toast";
import { convertToDubaiTime } from "../convertToDubaiTime";
import { DirhamIcon } from "../ui/DirhamIcon";
import { PatientOrderDetailsModal } from "./PatientOrderDetailsModal";

interface PatientOrderHistoryProps {
  patientId: string;
  handleCreateOrder?: any;
  completedOrder?: any;
}

export function PatientOrderHistory({
  patientId,
  handleCreateOrder,
  completedOrder,
}: PatientOrderHistoryProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [orders, setOrders] = useState<PatientOrder[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<OrderDetail | null>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isLoadingOrderDetails, setIsLoadingOrderDetails] = useState(false);

  // Pagination and filtering state
  const [filters, setFilters] = useState({
    search: "",
    sort_by: "updated_at",
    sort_order: "desc" as "asc" | "desc",
    per_page: 10,
    page: 1,
  });

  const [pagination, setPagination] = useState({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
  });

  // Fetch patient orders
  const fetchPatientOrders = async () => {
    try {
      setIsLoading(true);
      const response = await getPatientOrders({
        patient_id: patientId,
        ...filters,
      });

      if (response.success) {
        setOrders(response.data.orders.data);
        setPagination(response.data.pagination);
      } else {
        throw new Error(response.message || "Failed to fetch orders");
      }
    } catch (error: any) {
      console.error("Failed to fetch patient orders:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to load patient orders",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  // Fetch individual order details
  const fetchOrderDetails = async (orderId: string) => {
    try {
      setIsLoadingOrderDetails(true);
      const response = await getOrderDetails(orderId);

      if (response.success) {
        setSelectedOrder(response.data);
        setIsOrderModalOpen(true);
      } else {
        throw new Error(response.message || "Failed to fetch order details");
      }
    } catch (error: any) {
      console.error("Failed to fetch order details:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to load order details",
        variant: "destructive",
      });
    } finally {
      setIsLoadingOrderDetails(false);
    }
  };

  // Initial fetch and when filters change
  useEffect(() => {
    if (patientId) {
      fetchPatientOrders();
    }
  }, [patientId, filters]);

  // Refresh orders
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchPatientOrders();
  };

  // Handle search
  const handleSearch = (searchTerm: string) => {
    setFilters((prev) => ({
      ...prev,
      search: searchTerm,
      page: 1, // Reset to first page when searching
    }));
  };

  // Handle column sort
  const handleColumnSort = (column: string) => {
    setFilters((prev) => ({
      ...prev,
      sort_by: column,
      sort_order:
        prev.sort_by === column && prev.sort_order === "asc" ? "desc" : "asc",
      page: 1, // Reset to first page when sorting
    }));
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setFilters((prev) => ({
      ...prev,
      page,
    }));
  };

  // Handle per page change
  const handlePerPageChange = (perPage: number) => {
    setFilters((prev) => ({
      ...prev,
      per_page: perPage,
      page: 1, // Reset to first page when changing items per page
    }));
  };

  // Handle view order
  const handleViewOrder = async (order: PatientOrder) => {
    await fetchOrderDetails(order.id);
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "completed":
      case "closed":
        return "bg-primary hover:bg-primary/90";
      case "processing":
      case "open":
        return "bg-blue-500 hover:bg-blue-500/90";
      case "draft":
        return "bg-gray-500 hover:bg-gray-500/90";
      case "cancelled":
        return "bg-red-500 hover:bg-red-500/90";
      default:
        return "bg-gray-500 hover:bg-gray-500/90";
    }
  };

  const getStatusText = (status: string) => {
    switch (status.toLowerCase()) {
      case "open":
        return "Processing";
      case "closed":
        return "Completed";
      default:
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
  };

  const totalSpent = orders.reduce(
    (sum, order) => sum + parseFloat(order.total_price),
    0
  );

  const pendingOrders = orders.filter(
    (o) => o.status.toLowerCase() === "open"
  ).length;

  // Format date for display
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-GB", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  // Render sort icon for column headers
  const renderSortIcon = (column: string) => {
    if (filters.sort_by !== column) {
      return <ChevronUp className="h-4 w-4 opacity-30" />;
    }

    return filters.sort_order === "asc" ? (
      <ChevronUp className="h-4 w-4" />
    ) : (
      <ChevronDown className="h-4 w-4" />
    );
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <Package className="h-5 w-5" />
                <span>Order History</span>
              </CardTitle>
              <CardDescription>
                Complete history of all orders for this patient
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              {/* Compact Search */}
              <div className="relative w-64">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search..."
                  value={filters.search}
                  onChange={(e) => handleSearch(e.target.value)}
                  className="pl-8 h-9 text-sm"
                />
              </div>
              <Button
                className="bg-primary hover:bg-primary/90"
                onClick={handleCreateOrder}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create New Order
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Order Summary Stats */}
            <div className="grid gap-4 md:grid-cols-4">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-primary">
                  {pagination.total}
                </div>
                <div className="text-sm text-muted-foreground">
                  Total Orders
                </div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">
                  <DirhamIcon />
                  {totalSpent.toFixed(2)}
                </div>
                <div className="text-sm text-muted-foreground">Total Spent</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-secondary">
                  {completedOrder}
                </div>
                <div className="text-sm text-muted-foreground">
                  Completed Orders
                </div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">
                  {pendingOrders}
                </div>
                <div className="text-sm text-muted-foreground">
                  Processing Orders
                </div>
              </div>
            </div>

            {/* Orders Table */}
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => handleColumnSort("order_id")}
                    >
                      <div className="flex items-center space-x-1">
                        <span>Order ID</span>
                        {renderSortIcon("order_id")}
                      </div>
                    </TableHead>
                    <TableHead>Products</TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => handleColumnSort("total_price")}
                    >
                      <div className="flex items-center space-x-1">
                        <span>Total Amount</span>
                        {renderSortIcon("total_price")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => handleColumnSort("commission")}
                    >
                      <div className="flex items-center space-x-1">
                        <span>Commission</span>
                        {renderSortIcon("commission")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => handleColumnSort("status")}
                    >
                      <div className="flex items-center space-x-1">
                        <span>Status</span>
                        {renderSortIcon("status")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => handleColumnSort("order_date")}
                    >
                      <div className="flex items-center space-x-1">
                        <span>Order Date</span>
                        {renderSortIcon("order_date")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-gray-50"
                      onClick={() => handleColumnSort("updated_at")}
                    >
                      <div className="flex items-center space-x-1">
                        <span>Last Updated</span>
                        {renderSortIcon("updated_at")}
                      </div>
                    </TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-12">
                        <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-muted-foreground" />
                        <p className="text-muted-foreground">
                          Loading orders...
                        </p>
                      </TableCell>
                    </TableRow>
                  ) : orders.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={8}
                        className="text-center py-12 text-muted-foreground"
                      >
                        <Package className="h-16 w-16 mx-auto mb-4 opacity-50" />
                        <h3 className="text-lg font-medium mb-2">
                          No orders found
                        </h3>
                        <p className="mb-4">
                          {filters.search
                            ? "No orders match your search criteria"
                            : "This patient hasn't placed any orders yet"}
                        </p>
                        <Button
                          className="bg-primary hover:bg-primary/90"
                          onClick={handleCreateOrder}
                        >
                          <Plus className="h-4 w-4 mr-2" />
                          Create First Order
                        </Button>
                      </TableCell>
                    </TableRow>
                  ) : (
                    orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="font-medium">{order.order_id}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="text-sm font-medium">
                              {order.products_count} product(s)
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {order.products.slice(0, 2).join(", ")}
                              {order.products.length > 2 && "..."}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">
                            <DirhamIcon />
                            {parseFloat(order.total_price).toFixed(2)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            <DirhamIcon />
                            {parseFloat(order.commission).toFixed(2)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(order.status)}>
                            {order.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2 text-sm">
                            <Calendar className="h-3 w-3 text-muted-foreground" />
                            <span>{convertToDubaiTime(order.order_date)}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {convertToDubaiTime(order.updated_at)}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleViewOrder(order)}
                            disabled={isLoadingOrderDetails}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">Show</span>
                <Select
                  value={filters.per_page.toString()}
                  onValueChange={(value) => handlePerPageChange(Number(value))}
                >
                  <SelectTrigger className="w-20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5">5</SelectItem>
                    <SelectItem value="10">10</SelectItem>
                    <SelectItem value="20">20</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                  </SelectContent>
                </Select>
                <span className="text-sm text-muted-foreground">entries</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-muted-foreground">
                  Showing {pagination.from} to {pagination.to} of{" "}
                  {pagination.total} entries
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(pagination.current_page - 1)}
                  disabled={pagination.current_page === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm px-3 py-2 border rounded-md">
                  {pagination.current_page}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handlePageChange(pagination.current_page + 1)}
                  disabled={pagination.current_page === pagination.last_page}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Order Details Modal */}
      {selectedOrder && (
        <PatientOrderDetailsModal
          order={selectedOrder}
          isOpen={isOrderModalOpen}
          onClose={() => {
            setIsOrderModalOpen(false);
            setSelectedOrder(null);
          }}
        />
      )}
    </>
  );
}
