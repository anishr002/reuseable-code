"use client";

import * as React from "react";
import {
  type ColumnDef,
  type ColumnFiltersState,
  type SortingState,
  type VisibilityState,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  useReactTable,
} from "@tanstack/react-table";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DataTablePagination } from "./data-table-pagination";
import { DataTableViewOptions } from "./data-table-view-options";
import { DataTableFacetedFilter } from "./data-table-faceted-filter";
import { ExportButton } from "@/components/ui/export-button";
import { Search, X, UserCog, Loader2 } from "lucide-react";

interface DataTableProps<TData, TValue> {
  columns: ColumnDef<TData, TValue>[];
  data: TData[];
  // Server mode props (optional)
  manual?: boolean;
  pageCount?: number;
  state?: {
    sorting?: SortingState;
    columnFilters?: ColumnFiltersState;
    pagination?: { pageIndex: number; pageSize: number };
    searchValue?: string;
  };
  onSortingChange?: (sorting: SortingState) => void;
  onColumnFiltersChange?: (filters: ColumnFiltersState) => void;
  onPaginationChange?: (pagination: {
    pageIndex: number;
    pageSize: number;
  }) => void;
  onSearchChange?: (value: string) => void;
  toolbarHidden?: boolean;
  searchColumnId?: string;
  canExport?: boolean;
  isDoctorStaff?: boolean; // New prop to indicate doctor/staff context
  isLoading?: boolean;
  doctor_id?: string;
}

export function DataTable<TData, TValue>({
  columns,
  data,
  manual = false,
  pageCount,
  state,
  onSortingChange,
  onColumnFiltersChange,
  onPaginationChange,
  onSearchChange,
  toolbarHidden = false,
  searchColumnId = "name",
  canExport = false, // Default to false
  isDoctorStaff = false, // New prop to indicate doctor/staff context
  isLoading = false,
  doctor_id,
}: DataTableProps<TData, TValue>) {
  const [sorting, setSorting] = React.useState<SortingState>(
    state?.sorting ?? []
  );
  const [columnFilters, setColumnFilters] = React.useState<ColumnFiltersState>(
    state?.columnFilters ?? []
  );
  const [columnVisibility, setColumnVisibility] =
    React.useState<VisibilityState>({
      // Hide some columns on mobile by default
      clinic: typeof window !== "undefined" ? window.innerWidth > 768 : true,
    });
  const [rowSelection, setRowSelection] = React.useState({});
  const [pagination, setPagination] = React.useState<{
    pageIndex: number;
    pageSize: number;
  }>(state?.pagination ?? { pageIndex: 0, pageSize: 10 });

  // Sync with external state when provided
  React.useEffect(() => {
    if (state?.sorting) setSorting(state.sorting);
  }, [state?.sorting]);
  React.useEffect(() => {
    if (state?.columnFilters) setColumnFilters(state.columnFilters);
  }, [state?.columnFilters]);
  React.useEffect(() => {
    if (state?.pagination) setPagination(state.pagination);
  }, [state?.pagination]);

  const table = useReactTable({
    data,
    columns,
    onSortingChange: (updater) => {
      const next = typeof updater === "function" ? updater(sorting) : updater;
      setSorting(next);
      onSortingChange?.(next);
    },
    onColumnFiltersChange: (updater) => {
      const next =
        typeof updater === "function" ? updater(columnFilters) : updater;
      setColumnFilters(next);
      onColumnFiltersChange?.(next);
    },
    onPaginationChange: (updater: any) => {
      const next =
        typeof updater === "function" ? updater(pagination) : updater;
      setPagination(next);
      onPaginationChange?.(next);
    },
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: manual ? undefined : getPaginationRowModel(),
    getSortedRowModel: manual ? undefined : getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    onRowSelectionChange: setRowSelection,
    manualPagination: manual,
    manualSorting: manual,
    pageCount: manual && pageCount !== undefined ? pageCount : undefined,
    state: {
      sorting,
      columnFilters,
      columnVisibility,
      rowSelection,
      pagination,
    },
  });

  const isFiltered = table.getState().columnFilters.length > 0;
  // Safe column lookups (avoid getColumn errors when column doesn't exist)
  const allColumns = table.getAllColumns();
  const searchColumn = allColumns.find((c) => c.id === searchColumnId);
  const statusColumn = allColumns.find((c) => c.id === "status");

  const statusOptions = [
    {
      label: "Active",
      value: "Active",
      icon: UserCog,
    },
    {
      label: "Inactive",
      value: "Inactive",
      icon: UserCog,
    },
  ];

  const specializationOptions = [
    {
      label: "Nutritionist",
      value: "Nutritionist",
    },
    {
      label: "Dietitian",
      value: "Dietitian",
    },
    {
      label: "Sports Nutritionist",
      value: "Sports Nutritionist",
    },
  ];

  return (
    <div className="w-full">
      {!toolbarHidden && (
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4">
          <div className="flex flex-col sm:flex-row flex-1 items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 w-full sm:w-auto">
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                value={
                  state?.searchValue !== undefined
                    ? state.searchValue
                    : (searchColumn?.getFilterValue() as string) ?? ""
                }
                onChange={(event) => {
                  onSearchChange?.(event.target.value);
                  // Only set filter on client-side mode when column exists
                  if (!manual) {
                    searchColumn?.setFilterValue(event.target.value);
                  }
                }}
                className="h-8 w-full sm:w-[200px] lg:w-[250px] pl-8"
              />
            </div>
            <div className="flex items-center space-x-2 w-full sm:w-auto">
              {/* {statusColumn && (
                <DataTableFacetedFilter column={statusColumn as any} title="Status" options={statusOptions} />
              )} */}
              {isFiltered && (
                <Button
                  variant="ghost"
                  onClick={() => table.resetColumnFilters()}
                  className="h-8 px-2 lg:px-3"
                >
                  Reset
                  <X className="ml-2 h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
          <div className="flex items-center space-x-2 w-full sm:w-auto">
            {/* // In your DataTable component, update the ExportButton usage: */}
            {canExport && (
              <ExportButton
                // For client-side export (existing data)
                data={data}
                filename={
                  isDoctorStaff ? "doctor_subaccounts_report" : "doctors_report"
                }
                title="Export"
                // For API export (new)
                useApiExport={true}
                entity={isDoctorStaff ? "doctor-subaccounts" : "doctors"}
                doctor_id={doctor_id}
                search={state?.searchValue || ""}
                sort_by={sorting.length > 0 ? sorting[0].id : "updated_at"}
                sort_order={
                  sorting.length > 0
                    ? sorting[0].desc
                      ? "desc"
                      : "asc"
                    : "desc"
                }
              />
            )}
            <DataTableViewOptions table={table} />
          </div>
        </div>
      )}
      <div className="border rounded-md mx-4 mb-4">
        <div className="w-full overflow-auto">
          <Table className="w-full">
            <TableHeader>
              {table.getHeaderGroups().map((headerGroup) => (
                <TableRow key={headerGroup.id}>
                  {headerGroup.headers.map((header) => {
                    return (
                      <TableHead
                        key={header.id}
                        className="px-2 py-3 text-xs font-medium"
                      >
                        {header.isPlaceholder
                          ? null
                          : flexRender(
                              header.column.columnDef.header,
                              header.getContext()
                            )}
                      </TableHead>
                    );
                  })}
                </TableRow>
              ))}
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="h-24 text-center p-0" // Remove padding so the div can take full height
                  >
                    <div className="flex justify-center items-center py-12 w-full h-full">
                      <div className="flex flex-col items-center gap-4">
                        <Loader2 className="h-8 w-8 animate-spin text-primary" />
                        <p className="text-muted-foreground">
                          Loading doctors...
                        </p>
                      </div>
                    </div>
                  </TableCell>
                </TableRow>
              ) : table.getRowModel().rows?.length ? (
                table.getRowModel().rows.map((row) => (
                  <TableRow
                    key={row.id}
                    data-state={row.getIsSelected() && "selected"}
                  >
                    {row.getVisibleCells().map((cell) => (
                      <TableCell key={cell.id} className="px-2 py-3">
                        {flexRender(
                          cell.column.columnDef.cell,
                          cell.getContext()
                        )}
                      </TableCell>
                    ))}
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={columns.length}
                    className="h-24 text-center"
                  >
                    No results.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
      <div className="px-4">
        <DataTablePagination table={table} />
      </div>
    </div>
  );
}
