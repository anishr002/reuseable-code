"use client";

import type { ColumnDef } from "@tanstack/react-table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { DataTableColumnHeader } from "./data-table-column-header";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Phone,
  Mail,
  MapPin,
  Calendar,
  UserCog,
} from "lucide-react";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import type { Doctor } from "@/components/admin/edit-doctor-modal";
import { convertToDubaiTime } from "../convertToDubaiTime";

interface ColumnsProps {
  onEdit: (doctor: Doctor) => void;
  onDelete?: (doctor: Doctor) => void;
  canEdit: boolean;
  canDelete: boolean;
}

export const columns = ({
  onEdit,
  onDelete,
  canEdit,
  canDelete,
}: ColumnsProps): ColumnDef<Doctor>[] => [
  {
    accessorKey: "name",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Doctor" />
    ),
    cell: ({ row }) => {
      const doctor = row.original;
      const getInitials = (name: string) => {
        return name
          .split(" ")
          .map((n) => n[0])
          .join("")
          .toUpperCase();
      };

      return (
        <div className="flex items-center space-x-3 min-w-[200px]">
          <Avatar className="h-8 w-8 flex-shrink-0">
            <AvatarFallback className="text-xs font-semibold bg-blue-600 text-white">
              {getInitials(doctor.name)}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <Link
              href={`/admin/doctors/${doctor.id}`}
              className="font-medium text-sm text-blue-600 hover:text-blue-800 hover:underline truncate block"
            >
              {doctor.name}
            </Link>
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <UserCog className="h-3 w-3" />
              {doctor.specialization}
            </div>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "clinic",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Clinic" />
    ),
    cell: ({ row }) => {
      const doctor = row.original;
      return (
        <div className="min-w-[150px] space-y-1">
          <div className="font-medium text-sm">{doctor.clinic}</div>
          <div className="text-xs text-muted-foreground flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            Joined {convertToDubaiTime(doctor.joinDate)}
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "email",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Contact" />
    ),
    cell: ({ row }) => {
      const doctor = row.original;
      return (
        <div className="min-w-[200px] space-y-1">
          <div className="flex items-center space-x-1 text-xs">
            <Mail className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate max-w-[160px]" title={doctor.email}>
              {doctor.email}
            </span>
          </div>
          <div className="flex items-center space-x-1 text-xs">
            <Phone className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate">{doctor.phone}</span>
          </div>
          <div className="flex items-center space-x-1 text-xs">
            <MapPin className="h-3 w-3 text-muted-foreground flex-shrink-0" />
            <span className="truncate max-w-[160px]" title={doctor.address}>
              {doctor.address}
            </span>
          </div>
        </div>
      );
    },
  },
  {
    accessorKey: "status",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Status" />
    ),
    cell: ({ row }) => {
      const status = row.getValue("status") as string;
      return (
        <div className="min-w-[80px]">
          <Badge
            variant={status === "Active" ? "default" : "secondary"}
            className={`text-xs ${
              status === "Active" ? "bg-green-600 hover:bg-green-700" : ""
            }`}
          >
            {status}
          </Badge>
        </div>
      );
    },
    filterFn: (row, id, value) => {
      return value.includes(row.getValue(id));
    },
  },
  {
    accessorKey: "patients_count",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Patients" />
    ),
    cell: ({ row }) => {
      const patients = row.getValue("patients_count") as number;
      return (
        <div className="text-center min-w-[70px]">
          <Badge variant="outline" className="text-xs px-2">
            {patients}
          </Badge>
        </div>
      );
    },
  },
  {
    accessorKey: "orders_count",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Orders" />
    ),
    cell: ({ row }) => {
      const totalOrders = row.getValue("orders_count") as number;
      return (
        <div className="text-center min-w-[70px]">
          <Badge variant="outline" className="text-xs px-2">
            {totalOrders}
          </Badge>
        </div>
      );
    },
  },
  {
    accessorKey: "product_commission",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Product Commission" />
    ),
    cell: ({ row }) => {
      const commission = row.getValue("product_commission") as number;
      console.log(commission, "commissioncommission");
      return (
        <div className="text-center min-w-[80px]">
          <Badge variant="secondary" className="text-xs px-2">
            {commission}%
          </Badge>
        </div>
      );
    },
  },
  {
    accessorKey: "lab_test_commission",
    header: ({ column }) => (
      <DataTableColumnHeader column={column} title="Labtest Commission" />
    ),
    cell: ({ row }) => {
      const commission = row.getValue("lab_test_commission") as number;
      console.log(commission, "commissioncommission");
      return (
        <div className="text-center min-w-[80px]">
          <Badge variant="secondary" className="text-xs px-2">
            {commission}%
          </Badge>
        </div>
      );
    },
  },
  {
    id: "actions",
    cell: ({ row }) => {
      const doctor = row.original;
      const router = useRouter();

      // Check if there are any actions available
      const hasActions = canEdit || canDelete;

      if (!hasActions) {
        return (
          <div className="min-w-[40px] text-center">
            <span className="text-muted-foreground text-xs">No actions</span>
          </div>
        );
      }

      return (
        <div className="min-w-[40px]">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-7 w-7 p-0">
                <span className="sr-only">Open menu</span>
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-[160px]">
              <DropdownMenuLabel>Actions</DropdownMenuLabel>
              <DropdownMenuItem
                onClick={() => router.push(`/admin/doctors/${doctor.id}`)}
              >
                <Eye className="mr-2 h-4 w-4" />
                View Profile
              </DropdownMenuItem>

              {canEdit && (
                <DropdownMenuItem onClick={() => onEdit(doctor)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Doctor
                </DropdownMenuItem>
              )}

              {canEdit && canDelete && <DropdownMenuSeparator />}

              {canDelete && (
                <DropdownMenuItem
                  className="text-red-600"
                  onClick={() => onDelete?.(doctor)}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete Doctor
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      );
    },
  },
];
