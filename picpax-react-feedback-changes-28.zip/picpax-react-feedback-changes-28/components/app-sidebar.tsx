"use client";

import type React from "react";

import { useState, useEffect } from "react";
import {
  Home,
  Package,
  Users,
  DollarSign,
  FileText,
  LogOut,
  Settings,
  UserCog,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
} from "@/components/ui/sidebar";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth-context";
import { ProfileModal } from "./profile-modal";
import { StaffProfileModal } from "./staff-profile-modal";
import { AdminProfileModal } from "./admin-profile-modal";

const menuItems = [
  {
    title: "Dashboard",
    url: "/dashboard",
    icon: Home,
    requiredPermissions: [], // always show
  },
  {
    title: "Patient Management",
    url: "/patients",
    icon: Users,
    requiredPermissions: ["patient_read"], // specific permission required
  },
  {
    title: "Draft Orders Management",
    url: "/draft-orders",
    icon: FileText,
    requiredPermissions: ["draftOrder_read"], // always show
  },
  {
    title: "Orders Management",
    url: "/orders",
    icon: FileText,
    requiredPermissions: ["order_read"], // always show
  },

  {
    title: "Commission Tracking",
    url: "/commission",
    icon: DollarSign,
    requiredPermissions: ["commission_read"], // specific permission required
  },
  {
    title: "Product Management",
    url: "/products",
    icon: Package,
    requiredPermissions: ["product_read"], // always show
  },
  {
    title: "Staff Management",
    url: "/doctor-staff",
    icon: Users,
    requiredPermissions: ["doctorStaff_read"], // specific permission required
  },
  {
    title: "System Settings",
    url: "/settings",
    icon: Settings,
    requiredPermissions: ["generalSetting_read", "notificationSetting_read"], // always show
  },
];

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout, startRouting }: any = useAuth();
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  console.log(user, "useruser");

  // 🔹 load permissions from localStorage
  const [permissions, setPermissions] = useState<string[]>([]);

  console.log(user, "user111");

  useEffect(() => {
    const storedUser = localStorage.getItem("picpax_user");
    if (storedUser) {
      const parsed = JSON.parse(storedUser);
      setPermissions(parsed.permission || []);
    }
  }, []);

  // Prefetch main routes to speed up navigation
  useEffect(() => {
    menuItems.forEach((item) => {
      router.prefetch(item.url);
    });
  }, [router]);

  if (!user) return null;

  // 🔹 check if menu item should be shown
  const hasPermission = (requiredPermissions: string[]) => {
    if (requiredPermissions.length === 0) return true; // always show
    return requiredPermissions.some((perm) => permissions.includes(perm));
  };

  const getInitials = (name: string) => {
    return name
      ?.split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  return (
    <>
      <Sidebar {...props}>
        <SidebarHeader className="border-b border-gray-200 p-3 sm:p-4">
          <div className="flex items-center justify-center group-data-[collapsible=icon]:justify-center">
            <img
              src="/images/logo.png"
              alt="PicPax"
              className="h-6 sm:h-8 w-auto object-contain group-data-[collapsible=icon]:h-6"
            />
          </div>
        </SidebarHeader>

        <SidebarContent>
          <SidebarGroup>
            <SidebarGroupLabel>Navigation</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {menuItems
                  .filter((item) => hasPermission(item.requiredPermissions))
                  .map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton
                        asChild
                        isActive={pathname === item.url}
                      >
                        <Link href={item.url} onClick={() => startRouting()}>
                          <item.icon className="h-4 w-4" />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>

        <SidebarFooter className="border-t border-gray-200 p-4">
          <div
            className="flex items-center gap-3 mb-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
            onClick={() => setIsProfileModalOpen(true)}
          >
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs font-semibold bg-primary text-primary-foreground">
                {getInitials(user.full_name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.full_name}</p>
              <p className="text-xs text-muted-foreground truncate">
                {user.email}
              </p>
            </div>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </div>
          <Button
            variant="outline"
            size="sm"
            className="w-full bg-transparent"
            onClick={logout}
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </SidebarFooter>

        <SidebarRail />
      </Sidebar>
      {user?.role === "doctor" ? (
        <ProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
        />
      ) : user?.role === "doctor staff" ? (
        <StaffProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
        />
      ) : (
        <AdminProfileModal
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
        />
      )}
    </>
  );
}
