"use client";

import React, { useEffect, useRef, useState } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { useAuth } from "@/lib/auth-context";

const RouteProgress: React.FC = () => {
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const { isRouting } = useAuth();

  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(0);

  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const incTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const prevKeyRef = useRef<string>("");
  const apiActiveRef = useRef(0);

  const start = () => {
    if (incTimerRef.current) clearInterval(incTimerRef.current);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);

    setVisible(true);
    setProgress(0);

    incTimerRef.current = setInterval(() => {
      setProgress((p) => {
        if (p >= 90) return 90;
        const delta = Math.random() * 10;
        return Math.min(p + delta, 90);
      });
    }, 200);
  };

  const complete = () => {
    if (incTimerRef.current) clearInterval(incTimerRef.current);
    setProgress(100);
    hideTimerRef.current = setTimeout(() => {
      setVisible(false);
      setProgress(0);
    }, 200);
  };

  // Trigger on route changes
  useEffect(() => {
    const key = pathname + "?" + (searchParams?.toString() || "");
    if (prevKeyRef.current && prevKeyRef.current !== key) {
      start();
    }
    prevKeyRef.current = key;
  }, [pathname, searchParams]);

  // Keep progress active while API requests are in flight
  useEffect(() => {
    if (typeof window === "undefined") return;

    const onStart = () => {
      apiActiveRef.current += 1;
      start();
    };
    const onEnd = () => {
      apiActiveRef.current = Math.max(0, apiActiveRef.current - 1);
      if (apiActiveRef.current === 0) complete();
    };

    window.addEventListener("api:start", onStart as EventListener);
    window.addEventListener("api:end", onEnd as EventListener);

    return () => {
      window.removeEventListener("api:start", onStart as EventListener);
      window.removeEventListener("api:end", onEnd as EventListener);
    };
  }, []);

  // Safety timeout: avoid infinite loader if no events arrive
  useEffect(() => {
    if (visible) {
      const id = setTimeout(() => {
        if (apiActiveRef.current === 0) complete();
      }, 10000);
      return () => clearTimeout(id);
    }
  }, [visible]);

  // Respond to explicit routing signals (e.g., auth redirects)
  useEffect(() => {
    if (isRouting) {
      start();
    } else {
      // Only complete if there are no active API requests
      if (visible && apiActiveRef.current === 0) complete();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isRouting]);

  useEffect(() => {
    return () => {
      if (incTimerRef.current) clearInterval(incTimerRef.current);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, []);

  if (!visible) return null;

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        height: "3px",
        width: "100%",
        zIndex: 9999,
        backgroundColor: "transparent",
      }}
      aria-hidden="true"
    >
      <div
        style={{
          height: "100%",
          width: `${progress}%`,
          background: "linear-gradient(90deg, #0ea5e9, #22c55e, #a78bfa)",
          boxShadow: "0 0 10px rgba(14,165,233,0.6)",
          transition: "width 200ms ease",
        }}
      />
    </div>
  );
};

export default RouteProgress;
