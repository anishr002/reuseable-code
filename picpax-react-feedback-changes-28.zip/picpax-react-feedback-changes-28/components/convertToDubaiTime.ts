// utils/convertToDubaiTime.ts
export const convertToDubaiTime = (dateString: string | Date) => {
  const date = new Date(dateString);

  // Convert to Asia/Dubai timezone
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Dubai",
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  }).format(date);
};

export const convertToDubaiDate = (dateString: string | Date) => {
  const date = new Date(dateString);
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Dubai",
    year: "numeric",
    month: "short",
    day: "2-digit",
  }).format(date);
};
