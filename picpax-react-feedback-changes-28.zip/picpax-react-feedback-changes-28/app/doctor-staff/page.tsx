"use client";

import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { DataTable } from "@/components/doctors/data-table";
import { DataTableColumnHeader } from "@/components/doctors/data-table-column-header";
import {
  Mail,
  Phone,
  Edit,
  Trash2,
  Plus,
  Loader2,
  Users,
  UserCheck,
  UserX,
  Clock,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  createStaff,
  getStaffById,
  updateStaff,
  deleteStaff,
  getStaffList,
  type StaffMember,
} from "@/lib/doctorApi";
import type { ColumnDef } from "@tanstack/react-table";
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog";
import { convertToDubaiTime } from "@/components/convertToDubaiTime";

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

export default function DoctorStaffManagement() {
  const { toast } = useToast();
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<any>(null);
  const [isEditing, setIsEditing] = useState(false);

  // Pagination and search states
  const [searchTerm, setSearchTerm] = useState("");
  const [paginationState, setPaginationState] = useState({
    pageIndex: 0,
    pageSize: 10,
  });
  const [sortingState, setSortingState] = useState<any>([]);

  // Permission state
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);
  const [doctorId, setDoctorId] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState({
    isOpen: false,
    title: "",
    description: "",
    staff: null as StaffMember | null,
  });

  // Calculate stats
  const totalStaff = staffMembers.length;
  const activeStaff = staffMembers.filter(
    (staff) => staff.status === "active"
  ).length;
  const inactiveStaff = staffMembers.filter(
    (staff) => staff.status === "inactive"
  ).length;
  const femaleStaff = staffMembers.filter(
    (staff) => staff.gender === "female"
  ).length;

  // Load user data from localStorage
  useEffect(() => {
    const loadUserData = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          setDoctorId(user.id); // Doctor ID from logged-in user
          console.log("Doctor user loaded:", user);
        } else {
          setUserPermissions(null);
          setDoctorId(null);
        }
      } catch (error) {
        console.error("Error loading user data:", error);
        setUserPermissions(null);
        setDoctorId(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserData();
    window.addEventListener("storage", loadUserData);

    return () => {
      window.removeEventListener("storage", loadUserData);
    };
  }, []);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Fetch staff members
  const fetchStaffMembers = async (params?: {
    search?: string;
    page?: number;
    per_page?: number;
    sort_by?: string;
    sort_order?: "asc" | "desc";
  }) => {
    if (!doctorId) return;

    // Check permission before fetching
    if (!hasPermission("doctorStaff_read")) {
      console.log("No permission to read staff members");
      setStaffMembers([]);
      return;
    }

    try {
      setIsLoading(true);
      const response = await getStaffList({
        doctor_id: doctorId,
        per_page: params?.per_page || 50,
        page: params?.page || 1,
        search: params?.search || "",
        sort_by: params?.sort_by || "created_at",
        sort_order: params?.sort_order || "desc",
      });
      setStaffMembers(response.data.staff || []);
    } catch (error) {
      console.error("Error fetching staff members:", error);
      setStaffMembers([]);
      toast({
        title: "Error",
        description: "Failed to load staff members",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Search handler
  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    fetchStaffMembers({
      search: value,
      page: 1,
      per_page: paginationState.pageSize,
      sort_by: sortingState[0]?.id || "created_at",
      sort_order: sortingState[0]?.desc ? "desc" : "asc",
    });
  };

  // Pagination handler
  const handlePaginationChange = (pagination: {
    pageIndex: number;
    pageSize: number;
  }) => {
    setPaginationState(pagination);
    fetchStaffMembers({
      search: searchTerm,
      page: pagination.pageIndex + 1,
      per_page: pagination.pageSize,
      sort_by: sortingState[0]?.id || "created_at",
      sort_order: sortingState[0]?.desc ? "desc" : "asc",
    });
  };

  // Sorting handler
  const handleSortingChange = (sorting: any) => {
    setSortingState(sorting);
    if (sorting.length > 0) {
      fetchStaffMembers({
        search: searchTerm,
        page: 1,
        per_page: paginationState.pageSize,
        sort_by: sorting[0].id,
        sort_order: sorting[0].desc ? "desc" : "asc",
      });
    } else {
      fetchStaffMembers({
        search: searchTerm,
        page: 1,
        per_page: paginationState.pageSize,
        sort_by: "created_at",
        sort_order: "desc",
      });
    }
  };

  // Load staff members when component mounts and doctorId is available
  useEffect(() => {
    if (permissionsLoaded && doctorId && hasPermission("doctorStaff_read")) {
      fetchStaffMembers();
    }
  }, [doctorId, permissionsLoaded]);

  const handleAddStaff = () => {
    // Check permission
    if (!hasPermission("doctorStaff_write")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to add staff members.",
      });
      return;
    }

    setSelectedStaff({
      name: "",
      email: "",
      phone_number: "",
      gender: "",
      status: "active",
    });
    setIsEditing(false);
    setIsDialogOpen(true);
  };

  const handleEditStaff = async (staff: StaffMember) => {
    // Check permission
    if (!hasPermission("doctorStaff_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to edit staff members.",
      });
      return;
    }

    try {
      const response = await getStaffById(staff.id);
      setSelectedStaff(response.data);
      setIsEditing(true);
      setIsDialogOpen(true);
    } catch (error) {
      console.error("Error fetching staff details:", error);
      // Fallback to local data if API fails
      setSelectedStaff(staff);
      setIsEditing(true);
      setIsDialogOpen(true);
      toast({
        title: "Warning",
        description: "Using cached staff data",
        variant: "default",
      });
    }
  };

  const handleDeleteStaff = async (staff: StaffMember) => {
    // Check permission
    if (!hasPermission("doctorStaff_delete")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to delete staff members.",
      });
      return;
    }

    setConfirmation({
      isOpen: true,
      title: "Delete Staff Member",
      description: `Are you sure you want to delete ${staff.name}? This action cannot be undone.`,
      staff: staff,
    });
  };

  // Add handleConfirmDelete function
  const handleConfirmDelete = async () => {
    if (!confirmation.staff) return;

    try {
      await deleteStaff(confirmation.staff.id);
      // Refresh staff list after deletion
      await fetchStaffMembers();
      toast({
        title: "Success",
        description: "Staff member deleted successfully",
      });
    } catch (error) {
      console.error("Error deleting staff member:", error);
      toast({
        title: "Error",
        description: "Failed to delete staff member. Please try again.",
        variant: "destructive",
      });
    } finally {
      // Close confirmation dialog
      setConfirmation({
        isOpen: false,
        title: "",
        description: "",
        staff: null,
      });
    }
  };

  // Add handleCancelDelete function
  const handleCancelDelete = () => {
    setConfirmation({
      isOpen: false,
      title: "",
      description: "",
      staff: null,
    });
  };

  const handleSaveStaff = async () => {
    if (!doctorId || !selectedStaff) return;

    // Validate required fields
    if (!selectedStaff.name?.trim()) {
      toast({
        title: "Error",
        description: "Name is required",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.email?.trim()) {
      toast({
        title: "Error",
        description: "Email is required",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.phone_number?.trim()) {
      toast({
        title: "Error",
        description: "Phone number is required",
        variant: "destructive",
      });
      return;
    }

    // Validate UAE phone number format
    const phoneNumber = selectedStaff.phone_number.trim();
    const uaePhoneRegex = /^\+971\s?\d{1,3}[\s-]?\d{3}[\s-]?\d{4}$/;

    if (!uaePhoneRegex.test(phoneNumber)) {
      toast({
        title: "Error",
        description:
          "Phone number must start with +971 (UAE country code). Example: +971 50 123 4567",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.gender) {
      toast({
        title: "Error",
        description: "Gender is required",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.status) {
      toast({
        title: "Error",
        description: "Status is required",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsSaving(true);
      const payload = {
        doctor_id: doctorId,
        name: selectedStaff.name.trim(),
        email: selectedStaff.email.trim(),
        phone_number: selectedStaff.phone_number.trim(),
        gender: selectedStaff.gender,
        status: selectedStaff.status,
      };

      if (isEditing) {
        await updateStaff(selectedStaff.id, payload);
        toast({
          title: "Success",
          description: "Staff member updated successfully",
        });
      } else {
        await createStaff(payload);
        toast({
          title: "Success",
          description: "Staff member added successfully",
        });
      }

      // Refresh staff list after successful operation
      await fetchStaffMembers();
      setIsDialogOpen(false);
    } catch (error: any) {
      console.error("Error saving staff member:", error);
      const errorMessage =
        error.response?.data?.message ||
        "Failed to save staff member. Please try again.";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleStaffInputChange = (field: string, value: string) => {
    setSelectedStaff({
      ...selectedStaff,
      [field]: value,
    });
  };

  // Staff members columns for data table
  const staffColumns: ColumnDef<StaffMember>[] = [
    {
      accessorKey: "name",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Name" />
      ),
      cell: ({ row }) => {
        const name = row.getValue("name") as string;
        const getInitials = (name: string) => {
          return name
            .split(" ")
            .map((n) => n[0])
            .join("")
            .toUpperCase();
        };
        return (
          <div className="flex items-center space-x-3 min-w-[150px]">
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
              <span className="text-xs font-semibold text-blue-600">
                {getInitials(name)}
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-medium text-sm truncate">{name}</div>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "email",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Contact" />
      ),
      cell: ({ row }) => {
        const staff = row.original;
        return (
          <div className="min-w-[200px] space-y-1">
            <div className="flex items-center space-x-1 text-xs">
              <Mail className="h-3 w-3 text-muted-foreground flex-shrink-0" />
              <span className="truncate max-w-[160px]" title={staff.email}>
                {staff.email}
              </span>
            </div>
            <div className="flex items-center space-x-1 text-xs">
              <Phone className="h-3 w-3 text-muted-foreground flex-shrink-0" />
              <span className="truncate" title={staff.phone_number}>
                {staff.phone_number}
              </span>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "gender",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Gender" />
      ),
      cell: ({ row }) => {
        const gender = row.getValue("gender") as string;
        return (
          <div className="min-w-[80px]">
            <Badge variant="outline" className="text-xs capitalize">
              {gender}
            </Badge>
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Status" />
      ),
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        return (
          <div className="min-w-[80px]">
            <Badge
              variant={status === "active" ? "default" : "secondary"}
              className="capitalize"
            >
              {status}
            </Badge>
          </div>
        );
      },
      filterFn: (row, id, value) => {
        return value.includes(row.getValue(id));
      },
    },
    {
      accessorKey: "created_by",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Created By" />
      ),
      cell: ({ row }) => {
        const created_by = row.getValue("created_by") as string;
        return (
          <div className="min-w-[120px]">
            <div className="text-sm">{created_by || "-"}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "created_at",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Join Date" />
      ),
      cell: ({ row }) => {
        const created_at = row.getValue("created_at") as string;
        const formattedDate = created_at ? convertToDubaiTime(created_at) : "-";
        return (
          <div className="min-w-[100px]">
            <div className="text-sm">{formattedDate}</div>
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const staff = row.original;
        const canEdit = hasPermission("doctorStaff_update");
        const canDelete = hasPermission("doctorStaff_delete");

        if (!canEdit && !canDelete) {
          return (
            <div className="min-w-[80px] text-xs text-muted-foreground">
              No actions
            </div>
          );
        }

        return (
          <div className="min-w-[80px]">
            <div className="flex gap-2">
              {canEdit && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEditStaff(staff)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
              )}
              {canDelete && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDeleteStaff(staff)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        );
      },
    },
  ];

  const canViewStaff = hasPermission("doctorStaff_read");
  const canAddStaff = hasPermission("doctorStaff_write");

  if (!permissionsLoaded) {
    return (
      <div className="flex justify-center items-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }

  if (!canViewStaff) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Staff Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="text-center">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">Access Denied</h3>
              <p className="text-muted-foreground">
                You don't have permission to view staff members.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Section - Added similar to Patient Management */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
            Staff Management
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Manage your clinic staff members and their details
          </p>
        </div>
        {canAddStaff && (
          <Button
            className="bg-primary hover:bg-primary/90 w-full sm:w-auto"
            onClick={handleAddStaff}
            disabled={isLoading}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Staff
          </Button>
        )}
      </div>

      {/* Stats Cards Section - Added similar to Patient Management */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStaff}</div>
            <p className="text-xs text-muted-foreground">
              All registered staff
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Staff</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{activeStaff}</div>
            <p className="text-xs text-muted-foreground">Currently active</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Inactive Staff
            </CardTitle>
            <UserX className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-muted-foreground">
              {inactiveStaff}
            </div>
            <p className="text-xs text-muted-foreground">
              Not currently active
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Female Staff</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">
              {femaleStaff}
            </div>
            <p className="text-xs text-muted-foreground">
              Female staff members
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Staff Management Card */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Staff Members
              </CardTitle>
              <CardDescription>
                Manage your clinic staff members and their information
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <DataTable
            columns={staffColumns}
            data={staffMembers}
            searchColumnId="name"
            manual={true}
            state={{
              searchValue: searchTerm,
              pagination: paginationState,
              sorting: sortingState,
            }}
            onSearchChange={handleSearchChange}
            onPaginationChange={handlePaginationChange}
            onSortingChange={handleSortingChange}
            canExport={hasPermission("doctorStaff_export")}
            isDoctorStaff={true}
            isLoading={isLoading}
          />
        </CardContent>
      </Card>

      {/* Staff Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {isEditing ? "Edit Staff Member" : "Add Staff Member"}
            </DialogTitle>
            <DialogDescription>
              {isEditing
                ? "Update staff member information"
                : "Add a new staff member to your clinic"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                placeholder="Enter full name"
                value={selectedStaff?.name || ""}
                onChange={(e) => handleStaffInputChange("name", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter email address"
                value={selectedStaff?.email || ""}
                onChange={(e) =>
                  handleStaffInputChange("email", e.target.value)
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                placeholder="+971 50 123 4567"
                value={selectedStaff?.phone_number || ""}
                onChange={(e) =>
                  handleStaffInputChange("phone_number", e.target.value)
                }
                required
              />
              <p className="text-xs text-muted-foreground">
                Must start with +971 (UAE country code)
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Select
                  value={selectedStaff?.gender || ""}
                  onValueChange={(value) =>
                    handleStaffInputChange("gender", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select
                  value={selectedStaff?.status || ""}
                  onValueChange={(value) =>
                    handleStaffInputChange("status", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveStaff} disabled={isSaving}>
              {isSaving && <Loader2 className="h-4 w-4 animate-spin mr-2" />}
              {isEditing ? "Update Staff" : "Add Staff"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        onClose={handleCancelDelete}
        onConfirm={handleConfirmDelete}
        title={confirmation.title}
        description={confirmation.description}
        confirmText="Delete"
        cancelText="Cancel"
        variant="destructive"
      />
    </div>
  );
}
