"use client";

import { useState, useEffect, useRef } from "react";
import { useSearchParams } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  Minus,
  Save,
  Send,
  ArrowLeft,
  CheckCircle,
  Mail,
  Package,
  Search,
  ShoppingCart,
  User,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { useToast } from "@/hooks/use-toast";
import { CouponApply } from "@/components/shopify-coupon-apply";
import {
  ProductVariationSelector,
  type ProductVariation,
} from "@/components/products/product-variation-selector";
import {
  getPatients,
  getDoctors,
  getProducts,
  getProductTypes,
  createDraftOrder,
  type Patient,
  type Doctor,
  type Product,
} from "@/lib/orderService";
import { DirhamIcon } from "@/components/ui/DirhamIcon";
import { getPatientById as getPatientByIdApi } from "@/lib/doctorApi";
import axiosInstance from "@/services/axiosInstance";
// import { DirhamIcon } from "@/components/ui/icons"; // Make sure you have this icon component

export default function AdminCreateOrderPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { toast } = useToast();
  const preSelectedPatientId = searchParams.get("patientId");
  const fromPatientDetail = searchParams.get("fromPatientDetail");
  const isFromDetails = !!fromPatientDetail;

  const [selectedDoctor, setSelectedDoctor] = useState("");
  const [selectedPatient, setSelectedPatient] = useState(
    preSelectedPatientId || ""
  );
  const [selectedProducts, setSelectedProducts] = useState<
    Array<{
      id: string;
      quantity: number;
      variation?: ProductVariation;
      productData: Product; // Store complete product data
    }>
  >([]);
  const [selectedVariations, setSelectedVariations] = useState<
    Record<string, ProductVariation>
  >({});
  const [isLoading, setIsLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [patientSearchTerm, setPatientSearchTerm] = useState("");
  const [doctorSearchTerm, setDoctorSearchTerm] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);

  const [preselectedPatient, setPreselectedPatient] = useState<any>(null);
  const [preselectedDoctorName, setPreselectedDoctorName] = useState<
    string | null
  >(null);
  const [doctorFetchAttempted, setDoctorFetchAttempted] = useState(false);

  // API data states
  const [patients, setPatients] = useState<Patient[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loadingData, setLoadingData] = useState({
    patients: false,
    doctors: false,
    products: false,
    categories: false,
  });
  const [pagination, setPagination] = useState<any>({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
  });
  const [commissionRate, setCommissionRate] = useState(0);
  const [shippingSettings, setShippingSettings] = useState({
    shipping_charges: 0,
    minimum_order_amount_for_shipping: 0,
  });

  const didInitDoctorChange = useRef(false);

  // Add this function to fetch shipping settings
  const loadShippingSettings = async () => {
    try {
      const response = await axiosInstance.get("/draft-order/settings");
      if (response.data.success) {
        setShippingSettings({
          shipping_charges:
            parseFloat(response.data.data.settings.shipping_charges) || 0,
          minimum_order_amount_for_shipping:
            parseFloat(
              response.data.data.settings.minimum_order_amount_for_shipping
            ) || 0,
        });
      }
    } catch (error) {
      console.error("Failed to load shipping settings:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load shipping settings",
      });
    }
  };

  // Load initial data
  useEffect(() => {
    loadPatients();
    loadDoctors();
    loadProducts();
    loadCategories();
    loadShippingSettings(); // Add this line
  }, []);

  // Load patients
  const loadPatients = async (search?: string, doctorId?: string) => {
    setLoadingData((prev) => ({ ...prev, patients: true }));
    try {
      const response = await getPatients({ search, doctor_id: doctorId });
      setPatients(response.data.patients);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load patients",
      });
    } finally {
      setLoadingData((prev) => ({ ...prev, patients: false }));
    }
  };

  // Load doctors
  const loadDoctors = async (search?: string) => {
    setLoadingData((prev) => ({ ...prev, doctors: true }));
    try {
      const response = await getDoctors(search);
      setDoctors(response.data.doctors);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load doctors",
      });
    } finally {
      setLoadingData((prev) => ({ ...prev, doctors: false }));
    }
  };

  // Load products
  const loadProducts = async (page = 1, search?: string, category?: string) => {
    setLoadingData((prev) => ({ ...prev, products: true }));
    try {
      const response = await getProducts({
        search,
        category: category === "all" ? undefined : category,
        page,
        per_page: 10,
      });
      setProducts(response.data.products);
      setPagination(response.data.pagination);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load products",
      });
    } finally {
      setLoadingData((prev) => ({ ...prev, products: false }));
    }
  };

  // Load categories
  const loadCategories = async () => {
    setLoadingData((prev) => ({ ...prev, categories: true }));
    try {
      const response = await getProductTypes();
      setCategories(["all", ...response.data.filter((type) => type !== "")]);
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load categories",
      });
    } finally {
      setLoadingData((prev) => ({ ...prev, categories: false }));
    }
  };

  // Search handlers with debouncing
  useEffect(() => {
    const timer = setTimeout(() => {
      loadPatients(patientSearchTerm, selectedDoctor || undefined);
    }, 500);
    return () => clearTimeout(timer);
  }, [patientSearchTerm, selectedDoctor]);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadDoctors(doctorSearchTerm);
    }, 500);
    return () => clearTimeout(timer);
  }, [doctorSearchTerm]);

  useEffect(() => {
    const timer = setTimeout(() => {
      loadProducts(1, searchTerm, categoryFilter);
    }, 500);
    return () => clearTimeout(timer);
  }, [searchTerm, categoryFilter]);

  // Set pre-selected patient if coming from patient details
  useEffect(() => {
    if (preSelectedPatientId) {
      setSelectedPatient(preSelectedPatientId);
    }
  }, [preSelectedPatientId]);

  // Fetch preselected patient details to ensure it appears in dropdown and for doctor auto-select
  useEffect(() => {
    const run = async () => {
      if (!preSelectedPatientId) return;
      try {
        const resp = await getPatientByIdApi(preSelectedPatientId);
        if (resp?.success && resp.data) {
          const p = resp.data;
          setPreselectedPatient({
            id: p.id,
            full_name: p.full_name,
            email: p.email,
            status: p.status || "active",
            doctor_name: p.doctor_name || "",
          });
        }
      } catch (e) {
        // ignore errors
      }
    };
    run();
  }, [preSelectedPatientId]);

  // Derive preselected doctor name from patient (only when coming from details)
  useEffect(() => {
    if (!isFromDetails) {
      setPreselectedDoctorName(null);
      return;
    }
    if (!selectedPatient) {
      setPreselectedDoctorName(null);
      return;
    }
    const patient =
      patients.find((p) => p.id === selectedPatient) || preselectedPatient;
    if (patient?.doctor_name) {
      setPreselectedDoctorName(patient.doctor_name);
    }
  }, [isFromDetails, selectedPatient, patients, preselectedPatient]);

  // Reset doctor fetch attempt when the target doctor name changes
  useEffect(() => {
    setDoctorFetchAttempted(false);
  }, [preselectedDoctorName]);

  // Auto-select/fetch doctor once based on preselectedDoctorName (only when coming from details)
  useEffect(() => {
    if (!isFromDetails) return;
    if (!preselectedDoctorName) return;
    const doctor = doctors.find((d) => d.full_name === preselectedDoctorName);
    if (doctor) {
      if (selectedDoctor !== doctor.id) setSelectedDoctor(doctor.id);
      return;
    }
    if (!doctorFetchAttempted) {
      setDoctorFetchAttempted(true);
      loadDoctors(preselectedDoctorName);
    }
  }, [
    isFromDetails,
    preselectedDoctorName,
    doctors,
    selectedDoctor,
    doctorFetchAttempted,
  ]);

  // Convert product variants to variations format
  const convertVariantsToVariations = (
    product: Product
  ): ProductVariation[] => {
    return product.product_variants.map((variant) => ({
      id: variant.variant_id.toString(),
      name: variant.title === "Default Title" ? "Standard" : `${variant.title}`,
      duration:
        variant.title === "Default Title" ? 30 : parseInt(variant.title) || 30,
      price: variant.price,
      inStock: variant.inventory_summary.in_stock,
    }));
  };

  const addProduct = (productId: string) => {
    const product = products.find((p) => p.id === productId);
    const selectedVariation = selectedVariations[productId];

    if (product && product.variants_count > 1 && !selectedVariation) {
      toast({
        variant: "destructive",
        title: "Variation Required",
        description: "Please select a supply duration for this product.",
      });
      return;
    }

    const existing = selectedProducts.find((p) => p.id === productId);
    if (existing) {
      setSelectedProducts((prev) =>
        prev.map((p) =>
          p.id === productId
            ? { ...p, quantity: p.quantity + 1, variation: selectedVariation }
            : p
        )
      );
    } else {
      setSelectedProducts((prev) => [
        ...prev,
        {
          id: productId,
          quantity: 1,
          variation: selectedVariation,
          productData: product!, // Store the complete product data
        },
      ]);
    }
  };

  // Sync selected variations with selected products
  useEffect(() => {
    setSelectedProducts((prev) =>
      prev.map((item) => ({
        ...item,
        variation: selectedVariations[item.id] || item.variation,
      }))
    );
  }, [selectedVariations]);

  const handleVariationSelect = (
    productId: string,
    variation: ProductVariation
  ) => {
    setSelectedVariations((prev) => ({
      ...prev,
      [productId]: variation,
    }));

    // Also update the selectedProducts if this product is already in cart
    setSelectedProducts((prev) =>
      prev.map((item) =>
        item.id === productId ? { ...item, variation } : item
      )
    );
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      setSelectedProducts((prev) => prev.filter((p) => p.id !== productId));
    } else {
      setSelectedProducts((prev) =>
        prev.map((p) => (p.id === productId ? { ...p, quantity } : p))
      );
    }
  };

  const getSelectedProductDetails = () => {
    return selectedProducts.map((sp) => {
      const defaultVariant = sp.productData.product_variants[0];
      const selectedVariation = sp.variation;
      const price = selectedVariation
        ? selectedVariation.price
        : defaultVariant.price;

      return {
        ...sp.productData,
        quantity: sp.quantity,
        selectedVariation: sp.variation,
        price,
        inStock: selectedVariation
          ? selectedVariation.inStock
          : defaultVariant.inventory_summary.in_stock,
        product_type: sp.productData.product_type, // Ensure this is included
      };
    });
  };

  const calculateSubtotal = () => {
    return getSelectedProductDetails().reduce(
      (total, product) => total + (product.price || 0) * product.quantity,
      0
    );
  };

  // Calculate discount amount based on coupon type
  const calculateDiscountAmount = () => {
    if (!appliedCoupon) return 0;

    const { discount }: any = appliedCoupon;

    switch (discount.type) {
      case "order":
        if (discount.applied_discount.value_type === "fixed_amount") {
          return discount.applied_discount.amount;
        } else if (discount.applied_discount.value_type === "percentage") {
          const subtotal = calculateSubtotal();
          return (subtotal * discount.applied_discount.value) / 100;
        }
        return 0;

      case "line_item":
        // For line item discounts, calculate discount only for items with applied_discount
        let lineItemDiscount = 0;
        discount.line_items.forEach((discountedItem: any) => {
          // Only process items that have applied_discount
          if (discountedItem.applied_discount) {
            const cartItem = selectedProducts.find((item: any) => {
              const variantId = item.variation
                ? parseInt(item.variation.id)
                : item.productData.product_variants[0].variant_id;
              return variantId === discountedItem.variant_id;
            });

            if (cartItem) {
              const { value_type, value } = discountedItem.applied_discount;
              const itemPrice = cartItem.variation
                ? cartItem.variation.price
                : cartItem.productData.product_variants[0].price;

              if (value_type === "fixed_amount") {
                lineItemDiscount += value * cartItem.quantity;
              } else if (value_type === "percentage") {
                lineItemDiscount +=
                  ((itemPrice * value) / 100) * cartItem.quantity;
              }
            }
          }
        });
        return lineItemDiscount;

      case "shipping":
        // Shipping discount doesn't affect subtotal, handled separately
        return 0;

      default:
        return 0;
    }
  };

  // Calculate subtotal of only non-service products
  const calculateNonServiceSubtotal = () => {
    return getSelectedProductDetails().reduce((total, product) => {
      if (product.product_type !== "Service") {
        return total + (product.price || 0) * product.quantity;
      }
      return total;
    }, 0);
  };

  // Update calculateShipping function
  const calculateShipping = () => {
    // If coupon provides free shipping, return 0
    if (appliedCoupon?.discount.type === "shipping") {
      return 0;
    }

    const nonServiceSubtotal = calculateNonServiceSubtotal();

    // Check if there are any non-service products in the cart
    const hasNonServiceProducts = selectedProducts.some(
      (item) => item.productData.product_type !== "Service"
    );

    // If no non-service products OR non-service subtotal meets minimum, no shipping
    if (
      !hasNonServiceProducts ||
      nonServiceSubtotal >= shippingSettings.minimum_order_amount_for_shipping
    ) {
      return 0;
    }

    // Apply shipping charges only for non-service products below minimum order amount
    return shippingSettings.shipping_charges;
  };

  // Helper function to check if cart has non-service products
  const hasNonServiceProductsInCart = () => {
    return selectedProducts.some(
      (item) => item.productData.product_type !== "Service"
    );
  };

  // Get count of non-service products
  const getNonServiceProductCount = () => {
    return selectedProducts
      .filter((item) => item.productData.product_type !== "Service")
      .reduce((sum, item) => sum + item.quantity, 0);
  };
  // Calculate total including shipping
  const calculateTotal = () => {
    const subtotal = calculateSubtotal();
    const discount = calculateDiscountAmount();
    const shipping = calculateShipping();

    return Math.max(0, subtotal - discount + shipping);
  };

  // Get cart items for coupon API
  const getCartItemsForCoupon = () => {
    return selectedProducts.map((item: any) => {
      const defaultVariant = item.productData.product_variants[0];
      const selectedVariation = item.variation;
      const variantId = selectedVariation
        ? parseInt(selectedVariation.id)
        : defaultVariant.variant_id;
      const price = selectedVariation
        ? selectedVariation.price.toString()
        : defaultVariant.price.toString();
      const name = selectedVariation
        ? `${item.productData.title} - ${selectedVariation.name}`
        : item.productData.title;

      return {
        variant_id: variantId,
        quantity: item.quantity,
        price: price,
        name: name,
      };
    });
  };

  // Update product prices based on line item discounts
  const getProductDisplayPrice = (product: any) => {
    if (!appliedCoupon || appliedCoupon.discount.type !== "line_item") {
      return product.price;
    }

    const discountedItem = appliedCoupon.discount.line_items.find(
      (item: any) => {
        const variantId = product.selectedVariation
          ? parseInt(product.selectedVariation.id)
          : product.product_variants[0].variant_id;
        return item.variant_id === variantId && item.applied_discount; // Only if has discount
      }
    );

    if (discountedItem && discountedItem.applied_discount) {
      const { value_type, value } = discountedItem.applied_discount;
      if (value_type === "fixed_amount") {
        return Math.max(0, product.price - value);
      } else if (value_type === "percentage") {
        return product.price * (1 - value / 100);
      }
    }

    return product.price; // Return original price if no discount for this item
  };

  // Update the handleSaveAsDraft and handleSendToPatient functions
  const createOrderPayload = (status: "draft" | "processing") => {
    const items = selectedProducts.map((p) => {
      const defaultVariant = p.productData.product_variants[0];
      const selectedVariation = p.variation;
      const variantId: any = selectedVariation
        ? selectedVariation.id
        : defaultVariant.variant_id;

      let price = selectedVariation
        ? selectedVariation.price
        : defaultVariant.price;

      // Apply line item discounts ONLY if this specific item has applied_discount
      if (appliedCoupon && appliedCoupon.discount.type === "line_item") {
        const discountedItem = appliedCoupon.discount.line_items.find(
          (item: any) =>
            item.variant_id === parseInt(variantId) && item.applied_discount // Only apply if this item has discount
        );

        if (discountedItem && discountedItem.applied_discount) {
          const { value_type, value } = discountedItem.applied_discount;
          if (value_type === "fixed_amount") {
            price = Math.max(0, price - value);
          } else if (value_type === "percentage") {
            price = price * (1 - value / 100);
          }
        }
      }

      return {
        variant_id: Number(variantId),
        quantity: p.quantity,
        price: price.toString(), // Ensure price is string as per API requirement
        name: p.productData.title,
      };
    });

    return {
      doctor_id: selectedDoctor,
      patient_id: selectedPatient,
      items,
      coupon: appliedCoupon ? appliedCoupon.code : "",
      discount: appliedCoupon ? appliedCoupon.discount : null,
      // commission_rate: commissionRate,
      status: status,
    };
  };

  const handleSaveAsDraft = async () => {
    setIsLoading(true);
    try {
      const payload = createOrderPayload("draft");

      const res = await createDraftOrder(payload as any);

      setIsLoading(false);

      if (res && res.success) {
        toast({
          variant: "default",
          title: "Draft Saved Successfully",
          description: res.message || "Your order has been saved as a draft.",
        });

        if (fromPatientDetail && selectedPatient) {
          router.push(`/admin/patients/${selectedPatient}`);
        } else {
          router.push("/admin/draft-orders");
        }
      } else {
        toast({
          variant: "destructive",
          title: "Save Failed",
          description: res?.message || "Failed to save draft",
        });
      }
    } catch (error: any) {
      setIsLoading(false);
      // Prefer backend validation message when available
      let message = "Failed to save draft. Please try again.";
      try {
        const resp = error?.response?.data;
        if (resp) {
          if (resp.message) message = resp.message;
          const errs = resp.data?.errors || resp.errors;
          if (errs && typeof errs === "object") {
            const firstField = Object.keys(errs)[0];
            const firstMsg = errs[firstField]?.[0];
            if (firstMsg) message = firstMsg;
          }
        }
      } catch (e) {
        // ignore parsing errors
      }

      toast({
        variant: "destructive",
        title: "Error",
        description: message,
      });
      console.error("create draft error", error);
    }
  };

  const handleSendToPatient = async () => {
    setIsLoading(true);
    try {
      const payload = createOrderPayload("processing");

      const res = await createDraftOrder(payload as any);

      setIsLoading(false);

      if (res && res.success) {
        const doctor = doctors.find((d) => d.id === selectedDoctor);
        const patient = patients.find((p) => p.id === selectedPatient);
        const productCount = selectedProducts.reduce(
          (sum, p) => sum + p.quantity,
          0
        );
        const total = calculateTotal();

        toast({
          variant: "success",
          title: "Order Sent Successfully!",
          description: (
            <div className="space-y-2 mt-2">
              <div className="flex items-center space-x-2 text-sm">
                <User className="h-3 w-3" />
                <span>
                  Created by {doctor?.full_name} for {patient?.full_name}
                </span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Mail className="h-3 w-3" />
                <span>Prescription sent to patient</span>
              </div>
              <div className="flex items-center space-x-2 text-sm">
                <Package className="h-3 w-3" />
                <span>
                  {productCount} items •{" "}
                  <DirhamIcon className="h-[13px] w-4 text-muted-foreground" />{" "}
                  {total.toFixed(2)} total
                </span>
              </div>
              <div className="text-xs text-green-700 mt-2 p-2 bg-green-100 rounded">
                The patient will receive an email with their personalized
                supplement prescription and payment instructions.
              </div>
            </div>
          ),
        });

        // Optional: Redirect after a short delay
        setTimeout(() => {
          if (fromPatientDetail && selectedPatient) {
            router.push(`/admin/patients/${selectedPatient}`);
          } else {
            router.push("/admin/orders");
          }
        }, 3000);
      } else {
        toast({
          variant: "destructive",
          title: "Send Failed",
          description: res?.message || "Failed to send order",
        });
      }
    } catch (error: any) {
      setIsLoading(false);
      let message = "Failed to send order. Please try again.";
      try {
        const resp = error?.response?.data;
        if (resp) {
          if (resp.message) message = resp.message;
          const errs = resp.data?.errors || resp.errors;
          if (errs && typeof errs === "object") {
            const firstField = Object.keys(errs)[0];
            const firstMsg = errs[firstField]?.[0];
            if (firstMsg) message = firstMsg;
          }
        }
      } catch (e) {
        // ignore parsing errors
      }

      toast({
        variant: "destructive",
        title: "Error",
        description: message,
      });
      console.error("send order error", error);
    }
  };

  useEffect(() => {
    if (selectedDoctor) {
      const doctor = doctors.find((d) => d.id === selectedDoctor);
      if (doctor) {
        setCommissionRate(parseFloat(doctor.commission) || 0);
      }
    } else {
      setCommissionRate(0);
    }
  }, [selectedDoctor, doctors]);
  // Calculate commission amount
  const calculateCommission = () => {
    return calculateTotal() * (commissionRate / 100);
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const goToPage = (page: number) => {
    if (page >= 1 && page <= pagination.last_page) {
      loadProducts(page, searchTerm, categoryFilter);
    }
  };

  // Clear patient selection when doctor changes (only when not coming from details)
  useEffect(() => {
    if (isFromDetails) return;
    if (!didInitDoctorChange.current) {
      didInitDoctorChange.current = true;
      return;
    }
    setSelectedPatient("");
    setPatientSearchTerm("");
  }, [selectedDoctor, isFromDetails]);

  // Generate page numbers for pagination
  const generatePageNumbers = () => {
    const pages = [];
    const current = pagination.current_page;
    const last = pagination.last_page;

    // Always show first page
    pages.push(1);

    // Calculate range around current page
    let start = Math.max(2, current - 1);
    let end = Math.min(last - 1, current + 1);

    // Add ellipsis if needed
    if (start > 2) {
      pages.push("...");
    }

    // Add middle pages
    for (let i = start; i <= end; i++) {
      if (i !== 1 && i !== last) {
        pages.push(i);
      }
    }

    // Add ellipsis if needed
    if (end < last - 1) {
      pages.push("...");
    }

    // Always show last page if there is more than one page
    if (last > 1) {
      pages.push(last);
    }

    return pages;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full h-10 w-10 bg-transparent"
          onClick={() => router.back()}
        >
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Create New Order</h1>
          <p className="text-muted-foreground">
            Create a personalized supplement prescription for any patient
          </p>
        </div>
      </div>

      {/* First Row - Doctor and Patient Information */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Doctor Selection */}
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center space-x-2">
              <User className="h-5 w-5" />
              <span>Doctor Information</span>
            </CardTitle>
            <CardDescription>
              Select the doctor for this prescription
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="doctor">Select Doctor</Label>
                <Select
                  value={selectedDoctor}
                  onValueChange={setSelectedDoctor}
                >
                  <SelectTrigger disabled={isFromDetails}>
                    <SelectValue placeholder="Select a doctor" />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="p-2">
                      <Input
                        placeholder="Search..."
                        value={doctorSearchTerm}
                        onChange={(e) => setDoctorSearchTerm(e.target.value)}
                        className="mb-2"
                      />
                    </div>
                    {loadingData.doctors ? (
                      <div className="p-2 text-center text-sm text-muted-foreground">
                        Loading doctors...
                      </div>
                    ) : doctors.length === 0 ? (
                      <>
                        {preselectedDoctorName ? (
                          <SelectItem value="__not_selectable__" disabled>
                            {preselectedDoctorName}
                          </SelectItem>
                        ) : (
                          <div className="p-2 text-center text-sm text-muted-foreground">
                            No doctors found
                          </div>
                        )}
                      </>
                    ) : (
                      doctors.map((doctor) => (
                        <SelectItem key={doctor.id} value={doctor.id}>
                          {doctor.full_name}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              {selectedDoctor && (
                <div className="p-4 bg-gray-50 rounded-lg">
                  {(() => {
                    const doctor = doctors.find((d) => d.id === selectedDoctor);
                    return doctor ? (
                      <div className="space-y-2 text-center">
                        <div className="flex justify-center mb-2">
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
                            {getInitials(doctor.full_name)}
                          </div>
                        </div>
                        <h4 className="font-medium">{doctor.full_name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {doctor.email}
                        </p>
                        <Badge
                          variant={
                            doctor.status === "Active" ? "default" : "secondary"
                          }
                        >
                          {doctor.status}
                        </Badge>
                      </div>
                    ) : null;
                  })()}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Patient Selection */}
        <Card>
          <CardHeader className="text-center">
            <CardTitle>Patient Information</CardTitle>
            <CardDescription>
              Select the patient for this prescription
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="patient">Select Patient</Label>
                <Select
                  value={selectedPatient}
                  onValueChange={setSelectedPatient}
                >
                  <SelectTrigger disabled={isFromDetails}>
                    <SelectValue placeholder="Select a patient" />
                  </SelectTrigger>
                  <SelectContent>
                    <div className="p-2">
                      <Input
                        placeholder="Search..."
                        value={patientSearchTerm}
                        onChange={(e) => setPatientSearchTerm(e.target.value)}
                        className="mb-2"
                      />
                    </div>
                    {loadingData.patients ? (
                      <div className="p-2 text-center text-sm text-muted-foreground">
                        Loading patients...
                      </div>
                    ) : patients.length === 0 ? (
                      <>
                        {preselectedPatient ? (
                          <SelectItem
                            key={preselectedPatient.id}
                            value={preselectedPatient.id}
                          >
                            {preselectedPatient.full_name}
                          </SelectItem>
                        ) : (
                          <div className="p-2 text-center text-sm text-muted-foreground">
                            No patients found
                          </div>
                        )}
                      </>
                    ) : (
                      patients.map((patient) => (
                        <SelectItem key={patient.id} value={patient.id}>
                          {patient.full_name}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              {selectedPatient && (
                <div className="p-4 bg-gray-50 rounded-lg">
                  {(() => {
                    const patient =
                      patients.find((p) => p.id === selectedPatient) ||
                      preselectedPatient;
                    return patient ? (
                      <div className="space-y-2 text-center">
                        <div className="flex justify-center mb-2">
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground font-semibold">
                            {getInitials(patient.full_name)}
                          </div>
                        </div>
                        <h4 className="font-medium">{patient.full_name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {patient.email}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {patient?.phone_number}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          • {patient?.gender}
                        </p>
                        {/* <Badge
                          variant={
                            patient.status === "active"
                              ? "default"
                              : "secondary"
                          }
                        >
                          {patient.status}
                        </Badge> */}
                        <p className="text-sm text-muted-foreground">
                          Doctor: {patient.doctor_name}
                        </p>
                      </div>
                    ) : null;
                  })()}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Second Row - Products (2/3) and Cart (1/3) */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Available Products - 2/3 width */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Package className="h-5 w-5" />
                <span>Available Products</span>
              </CardTitle>
              <CardDescription>
                Browse and select products to add to the prescription
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Search and Filter */}
              <div className="flex gap-4 mb-6">
                <div className="relative flex-1">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-8"
                  />
                </div>
                <Select
                  value={categoryFilter}
                  onValueChange={setCategoryFilter}
                >
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    {loadingData.categories ? (
                      <SelectItem value="all">Loading...</SelectItem>
                    ) : (
                      categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category === "all"
                            ? "All Categories"
                            : category || "Uncategorized"}
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
              </div>

              {/* Products Grid */}
              <div className="grid gap-4 md:grid-cols-2">
                {loadingData.products ? (
                  <div className="col-span-2 text-center py-8 text-muted-foreground">
                    Loading products...
                  </div>
                ) : products.length === 0 ? (
                  <div className="col-span-2 text-center py-8 text-muted-foreground">
                    <Package className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <h3 className="text-lg font-medium mb-2">
                      No products found
                    </h3>
                    <p>Try adjusting your search or filter criteria</p>
                  </div>
                ) : (
                  products.map((product) => {
                    const isSelected = selectedProducts.some(
                      (p) => p.id === product.id
                    );
                    const selectedQuantity =
                      selectedProducts.find((p) => p.id === product.id)
                        ?.quantity || 0;
                    const variations = convertVariantsToVariations(product);
                    const defaultVariant = product.product_variants[0];
                    const selectedVariation: any =
                      selectedVariations[product.id];
                    const effectivePrice = selectedVariation
                      ? selectedVariation.price
                      : defaultVariant.price;
                    const inStock = selectedVariation
                      ? selectedVariation.inStock
                      : defaultVariant.inventory_summary.in_stock;

                    return (
                      <Card
                        key={product.id}
                        className={`transition-all hover:shadow-md ${
                          isSelected ? "ring-2 ring-primary" : ""
                        }`}
                      >
                        <CardContent className="p-4">
                          <div className="space-y-3">
                            {/* Product Header */}
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h4 className="font-semibold text-sm">
                                  {product.title}
                                </h4>
                                <Badge
                                  variant="outline"
                                  className="text-xs mt-1"
                                >
                                  {product.product_type || "Uncategorized"}
                                </Badge>
                              </div>
                              <div className="text-right">
                                <div className="font-bold text-lg flex items-center justify-end">
                                  <DirhamIcon className="h-[13px] w-4 text-muted-foreground mr-1" />
                                  {effectivePrice}
                                </div>
                                {product.variants_count > 1 &&
                                  selectedVariation && (
                                    <div className="text-xs text-green-600">
                                      {selectedVariation.name}
                                    </div>
                                  )}
                                <Badge
                                  variant={inStock ? "default" : "destructive"}
                                  className="text-xs"
                                >
                                  {inStock ? "In Stock" : "Out of Stock"}
                                </Badge>
                              </div>
                            </div>

                            {/* Product Description */}
                            <p className="text-sm text-muted-foreground line-clamp-2">
                              {product.vendor}
                            </p>

                            {/* Product Variations */}
                            {product.variants_count > 1 && (
                              <div className="mt-3">
                                <ProductVariationSelector
                                  product={{
                                    id: product.id,
                                    name: product.title,
                                    variations: variations,
                                  }}
                                  selectedVariation={selectedVariation}
                                  onVariationSelect={(variation) =>
                                    handleVariationSelect(product.id, variation)
                                  }
                                  compact={true}
                                />
                              </div>
                            )}

                            {/* Action Buttons */}
                            <div className="flex items-center justify-between pt-2">
                              {isSelected ? (
                                <div className="flex items-center space-x-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() =>
                                      updateQuantity(
                                        product.id,
                                        selectedQuantity - 1
                                      )
                                    }
                                    className="h-8 w-8 p-0"
                                  >
                                    <Minus className="h-3 w-3" />
                                  </Button>
                                  <span className="text-sm font-medium w-8 text-center">
                                    {selectedQuantity}
                                  </span>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() =>
                                      updateQuantity(
                                        product.id,
                                        selectedQuantity + 1
                                      )
                                    }
                                    className="h-8 w-8 p-0"
                                  >
                                    <Plus className="h-3 w-3" />
                                  </Button>
                                </div>
                              ) : (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => addProduct(product.id)}
                                  disabled={
                                    !inStock ||
                                    (product.variants_count > 1 &&
                                      !selectedVariation)
                                  }
                                  className="flex-1"
                                >
                                  <Plus className="h-3 w-3 mr-1" />
                                  Add to Cart
                                </Button>
                              )}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })
                )}
              </div>

              {/* Numbered Pagination */}
              {products.length > 0 && pagination.last_page > 1 && (
                <div className="mt-6 flex items-center justify-between">
                  <div className="text-sm text-muted-foreground">
                    Showing {pagination.from}-{pagination.to} of{" "}
                    {pagination.total} products
                  </div>

                  <div className="flex items-center space-x-2">
                    {/* Previous Button */}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => goToPage(pagination.current_page - 1)}
                      disabled={
                        pagination.current_page === 1 || loadingData.products
                      }
                      className="h-8 w-8 p-0"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>

                    {/* Page Numbers */}
                    {generatePageNumbers().map((page, index) =>
                      page === "..." ? (
                        <span
                          key={`ellipsis-${index}`}
                          className="px-2 text-sm text-muted-foreground"
                        >
                          ...
                        </span>
                      ) : (
                        <Button
                          key={page}
                          variant={
                            pagination.current_page === page
                              ? "default"
                              : "outline"
                          }
                          size="sm"
                          onClick={() => goToPage(page as number)}
                          disabled={loadingData.products}
                          className="h-8 w-8 p-0"
                        >
                          {page}
                        </Button>
                      )
                    )}

                    {/* Next Button */}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => goToPage(pagination.current_page + 1)}
                      disabled={
                        pagination.current_page === pagination.last_page ||
                        loadingData.products
                      }
                      className="h-8 w-8 p-0"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Cart/Order Summary - 1/3 width */}
        <div className="lg:col-span-1">
          <Card className="sticky top-6">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <ShoppingCart className="h-5 w-5" />
                <span>Cart</span>
                {selectedProducts.length > 0 && (
                  <Badge variant="secondary" className="ml-auto">
                    {selectedProducts.reduce((sum, p) => sum + p.quantity, 0)}
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>Review selected products</CardDescription>
            </CardHeader>
            <CardContent>
              {selectedProducts.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <ShoppingCart className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-sm">No products selected</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Cart Items */}
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {getSelectedProductDetails().map((product) => {
                      const displayPrice = getProductDisplayPrice(product);
                      const selectedVariation = product.selectedVariation;
                      const hasDiscount =
                        appliedCoupon?.discount.type === "line_item" &&
                        appliedCoupon.discount.line_items.some((item: any) => {
                          const variantId = product.selectedVariation
                            ? parseInt(product.selectedVariation.id)
                            : product.product_variants[0].variant_id;
                          return (
                            item.variant_id === variantId &&
                            item.applied_discount
                          );
                        });

                      return (
                        <div
                          key={product.id}
                          className="flex items-center justify-between p-3 border rounded-lg"
                        >
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-sm truncate">
                              {product.title}
                            </h4>
                            {selectedVariation && (
                              <p className="text-xs text-blue-600">
                                {selectedVariation.name} (
                                {selectedVariation.duration} days)
                              </p>
                            )}
                            <p className="text-xs text-muted-foreground flex items-center">
                              <DirhamIcon className="h-[13px] w-4 text-muted-foreground mr-1" />
                              {displayPrice.toFixed(2)} each
                              {hasDiscount &&
                                displayPrice !== product.price && (
                                  <span className="text-green-600 ml-2 line-through">
                                    <DirhamIcon className="h-[13px] w-4 mr-1" />
                                    {product.price.toFixed(2)}
                                  </span>
                                )}
                            </p>
                            {hasDiscount && (
                              <Badge
                                variant="outline"
                                className="text-xs bg-green-50 text-green-700 mt-1"
                              >
                                Discount Applied
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center space-x-2 ml-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                updateQuantity(product.id, product.quantity - 1)
                              }
                              className="h-6 w-6 p-0"
                            >
                              <Minus className="h-3 w-3" />
                            </Button>
                            <span className="text-sm font-medium w-6 text-center">
                              {product.quantity}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() =>
                                updateQuantity(product.id, product.quantity + 1)
                              }
                              className="h-6 w-6 p-0"
                            >
                              <Plus className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Coupon Section */}
                  <div className="space-y-3">
                    <CouponApply
                      onCouponApplied={setAppliedCoupon}
                      onCouponRemoved={() => setAppliedCoupon(null)}
                      appliedCoupon={appliedCoupon}
                      cartItems={getCartItemsForCoupon()}
                    />
                  </div>

                  {/* Cart Summary */}
                  <div className="border-t pt-4 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Items:</span>
                      <span className="text-sm">
                        {selectedProducts.reduce(
                          (sum, p) => sum + p.quantity,
                          0
                        )}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Subtotal:</span>
                      <span className="text-sm flex items-center">
                        <DirhamIcon className="h-[13px] w-4 text-muted-foreground mr-1" />
                        {calculateSubtotal().toFixed(2)}
                      </span>
                    </div>

                    {/* Discount Display */}
                    {appliedCoupon &&
                      appliedCoupon.discount.type !== "shipping" && (
                        <div className="flex justify-between items-center text-green-600">
                          <span className="text-sm">
                            Discount ({appliedCoupon.code}):
                          </span>
                          <span className="text-sm flex items-center">
                            -
                            <DirhamIcon className="h-[13px] w-4 text-green-600 mr-1" />
                            {calculateDiscountAmount().toFixed(2)}
                          </span>
                        </div>
                      )}

                    {/* Shipping Display */}
                    {/* Shipping Display */}
                    <div className="flex justify-between items-center text-sm">
                      <span>Shipping:</span>
                      <span className="text-sm flex items-center">
                        {calculateShipping() > 0 ? (
                          <>
                            <DirhamIcon className="h-[13px] w-4 text-muted-foreground mr-1" />
                            {calculateShipping().toFixed(2)}
                          </>
                        ) : (
                          "Free"
                        )}
                      </span>
                    </div>

                    {/* Show shipping breakdown if applicable */}
                    {hasNonServiceProductsInCart() && (
                      <div className="text-xs text-muted-foreground">
                        {calculateNonServiceSubtotal() <
                        shippingSettings.minimum_order_amount_for_shipping ? (
                          <div className="text-amber-600 bg-amber-50 p-2 rounded">
                            Shipping applied to {getNonServiceProductCount()}{" "}
                            non-service product(s) (Subtotal:{" "}
                            <DirhamIcon className="h-3 w-3 inline mx-1" />
                            {calculateNonServiceSubtotal().toFixed(2)})
                          </div>
                        ) : (
                          <div className="text-green-600 bg-green-50 p-2 rounded">
                            Free shipping (Subtotal:{" "}
                            <DirhamIcon className="h-3 w-3 inline mx-1" />
                            {calculateNonServiceSubtotal().toFixed(2)})
                          </div>
                        )}
                      </div>
                    )}

                    {/* Service products info */}
                    {selectedProducts.some(
                      (item) => item.productData.product_type === "Service"
                    ) && (
                      <div className="text-xs text-blue-600 bg-blue-50 p-2 rounded">
                        Service products are excluded from shipping calculation
                      </div>
                    )}
                    {/* <div className="flex justify-between items-center text-sm text-muted-foreground">
                      <span>Commission ({commissionRate}%):</span>
                      <span className="flex items-center">
                        <DirhamIcon className="h-[13px] w-4 text-muted-foreground mr-1" />
                        {calculateCommission().toFixed(2)}
                      </span>
                    </div> */}
                    <div className="border-t pt-2">
                      <div className="flex justify-between items-center font-medium">
                        <span>Total:</span>
                        <span className="text-lg flex items-center">
                          <DirhamIcon className="h-[13px] w-4 text-muted-foreground mr-1" />
                          {calculateTotal().toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="space-y-2 pt-4">
                    <Button
                      className="w-full bg-primary hover:bg-primary/90"
                      disabled={
                        !selectedDoctor ||
                        !selectedPatient ||
                        selectedProducts.length === 0 ||
                        isLoading
                      }
                      onClick={handleSendToPatient}
                    >
                      <Send className="h-4 w-4 mr-2" />
                      {isLoading ? "Sending..." : "Send to Patient"}
                    </Button>
                    <Button
                      variant="outline"
                      className="w-full bg-transparent"
                      onClick={handleSaveAsDraft}
                      disabled={isLoading}
                    >
                      <Save className="h-4 w-4 mr-2" />
                      {isLoading ? "Saving..." : "Save as Draft"}
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
