"use client";
import { useParams, useRouter } from "next/navigation";
import { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import {
  ArrowLeft,
  Mail,
  Phone,
  User,
  Calendar,
  Clock,
  Edit,
  Package,
  DollarSign,
  CheckCircle,
  MapPin,
  RefreshCw,
} from "lucide-react";
import { PatientOrderHistory } from "@/components/patients/patient-order-history";
import { EditPatientModal } from "@/components/patients/edit-patient-modal";
import { getPatientById, type Patient as ApiPatient } from "@/lib/doctorApi";
import { useToast } from "@/hooks/use-toast";
import { EditAdminPatientModal } from "@/components/admin/patients/edit-admin-patient-modal";
import { convertToDubaiTime } from "@/components/convertToDubaiTime";
import { DirhamIcon } from "@/components/ui/DirhamIcon";

// Transform API patient data to match your component structure
const transformPatientData = (apiPatient: any) => ({
  id: apiPatient.id,
  parent_id: "", // You might need to get this from your auth context
  name: apiPatient.full_name,
  email: apiPatient.email,
  phone: apiPatient.phone_number,
  addresses: apiPatient.address,
  age: apiPatient.age,
  gender: apiPatient.gender,
  lastVisit: apiPatient.created_at, // Use created_at for last visit
  totalOrders: apiPatient.orders || 0,
  totalSpent: parseFloat(apiPatient.total_spent) || 0,
  completedOrders: apiPatient.completed_orders || 0,
  status: apiPatient.status === "active" ? "Active" : "Inactive",
  created_at: apiPatient.created_at,
  doctor_name: apiPatient.doctor_name,
  villa_apartment: apiPatient.villa_apartment,
  area_street: apiPatient.area_street,
  nearby_landmark: apiPatient.nearby_landmark,
  emirates_states: apiPatient.emirates_states,
  country: apiPatient.country,
});

// Helper function to format date in Dubai timezone
const formatToDubaiDate = (utcDateString: string): string => {
  try {
    const date = new Date(utcDateString);
    // Convert to Dubai time (UTC+4)
    const dubaiTime = new Date(date.getTime() + 4 * 60 * 60 * 1000);

    // Format: DD/MM/YYYY
    const day = dubaiTime.getDate().toString().padStart(2, "0");
    const month = (dubaiTime.getMonth() + 1).toString().padStart(2, "0");
    const year = dubaiTime.getFullYear();

    return `${day}/${month}/${year}`;
  } catch (error) {
    console.error("Error formatting date:", error);
    return "N/A";
  }
};

// Helper function to calculate days since last visit
const calculateDaysSinceLastVisit = (dateString: string): number => {
  try {
    const date = new Date(dateString);
    const dubaiTime = new Date(date.getTime() + 4 * 60 * 60 * 1000);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - dubaiTime.getTime());
    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
  } catch (error) {
    console.error("Error calculating days:", error);
    return 0;
  }
};

export default function AdminPatientDetailPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const patientId = params.id as string;
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [patient, setPatient] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [patientOrders, setPatientOrders] = useState<any[]>([]);

  // Fetch patient details
  const fetchPatientDetails = useCallback(async () => {
    try {
      setIsLoading(true);
      const response = await getPatientById(patientId);

      if (response.success) {
        const transformedPatient = transformPatientData(response.data);
        setPatient(transformedPatient);

        // For now, we'll use mock orders. You can replace this with real API call later
        // const ordersResponse = await getPatientOrders(patientId);
        // setPatientOrders(ordersResponse.data.orders || []);
      } else {
        throw new Error(response.message || "Failed to fetch patient details");
      }
    } catch (error: any) {
      console.error("Failed to fetch patient details:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to load patient details",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [patientId, toast]);

  // Refresh patient data
  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchPatientDetails();
  };

  // Initial fetch
  useEffect(() => {
    if (patientId) {
      fetchPatientDetails();
    }
  }, [patientId, fetchPatientDetails]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-xl font-semibold">Loading Patient Details...</h2>
          <p className="text-muted-foreground mt-2">
            Please wait while we fetch the patient information.
          </p>
        </div>
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <h2 className="text-2xl font-semibold">Patient Not Found</h2>
          <p className="text-muted-foreground mt-2">
            The requested patient could not be found.
          </p>
          <Button onClick={() => router.push("/patients")} className="mt-4">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Patients
          </Button>
        </div>
      </div>
    );
  }

  const totalSpent = patientOrders.reduce(
    (sum: number, order: any) => sum + order.total,
    0
  );
  const completedOrders = patientOrders.filter(
    (o: any) => o.status === "Completed"
  ).length;
  const pendingOrders = patientOrders.filter(
    (o: any) => o.status === "Processing"
  ).length;
  const draftOrders = patientOrders.filter(
    (o: any) => o.status === "Draft"
  ).length;

  // Generate initials from patient name
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  // Calculate days since last visit using created_at
  const daysSinceLastVisit = calculateDaysSinceLastVisit(patient.created_at);
  const formattedLastVisit = convertToDubaiTime(patient.created_at);

  // Handle Create Order - navigate to order creation with pre-selected patient
  const handleCreateOrder = () => {
    router.push(
      `/admin/orders/create?patientId=${patientId}&fromPatientDetail=1`
    );
  };

  // Handle patient updated
  const handlePatientUpdated = () => {
    setIsEditModalOpen(false);
    fetchPatientDetails(); // Refresh patient data
    toast({
      title: "Success",
      description: "Patient information updated successfully",
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="icon"
            className="rounded-full h-10 w-10 bg-transparent"
            onClick={() => router.push("/admin/patients")}
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{patient.name}</h1>
            <p className="text-muted-foreground">
              Patient profile and order history
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Button variant="outline" size="sm" onClick={handleCreateOrder}>
            <Package className="h-4 w-4 mr-2" />
            Create Order
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsEditModalOpen(true)}
          >
            <Edit className="h-4 w-4 mr-2" />
            Edit Profile
          </Button>
        </div>
      </div>

      {/* Patient Profile Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <User className="h-5 w-5" />
              <span>Patient Profile</span>
            </div>
            <Badge
              variant={patient.status === "Active" ? "default" : "secondary"}
              className={
                patient.status === "Active"
                  ? "bg-primary hover:bg-primary/90"
                  : ""
              }
            >
              {patient.status}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Main Profile Section */}
          <div className="flex items-start space-x-6">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="text-xl font-semibold bg-primary text-primary-foreground">
                {getInitials(patient.name)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 space-y-4">
              <div>
                <h3 className="text-2xl font-semibold">{patient.name}</h3>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground mt-1">
                  {/* <span>ID: {patient.id}</span> */}
                  <span>Doctor: {patient.doctor_name}</span>
                </div>
              </div>

              {/* Key Metrics */}
              <div className="grid grid-cols-4 gap-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-xl font-bold text-primary">
                    {patient.totalOrders}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Total Orders
                  </div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-xl font-bold text-green-600">
                    <DirhamIcon />
                    {patient?.totalSpent}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Total Spent
                  </div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-xl font-bold text-secondary">
                    {patient?.completedOrders}
                  </div>
                  <div className="text-xs text-muted-foreground">Completed</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-xl font-bold text-orange-600">
                    {daysSinceLastVisit}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Days Since Created At{" "}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Basic Information */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Personal Information */}
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <User className="h-4 w-4" />
                <span>Personal Information</span>
              </h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Age & Gender</div>
                    <div className="text-sm text-muted-foreground">
                      {patient.age} years old, {patient.gender}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Address</div>
                    <div className="text-sm text-muted-foreground">
                      {[
                        patient.villa_apartment,
                        patient.area_street,
                        patient.nearby_landmark,
                        patient.emirates_states,
                        patient.country,
                      ]
                        .filter(Boolean)
                        .join(", ")}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Created On</div>
                    <div className="text-sm text-muted-foreground">
                      {convertToDubaiTime(patient.created_at)}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="space-y-4">
              <h4 className="font-semibold text-gray-900 flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>Contact Information</span>
              </h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Email</div>
                    <div className="text-sm text-muted-foreground">
                      {patient.email}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Phone</div>
                    <div className="text-sm text-muted-foreground">
                      {patient.phone}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Order History */}
      <PatientOrderHistory
        // orders={patientOrders}
        handleCreateOrder={handleCreateOrder}
        patientId={patientId}
        completedOrder={patient?.completedOrders}
      />

      {/* Edit Patient Modal */}
      {patient && (
        <EditAdminPatientModal
          patient={patient}
          isOpen={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onPatientUpdated={handlePatientUpdated}
        />
      )}
    </div>
  );
}
