"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Users, UserCheck, UserX, Clock, Loader2 } from "lucide-react";
import { DataTable } from "@/components/patients/data-table";
import { AddAdminPatientModal } from "@/components/add-admin-patient-modal";
import { useAuth } from "@/lib/auth-context";
import {
  getPatients,
  deletePatient,
  getDoctorsList,
  type Patient as ApiPatient,
  type Doctor,
} from "@/lib/doctorApi";
import { createColumns } from "@/components/admin/patients/columns";
import { EditPatientModal } from "@/components/patients/edit-patient-modal";
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog";
import { useToast } from "@/hooks/use-toast";
import { useDebounce } from "@/hooks/use-debounce";
import { EditAdminPatientModal } from "@/components/admin/patients/edit-admin-patient-modal";
import {
  convertToDubaiDate,
  convertToDubaiTime,
} from "@/components/convertToDubaiTime";

interface AdminPatientManagementProps {
  className?: string;
}

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

interface ConfirmationState {
  isOpen: boolean;
  title: string;
  description: string;
  patient: any | null;
}

// Transform API patient data to match your table structure
const transformPatientData = (apiPatient: any) => {
  // Build address by directly combining all address components
  const addressParts = [
    apiPatient?.villa_apartment,
    apiPatient?.area_street,
    apiPatient?.emirates_states,
    apiPatient?.nearby_landmark,
    apiPatient?.country,
  ]?.filter((part) => part && part.trim() !== "");

  const formattedAddress = addressParts.join(", ");

  return {
    id: apiPatient.id,
    parent_id: apiPatient.parent_id || "",
    name: apiPatient.full_name,
    email: apiPatient.email,
    phone: apiPatient.phone_number,
    addresses: formattedAddress, // Direct combined address
    age: apiPatient.age,
    gender: apiPatient.gender,
    created_at: convertToDubaiTime(apiPatient.created_at),
    totalOrders: apiPatient?.orders || 0,
    status: apiPatient.status === "active" ? "Active" : "Inactive",
    // Keep original fields for admin view
    doctor_name: apiPatient.doctor_name,
    // Include individual address fields for editing modal
    villa_apartment: apiPatient.villa_apartment,
    area_street: apiPatient.area_street,
    nearby_landmark: apiPatient.nearby_landmark,
    country: apiPatient.country,
    emirates_states: apiPatient.emirates_states,
    originalData: apiPatient,
  };
};

// Helper function to format date
const formatDate = (dateString: string) => {
  if (!dateString) return "N/A";
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return "N/A";
  }
};

export default function AdminPatientsPage({
  className = "",
}: AdminPatientManagementProps) {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [patients, setPatients] = useState<any[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);

  const [confirmation, setConfirmation] = useState<ConfirmationState>({
    isOpen: false,
    title: "",
    description: "",
    patient: null,
  });

  const [pagination, setPagination] = useState({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
  });

  const [total, setTotal] = useState<any>(null);

  const [filters, setFilters] = useState({
    search: "",
    sort_by: "created_at",
    sort_order: "desc" as "asc" | "desc",
    page: 1,
    per_page: 10,
  });

  const [searchTerm, setSearchTerm] = useState("");
  const debouncedSearch = useDebounce(searchTerm, 500);

  const hasFetched = useRef(false);

  // Check if user has specific permission
  const hasPermission = useCallback(
    (permission: string): boolean => {
      if (!userPermissions || !userPermissions.permission) {
        console.log("No user permissions found for check:", permission);
        return false;
      }

      const hasPerm = userPermissions.permission.includes(permission);
      console.log(
        `Permission check for ${permission}:`,
        hasPerm,
        "Available permissions:",
        userPermissions.permission
      );
      return hasPerm;
    },
    [userPermissions]
  );

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        console.log("Raw user data from localStorage:", userData);

        if (userData) {
          const user = JSON.parse(userData);
          console.log("Parsed user permissions:", user);
          setUserPermissions(user);
        } else {
          console.log("No user data found in localStorage");
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();

    // Also listen for storage changes
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Fetch patients from API
  const fetchPatients = useCallback(async () => {
    // Don't fetch if we don't have read permission
    if (!hasPermission("patient_read")) {
      console.log("No patient_read permission, skipping patient fetch");
      return;
    }

    setIsLoading(true);
    try {
      const response: any = await getPatients({
        ...filters,
        search: debouncedSearch || undefined,
      });

      if (response.success) {
        const transformedPatients =
          response.data.patients.map(transformPatientData);
        setPatients(transformedPatients);
        setPagination(response.data.pagination);
        setTotal(response?.data?.summary);
        hasFetched.current = true;
      }
    } catch (error) {
      console.error("Failed to fetch patients:", error);
      toast({
        title: "Error",
        description: "Failed to load patients",
        variant: "destructive",
      });
      setPatients([]);
      setPagination({
        current_page: 1,
        last_page: 1,
        per_page: 10,
        total: 0,
        from: 0,
        to: 0,
      });
    } finally {
      setIsLoading(false);
    }
  }, [filters, debouncedSearch, toast, hasPermission]);

  // Initial fetch - only once on mount and when permissions are loaded
  useEffect(() => {
    if (
      permissionsLoaded &&
      hasPermission("patient_read") &&
      !hasFetched.current
    ) {
      fetchPatients();
    }
  }, [permissionsLoaded, hasPermission, fetchPatients]);

  // Fetch when filters change - separate useEffect
  useEffect(() => {
    if (
      hasFetched.current &&
      permissionsLoaded &&
      hasPermission("patient_read")
    ) {
      const timeoutId = setTimeout(() => {
        fetchPatients();
      }, 300);

      return () => clearTimeout(timeoutId);
    }
  }, [filters, fetchPatients, permissionsLoaded, hasPermission]);

  const activePatients = patients.filter((p) => p.status === "Active").length;
  const inactivePatients = patients.filter(
    (p) => p.status === "Inactive"
  ).length;
  const totalOrders = patients.reduce((sum, p) => sum + p.totalOrders, 0);

  // Action handlers
  const handleViewDetails = useCallback(
    (patientId: string) => {
      if (!hasPermission("patient_read")) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to view patient details.",
        });
        return;
      }
      router.push(`/admin/patients/${patientId}`);
    },
    [router, toast, hasPermission]
  );

  const handleEditPatient = useCallback(
    (patient: any) => {
      if (!hasPermission("patient_update")) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to edit patients.",
        });
        return;
      }
      setSelectedPatient(patient);
      setIsEditModalOpen(true);
    },
    [toast, hasPermission]
  );

  // Delete confirmation handlers
  const handleDeletePatient = useCallback(
    (patient: any) => {
      if (!hasPermission("patient_delete")) {
        toast({
          variant: "destructive",
          title: "Access Denied",
          description: "You don't have permission to delete patients.",
        });
        return;
      }

      setConfirmation({
        isOpen: true,
        title: "Delete Patient",
        description: `Are you sure you want to delete ${patient.name}? This action cannot be undone.`,
        patient: patient,
      });
    },
    [toast, hasPermission]
  );

  const handleConfirmDelete = async () => {
    if (!confirmation.patient) return;

    const patient = confirmation.patient;
    setDeletingId(patient.id);

    try {
      const response = await deletePatient(patient.id);

      if (response.success) {
        toast({
          title: "Success",
          description: response.message || "Patient deleted successfully",
        });

        // Close confirmation dialog
        setConfirmation({
          isOpen: false,
          title: "",
          description: "",
          patient: null,
        });

        // Reload patients list
        fetchPatients();
      } else {
        throw new Error(response.message || "Failed to delete patient");
      }
    } catch (error: any) {
      console.error("Delete error:", error);
      toast({
        title: "Error",
        description:
          error?.response?.data?.message ||
          error.message ||
          "Failed to delete patient",
        variant: "destructive",
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleCancelDelete = () => {
    setConfirmation({
      isOpen: false,
      title: "",
      description: "",
      patient: null,
    });
    setDeletingId(null);
  };

  const handleCloseEditModal = useCallback(() => {
    setIsEditModalOpen(false);
    setSelectedPatient(null);
  }, []);

  const handlePatientUpdated = useCallback(() => {
    handleCloseEditModal();
    fetchPatients();
  }, [handleCloseEditModal, fetchPatients]);

  // Handle search
  const handleSearch = useCallback((searchTerm: string) => {
    setSearchTerm(searchTerm);
    setFilters((prev) => ({
      ...prev,
      page: 1,
    }));
  }, []);

  // Handle pagination
  const handlePaginationChange = useCallback(
    (page: number, pageSize: number) => {
      setFilters((prev) => ({
        ...prev,
        page,
        per_page: pageSize,
      }));
    },
    []
  );

  // Handle sorting
  const handleSortingChange = useCallback((sorting: any[]) => {
    if (sorting.length > 0) {
      const sort = sorting[0];
      setFilters((prev) => ({
        ...prev,
        sort_by: mapSortField(sort.id),
        sort_order: sort.desc ? "desc" : "asc",
        page: 1,
      }));
    } else {
      setFilters((prev) => ({
        ...prev,
        sort_by: "created_at",
        sort_order: "desc",
      }));
    }
  }, []);

  // Map frontend sort fields to backend sort fields
  const mapSortField = (frontendField: string): string => {
    const fieldMap: { [key: string]: string } = {
      name: "full_name",
      email: "email",
      age: "age",
      created_at: "created_at",
      totalOrders: "total_orders",
      status: "status",
      doctor_name: "doctor_name",
    };
    return fieldMap[frontendField] || frontendField;
  };

  // Handle patient added successfully
  const handlePatientAdded = useCallback(() => {
    fetchPatients();
    setIsAddDialogOpen(false);
  }, [fetchPatients]);

  // Create columns with action handlers and permission checks
  const columns = createColumns(
    handleViewDetails,
    handleEditPatient,
    handleDeletePatient,
    {
      canEdit: hasPermission("patient_update"),
      canDelete: hasPermission("patient_delete"),
    }
  );

  // Show loading while permissions are being loaded
  if (!permissionsLoaded) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-16 w-16 text-muted-foreground mx-auto mb-4 animate-spin" />
          <h3 className="text-lg font-medium mb-2">Loading...</h3>
          <p className="text-muted-foreground">Checking permissions...</p>
        </div>
      </div>
    );
  }

  // Show no access message if user has no read permissions
  if (!hasPermission("patient_read")) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You don't have permission to access patient management. Available
            permissions: {userPermissions?.permission?.join(", ") || "None"}
          </p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className={`space-y-4 sm:space-y-6 ${className}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
            Patient Management
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Manage all patients across the system
          </p>
        </div>
        {hasPermission("patient_write") && (
          <Button
            className="bg-primary hover:bg-primary/90 w-full sm:w-auto"
            onClick={() => setIsAddDialogOpen(true)}
            disabled={isLoading}
          >
            Add Patient
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Patients
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {total?.total_patients || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              All registered patients
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Active Patients
            </CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {total?.active_patients || 0}
            </div>
            <p className="text-xs text-muted-foreground">Currently active</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Inactive Patients
            </CardTitle>
            <UserX className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-muted-foreground">
              {total?.inactive_patients || 0}
            </div>
            <p className="text-xs text-muted-foreground">Need follow-up</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <Badge variant="outline" className="text-xs">
              {total?.total_orders || 0}
            </Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">
              {total?.total_orders || 0}
            </div>
            <p className="text-xs text-muted-foreground">All patient orders</p>
          </CardContent>
        </Card>
      </div>

      {/* Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Patient Records</CardTitle>
          <CardDescription>
            Comprehensive view of all patients with advanced filtering and
            sorting capabilities
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <DataTable
              columns={columns}
              data={patients}
              isLoading={isLoading}
              pagination={pagination}
              onSearch={handleSearch}
              onPaginationChange={handlePaginationChange}
              onSortingChange={handleSortingChange}
              canExport={hasPermission("patient_export")}
            />
          </div>
        </CardContent>
      </Card>

      {/* Add Patient Modal */}
      {hasPermission("patient_write") && (
        <AddAdminPatientModal
          isOpen={isAddDialogOpen}
          onClose={() => setIsAddDialogOpen(false)}
          onPatientAdded={handlePatientAdded}
          doctors={doctors}
        />
      )}

      {/* Edit Patient Modal */}
      {selectedPatient && hasPermission("patient_update") && (
        <EditAdminPatientModal
          patient={selectedPatient}
          isOpen={isEditModalOpen}
          onClose={handleCloseEditModal}
          onPatientUpdated={handlePatientUpdated}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        onClose={handleCancelDelete}
        onConfirm={handleConfirmDelete}
        title={confirmation.title}
        description={confirmation.description}
        confirmText="Delete"
        cancelText="Cancel"
        variant="destructive"
        isLoading={deletingId === (confirmation.patient?.id || null)}
      />
    </div>
  );
}
