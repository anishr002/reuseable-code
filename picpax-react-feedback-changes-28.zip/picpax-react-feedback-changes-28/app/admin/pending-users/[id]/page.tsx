"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  Users,
  FileText,
  Edit,
  Briefcase,
  MapPin,
  Calendar,
  GraduationCap,
  Shield,
  Building,
  Stethoscope,
  Eye,
  Download,
  Clock,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  getPendingUserDetail,
  type PendingUserDetail,
  type PendingUserDocument,
} from "@/lib/doctorApi";

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

export default function PendingUserDetailPage() {
  const { toast } = useToast();
  const params = useParams();
  const router = useRouter();
  const userId = params.id as string;

  const [pendingUser, setPendingUser] = useState<PendingUserDetail | null>(
    null
  );
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    // Add null check and ensure permission array exists
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          console.log("User permissions loaded:", user.permission);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Handle logout and authentication state changes
  useEffect(() => {
    const handleStorageChange = () => {
      const userData = localStorage.getItem("picpax_user");
      if (!userData) {
        // User logged out, clear state and stop any pending requests
        setPendingUser(null);
        setIsLoading(false);
      }
    };

    window.addEventListener("storage", handleStorageChange);

    // Also check on mount if user exists
    const userData = localStorage.getItem("picpax_user");
    if (!userData) {
      setIsLoading(false);
    }

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  // Load pending user details
  useEffect(() => {
    const loadPendingUserDetail = async () => {
      if (!userId) return;

      // Check permissions before making API call
      if (!hasPermission("pendingUser_read")) {
        console.log("No permission to read pending user details");
        setIsLoading(false);
        return;
      }

      setIsLoading(true);
      setHasError(false);

      try {
        console.log("Loading pending user detail for ID:", userId);
        const response = await getPendingUserDetail(userId);
        console.log("API Response - User Detail:", response);

        if (response.success) {
          setPendingUser(response.data);
        } else {
          setHasError(true);
          toast({
            variant: "destructive",
            title: "Error",
            description: response.message || "Failed to load user details",
          });
        }
      } catch (error: any) {
        console.error("Error loading pending user detail:", error);
        setHasError(true);
        toast({
          variant: "destructive",
          title: "Error",
          description:
            error.response?.data?.message || "Failed to load user details",
        });
      } finally {
        setIsLoading(false);
      }
    };

    // Only load if permissions are available
    if (permissionsLoaded && hasPermission("pendingUser_read")) {
      loadPendingUserDetail();
    } else if (permissionsLoaded) {
      setIsLoading(false);
    }
  }, [userId, toast, permissionsLoaded]);

  const formatFileSize = (fileSize: string): string => {
    return fileSize; // The API already returns formatted file size like "190.75 KB"
  };

  const getCategoryFromFileName = (fileName: string): string => {
    const lowerCaseName = fileName.toLowerCase();
    if (
      lowerCaseName.includes("license") ||
      lowerCaseName.includes("licence")
    ) {
      return "License";
    } else if (
      lowerCaseName.includes("degree") ||
      lowerCaseName.includes("education") ||
      lowerCaseName.includes("certificate")
    ) {
      return "Education";
    } else if (
      lowerCaseName.includes("id") ||
      lowerCaseName.includes("identification") ||
      lowerCaseName.includes("proof")
    ) {
      return "Identification";
    } else if (
      lowerCaseName.includes("registration") ||
      lowerCaseName.includes("clinic")
    ) {
      return "Registration";
    } else if (lowerCaseName.includes("insurance")) {
      return "Insurance";
    } else {
      return "Other";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "License":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "Education":
        return "bg-green-100 text-green-800 border-green-200";
      case "Identification":
        return "bg-purple-100 text-purple-800 border-purple-200";
      case "Registration":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "Insurance":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const handleDownloadDocument = (doc: PendingUserDocument) => {
    // Create a temporary link to download the file
    const link = document.createElement("a");
    link.href = doc.url;
    link.download = doc.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleViewDocument = (doc: PendingUserDocument) => {
    // Open the document in a new tab
    window.open(doc.url, "_blank");
  };

  // Show no access message if user has no permissions
  if (!hasPermission("pendingUser_read")) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Access Denied</h3>
          <p className="text-muted-foreground mb-4">
            You don't have permission to access pending user details.
          </p>
          <Button onClick={() => router.push("/admin/pending-users")}>
            Back to Pending Users
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading user details...</p>
        </div>
      </div>
    );
  }

  if (hasError || !pendingUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <User className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">User not found</h3>
          <p className="text-muted-foreground mb-4">
            {hasError
              ? "There was an error loading the user details."
              : "The requested user could not be found."}
          </p>
          <Button onClick={() => router.push("/admin/pending-users")}>
            Back to Pending Users
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={() => router.push("/admin/pending-users")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Pending Users
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              {pendingUser.title} {pendingUser.first_name}{" "}
              {pendingUser.last_name}
            </h1>
            <p className="text-muted-foreground">Pending User Details</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            General Information
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Documents ({pendingUser.documents.length})
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: General Information (Active by default) */}
        <TabsContent value="general" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Basic Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Full Name
                  </Label>
                  <p className="text-sm font-medium">
                    {pendingUser.title} {pendingUser.first_name}{" "}
                    {pendingUser.last_name}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Gender
                  </Label>
                  <p className="text-sm capitalize">{pendingUser.gender}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Medical Specialty
                  </Label>
                  <div className="flex items-center gap-2">
                    <Stethoscope className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm capitalize">
                      {pendingUser.medical_speciality}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Email Address
                  </Label>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm">{pendingUser.email}</p>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Phone Number
                  </Label>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm">{pendingUser.phone_number}</p>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Contact Number
                  </Label>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm">{pendingUser.contact_number}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Professional Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  Professional Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Clinic Name
                  </Label>
                  <p className="text-sm">{pendingUser.clinic_name}</p>
                </div>
                {/* <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Clinic Practice
                  </Label>
                  <p className="text-sm">{pendingUser.clinic_practice}</p>
                </div> */}

                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Medical License
                  </Label>
                  <div className="flex items-center gap-2">
                    <Shield className="h-4 w-4 text-muted-foreground" />
                    <p className="text-sm font-mono">
                      {pendingUser.medical_license}
                    </p>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Emirates/State
                  </Label>
                  <Badge variant="outline">{pendingUser.emirates_states}</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Address Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Address Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                <p className="text-sm">{pendingUser.address}</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: Documents - Only List View */}
        <TabsContent value="documents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                User Documents
              </CardTitle>
              <CardDescription>
                Verification documents submitted by the user
              </CardDescription>
            </CardHeader>
            <CardContent>
              {pendingUser.documents.length === 0 ? (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">
                    No documents found
                  </h3>
                  <p className="text-muted-foreground">
                    This user hasn't uploaded any documents yet.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {pendingUser.documents.map((document) => {
                      const category = getCategoryFromFileName(document.name);
                      return (
                        <Card key={document.id} className="overflow-hidden">
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between mb-3">
                              <div className="flex items-center gap-2">
                                <FileText className="h-5 w-5 text-blue-600" />
                                <div>
                                  <p className="font-medium text-sm truncate max-w-[180px]">
                                    {document.name}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {formatFileSize(document.file_size)}
                                  </p>
                                </div>
                              </div>
                              <Badge
                                variant="outline"
                                className={`text-xs ${getCategoryColor(
                                  category
                                )}`}
                              >
                                {category}
                              </Badge>
                            </div>

                            <div className="space-y-2 text-xs text-muted-foreground">
                              <div className="flex justify-between">
                                <span>Uploaded:</span>
                                <span className="font-medium">
                                  {new Date(
                                    document.uploaded_at
                                  ).toLocaleDateString()}
                                </span>
                              </div>
                              <div className="flex justify-between">
                                <span>Type:</span>
                                <span className="font-medium">
                                  PDF Document
                                </span>
                              </div>
                            </div>

                            <div className="mt-4 flex gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1"
                                onClick={() => handleViewDocument(document)}
                              >
                                <Eye className="h-3 w-3 mr-1" />
                                View
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                className="flex-1"
                                onClick={() => handleDownloadDocument(document)}
                              >
                                <Download className="h-3 w-3 mr-1" />
                                Download
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
