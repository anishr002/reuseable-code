"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog";
import {
  getPendingUsers,
  bulkActionPendingUsers,
  type PendingUser,
  type PendingUsersFilters,
  type BulkActionPayload,
} from "@/lib/doctorApi";
import { useToast } from "@/hooks/use-toast";
import {
  Search,
  MoreHorizontal,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ArrowUp,
  ArrowDown,
  Users,
  Clock,
  CheckCircle,
  XCircle,
  Settings,
  Filter,
  MessageCircle,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import Link from "next/link";
import { CommissionUpdateModal } from "@/components/commission-update-modal";
import { RequestMoreDialog } from "@/components/RequestMoreDialog";

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

interface ConfirmationState {
  isOpen: boolean;
  action: "approve" | "reject" | "delete" | null;
  items: PendingUser[];
  title: string;
  description: string;
  message?: string; // Add this for request more
}

export default function PendingUsersPage() {
  const { toast } = useToast();
  const [pendingUsers, setPendingUsers] = useState<PendingUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState<Set<string>>(new Set());
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [isBulkActionLoading, setIsBulkActionLoading] = useState(false);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);

  // Confirmation dialog state
  const [confirmation, setConfirmation] = useState<ConfirmationState>({
    isOpen: false,
    action: null,
    items: [],
    title: "",
    description: "",
  });

  // Filters and pagination
  const [filters, setFilters] = useState<PendingUsersFilters>({
    name: "",
    email: "",
    emirates_states: "",
    sort_by: "created_at",
    sort_order: "desc",
    per_page: 10,
    page: 1,
    status: "",
  });

  const [pagination, setPagination] = useState({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
    has_more_pages: false,
  });

  const [summary, setSummary] = useState({
    total_pending: 0,
    total_approved: 0,
    total_rejected: 0,
    filtered_count: 0,
  });
  const [commissionModal, setCommissionModal] = useState({
    isOpen: false,
    user: null as PendingUser | null,
  });
  const [requestMoreModal, setRequestMoreModal] = useState({
    isOpen: false,
    user: null as PendingUser | null,
  });

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    // Add null check and ensure permission array exists
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          console.log("User permissions loaded:", user.permission);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Handle logout and authentication state changes
  useEffect(() => {
    const handleStorageChange = () => {
      const userData = localStorage.getItem("picpax_user");
      if (!userData) {
        // User logged out, clear state and stop any pending requests
        setPendingUsers([]);
        setSelectedUsers(new Set());
        setIsLoading(false);
      }
    };

    window.addEventListener("storage", handleStorageChange);

    // Also check on mount if user exists
    const userData = localStorage.getItem("picpax_user");
    if (!userData) {
      setIsLoading(false);
    }

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  // Custom debounce hook
  const useDebounce = (callback: Function, delay: number) => {
    const timeoutRef = useRef<NodeJS.Timeout>();

    return useCallback(
      (...args: any[]) => {
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }

        timeoutRef.current = setTimeout(() => {
          callback(...args);
        }, delay);
      },
      [callback, delay]
    );
  };

  const debouncedSearch = useDebounce((newFilters: PendingUsersFilters) => {
    loadPendingUsers(newFilters);
  }, 500);

  // Load pending users
  const loadPendingUsers = async (newFilters?: PendingUsersFilters) => {
    // Check permissions before making API call
    if (!hasPermission("pendingUser_read")) {
      console.log("No permission to read pending users");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setHasError(false);
    try {
      console.log("Loading pending users with filters:", newFilters || filters);
      const filtersToUse = newFilters || filters;
      const response = await getPendingUsers(filtersToUse);
      console.log("API Response received:", response);

      setPendingUsers(response.data.doctors);
      setPagination(response.data.pagination);
      setSummary(response.data.summary);

      if (newFilters) {
        setFilters(newFilters);
      }

      // Clear selection when data changes
      setSelectedUsers(new Set());
    } catch (error: any) {
      console.error("Error loading pending users:", error);
      setHasError(true);
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message || "Failed to load pending users data",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Add these handler functions
  const handleCommissionUpdate = (user: PendingUser) => {
    // Check permission
    if (!hasPermission("pendingUser_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to update user commissions.",
      });
      return;
    }

    setCommissionModal({
      isOpen: true,
      user,
    });
  };

  const handleCommissionModalClose = () => {
    setCommissionModal({
      isOpen: false,
      user: null,
    });
  };

  const handleCommissionUpdated = () => {
    // Reload the users list to reflect any changes
    loadPendingUsers(filters);
  };

  // Initial load - only load if permissions are available
  useEffect(() => {
    if (permissionsLoaded && hasPermission("pendingUser_read")) {
      console.log("Component mounted, loading pending users...");
      loadPendingUsers();
    } else if (permissionsLoaded) {
      setIsLoading(false);
    }
  }, [permissionsLoaded]);

  // Handle filter changes with debouncing
  const handleFilterChange = (
    key: keyof PendingUsersFilters,
    value: string
  ) => {
    const newFilters = {
      ...filters,
      [key]: value,
      page: 1, // Reset to first page when filtering
    };
    setFilters(newFilters);
    debouncedSearch(newFilters);
  };

  // Handle sorting
  const handleSort = (column: string) => {
    const newSortOrder =
      filters.sort_by === column && filters.sort_order === "asc"
        ? "desc"
        : "asc";

    const newFilters: any = {
      ...filters,
      sort_by: column,
      sort_order: newSortOrder,
      page: 1,
    };
    setFilters(newFilters);
    loadPendingUsers(newFilters);
  };

  const getSortIcon = (column: string) => {
    if (filters.sort_by !== column) {
      return <ArrowUp className="h-4 w-4 opacity-30" />;
    }
    return filters.sort_order === "asc" ? (
      <ArrowUp className="h-4 w-4" />
    ) : (
      <ArrowDown className="h-4 w-4" />
    );
  };

  // Pagination handlers
  const handlePageChange = (newPage: number) => {
    const newFilters = {
      ...filters,
      page: newPage,
    };
    setFilters(newFilters);
    loadPendingUsers(newFilters);
  };

  // Selection handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      // Only select users with status "Pending"
      const pendingUserIds = pendingUsers
        .filter((user) => user.status === "Pending")
        .map((user) => user.id);
      setSelectedUsers(new Set(pendingUserIds));
    } else {
      setSelectedUsers(new Set());
    }
  };

  const handleSelectUser = (userId: string, checked: boolean) => {
    const newSelected = new Set(selectedUsers);
    if (checked) {
      newSelected.add(userId);
    } else {
      newSelected.delete(userId);
    }
    setSelectedUsers(newSelected);
  };

  const isAllSelected =
    selectedUsers.size ===
      pendingUsers.filter((user) => user.status === "Pending").length &&
    pendingUsers.filter((user) => user.status === "Pending").length > 0;
  const isSomeSelected =
    selectedUsers.size > 0 &&
    selectedUsers.size <
      pendingUsers.filter((user) => user.status === "Pending").length;

  // Bulk action handlers with permission checks
  const handleBulkAction = (action: "approve" | "reject" | "delete") => {
    const selectedItems = pendingUsers.filter((user) =>
      selectedUsers.has(user.id)
    );

    if (selectedItems.length === 0) return;

    // Check permissions
    if (
      (action === "approve" || action === "reject") &&
      !hasPermission("pendingUser_update")
    ) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to approve or reject users.",
      });
      return;
    }

    if (action === "delete" && !hasPermission("pendingUser_delete")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to delete users.",
      });
      return;
    }

    const actionTitles = {
      approve: "Approve Users",
      reject: "Reject Users",
      delete: "Delete Users",
    };

    const actionDescriptions = {
      approve: `Are you sure you want to approve ${selectedItems.length} user(s)? This will grant them access to the system.`,
      reject: `Are you sure you want to reject ${selectedItems.length} user(s)? They will be notified about this decision.`,
      delete: `Are you sure you want to delete ${selectedItems.length} user(s)? This action cannot be undone.`,
    };

    setConfirmation({
      isOpen: true,
      action,
      items: selectedItems,
      title: actionTitles[action],
      description: actionDescriptions[action],
    });
  };

  const handleConfirmBulkAction = async () => {
    if (!confirmation.action || confirmation.items.length === 0) return;

    setIsBulkActionLoading(true);
    try {
      const payload: BulkActionPayload = {
        id: confirmation.items.map((item) => item.id),
        action: confirmation.action,
      };

      await bulkActionPendingUsers(payload);

      toast({
        title: "Success",
        description: `${confirmation.items.length} user(s) ${confirmation.action}ed successfully`,
      });

      // Close confirmation and reload data
      setConfirmation({ ...confirmation, isOpen: false });
      await loadPendingUsers(filters);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message ||
          `Failed to ${confirmation.action} users`,
      });
    } finally {
      setIsBulkActionLoading(false);
    }
  };

  const handleCancelBulkAction = () => {
    setConfirmation({
      isOpen: false,
      action: null,
      items: [],
      title: "",
      description: "",
    });
  };

  // Individual request more handler
  const handleRequestMore = (user: PendingUser) => {
    // Check permission
    if (!hasPermission("pendingUser_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description:
          "You don't have permission to request more information from users.",
      });
      return;
    }

    setRequestMoreModal({
      isOpen: true,
      user,
    });
  };

  // Confirm request more handler
  const handleConfirmRequestMore = async (message: string) => {
    if (!requestMoreModal.user) return;

    setIsBulkActionLoading(true);
    try {
      const payload: BulkActionPayload = {
        id: [requestMoreModal.user.id],
        action: "request_more_documents",
        request_more: message,
      };

      await bulkActionPendingUsers(payload);

      toast({
        title: "Success",
        description: "Request for more information sent successfully",
      });

      // Close modal and reload data
      setRequestMoreModal({ isOpen: false, user: null });
      await loadPendingUsers(filters);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message ||
          "Failed to send request for more information",
      });
    } finally {
      setIsBulkActionLoading(false);
    }
  };
  // Individual action handlers with permission checks
  const handleIndividualAction = (
    user: PendingUser,
    action: "approve" | "reject" | "delete"
  ) => {
    // Check permissions
    if (
      (action === "approve" || action === "reject") &&
      !hasPermission("pendingUser_update")
    ) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to approve or reject users.",
      });
      return;
    }

    if (action === "delete" && !hasPermission("pendingUser_delete")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to delete users.",
      });
      return;
    }

    const userArray = [user];
    const actionTitles = {
      approve: "Approve User",
      reject: "Reject User",
      delete: "Delete User",
    };

    const actionDescriptions = {
      approve: `Are you sure you want to approve ${user.first_name} ${user.last_name}?`,
      reject: `Are you sure you want to reject ${user.first_name} ${user.last_name}?`,
      delete: `Are you sure you want to delete ${user.first_name} ${user.last_name}? This action cannot be undone.`,
    };

    setConfirmation({
      isOpen: true,
      action,
      items: userArray,
      title: actionTitles[action],
      description: actionDescriptions[action],
    });
  };

  // Empty state component
  const EmptyState = () => (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <Users className="h-16 w-16 text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium mb-2">No pending users found</h3>
      <p className="text-muted-foreground mb-4 max-w-md">
        {hasError
          ? "There was an error loading pending users data. Please try again."
          : filters.name || filters.email
          ? "No users match your search criteria. Try adjusting your filters."
          : "There are currently no pending user registrations to review."}
      </p>
      {hasError && (
        <Button onClick={() => loadPendingUsers(filters)} variant="outline">
          Try Again
        </Button>
      )}
    </div>
  );

  // Show no access message if user has no permissions
  if (!hasPermission("pendingUser_read")) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You don't have permission to access pending users management.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Pending Users Management</h1>
          <p className="text-muted-foreground">
            Review and manage pending user account registrations
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  Total Pending
                </p>
                <p className="text-2xl font-bold">{summary.total_pending}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  Approved
                </p>
                <p className="text-2xl font-bold text-green-600">
                  {summary.total_approved}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">
                  Rejected
                </p>
                <p className="text-2xl font-bold text-red-600">
                  {summary.total_rejected}
                </p>
              </div>
              <XCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Pending User Registrations</CardTitle>
              <CardDescription>
                Review and manage pending doctor registrations
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search and Filter - Single Search Input */}
          <div className="flex flex-col sm:flex-row gap-4 mb-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search...."
                value={filters.name || ""}
                onChange={(e) => handleFilterChange("name", e.target.value)}
                className="pl-8"
              />
            </div>
          </div>

          {/* Bulk Actions Bar - Only show when users are selected */}
          {selectedUsers.size > 0 && (
            <div className="flex items-center justify-between p-4 bg-muted/50 rounded-lg mb-4">
              <div className="flex items-center space-x-2">
                <Label htmlFor="select-all" className="text-sm font-medium">
                  {selectedUsers.size} user(s) selected
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                {hasPermission("pendingUser_update") && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBulkAction("approve")}
                      disabled={isBulkActionLoading}
                    >
                      <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                      Approve
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleBulkAction("reject")}
                      disabled={isBulkActionLoading}
                    >
                      <XCircle className="h-4 w-4 mr-2 text-yellow-500" />
                      Reject
                    </Button>
                  </>
                )}
                {hasPermission("pendingUser_delete") && (
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => handleBulkAction("delete")}
                    disabled={isBulkActionLoading}
                  >
                    <Trash2 className="h-4 w-4 mr-2" />
                    Delete
                  </Button>
                )}
              </div>
            </div>
          )}

          <>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <Checkbox
                        checked={isAllSelected}
                        onCheckedChange={handleSelectAll}
                        aria-label="Select all pending users"
                        disabled={
                          pendingUsers.filter(
                            (user) => user.status === "Pending"
                          ).length === 0
                        }
                      />
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleSort("first_name")}
                    >
                      <div className="flex items-center gap-1">
                        Name
                        {getSortIcon("first_name")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleSort("email")}
                    >
                      <div className="flex items-center gap-1">
                        Email
                        {getSortIcon("email")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleSort("phone")}
                    >
                      {" "}
                      <div className="flex items-center gap-1">
                        Phone
                        {getSortIcon("phone")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleSort("clinic")}
                    >
                      {" "}
                      <div className="flex items-center gap-1">
                        Clinic
                        {getSortIcon("clinic")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleSort("emirates_states")}
                    >
                      <div className="flex items-center gap-1">
                        Emirates
                        {getSortIcon("emirates_states")}
                      </div>
                    </TableHead>
                    <TableHead
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => handleSort("status")}
                    >
                      <div className="flex items-center gap-1">
                        Status
                        {getSortIcon("status")}
                      </div>
                    </TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={8} className="h-64 text-center p-0">
                        <div className="flex items-center justify-center h-full w-full">
                          <div className="text-center">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                            <p className="text-muted-foreground">
                              Loading pending users...
                            </p>
                          </div>
                        </div>
                      </TableCell>
                    </TableRow>
                  ) : pendingUsers.length === 0 || hasError ? (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center">
                        <EmptyState />
                      </TableCell>
                    </TableRow>
                  ) : (
                    pendingUsers.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedUsers.has(user.id)}
                            onCheckedChange={(checked) =>
                              handleSelectUser(user.id, checked as boolean)
                            }
                            aria-label={`Select ${user.first_name} ${user.last_name}`}
                            disabled={user.status !== "Pending"}
                          />
                        </TableCell>
                        <TableCell className="font-medium">
                          <Link
                            href={`/admin/pending-users/${user.id}`}
                            className="font-medium text-sm text-blue-600 hover:text-blue-800 hover:underline truncate block"
                          >
                            {user.title} {user.first_name} {user.last_name}
                          </Link>
                        </TableCell>
                        <TableCell>{user.email}</TableCell>
                        <TableCell>{user.phone_number}</TableCell>
                        <TableCell>{user.clinic_name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {user.emirates_states}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="secondary"
                            className={
                              user.status === "Approved"
                                ? "bg-green-100 text-green-800 border-green-200"
                                : user.status === "Rejected"
                                ? "bg-red-100 text-red-800 border-red-200"
                                : "bg-yellow-100 text-yellow-800 border-yellow-200"
                            }
                          >
                            {user.status}
                          </Badge>
                        </TableCell>
                        {(user?.status === "Pending" &&
                          hasPermission("pendingUser_update")) ||
                        (user?.status === "Rejected" &&
                          hasPermission("pendingUser_delete")) ? (
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" className="h-8 w-8 p-0">
                                  <span className="sr-only">Open menu</span>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuLabel>Actions</DropdownMenuLabel>

                                {/* Show Approve/Reject only for Pending users with update permission */}
                                {user.status === "Pending" &&
                                  hasPermission("pendingUser_update") && (
                                    <>
                                      <DropdownMenuItem
                                        onClick={() =>
                                          handleIndividualAction(
                                            user,
                                            "approve"
                                          )
                                        }
                                        className="cursor-pointer flex items-center"
                                      >
                                        <CheckCircle className="mr-2 h-4 w-4 text-green-500" />
                                        Approve
                                      </DropdownMenuItem>
                                      <DropdownMenuItem
                                        onClick={() =>
                                          handleIndividualAction(user, "reject")
                                        }
                                        className="cursor-pointer flex items-center"
                                      >
                                        <XCircle className="mr-2 h-4 w-4 text-yellow-500" />
                                        Reject
                                      </DropdownMenuItem>
                                      <DropdownMenuItem
                                        onClick={() => handleRequestMore(user)}
                                        className="cursor-pointer flex items-center"
                                      >
                                        <MessageCircle className="mr-2 h-4 w-4 text-blue-500" />
                                        Request More
                                      </DropdownMenuItem>
                                      <DropdownMenuItem
                                        onClick={() =>
                                          handleCommissionUpdate(user)
                                        }
                                        className="cursor-pointer flex items-center"
                                      >
                                        <Settings className="mr-2 h-4 w-4 text-blue-500" />
                                        Update Commission
                                      </DropdownMenuItem>
                                    </>
                                  )}

                                {/* Show Delete only for Rejected users with delete permission */}
                                {(user.status === "Rejected" ||
                                  user.status === "Pending") &&
                                  hasPermission("pendingUser_delete") && (
                                    <DropdownMenuItem
                                      onClick={() =>
                                        handleIndividualAction(user, "delete")
                                      }
                                      className="text-red-600 cursor-pointer"
                                    >
                                      <Trash2 className="mr-2 h-4 w-4" />
                                      Delete
                                    </DropdownMenuItem>
                                  )}
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        ) : (
                          // Show empty cell or "No actions" for users with no available actions
                          <TableCell>
                            <span className="text-muted-foreground text-xs">
                              No actions
                            </span>
                          </TableCell>
                        )}
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between px-2 py-4">
              <div className="flex-1 text-sm text-muted-foreground">
                Showing {pagination.from} to {pagination.to} of{" "}
                {pagination.total} entries
              </div>
              <div className="flex items-center space-x-6 lg:space-x-8">
                <div className="flex items-center space-x-2">
                  <p className="text-sm font-medium">Rows per page</p>
                  <Select
                    value={`${filters.per_page}`}
                    onValueChange={(value) => {
                      handleFilterChange("per_page", value);
                    }}
                  >
                    <SelectTrigger className="h-8 w-[70px]">
                      <SelectValue placeholder={filters.per_page} />
                    </SelectTrigger>
                    <SelectContent side="top">
                      {[10, 20, 30, 40, 50].map((pageSize) => (
                        <SelectItem key={pageSize} value={`${pageSize}`}>
                          {pageSize}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex w-[100px] items-center justify-center text-sm font-medium">
                  Page {pagination.current_page} of {pagination.last_page}
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    className="hidden h-8 w-8 p-0 lg:flex"
                    onClick={() => handlePageChange(1)}
                    disabled={pagination.current_page === 1}
                  >
                    <span className="sr-only">Go to first page</span>
                    <ChevronsLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    className="h-8 w-8 p-0"
                    onClick={() =>
                      handlePageChange(pagination.current_page - 1)
                    }
                    disabled={pagination.current_page === 1}
                  >
                    <span className="sr-only">Go to previous page</span>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    className="h-8 w-8 p-0"
                    onClick={() =>
                      handlePageChange(pagination.current_page + 1)
                    }
                    disabled={pagination.current_page >= pagination.last_page}
                  >
                    <span className="sr-only">Go to next page</span>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    className="hidden h-8 w-8 p-0 lg:flex"
                    onClick={() => handlePageChange(pagination.last_page)}
                    disabled={pagination.current_page >= pagination.last_page}
                  >
                    <span className="sr-only">Go to last page</span>
                    <ChevronsRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </>
        </CardContent>
      </Card>

      {/* Request More Dialog */}
      <RequestMoreDialog
        isOpen={requestMoreModal.isOpen}
        onClose={() => setRequestMoreModal({ isOpen: false, user: null })}
        onConfirm={handleConfirmRequestMore}
        user={requestMoreModal.user}
        isLoading={isBulkActionLoading}
      />

      <CommissionUpdateModal
        isOpen={commissionModal.isOpen}
        onClose={handleCommissionModalClose}
        user={commissionModal.user}
        onCommissionUpdated={handleCommissionUpdated}
      />

      {/* Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        onClose={handleCancelBulkAction}
        onConfirm={handleConfirmBulkAction}
        title={confirmation.title}
        description={confirmation.description}
        confirmText={
          confirmation.action === "approve"
            ? "Approve"
            : confirmation.action === "reject"
            ? "Reject"
            : "Delete"
        }
        cancelText="Cancel"
        variant={confirmation.action === "delete" ? "destructive" : "default"}
        isLoading={isBulkActionLoading}
      />
    </div>
  );
}
