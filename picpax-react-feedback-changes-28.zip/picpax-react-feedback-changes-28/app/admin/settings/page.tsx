"use client";

import { useState, useEffect } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Settings,
  Bell,
  Shield,
  Database,
  Globe,
  Users,
  Mail,
  Phone,
  MapPin,
  DollarSign,
  Clock,
  Loader2,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { useToast } from "@/hooks/use-toast";
import {
  getSystemSettings,
  updateSystemSettings,
  SystemSetting,
  getNotificationSettings,
  updateNotificationSettings,
  NotificationSetting,
  UpdateNotificationSettingsPayload,
} from "@/lib/SystemSettingService";

// Define the structure for transformed settings
interface TransformedSettings {
  general: SystemSetting[];
  notifications: NotificationSetting[];
  integrations: SystemSetting[]; // For future use
}

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

// Default empty settings structure
const defaultSettings: TransformedSettings = {
  general: [],
  notifications: [],
  integrations: [],
};

// Field configuration for different types of settings
const fieldConfig = {
  general: {
    text: [
      "site_name",
      "site_url",
      "admin_email",
      "support_phone",
      "support_email",
      "address",
    ],
    number: [
      "default_commission_rate",
      "shipping_charges",
      "minimum_order_amount_for_shipping",
    ],
    select: ["currency"],
  },
};

// Select options for specific fields
const selectOptions = {
  currency: [
    { value: "AED", label: "AED" },
    { value: "USD", label: "USD" },
  ],
};

export default function AdminSettingsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [settings, setSettings] =
    useState<TransformedSettings>(defaultSettings);
  const [hasChanges, setHasChanges] = useState({
    general: false,
    notifications: false,
    integrations: false,
  });
  const [isLoading, setIsLoading] = useState({
    general: false,
    notifications: false,
    integrations: false,
  });
  const [isFetching, setIsFetching] = useState({
    general: true,
    notifications: false,
    integrations: false,
  });
  const [activeTab, setActiveTab] = useState("general");
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found for check:", permission);
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(
      `Permission check for ${permission}:`,
      hasPerm,
      "Available permissions:",
      userPermissions.permission
    );
    return hasPerm;
  };

  // Determine which tabs to show based on permissions
  const showGeneralTab = hasPermission("generalSetting_read");
  const showNotificationsTab = hasPermission("notificationSetting_read");
  const showIntegrationsTab = hasPermission("generalSetting_read");

  // Set default active tab based on permissions
  useEffect(() => {
    if (showGeneralTab) {
      setActiveTab("general");
    } else if (showNotificationsTab) {
      setActiveTab("notifications");
    }
  }, [showGeneralTab, showNotificationsTab]);

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        console.log("Raw user data from localStorage:", userData);

        if (userData) {
          const user = JSON.parse(userData);
          console.log("Parsed user permissions:", user);
          setUserPermissions(user);
        } else {
          console.log("No user data found in localStorage");
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();

    // Also listen for storage changes
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Update a specific setting value
  const updateSetting = (
    category: "general" | "notifications",
    key: string,
    value: any
  ) => {
    // Check permissions based on category
    let hasUpdatePermission = false;

    if (category === "general") {
      hasUpdatePermission = hasPermission("generalSetting_update");
    } else if (category === "notifications") {
      hasUpdatePermission = hasPermission("notificationSetting_update");
    }

    if (!hasUpdatePermission) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to update these settings.",
      });
      return;
    }

    setSettings((prev) => ({
      ...prev,
      [category]: prev[category].map((setting) =>
        setting.key === key ? { ...setting, value } : setting
      ),
    }));

    setHasChanges((prev) => ({
      ...prev,
      [category]: true,
    }));
  };

  // Fetch general settings function
  const fetchGeneralSettings = async () => {
    if (!hasPermission("generalSetting_read")) {
      console.log("No generalSetting_read permission, skipping settings fetch");
      return;
    }

    try {
      setIsFetching((prev) => ({ ...prev, general: true }));
      const response = await getSystemSettings();
      if (response.success) {
        setSettings((prev) => ({
          ...prev,
          general: response.data.settings,
        }));
      } else {
        toast({
          title: "Error",
          description: response.message || "Failed to load settings",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error fetching system settings:", error);
      toast({
        title: "Error",
        description: "Failed to load system settings",
        variant: "destructive",
      });
    } finally {
      setIsFetching((prev) => ({ ...prev, general: false }));
    }
  };

  // Fetch notification settings function
  const fetchNotificationSettings = async () => {
    if (!hasPermission("notificationSetting_read")) {
      console.log(
        "No notificationSetting_read permission, skipping notification settings fetch"
      );
      return;
    }

    try {
      setIsFetching((prev) => ({ ...prev, notifications: true }));
      const response = await getNotificationSettings();
      if (response.success) {
        setSettings((prev) => ({
          ...prev,
          notifications: response.data.notification_settings,
        }));
      } else {
        toast({
          title: "Error",
          description:
            response.message || "Failed to load notification settings",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Error fetching notification settings:", error);
      toast({
        title: "Error",
        description: "Failed to load notification settings",
        variant: "destructive",
      });
    } finally {
      setIsFetching((prev) => ({ ...prev, notifications: false }));
    }
  };

  // Fetch settings on component mount after permissions are loaded
  useEffect(() => {
    if (permissionsLoaded && showGeneralTab) {
      fetchGeneralSettings();
    }
  }, [permissionsLoaded, showGeneralTab]);

  // Fetch notification settings when notifications tab becomes active
  useEffect(() => {
    if (
      activeTab === "notifications" &&
      permissionsLoaded &&
      showNotificationsTab
    ) {
      // Only fetch if we haven't already loaded notification settings
      if (!isFetching.notifications && settings.notifications.length === 0) {
        fetchNotificationSettings();
      }
    }
  }, [activeTab, permissionsLoaded, showNotificationsTab]);

  const saveGeneralSettings = async () => {
    if (!hasPermission("generalSetting_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to update general settings.",
      });
      return;
    }

    setIsLoading((prev) => ({ ...prev, general: true }));
    try {
      // Transform settings back to API format
      const settingsPayload = settings.general.map((setting) => ({
        key: setting.key,
        value: setting.value.toString(),
      }));

      const response = await updateSystemSettings({
        settings: settingsPayload,
      });
      if (response.success) {
        toast({
          title: "Success",
          description:
            response.message || "General settings updated successfully",
        });

        // Refresh settings to get latest changes from server
        await fetchGeneralSettings();
        setHasChanges((prev) => ({ ...prev, general: false }));
      } else {
        toast({
          title: "Error",
          description: response.message || "Failed to update general settings",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error("Error saving general settings:", error);
      toast({
        title: "Error",
        description:
          error.response?.data?.message || "Failed to update general settings",
        variant: "destructive",
      });
    } finally {
      setIsLoading((prev) => ({ ...prev, general: false }));
    }
  };

  const saveNotificationSettings = async () => {
    if (!hasPermission("notificationSetting_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description:
          "You don't have permission to update notification settings.",
      });
      return;
    }

    setIsLoading((prev) => ({ ...prev, notifications: true }));
    try {
      const payload: UpdateNotificationSettingsPayload = {
        email_notifications:
          settings.notifications.find((n) => n.key === "email_notifications")
            ?.value || false,
        push_notifications:
          settings.notifications.find((n) => n.key === "push_notifications")
            ?.value || false,
        new_order_alerts:
          settings.notifications.find((n) => n.key === "new_order_alerts")
            ?.value || false,
        commission_alerts:
          settings.notifications.find((n) => n.key === "commission_alerts")
            ?.value || false,
        doctor_registration_alerts:
          settings.notifications.find(
            (n) => n.key === "doctor_registration_alerts"
          )?.value || false,
        system_alerts:
          settings.notifications.find((n) => n.key === "system_alerts")
            ?.value || false,
      };

      const response = await updateNotificationSettings(payload);
      if (response.success) {
        toast({
          title: "Success",
          description:
            response.data.message ||
            "Notification settings updated successfully",
        });

        // Refresh notification settings to get latest changes from server
        await fetchNotificationSettings();
        setHasChanges((prev) => ({ ...prev, notifications: false }));
      } else {
        toast({
          title: "Error",
          description:
            response.message || "Failed to update notification settings",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error("Error saving notification settings:", error);
      toast({
        title: "Error",
        description:
          error.response?.data?.message ||
          "Failed to update notification settings",
        variant: "destructive",
      });
    } finally {
      setIsLoading((prev) => ({ ...prev, notifications: false }));
    }
  };

  const resetSettings = (category: keyof TransformedSettings) => {
    // Check permissions based on category
    let hasUpdatePermission = false;

    if (category === "general" || category === "integrations") {
      hasUpdatePermission = hasPermission("generalSetting_update");
    } else if (category === "notifications") {
      hasUpdatePermission = hasPermission("notificationSetting_update");
    }

    if (!hasUpdatePermission) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to reset these settings.",
      });
      return;
    }

    // Reset by fetching again from server
    if (category === "general") {
      fetchGeneralSettings();
    } else if (category === "notifications") {
      fetchNotificationSettings();
    }

    setHasChanges((prev) => ({ ...prev, [category]: false }));
    toast({
      title: "Reset",
      description: "Changes have been reset",
    });
  };

  // Helper function to determine input type based on field key
  const getInputType = (key: string) => {
    if (fieldConfig.general.number.includes(key)) return "number";
    if (fieldConfig.general.select.includes(key)) return "select";
    return "text";
  };

  // Render appropriate input field based on type
  const renderGeneralSettingField = (setting: SystemSetting) => {
    const inputType = getInputType(setting.key);
    const hasUpdatePermission = hasPermission("generalSetting_update");

    switch (inputType) {
      case "number":
        return (
          <div className="space-y-2" key={setting.key}>
            <Label htmlFor={setting.key}>{setting.title}</Label>
            <Input
              id={setting.key}
              type="number"
              value={setting.value}
              onChange={(e) =>
                updateSetting("general", setting.key, e.target.value)
              }
              disabled={!hasUpdatePermission}
            />
            {setting.key === "default_commission_rate" && (
              <p className="text-sm text-muted-foreground">
                Default commission rate for new doctors (0-100%)
              </p>
            )}
          </div>
        );

      case "select":
        return (
          <div className="space-y-2" key={setting.key}>
            <Label htmlFor={setting.key}>{setting.title}</Label>
            <Select
              value={setting.value}
              onValueChange={(value) =>
                updateSetting("general", setting.key, value)
              }
              disabled={!hasUpdatePermission}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {selectOptions.currency.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        );

      default:
        return (
          <div className="space-y-2" key={setting.key}>
            <Label htmlFor={setting.key}>{setting.title}</Label>
            <Input
              id={setting.key}
              type={setting.key.includes("email") ? "email" : "text"}
              value={setting.value}
              onChange={(e) =>
                updateSetting("general", setting.key, e.target.value)
              }
              disabled={!hasUpdatePermission}
            />
          </div>
        );
    }
  };

  // Render notification settings dynamically
  const renderNotificationSetting = (setting: NotificationSetting) => {
    const hasUpdatePermission = hasPermission("notificationSetting_update");

    return (
      <div className="flex items-center justify-between" key={setting.key}>
        <div className="space-y-0.5">
          <Label htmlFor={setting.key}>{setting.title}</Label>
          <p className="text-sm text-muted-foreground">{setting.description}</p>
        </div>
        <Switch
          id={setting.key}
          checked={setting.value}
          onCheckedChange={(checked) =>
            updateSetting("notifications", setting.key, checked)
          }
          disabled={!hasUpdatePermission}
        />
      </div>
    );
  };

  // Show loading while permissions are being loaded
  if (!permissionsLoaded) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-16 w-16 text-muted-foreground mx-auto mb-4 animate-spin" />
          <h3 className="text-lg font-medium mb-2">Loading...</h3>
          <p className="text-muted-foreground">Checking permissions...</p>
        </div>
      </div>
    );
  }

  // Show no access message if user has no read permissions for any tab
  if (!showGeneralTab && !showNotificationsTab) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You don't have permission to access any system settings. Available
            permissions: {userPermissions?.permission?.join(", ") || "None"}
          </p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">System Settings</h1>
        <p className="text-muted-foreground">
          Configure global system settings and preferences
        </p>
      </div>

      <Tabs
        value={activeTab}
        className="space-y-4"
        onValueChange={setActiveTab}
      >
        <TabsList
          className={`grid w-full ${
            [showGeneralTab, showNotificationsTab].filter(Boolean).length === 2
              ? "grid-cols-2"
              : "grid-cols-1"
          }`}
        >
          {showGeneralTab && <TabsTrigger value="general">General</TabsTrigger>}
          {showNotificationsTab && (
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          )}
        </TabsList>

        {showGeneralTab && (
          <TabsContent value="general" className="space-y-4">
            {isFetching.general ? (
              <div className="flex items-center justify-center h-64">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
                  <p className="mt-2 text-muted-foreground">
                    Loading general settings...
                  </p>
                </div>
              </div>
            ) : (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="h-5 w-5" />
                      General Settings
                    </CardTitle>
                    <CardDescription>
                      Basic site configuration and contact information
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      {settings.general.map((setting) =>
                        renderGeneralSettingField(setting)
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Save General Settings */}
                {hasPermission("generalSetting_update") && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Save General Settings</CardTitle>
                      <CardDescription>
                        {hasChanges.general
                          ? "You have unsaved changes in general settings"
                          : "All general settings are saved"}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex gap-2">
                        <Button
                          onClick={saveGeneralSettings}
                          disabled={!hasChanges.general || isLoading.general}
                        >
                          {isLoading.general
                            ? "Saving..."
                            : "Save General Settings"}
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => resetSettings("general")}
                          disabled={!hasChanges.general}
                        >
                          Reset Changes
                        </Button>
                      </div>
                      {hasChanges.general && (
                        <div className="mt-4">
                          <Badge variant="secondary">Unsaved Changes</Badge>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </TabsContent>
        )}

        {showNotificationsTab && (
          <TabsContent value="notifications" className="space-y-4">
            {isFetching.notifications ? (
              <div className="flex items-center justify-center h-64">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-900 mx-auto"></div>
                  <p className="mt-2 text-muted-foreground">
                    Loading notification settings...
                  </p>
                </div>
              </div>
            ) : (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Bell className="h-5 w-5" />
                      Notification Settings
                    </CardTitle>
                    <CardDescription>
                      Configure email and push notification preferences
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      {settings.notifications.map((setting) =>
                        renderNotificationSetting(setting)
                      )}
                    </div>
                  </CardContent>
                </Card>

                {/* Save Notification Settings */}
                {hasPermission("notificationSetting_update") && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Save Notification Settings</CardTitle>
                      <CardDescription>
                        {hasChanges.notifications
                          ? "You have unsaved changes in notification settings"
                          : "All notification settings are saved"}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex gap-2">
                        <Button
                          onClick={saveNotificationSettings}
                          disabled={
                            !hasChanges.notifications || isLoading.notifications
                          }
                        >
                          {isLoading.notifications
                            ? "Saving..."
                            : "Save Notification Settings"}
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => resetSettings("notifications")}
                          disabled={!hasChanges.notifications}
                        >
                          Reset Changes
                        </Button>
                      </div>
                      {hasChanges.notifications && (
                        <div className="mt-4">
                          <Badge variant="secondary">Unsaved Changes</Badge>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}
