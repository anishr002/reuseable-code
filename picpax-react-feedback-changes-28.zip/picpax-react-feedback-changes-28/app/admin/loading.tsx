export default function AdminLoading() {
  return (
    <div className="min-h-[60vh] p-4 sm:p-6 space-y-6">
      {/* Header placeholder */}
      <div className="h-8 w-56 rounded-md bg-gray-200 animate-pulse" />

      {/* KPI cards placeholder */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <div className="h-28 rounded-lg bg-gray-100 animate-pulse" />
        <div className="h-28 rounded-lg bg-gray-100 animate-pulse" />
        <div className="h-28 rounded-lg bg-gray-100 animate-pulse" />
      </div>

      {/* Table/content block placeholder */}
      <div className="h-96 rounded-lg bg-gray-100 animate-pulse" />
    </div>
  );
}
