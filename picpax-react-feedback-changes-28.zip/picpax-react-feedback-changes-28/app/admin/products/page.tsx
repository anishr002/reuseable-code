"use client";

import { useCallback, useEffect, useState, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Package,
  DollarSign,
  Activity,
  RefreshCw,
  Loader2,
  Clock,
  Plus,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { DataTable } from "@/components/products/data-table";
import { columns, type Product } from "@/components/products/columns";
import { ProductDetailsModal } from "@/components/products/product-details-modal";
import {
  getProducts,
  postSyncProduct,
  type Product as ApiProduct,
} from "@/lib/productService";
import { useDebounce } from "@/hooks/use-debounce";
import { useToast } from "@/hooks/use-toast";
import { DirhamIcon } from "@/components/ui/DirhamIcon";
import { ProductInfoModal } from "@/components/product-info-modal";

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

interface ApiResponse {
  products: ApiProduct[];
  pagination: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  };
  summary: {
    total_products: number;
    total_active_products: number;
    total_draft_products: number;
    total_inventory: number; // Added from backend
    inventory_value: number; // Added from backend
    product_types: number;
    shopify_synced_products: number;
    shopify_sync_pending_products: number;
  };
  filters_applied: {
    search: string | null;
    sort_by: string;
    sort_order: string;
  };
}

// Helper to transform API product shape to UI Product type used in columns/DataTable
function transformApiProduct(api: ApiProduct): Product {
  // Handle variants data properly - using locations data instead
  const variants =
    api.variants_count && api.sku && api.prices
      ? Array.from({ length: api.variants_count }).map((_, idx) => ({
          id: `${api.id}-v${idx}`,
          title: `Variant ${idx + 1}`,
          sku: api.sku[idx] ?? api.sku[0] ?? "",
          price: api.prices[idx] ?? api.prices[0] ?? 0,
          inventory: api.inventory ?? 0,
        }))
      : [];

  // Handle locations data
  const locations =
    api.locations_count && api.locations_count > 0
      ? Array.from({ length: api.locations_count }).map((_, idx) => ({
          name: `Location ${idx + 1}`,
          available: Math.floor((api.inventory || 0) / api.locations_count),
        }))
      : [];

  // Handle image data safely
  const images =
    api.image && api.image.url
      ? [
          {
            id: api.image.id || api.id,
            src: api.image.url,
            alt: api.image.alt ?? api.title,
          },
        ]
      : [];

  // Handle tags safely
  const tags = api.tags
    ? api.tags
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
    : [];

  // Get the primary price - use the first price from prices array
  const primaryPrice = api.prices && api.prices.length > 0 ? api.prices[0] : 0;

  console.log(`Transforming product: ${api.title}`, {
    prices: api.prices,
    primaryPrice: primaryPrice,
  }); // Debug log

  return {
    id: api.id,
    shopifyId: String(api.product_id),
    title: api.title,
    description: "",
    vendor: api.vendor,
    productType: api.product_type || "",
    tags: tags,
    status: api.status as Product["status"],
    inventory: {
      available: api.inventory || 0,
      locations: locations,
    },
    pricing: {
      price: Number(primaryPrice),
      compareAtPrice: null,
      cost: 0,
      currency: "USD",
    },
    variants,
    images,
    createdAt: api.created_at,
    updatedAt: api.updated_at,
    shopifySync: {
      lastSync: api.updated_at,
      syncStatus: api.sync_status as Product["shopifySync"]["syncStatus"],
      shopifyUrl: api.handle
        ? `https://picpax.myshopify.com/products/${api.handle}`
        : null,
    },
  };
}

export default function AdminProductsPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isProductDetailsOpen, setIsProductDetailsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);

  const [pagination, setPagination] = useState<{
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  }>({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
  });

  const [summary, setSummary] = useState<{
    total_products: number;
    total_active_products: number;
    total_draft_products: number;
    total_inventory: number; // Added from backend
    inventory_value: number; // Added from backend
    product_types: number;
    shopify_synced_products: number;
    shopify_sync_pending_products: number;
  }>({
    total_products: 0,
    total_active_products: 0,
    total_draft_products: 0,
    total_inventory: 0, // Initialize with 0
    inventory_value: 0, // Initialize with 0
    product_types: 0,
    shopify_synced_products: 0,
    shopify_sync_pending_products: 0,
  });

  const [filters, setFilters] = useState<{
    page: number;
    per_page: number;
    search?: string | null;
    sort_by?: string;
    sort_order?: "asc" | "desc";
  }>({
    page: 1,
    per_page: 10,
    sort_by: "created_at",
    sort_order: "desc",
    search: null,
  });

  const [searchTerm, setSearchTerm] = useState("");
  const debouncedSearch = useDebounce(searchTerm, 500);
  const hasFetched = useRef(false);
  const [selectedProductForInfo, setSelectedProductForInfo] =
    useState<Product | null>(null);
  const [isProductInfoOpen, setIsProductInfoOpen] = useState(false);

  // Check if user has specific permission
  const hasPermission = useCallback(
    (permission: string): boolean => {
      if (!userPermissions || !userPermissions.permission) {
        console.log("No user permissions found for check:", permission);
        return false;
      }

      const hasPerm = userPermissions.permission.includes(permission);
      console.log(
        `Permission check for ${permission}:`,
        hasPerm,
        "Available permissions:",
        userPermissions.permission
      );
      return hasPerm;
    },
    [userPermissions]
  );

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        console.log("Raw user data from localStorage:", userData);

        if (userData) {
          const user = JSON.parse(userData);
          console.log("Parsed user permissions:", user);
          setUserPermissions(user);
        } else {
          console.log("No user data found in localStorage");
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();

    // Also listen for storage changes
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  const fetchProducts = useCallback(async () => {
    // Don't fetch if we don't have read permission
    if (!hasPermission("product_read")) {
      console.log("No product_read permission, skipping product fetch");
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      const resp = await getProducts({
        page: filters.page,
        per_page: filters.per_page,
        search: debouncedSearch || undefined,
        sort_by: filters.sort_by,
        sort_order: filters.sort_order,
      });

      console.log("API Response:", resp);

      if (resp && resp.success) {
        const apiResponse = resp.data as ApiResponse;
        const transformed = apiResponse.products.map(transformApiProduct);
        console.log("Transformed products:", transformed);
        setProducts(transformed);
        setPagination(apiResponse.pagination);
        setSummary(apiResponse.summary);
        hasFetched.current = true;
      } else {
        setError(resp?.message || "Failed to fetch products");
      }
    } catch (err: any) {
      console.error("Error fetching products:", err);
      setError(err?.message || "Error fetching products");
    } finally {
      setIsLoading(false);
    }
  }, [filters, debouncedSearch, hasPermission]);

  // Initial fetch - only once on mount and when permissions are loaded
  useEffect(() => {
    if (
      permissionsLoaded &&
      hasPermission("product_read") &&
      !hasFetched.current
    ) {
      fetchProducts();
    }
  }, [permissionsLoaded, hasPermission, fetchProducts]);

  // Fetch when filters change - separate useEffect
  useEffect(() => {
    if (
      hasFetched.current &&
      permissionsLoaded &&
      hasPermission("product_read")
    ) {
      const timeoutId = setTimeout(() => {
        fetchProducts();
      }, 300);

      return () => clearTimeout(timeoutId);
    }
  }, [filters, fetchProducts, permissionsLoaded, hasPermission]);

  // Add this handler function
  const handleProductInfo = (product: Product) => {
    if (!hasPermission("product_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to manage product information.",
      });
      return;
    }
    setSelectedProductForInfo(product);
    setIsProductInfoOpen(true);
  };

  // REMOVED: No need to calculate from current page products anymore
  // Using summary.total_inventory and summary.inventory_value directly from API

  const handleViewProductDetails = (product: Product) => {
    if (!hasPermission("product_read")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to view product details.",
      });
      return;
    }
    setSelectedProduct(product);
    setIsProductDetailsOpen(true);
  };

  const handleSyncProduct = async (product: Product) => {
    if (!hasPermission("product_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to sync products.",
      });
      return;
    }

    try {
      console.log("Syncing product:", product.id);
      const resp = await postSyncProduct(product.shopifyId);
      if (resp && resp.success) {
        toast({
          title: "Success",
          description: resp.message || "Product synced successfully",
        });
        fetchProducts();
      } else {
        toast({
          title: "Error",
          description: resp?.message || "Failed to sync product",
          variant: "destructive",
        });
      }
    } catch (err: any) {
      console.error("Sync error:", err);
      toast({
        title: "Error",
        description: err?.message || "Failed to sync product",
        variant: "destructive",
      });
    }
  };

  const handleSearch = useCallback((searchTerm: string) => {
    setSearchTerm(searchTerm);
    setFilters((prev) => ({
      ...prev,
      page: 1,
    }));
  }, []);

  const handlePaginationChange = useCallback(
    (page: number, pageSize: number) => {
      setFilters((prev) => ({
        ...prev,
        page,
        per_page: pageSize,
      }));
    },
    []
  );

  const handleSortingChange = useCallback((sorting: any[]) => {
    if (sorting.length > 0) {
      const sort = sorting[0];
      setFilters((prev) => ({
        ...prev,
        sort_by: sort.id,
        sort_order: sort.desc ? "desc" : "asc",
        page: 1,
      }));
    } else {
      setFilters((prev) => ({
        ...prev,
        sort_by: "created_at",
        sort_order: "desc",
      }));
    }
  }, []);

  // Show loading while permissions are being loaded
  if (!permissionsLoaded) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-16 w-16 text-muted-foreground mx-auto mb-4 animate-spin" />
          <h3 className="text-lg font-medium mb-2">Loading...</h3>
          <p className="text-muted-foreground">Checking permissions...</p>
        </div>
      </div>
    );
  }

  // Show no access message if user has no read permissions
  if (!hasPermission("product_read")) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You don't have permission to access product management. Available
            permissions: {userPermissions?.permission?.join(", ") || "None"}
          </p>
        </div>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
            Product Management
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Manage products and sync with Shopify store
          </p>
        </div>
        {hasPermission("product_write") && (
          <Button
            className="bg-primary hover:bg-primary/90 w-full sm:w-auto"
            onClick={() => {
              // Add your add product logic here
              toast({
                title: "Add Product",
                description: "Add product functionality would go here",
              });
            }}
            disabled={isLoading}
          >
            <Plus className="mr-2 h-4 w-4" />
            Add Product
          </Button>
        )}
      </div>

      {/* Stats Cards - Using summary data from API */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {summary.total_products}
            </div>
            <p className="text-xs text-muted-foreground">
              {summary.total_active_products} active,{" "}
              {summary.total_draft_products} draft
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Inventory
            </CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {summary.total_inventory.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              Units available (across all products)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Inventory Value
            </CardTitle>
            <DirhamIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {summary.inventory_value.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              Total value (across all products)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Shopify Sync</CardTitle>
            <RefreshCw className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {summary.shopify_synced_products}
            </div>
            <p className="text-xs text-muted-foreground">
              {summary.shopify_sync_pending_products} pending sync
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Product Types</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              {summary.product_types}
            </div>
            <p className="text-xs text-muted-foreground">Categories</p>
          </CardContent>
        </Card>
      </div>

      {/* Products Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Products</CardTitle>
          <CardDescription>
            View and manage all products in the system. Click on any product to
            view detailed information.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="text-red-600 mb-2 p-2 bg-red-50 rounded">
              {error}
            </div>
          )}
          <DataTable
            columns={columns}
            data={products}
            onViewProductDetails={handleViewProductDetails}
            onSyncProduct={handleSyncProduct}
            onProductInfo={handleProductInfo}
            isLoading={isLoading}
            pagination={pagination}
            onSearch={handleSearch}
            onPaginationChange={handlePaginationChange}
            onSortingChange={handleSortingChange}
            canExport={hasPermission("product_export")}
            canRead={hasPermission("product_read")}
            canUpdate={hasPermission("product_update")}
          />
        </CardContent>
      </Card>

      {/* Product Info Modal */}
      {hasPermission("product_update") && (
        <ProductInfoModal
          product={selectedProductForInfo}
          isOpen={isProductInfoOpen}
          onClose={() => setIsProductInfoOpen(false)}
          onSave={() => {
            // Optional: Refresh products or show updated info
            toast({
              title: "Success",
              description: "Product information updated successfully",
            });
          }}
        />
      )}

      {/* Product Details Modal */}
      {hasPermission("product_read") && (
        <ProductDetailsModal
          product={selectedProduct}
          isOpen={isProductDetailsOpen}
          onClose={() => setIsProductDetailsOpen(false)}
        />
      )}
    </div>
  );
}
