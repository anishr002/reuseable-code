"use client";

import { useCallback, useEffect, useState, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { DataTable } from "@/components/logs/data-table";
import { columns, type ActivityLog } from "@/components/logs/columns";
import {
  getActivityLogs,
  type ActivityLog as ApiActivityLog,
} from "@/lib/logService";
import { useDebounce } from "@/hooks/use-debounce";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Clock, Activity } from "lucide-react";

export default function SystemLogsPage() {
  const { toast } = useToast();

  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [pagination, setPagination] = useState<{
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  }>({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
  });

  const [filters, setFilters] = useState<{
    page: number;
    per_page: number;
    search?: string | null;
    sort_by?: string;
    sort_order?: "asc" | "desc";
  }>({
    page: 1,
    per_page: 10,
    sort_by: "created_at",
    sort_order: "desc",
    search: null,
  });
  const [total, setTotal] = useState<any>(null);

  const [searchTerm, setSearchTerm] = useState("");
  const debouncedSearch = useDebounce(searchTerm, 500);
  const hasFetched = useRef(false);

  const fetchLogs = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      const resp: any = await getActivityLogs({
        page: filters.page,
        per_page: filters.per_page,
        search: debouncedSearch || undefined,
        sort_by: filters.sort_by,
        sort_order: filters.sort_order,
      });

      console.log("Logs API Response:", resp);

      if (resp && resp.success) {
        setLogs(resp.data.activity_logs);
        setPagination(resp.data.pagination);
        setTotal(resp?.data?.summary || null);
        hasFetched.current = true;
      } else {
        setError(resp?.message || "Failed to fetch system logs");
      }
    } catch (err: any) {
      console.error("Error fetching system logs:", err);
      setError(err?.message || "Error fetching system logs");
    } finally {
      setIsLoading(false);
    }
  }, [filters, debouncedSearch]);

  // Initial fetch
  useEffect(() => {
    if (!hasFetched.current) {
      fetchLogs();
    }
  }, [fetchLogs]);

  // Fetch when filters change
  useEffect(() => {
    if (hasFetched.current) {
      const timeoutId = setTimeout(() => {
        fetchLogs();
      }, 300);

      return () => clearTimeout(timeoutId);
    }
  }, [filters, fetchLogs]);

  const handleSearch = useCallback((searchTerm: string) => {
    setSearchTerm(searchTerm);
    setFilters((prev) => ({
      ...prev,
      page: 1,
    }));
  }, []);

  const handlePaginationChange = useCallback(
    (page: number, pageSize: number) => {
      setFilters((prev) => ({
        ...prev,
        page,
        per_page: pageSize,
      }));
    },
    []
  );

  const handleSortingChange = useCallback((sorting: any[]) => {
    if (sorting.length > 0) {
      const sort = sorting[0];

      // Map column IDs to API sort_by parameters
      const sortMapping: { [key: string]: string } = {
        subject: "field",
        event: "event",
        description: "description",
        causer: "user",
        created_at: "date",
      };

      const sortBy = sortMapping[sort.id] || "created_at";

      setFilters((prev) => ({
        ...prev,
        sort_by: sortBy,
        sort_order: sort.desc ? "desc" : "asc",
        page: 1,
      }));
    } else {
      setFilters((prev) => ({
        ...prev,
        sort_by: "created_at",
        sort_order: "desc",
      }));
    }
  }, []);

  // Calculate stats
  const totalLogs = pagination.total;
  const createdEvents = logs.filter((log) => log.event === "created").length;
  const updatedEvents = logs.filter((log) => log.event === "updated").length;
  const uniqueUsers = [
    ...new Set(logs.map((log) => log.causer?.id).filter(Boolean)),
  ].length;

  if (isLoading && !hasFetched.current) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-16 w-16 text-muted-foreground mx-auto mb-4 animate-spin" />
          <h3 className="text-lg font-medium mb-2">Loading System Logs...</h3>
          <p className="text-muted-foreground">
            Please wait while we load the activity logs.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">
            System Activity Logs
          </h1>
          <p className="text-sm sm:text-base text-muted-foreground">
            Track all system setting changes and activities
          </p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Logs</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {total?.total_logs || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              All system activities
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Created</CardTitle>
            <div className="h-4 w-4 bg-green-100 rounded-full flex items-center justify-center">
              <div className="h-2 w-2 bg-green-600 rounded-full" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {total?.settings_created || 0}
            </div>
            <p className="text-xs text-muted-foreground">Settings created</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Updated</CardTitle>
            <div className="h-4 w-4 bg-blue-100 rounded-full flex items-center justify-center">
              <div className="h-2 w-2 bg-blue-600 rounded-full" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {total?.settings_updated || 0}
            </div>
            <p className="text-xs text-muted-foreground">Settings updated</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Users</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {total?.active_users || 0}
            </div>
            <p className="text-xs text-muted-foreground">Active users</p>
          </CardContent>
        </Card>
      </div>

      {/* Logs Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Activity Logs</CardTitle>
          <CardDescription>
            View all system setting changes and activities. Search by
            description, setting name, or user.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <div className="text-red-600 mb-2 p-2 bg-red-50 rounded">
              {error}
            </div>
          )}
          <DataTable
            columns={columns}
            data={logs}
            isLoading={isLoading}
            pagination={pagination}
            onSearch={handleSearch}
            onPaginationChange={handlePaginationChange}
            onSortingChange={handleSortingChange}
          />
        </CardContent>
      </Card>
    </div>
  );
}
