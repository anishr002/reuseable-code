"use client";

import { useEffect, useMemo, useState, useCallback, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, UserCog, Mail, Phone, Loader2, Clock } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { DataTable } from "@/components/doctors/data-table";
import { columns } from "@/components/doctors/columns";
import { AddDoctorModal } from "@/components/admin/add-doctor-modal";
import {
  EditDoctorModal,
  type Doctor,
} from "@/components/admin/edit-doctor-modal";
import doctorService, { type DoctorListItem } from "@/services/doctorService";
import type { SortingState } from "@tanstack/react-table";
import { useToast } from "@/hooks/use-toast";
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog";

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

interface ConfirmationState {
  isOpen: boolean;
  title: string;
  description: string;
  item: Doctor | null;
}

export default function AdminDoctorsPage() {
  const { user } = useAuth();
  const { toast } = useToast();

  // Data state
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);

  // Server meta
  const [total, setTotal] = useState<any>(null);
  const [lastPage, setLastPage] = useState(1);

  // Table state (server-side)
  const [sorting, setSorting] = useState<SortingState>([]);
  const [pageIndex, setPageIndex] = useState(0);
  const [pageSize, setPageSize] = useState(10);
  const [searchValue, setSearchValue] = useState("");

  // Delete state
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState<ConfirmationState>({
    isOpen: false,
    title: "",
    description: "",
    item: null,
  });

  // Modal states
  const [isAddDoctorModalOpen, setIsAddDoctorModalOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  const [isLoadingDoctorDetail, setIsLoadingDoctorDetail] = useState(false);

  const pageCount = useMemo(() => lastPage, [lastPage]);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          console.log("User permissions loaded:", user.permission);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Handle logout and authentication state changes
  useEffect(() => {
    const handleStorageChange = () => {
      const userData = localStorage.getItem("picpax_user");
      if (!userData) {
        // User logged out, clear state and stop any pending requests
        setDoctors([]);
        setIsLoading(false);
      }
    };

    window.addEventListener("storage", handleStorageChange);

    // Also check on mount if user exists
    const userData = localStorage.getItem("picpax_user");
    if (!userData) {
      setIsLoading(false);
    }

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  const mapListItemToDoctor = (item: any): any => {
    const addressParts = [
      item.villa_apartment,
      item.area_street,
      item.emirates_states,
      item.nearby_landmark,
    ]
      .filter(Boolean)
      .join(", ");

    return {
      id: item.id,
      name: item.full_name || `${item.first_name} ${item.last_name}`,
      email: item.email,
      phone: item.phone_number,
      clinic: item.clinic_name || "",
      address: addressParts || item.address || "",
      status: item.status || "Active",
      patients_count: item.patients || 0,
      orders_count: item.orders || 0,
      joinDate: item.created_at,
      commission: parseFloat(String(item.commission || 0)) || 0,
      product_commission:
        parseFloat(String(item?.product_commission || 0)) || 0,
      lab_test_commission:
        parseFloat(String(item?.lab_test_commission || 0)) || 0,
      country: item.country || "",
      specialization: item.medical_speciality || "",
      license: "",
      experience: "",
      education: "",
      bio: "",
    };
  };

  const mapDetailToDoctor = (d: any): any => {
    const address = [
      d.villa_apartment,
      d.area_street,
      d.emirates_states,
      d.nearby_landmark,
    ]
      .filter((p: any) => p && String(p).trim() !== "")
      .join(", ");

    return {
      id: d.id,
      name: d.full_name || `${d.first_name} ${d.last_name}`,
      first_name: d.first_name || "",
      last_name: d.last_name || "",
      email: d.email,
      phone: d.phone_number,
      clinic: d.clinic_name || "",
      address: address || d.address || "",
      status: d.status || "Active",
      patients_count: 0,
      orders_count: 0,
      joinDate: d.created_at,
      country: d.country || "",
      commission:
        typeof d.commission === "string"
          ? parseFloat(d.commission)
          : Number(d.commission || 0),
      specialization: d.medical_speciality || "",
      license: d.medical_license || "",
      experience: String(d.years_of_experience || ""),
      education: "",
      bio: d.bio || "",
    };
  };

  const loadDoctors = async () => {
    // Check permissions before making API call
    if (!hasPermission("doctor_read")) {
      console.log("No permission to read doctors");
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    try {
      const sort_by =
        sorting[0]?.id === "clinic"
          ? "clinic_name"
          : sorting[0]?.id === "name"
          ? "name"
          : sorting[0]?.id;
      const sort_order = sorting[0]?.desc ? "desc" : "asc";

      const { data } = await doctorService.getDoctors({
        name: searchValue || undefined,
        sort_by: sort_by,
        sort_order: sorting.length ? (sort_order as any) : undefined,
        per_page: pageSize,
        page: pageIndex + 1,
      });

      const mapped: Doctor[] = data.doctors.map(mapListItemToDoctor);
      console.log(data, "data12333");
      setDoctors(mapped);
      setTotal(data.summary);
      setLastPage(data.pagination.last_page);
    } catch (error) {
      console.error(error);
      setDoctors([]);
      setTotal(0);
      setLastPage(1);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (!user || !permissionsLoaded) return;

    if (hasPermission("doctor_read")) {
      loadDoctors();
    } else {
      setIsLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user, permissionsLoaded, sorting, pageIndex, pageSize, searchValue]);

  const handleDoctorAdded = () => {
    setPageIndex(0);
    loadDoctors();
  };

  const handleEditDoctor = async (doctor: Doctor) => {
    // Check permission
    if (!hasPermission("doctor_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to edit doctors.",
      });
      return;
    }

    setIsLoadingDoctorDetail(true);
    try {
      const res = await doctorService.getDoctor(doctor.id);
      const detailed = mapDetailToDoctor(res.data);
      setEditingDoctor(detailed);
    } catch (error: any) {
      console.error(error);
      toast({
        title: "Error",
        description:
          error?.response?.data?.message || "Failed to load doctor details",
        variant: "destructive",
      });
      // Fallback to the list item data
      setEditingDoctor(doctor);
    } finally {
      setIsLoadingDoctorDetail(false);
    }
  };

  const handleDoctorUpdated = (updatedDoctor: Doctor) => {
    setEditingDoctor(null);
    loadDoctors();
  };

  // Delete confirmation handlers
  const handleDeleteDoctor = (doctor: Doctor) => {
    // Check permission
    if (!hasPermission("doctor_delete")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to delete doctors.",
      });
      return;
    }

    setConfirmation({
      isOpen: true,
      title: "Delete Doctor",
      description: `Are you sure you want to delete Dr. ${doctor.name}? This action cannot be undone.`,
      item: doctor,
    });
  };

  const handleConfirmDelete = async () => {
    if (!confirmation.item) return;

    const doctor = confirmation.item;
    setDeletingId(doctor.id);

    try {
      await doctorService.deleteDoctor(doctor.id);
      toast({
        title: "Success",
        description: "Doctor deleted successfully",
      });

      // Close confirmation dialog
      setConfirmation({
        isOpen: false,
        title: "",
        description: "",
        item: null,
      });

      // Reload doctors list
      loadDoctors();
    } catch (error: any) {
      console.error("Delete error:", error);
      toast({
        title: "Error",
        description:
          error?.response?.data?.message || "Failed to delete doctor",
        variant: "destructive",
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleCancelDelete = () => {
    setConfirmation({ isOpen: false, title: "", description: "", item: null });
    setDeletingId(null);
  };

  // Show no access message if user has no read permissions
  if (!hasPermission("doctor_read")) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Clock className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You don't have permission to access doctors management.
          </p>
        </div>
      </div>
    );
  }
  console.log(doctors, "doctors12222");
  if (!user) return null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Doctors Management
          </h1>
          <p className="text-muted-foreground">
            Manage all registered doctors and their information
          </p>
        </div>
        {hasPermission("doctor_write") && (
          <Button onClick={() => setIsAddDoctorModalOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Doctor
          </Button>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Doctors</CardTitle>
            <UserCog className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {total?.total_doctors || 0}
            </div>
            <p className="text-xs text-muted-foreground">Registered doctors</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Active Doctors
            </CardTitle>
            <UserCog className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {total?.total_active_doctors || 0}
            </div>
            <p className="text-xs text-muted-foreground">Currently active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Patients
            </CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {total?.total_patients || 0}
            </div>
            <p className="text-xs text-muted-foreground">Across all doctors</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <Phone className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">
              {total?.total_orders || 0}
            </div>
            <p className="text-xs text-muted-foreground">Orders placed</p>
          </CardContent>
        </Card>
      </div>

      {/* Doctors Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Doctors List</CardTitle>
          <CardDescription>
            View and manage all registered doctors. Click on doctor names to
            view their profiles.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="flex flex-col items-center gap-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-muted-foreground">Loading doctors...</p>
              </div>
            </div>
          ) : ( */}
          <DataTable
            columns={columns({
              onEdit: handleEditDoctor,
              onDelete: handleDeleteDoctor,
              canEdit: hasPermission("doctor_update"),
              canDelete: hasPermission("doctor_delete"),
            })}
            data={doctors}
            manual
            pageCount={pageCount}
            state={{
              sorting,
              pagination: { pageIndex, pageSize },
              searchValue,
            }}
            onSortingChange={(updater) => setSorting(updater)}
            onPaginationChange={({ pageIndex: pi, pageSize: ps }) => {
              setPageIndex(pi);
              setPageSize(ps);
            }}
            onSearchChange={(val) => {
              setSearchValue(val);
              setPageIndex(0);
            }}
            canExport={hasPermission("doctor_export")}
            isLoading={isLoading}
          />
          {/* // )} */}
        </CardContent>
      </Card>

      {/* Add Doctor Modal */}
      {hasPermission("doctor_write") && (
        <AddDoctorModal
          isOpen={isAddDoctorModalOpen}
          onClose={() => setIsAddDoctorModalOpen(false)}
          onDoctorAdded={handleDoctorAdded}
        />
      )}

      {/* Edit Doctor Modal */}
      {hasPermission("doctor_update") && (
        <EditDoctorModal
          isOpen={!!editingDoctor}
          onClose={() => setEditingDoctor(null)}
          doctor={editingDoctor}
          onDoctorUpdated={handleDoctorUpdated}
          // isLoading={isLoadingDoctorDetail}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        onClose={handleCancelDelete}
        onConfirm={handleConfirmDelete}
        title={confirmation.title}
        description={confirmation.description}
        confirmText="Delete"
        cancelText="Cancel"
        variant="destructive"
        isLoading={deletingId === (confirmation.item?.id || null)}
      />
    </div>
  );
}
