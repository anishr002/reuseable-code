"use client";

import { useState, useEffect } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import {
  EditDoctorModal,
  type Doctor,
} from "@/components/admin/edit-doctor-modal";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTable } from "@/components/doctors/data-table";
import { DataTableColumnHeader } from "@/components/doctors/data-table-column-header";
import { DocumentUpload } from "@/components/ui/document-upload";
import type { DocumentFile } from "@/components/ui/document-upload";
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  Users,
  FileText,
  Edit,
  ToggleLeft,
  ToggleRight,
  Plus,
  Trash2,
  Briefcase,
  TrendingUp,
  TrendingDown,
  Wallet,
  Package,
  Eye,
  Loader2,
  Clock,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { mockOrders } from "@/lib/mock-data";
import type { ColumnDef } from "@tanstack/react-table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal } from "lucide-react";
import doctorService, {
  deleteDoctorDocument,
  uploadDoctorDocuments,
} from "@/services/doctorService";
import {
  createStaff,
  getStaffById,
  updateStaff,
  deleteStaff,
  getStaffList,
  type StaffMember,
  getDoctorOrders,
  type DoctorOrder,
  type DoctorOrdersFilters,
  getOrderDetails,
} from "@/lib/doctorApi";
import { useToast } from "@/hooks/use-toast";
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog";
import { convertToDubaiTime } from "@/components/convertToDubaiTime";
import { PatientOrderDetailsModal } from "@/components/patients/PatientOrderDetailsModal";
import { OrderDetailsModal } from "@/components/patients/order-details-modal";
import axiosInstance from "@/services/axiosInstance";
import { DirhamIcon } from "@/components/ui/DirhamIcon";

// Mock commission and payout data
const mockCommissionData = {
  doc_001: [
    {
      id: "comm_001",
      type: "IN",
      date: "2024-01-15",
      order_id: "ORD-2024-001",
      commission_amount: 14.99,
      status: "Completed",
      description: "Commission from Vitamin D3 and Omega-3 order",
    },
    {
      id: "comm_002",
      type: "IN",
      date: "2024-01-20",
      order_id: "ORD-2024-002",
      commission_amount: 12.75,
      status: "Completed",
      description: "Commission from Multivitamin order",
    },
    {
      id: "payout_001",
      type: "OUT",
      date: "2024-01-31",
      payout_amount: 20.0,
      method: "Bank Transfer",
      reference_no: "TRF-001",
      status: "Completed",
      description: "Monthly payout",
    },
    {
      id: "comm_003",
      type: "IN",
      date: "2024-02-05",
      order_id: "ORD-2024-003",
      commission_amount: 18.5,
      status: "Completed",
      description: "Commission from Probiotics order",
    },
    {
      id: "payout_002",
      type: "OUT",
      date: "2024-02-28",
      payout_amount: 25.0,
      method: "Bank Transfer",
      reference_no: "TRF-002",
      status: "Completed",
      description: "Monthly payout",
    },
  ],
};

// Add these interfaces
interface OrderTableData {
  id: string;
  order_id: string;
  patientName: string;
  patientEmail: string;
  products: string[];
  products_count: number;
  total: number;
  commission: number;
  status: string;
  order_date: string;
  created_at: string;
}

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

// Add payout transaction interface
interface PayoutTransaction {
  id: string;
  date: string;
  type: string;
  description: string;
  order_id: string;
  amount: string;
  transaction_type: string;
  status: string;
  patient_name: string;
  created_at: string;
  updated_at: string;
}

interface PayoutsResponse {
  success: boolean;
  message: string;
  data: {
    transactions: {
      data: PayoutTransaction[];
      total: number;
    };
    summary: {
      doctor_name: string;
      total_transactions: number;
      total_credit_amount: string;
      total_debit_amount: string;
      net_amount: string;
      pending_amount: string;
      paid_amount: string;
      currency: string;
    };
    filters: {
      search: string | null;
      start_date: string | null;
      end_date: string | null;
      status: string | null;
      sort_by: string;
      sort_order: string;
    };
  };
}

// Separate TransactionActions component to isolate loading state
interface TransactionActionsProps {
  transaction: PayoutTransaction;
  onEditPayout: (payout: PayoutTransaction) => Promise<void>;
}

const TransactionActions: React.FC<TransactionActionsProps> = ({
  transaction,
  onEditPayout,
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const canEditPayout = true; // Add this permission check

  // Only show edit action for payout transactions (debit transactions)
  const isPayout = transaction.transaction_type === "Debit";

  if (!isPayout || !canEditPayout) {
    return (
      <div className="min-w-[40px] text-xs text-muted-foreground">
        {!isPayout ? "N/A" : "No access"}
      </div>
    );
  }

  const handleEditClick = async () => {
    setIsLoading(true);
    try {
      await onEditPayout(transaction);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-w-[40px]">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="h-7 w-7 p-0" disabled={isLoading}>
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <MoreHorizontal className="h-4 w-4" />
            )}
            <span className="sr-only">Open menu</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-[160px]">
          <DropdownMenuLabel>Actions</DropdownMenuLabel>
          <DropdownMenuItem onClick={handleEditClick} disabled={isLoading}>
            {isLoading ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Edit className="mr-2 h-4 w-4" />
            )}
            Edit Payout
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default function DoctorProfilePage() {
  const { user } = useAuth();
  const params = useParams();
  const router = useRouter();
  const doctorId = params.id as string;
  const { toast } = useToast();

  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [isLoadingStaff, setIsLoadingStaff] = useState(false);
  const [commissionData, setCommissionData] = useState(
    mockCommissionData[doctorId as keyof typeof mockCommissionData] || []
  );
  const [documents, setDocuments] = useState<DocumentFile[]>([]);
  const [serverDocs, setServerDocs] = useState<any[]>([]);
  const [isStatusDialogOpen, setIsStatusDialogOpen] = useState(false);
  const [isStaffDialogOpen, setIsStaffDialogOpen] = useState(false);
  const [isPayoutDialogOpen, setIsPayoutDialogOpen] = useState(false);
  const [editingDoctor, setEditingDoctor] = useState<Doctor | null>(null);
  const [selectedStaff, setSelectedStaff] = useState<any>(null);
  const [isEditingStaff, setIsEditingStaff] = useState(false);
  const [isSavingStaff, setIsSavingStaff] = useState(false);
  const [payoutForm, setPayoutForm] = useState({
    amount: "",
    method: "Bank Transfer",
    reference_no: "",
    notes: "",
    payoutDate: new Date().toISOString().split("T")[0], // Default to today
    dateRange: {
      start: "",
      end: "",
    },
  });

  const [searchTerm, setSearchTerm] = useState("");
  const [paginationState, setPaginationState] = useState({
    pageIndex: 0,
    pageSize: 10,
  });
  const [sortingState, setSortingState] = useState<any>([]);
  // Add these state variables to your component
  const [doctorOrders, setDoctorOrders] = useState<OrderTableData[]>([]);
  const [isLoadingOrders, setIsLoadingOrders] = useState(false);
  const [ordersPagination, setOrdersPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });
  const [ordersSorting, setOrdersSorting] = useState<any>([]);
  const [ordersSearchTerm, setOrdersSearchTerm] = useState("");
  const [ordersTotal, setOrdersTotal] = useState(0);
  // Add these state variables near your other state declarations
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [orderDetails, setOrderDetails] = useState<any>(null);
  const [isLoadingOrderDetails, setIsLoadingOrderDetails] = useState(false);

  // Permission state
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);
  const [confirmation, setConfirmation] = useState({
    isOpen: false,
    title: "",
    description: "",
    staff: null as StaffMember | null,
  });

  const [isSavingDocuments, setIsSavingDocuments] = useState(false);
  const [serverDocuments, setServerDocuments] = useState<any[]>([]);

  const [payoutTransactions, setPayoutTransactions] = useState<
    PayoutTransaction[]
  >([]);
  const [isLoadingPayouts, setIsLoadingPayouts] = useState(false);
  const [payoutsPagination, setPayoutsPagination] = useState({
    pageIndex: 0,
    pageSize: 10,
  });
  const [payoutsSorting, setPayoutsSorting] = useState<any>([]);
  const [payoutsSearchTerm, setPayoutsSearchTerm] = useState("");
  const [payoutsTotal, setPayoutsTotal] = useState(0);
  const [payoutSummary, setPayoutSummary] = useState<any>(null);
  const [editingPayout, setEditingPayout] = useState<any>(null);
  const [isEditPayoutDialogOpen, setIsEditPayoutDialogOpen] = useState(false);

  // Add active tab state to preserve current tab
  const [activeTab, setActiveTab] = useState("orders");
  const [commissionCalculation, setCommissionCalculation] = useState<{
    pending_summary: {
      total_pending_amount: string;
      minimum_amount_required: string;
      minimum_amount_required_message: string | null;
    };
  } | null>(null);

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          console.log("User permissions loaded:", user.permission);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  const fetchPayoutDetails = async (payoutId: string) => {
    try {
      const response = await axiosInstance.get(`/payout/${payoutId}`);

      if (response.data.success) {
        return response.data.data.payout;
      } else {
        throw new Error(
          response.data.message || "Failed to fetch payout details"
        );
      }
    } catch (error: any) {
      console.error("Error fetching payout details:", error);
      throw new Error(
        error.response?.data?.message || "Failed to fetch payout details"
      );
    }
  };

  const handleEditPayout = async (payout: PayoutTransaction) => {
    try {
      // Fetch the latest payout details from the API
      const payoutDetails = await fetchPayoutDetails(payout.id);

      setEditingPayout(payoutDetails);
      setPayoutForm({
        amount: payoutDetails.amount,
        method: payoutDetails.payment_method || "Bank Transfer",
        reference_no: payoutDetails.reference_number || "",
        notes: payoutDetails.description || "",
        payoutDate: payoutDetails?.transaction_date, // Extract date part from datetime
        dateRange: {
          start: "",
          end: "",
        },
      });
      setIsEditPayoutDialogOpen(true);
    } catch (error: any) {
      console.error("Error loading payout details:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to load payout details",
      });
    }
  };

  const updatePayout = async (
    payoutId: string,
    payoutData: {
      amount: string;
      payment_method: string;
      reference: string;
      notes: string;
      date: string;
    }
  ) => {
    try {
      const response = await axiosInstance.put(
        `/payout/${payoutId}`,
        payoutData
      );

      if (response.data.success) {
        return response.data;
      } else {
        throw new Error(response.data.message || "Failed to update payout");
      }
    } catch (error: any) {
      console.error("Error updating payout:", error);
      throw new Error(
        error.response?.data?.message || "Failed to update payout"
      );
    }
  };

  const handleUpdatePayout = async () => {
    if (!editingPayout || !payoutForm.amount || !payoutForm.payoutDate) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill all required fields",
      });
      return;
    }

    try {
      setIsSavingStaff(true);

      const payoutData = {
        amount: payoutForm.amount,
        payment_method: payoutForm.method,
        reference: payoutForm.reference_no,
        notes: payoutForm.notes,
        date: payoutForm.payoutDate,
      };

      const response = await updatePayout(editingPayout.id, payoutData);

      // Refresh payout transactions
      await fetchPayoutTransactions();

      setIsEditPayoutDialogOpen(false);
      setEditingPayout(null);

      toast({
        title: "Success",
        description: response.message || "Payout updated successfully",
      });
    } catch (error: any) {
      console.error("Error updating payout:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to update payout",
      });
    } finally {
      setIsSavingStaff(false);
    }
  };

  // Add this function to fetch orders
  const fetchDoctorOrders = async (params?: {
    search?: string;
    page?: number;
    per_page?: number;
    sort_by?: string;
    sort_order?: "asc" | "desc";
  }) => {
    if (!doctorId) return;

    try {
      setIsLoadingOrders(true);
      const filters: DoctorOrdersFilters = {
        doctor_id: doctorId,
        search: params?.search || "",
        page: params?.page || 1,
        per_page: params?.per_page || 10,
        sort_by: params?.sort_by || "updated_at",
        sort_order: params?.sort_order || "desc",
      };

      const response = await getDoctorOrders(filters);

      // Transform API data to match table structure
      const transformedOrders: OrderTableData[] = response.data.orders.data.map(
        (order: DoctorOrder) => ({
          id: order.id,
          order_id: order.order_id,
          patientName: order.patient.full_name,
          patientEmail: order.patient.email,
          products: order.products,
          products_count: order.products_count,
          total: parseFloat(order.total_price),
          commission: parseFloat(order.commission),
          status: order.status,
          order_date: order.order_date,
          created_at: order.created_at,
        })
      );

      setDoctorOrders(transformedOrders);
      setOrdersTotal(response.data.pagination.total);

      // Update pagination state
      setOrdersPagination({
        pageIndex: response.data.pagination.current_page - 1,
        pageSize: response.data.pagination.per_page,
      });
    } catch (error) {
      console.error("Error fetching doctor orders:", error);
      setDoctorOrders([]);
      toast({
        title: "Error",
        description: "Failed to load doctor orders",
        variant: "destructive",
      });
    } finally {
      setIsLoadingOrders(false);
    }
  };

  // Add handlers for orders table
  const handleOrdersSearchChange = (value: string) => {
    setOrdersSearchTerm(value);
    fetchDoctorOrders({
      search: value,
      page: 1,
      per_page: ordersPagination.pageSize,
      sort_by: ordersSorting[0]?.id || "updated_at",
      sort_order: ordersSorting[0]?.desc ? "desc" : "asc",
    });
  };

  const handleOrdersPaginationChange = (pagination: {
    pageIndex: number;
    pageSize: number;
  }) => {
    setOrdersPagination(pagination);
    fetchDoctorOrders({
      search: ordersSearchTerm,
      page: pagination.pageIndex + 1,
      per_page: pagination.pageSize,
      sort_by: ordersSorting[0]?.id || "updated_at",
      sort_order: ordersSorting[0]?.desc ? "desc" : "asc",
    });
  };

  const handleOrdersSortingChange = (sorting: any) => {
    setOrdersSorting(sorting);
    if (sorting.length > 0) {
      fetchDoctorOrders({
        search: ordersSearchTerm,
        page: 1,
        per_page: ordersPagination.pageSize,
        sort_by: sorting[0].id,
        sort_order: sorting[0].desc ? "desc" : "asc",
      });
    } else {
      fetchDoctorOrders({
        search: ordersSearchTerm,
        page: 1,
        per_page: ordersPagination.pageSize,
        sort_by: "updated_at",
        sort_order: "desc",
      });
    }
  };

  // Add this function to fetch and display order details
  const handleViewOrderDetails = async (order: OrderTableData) => {
    try {
      setIsLoadingOrderDetails(true);

      // Fetch detailed order information from API
      const response: any = await getOrderDetails(order.id);

      if (response.success) {
        setSelectedOrder(response.data);
        setIsOrderModalOpen(true);
      } else {
        throw new Error(response.message || "Failed to fetch order details");
      }
    } catch (error: any) {
      console.error("Error fetching order details:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to load order details",
        variant: "destructive",
      });
    } finally {
      setIsLoadingOrderDetails(false);
    }
  };

  const orderColumns: ColumnDef<any>[] = [
    {
      accessorKey: "order_id",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Order ID" />
      ),
      cell: ({ row }) => {
        const orderId = row.getValue("order_id") as string;
        return (
          <div className="font-mono text-sm font-medium min-w-[120px]">
            {orderId}
          </div>
        );
      },
    },
    {
      accessorKey: "patientName",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Patient" />
      ),
      cell: ({ row }) => {
        const patientName = row.getValue("patientName") as string;
        const patientEmail = row.original.patientEmail as string;
        return (
          <div className="min-w-[150px]">
            <div className="font-medium text-sm">{patientName}</div>
            <div className="text-xs text-muted-foreground">{patientEmail}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "products",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Products" />
      ),
      cell: ({ row }) => {
        const products = row.getValue("products") as string[];
        const productsCount = row.original.products_count as number;
        return (
          <div className="min-w-[200px]">
            <div className="text-sm">
              {products.slice(0, 2).map((product, index) => (
                <div key={index} className="flex items-center gap-1">
                  <Package className="h-3 w-3 text-muted-foreground" />
                  <span className="truncate">{product}</span>
                </div>
              ))}
              {products.length > 2 && (
                <div className="text-xs text-muted-foreground">
                  +{products.length - 2} more
                </div>
              )}
              {productsCount > products.length && (
                <div className="text-xs text-muted-foreground">
                  Total items: {productsCount}
                </div>
              )}
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "total",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Amount" />
      ),
      cell: ({ row }) => {
        const total = row.getValue("total") as number;
        return (
          <div className="min-w-[100px]">
            <div className="font-medium text-sm">
              {" "}
              <DirhamIcon />
              {total.toFixed(2)}
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "commission",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Commission" />
      ),
      cell: ({ row }) => {
        const commission = row.getValue("commission") as number;
        return (
          <div className="min-w-[100px]">
            <div className="font-medium text-sm text-green-600">
              <DirhamIcon />
              {commission.toFixed(2)}
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Status" />
      ),
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        const getStatusColor = (status: string) => {
          switch (status.toLowerCase()) {
            case "completed":
            case "closed":
              return "bg-green-600 hover:bg-green-700";
            case "processing":
              return "bg-blue-600 hover:bg-blue-700";
            case "pending":
            case "open":
              return "bg-yellow-600 hover:bg-yellow-700";
            case "draft":
              return "bg-gray-600 hover:bg-gray-700";
            case "cancelled":
              return "bg-red-600 hover:bg-red-700";
            default:
              return "bg-gray-600 hover:bg-gray-700";
          }
        };

        const getStatusDisplay = (status: string) => {
          const statusMap: { [key: string]: string } = {
            open: "Open",
            closed: "Completed",
            cancelled: "Cancelled",
            pending: "Pending",
            processing: "Processing",
            draft: "Draft",
          };
          return statusMap[status.toLowerCase()] || status;
        };

        return (
          <div className="min-w-[100px]">
            <Badge
              variant="default"
              className={`text-xs ${getStatusColor(status)} capitalize`}
            >
              {getStatusDisplay(status)}
            </Badge>
          </div>
        );
      },
      filterFn: (row, id, value) => {
        return value.includes(row.getValue(id));
      },
    },
    {
      accessorKey: "order_date",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Order Date" />
      ),
      cell: ({ row }) => {
        const orderDate = row.getValue("order_date") as string;
        return (
          <div className="min-w-[100px]">
            <div className="text-sm">{orderDate}</div>
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const order = row.original;
        return (
          <div className="min-w-[40px]">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="h-7 w-7 p-0"
                  disabled={isLoadingOrderDetails}
                >
                  <MoreHorizontal className="h-4 w-4" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-[160px]">
                <DropdownMenuLabel>Actions</DropdownMenuLabel>
                <DropdownMenuItem
                  onClick={() => handleViewOrderDetails(order)}
                  disabled={isLoadingOrderDetails}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  View Details
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        );
      },
    },
  ];

  useEffect(() => {
    if (doctorId) {
      fetchDoctorOrders();
      fetchPayoutTransactions();
    }
  }, [doctorId]);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Fetch doctor detail from API
  useEffect(() => {
    const load = async () => {
      try {
        setIsLoading(true);
        const res = await doctorService.getDoctor(doctorId);
        const d: any = res.data;
        const name = d.full_name || `${d.first_name} ${d.last_name}`;
        const address = [
          d.villa_apartment,
          d.area_street,
          d.emirates_states,
          d.nearby_landmark,
        ]
          .filter((p) => p && String(p).trim() !== "")
          .join(", ");

        const uiDoctor: any = {
          id: d.id,
          name,
          email: d.email,
          phone: d.phone_number,
          clinic: d.clinic_name || "",
          address: address || d.address || "",
          status: d.status || "Active",
          patients: d?.patients || 0,
          totalOrders: 0,
          joinDate: d.created_at,
          commission:
            typeof d.commission === "string"
              ? parseFloat(d.commission)
              : Number(d.commission || 0),
          specialization: d.medical_speciality || "",
          license: d.medical_license || "",
          experience: String(d.years_of_experience || ""),
          education: "",
          bio: d.bio || "",
          product_commission: d.product_commission || 0,
          lab_test_commission: d.lab_test_commission || 0,
        };
        setDoctor(uiDoctor);
        setServerDocs(d.documents || []);
      } catch (e) {
        console.error(e);
        setDoctor(null);
        setServerDocs([]);
        toast({
          title: "Error",
          description: "Failed to load doctor profile",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };
    load();
  }, [doctorId, toast]);

  // Add function to fetch payout transactions
  const fetchPayoutTransactions = async (params?: {
    search?: string;
    page?: number;
    per_page?: number;
    sort_by?: string;
    sort_order?: "asc" | "desc";
    start_date?: string;
    end_date?: string;
    status?: string;
  }) => {
    if (!doctorId) return;

    try {
      setIsLoadingPayouts(true);
      const response = await axiosInstance.get("/payouts", {
        params: {
          doctor_id: doctorId,
          search: params?.search || "",
          page: params?.page || 1,
          per_page: params?.per_page || 10,
          sort_by: params?.sort_by || "created_at",
          sort_order: params?.sort_order || "desc",
          start_date: params?.start_date || "",
          end_date: params?.end_date || "",
          status: params?.status || "",
        },
      });

      const data: PayoutsResponse = response.data;

      if (data.success) {
        setPayoutTransactions(data.data.transactions.data);
        setPayoutsTotal(data.data.transactions.total);
        setPayoutSummary(data.data.summary);

        // Update pagination state
        setPayoutsPagination({
          pageIndex: (params?.page || 1) - 1,
          pageSize: params?.per_page || 10,
        });
      } else {
        throw new Error(data.message || "Failed to fetch payout transactions");
      }
    } catch (error) {
      console.error("Error fetching payout transactions:", error);
      setPayoutTransactions([]);
      toast({
        title: "Error",
        description: "Failed to load payout transactions",
        variant: "destructive",
      });
    } finally {
      setIsLoadingPayouts(false);
    }
  };

  // Add handlers for payout transactions table
  const handlePayoutsSearchChange = (value: string) => {
    setPayoutsSearchTerm(value);
    fetchPayoutTransactions({
      search: value,
      page: 1,
      per_page: payoutsPagination.pageSize,
      sort_by: payoutsSorting[0]?.id || "created_at",
      sort_order: payoutsSorting[0]?.desc ? "desc" : "asc",
    });
  };

  const handlePayoutsPaginationChange = (pagination: {
    pageIndex: number;
    pageSize: number;
  }) => {
    setPayoutsPagination(pagination);
    fetchPayoutTransactions({
      search: payoutsSearchTerm,
      page: pagination.pageIndex + 1,
      per_page: pagination.pageSize,
      sort_by: payoutsSorting[0]?.id || "created_at",
      sort_order: payoutsSorting[0]?.desc ? "desc" : "asc",
    });
  };

  const handlePayoutsSortingChange = (sorting: any) => {
    setPayoutsSorting(sorting);
    if (sorting.length > 0) {
      fetchPayoutTransactions({
        search: payoutsSearchTerm,
        page: 1,
        per_page: payoutsPagination.pageSize,
        sort_by: sorting[0].id,
        sort_order: sorting[0].desc ? "desc" : "asc",
      });
    } else {
      fetchPayoutTransactions({
        search: payoutsSearchTerm,
        page: 1,
        per_page: payoutsPagination.pageSize,
        sort_by: "created_at",
        sort_order: "desc",
      });
    }
  };

  // Transaction ledger columns for data table with actions
  const transactionColumns: ColumnDef<any>[] = [
    {
      accessorKey: "date",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Date" />
      ),
      cell: ({ row }) => {
        const date = row.getValue("date") as string;
        return (
          <div className="min-w-[100px]">
            <div className="text-sm">{date}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "type",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Type" />
      ),
      cell: ({ row }) => {
        const type = row.getValue("type") as string;
        return (
          <div className="min-w-[100px]">
            <Badge variant={type === "Commission" ? "default" : "secondary"}>
              {type}
            </Badge>
          </div>
        );
      },
      filterFn: (row, id, value) => {
        return value.includes(row.getValue(id));
      },
    },
    {
      accessorKey: "description",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Description" />
      ),
      cell: ({ row }) => {
        const description = row.getValue("description") as string;
        return (
          <div className="min-w-[200px]">
            <div className="text-sm">{description}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "order_id",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Order ID" />
      ),
      cell: ({ row }) => {
        const orderId = row.getValue("order_id") as string;
        return (
          <div className="min-w-[120px]">
            <div className="font-mono text-sm">{orderId || "-"}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "amount",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Amount" />
      ),
      cell: ({ row }) => {
        const transaction = row.original;
        const amount = parseFloat(transaction.amount || "0");
        const formattedAmount = amount.toFixed(2);
        const isCredit = transaction.transaction_type === "Credit";

        return (
          <div className="min-w-[100px]">
            <div
              className={`font-medium text-sm ${
                isCredit ? "text-green-600" : "text-red-600"
              }`}
            >
              <DirhamIcon />
              {formattedAmount}
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Status" />
      ),
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        return (
          <div className="min-w-[100px]">
            <Badge variant={status === "Completed" ? "default" : "outline"}>
              {status}
            </Badge>
          </div>
        );
      },
      filterFn: (row, id, value) => {
        return value.includes(row.getValue(id));
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const transaction = row.original;
        return (
          <TransactionActions
            transaction={transaction}
            onEditPayout={handleEditPayout}
          />
        );
      },
    },
  ];

  // Fetch staff members for the doctor
  const fetchStaffMembers = async (params?: {
    search?: string;
    page?: number;
    per_page?: number;
    sort_by?: string;
    sort_order?: "asc" | "desc";
  }) => {
    if (!doctorId) return;

    // Check permission before fetching
    if (!hasPermission("doctorStaff_read")) {
      console.log("No permission to read staff members");
      setStaffMembers([]);
      return;
    }

    try {
      setIsLoadingStaff(true);
      const response = await getStaffList({
        doctor_id: doctorId,
        per_page: params?.per_page || 50,
        page: params?.page || 1,
        search: params?.search || "",
        sort_by: params?.sort_by || "created_at",
        sort_order: params?.sort_order || "desc",
      });
      setStaffMembers(response.data.staff || []);
    } catch (error) {
      console.error("Error fetching staff members:", error);
      setStaffMembers([]);
      toast({
        title: "Error",
        description: "Failed to load staff members",
        variant: "destructive",
      });
    } finally {
      setIsLoadingStaff(false);
    }
  };

  // Add handlers for server-side operations
  const handleSearchChange = (value: string) => {
    setSearchTerm(value);
    fetchStaffMembers({
      search: value,
      page: 1,
      per_page: paginationState.pageSize,
      sort_by: sortingState[0]?.id || "created_at",
      sort_order: sortingState[0]?.desc ? "desc" : "asc",
    });
  };

  const handlePaginationChange = (pagination: {
    pageIndex: number;
    pageSize: number;
  }) => {
    setPaginationState(pagination);
    fetchStaffMembers({
      search: searchTerm,
      page: pagination.pageIndex + 1,
      per_page: pagination.pageSize,
      sort_by: sortingState[0]?.id || "created_at",
      sort_order: sortingState[0]?.desc ? "desc" : "asc",
    });
  };

  const handleSortingChange = (sorting: any) => {
    setSortingState(sorting);
    if (sorting.length > 0) {
      fetchStaffMembers({
        search: searchTerm,
        page: 1,
        per_page: paginationState.pageSize,
        sort_by: sorting[0].id,
        sort_order: sorting[0].desc ? "desc" : "asc",
      });
    } else {
      fetchStaffMembers({
        search: searchTerm,
        page: 1,
        per_page: paginationState.pageSize,
        sort_by: "created_at",
        sort_order: "desc",
      });
    }
  };

  useEffect(() => {
    if (permissionsLoaded && hasPermission("doctorStaff_read")) {
      fetchStaffMembers();
    }
  }, [doctorId, toast, permissionsLoaded]);

  // Calculate commission statistics
  const totalCommissionEarned = payoutSummary
    ? parseFloat(payoutSummary.total_credit_amount)
    : 0;
  const totalPayoutsMade = payoutSummary
    ? parseFloat(payoutSummary.total_debit_amount)
    : 0;
  const currentWalletBalance = payoutSummary
    ? parseFloat(payoutSummary.net_amount)
    : 0;

  const handleToggleStatus = () => {
    if (doctor) {
      const newStatus = doctor.status === "Active" ? "Inactive" : "Active";
      setDoctor({ ...doctor, status: newStatus });
      setIsStatusDialogOpen(false);
      toast({
        title: "Success",
        description: `Doctor status changed to ${newStatus}`,
      });
    }
  };

  const handleAddPayout = () => {
    setPayoutForm({
      amount: "",
      method: "Bank Transfer",
      reference_no: "",
      notes: "",
      payoutDate: new Date().toISOString().split("T")[0], // Default to today
      dateRange: {
        start: "",
        end: "",
      },
    });
    setIsPayoutDialogOpen(true);
  };

  // Replace your current fetchServerDocuments function with this:
  const fetchServerDocuments = async () => {
    try {
      // Fetch fresh doctor data to get updated documents
      const res = await doctorService.getDoctor(doctorId);
      const updatedDoctor = res.data;

      // Update both serverDocs state and return the documents
      const documents = updatedDoctor.documents || [];
      setServerDocs(documents);

      return documents;
    } catch (error) {
      console.error("Error fetching server documents:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load server documents",
      });
      return [];
    }
  };

  // Update your handleSaveDocuments function to properly refresh documents:
  const handleSaveDocuments = async (documents: DocumentFile[]) => {
    if (!doctorId) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Doctor ID is required to upload documents",
      });
      return;
    }

    setIsSavingDocuments(true);

    try {
      const formData = new FormData();
      formData.append("doctor_id", doctorId);

      documents.forEach((doc, index) => {
        formData.append(`documents[${index}]`, doc.file);
      });

      const response = await uploadDoctorDocuments(formData);

      if (response.success) {
        // Clear the selected documents after successful upload
        setDocuments([]);

        // Refresh server documents to show the newly uploaded ones
        await fetchServerDocuments();

        toast({
          variant: "success",
          title: "Documents Uploaded!",
          description:
            response.message ||
            "Your documents have been uploaded successfully.",
        });
      }
    } catch (error: any) {
      console.error("Document upload error:", error);

      toast({
        variant: "destructive",
        title: "Upload Failed",
        description:
          error.response?.data?.message ||
          "Failed to upload documents. Please try again.",
      });

      throw error;
    } finally {
      setIsSavingDocuments(false);
    }
  };

  // Also, update your deleteServerDocument function to properly handle the deletion:
  const deleteServerDocument = async (documentId: string) => {
    try {
      // Call the actual API to delete the document
      await deleteDoctorDocument(documentId);

      // Update local state to remove the deleted document
      setServerDocs((prev) => prev.filter((doc) => doc.id !== documentId));

      toast({
        variant: "success",
        title: "Document Deleted",
        description: "Document has been deleted successfully",
      });
    } catch (error) {
      console.error("Error deleting document:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete document",
      });
      throw error;
    }
  };

  const calculateCommissionByDateRange = async (
    startDate: string,
    endDate: string
  ) => {
    try {
      const response = await axiosInstance.get("/commission/date-range", {
        params: {
          doctor_id: doctorId,
          start_date: startDate,
          end_date: endDate,
        },
      });

      if (response.data.success) {
        return response.data.data;
      } else {
        throw new Error(
          response.data.message || "Failed to calculate commission"
        );
      }
    } catch (error: any) {
      console.error("Error calculating commission:", error);
      throw new Error(
        error.response?.data?.message || "Failed to calculate commission"
      );
    }
  };

  const createPayout = async (payoutData: {
    doctor_id: string;
    amount: string;
    payment_method: string;
    reference: string;
    notes: string;
    date: string;
    start_date: string;
    end_date: string;
  }) => {
    try {
      const response = await axiosInstance.post("/payouts", payoutData);

      if (response.data.success) {
        return response.data;
      } else {
        throw new Error(response.data.message || "Failed to create payout");
      }
    } catch (error: any) {
      console.error("Error creating payout:", error);
      throw new Error(
        error.response?.data?.message || "Failed to create payout"
      );
    }
  };

  const handleEndDateChange = async (endDate: string) => {
    if (payoutForm.dateRange?.start && endDate) {
      try {
        setIsLoadingOrders(true);
        const commissionData = await calculateCommissionByDateRange(
          payoutForm.dateRange.start,
          endDate
        );

        // Store the commission calculation data
        setCommissionCalculation(commissionData);

        // Only auto-fill amount if minimum requirement is met
        if (!commissionData.pending_summary.minimum_amount_required_message) {
          setPayoutForm((prev) => ({
            ...prev,
            amount: commissionData.pending_summary.total_pending_amount,
          }));
        } else {
          // Clear amount if minimum requirement not met
          setPayoutForm((prev) => ({
            ...prev,
            amount: "",
          }));
        }

        toast({
          title: "Commission Calculated",
          description: `Commission for the selected period: ${commissionData.pending_summary.total_pending_amount} ${commissionData.pending_summary.currency}`,
        });
      } catch (error: any) {
        console.error("Error calculating commission:", error);
        setCommissionCalculation(null);
        toast({
          title: "Error",
          description:
            error.message ||
            "Failed to calculate commission for the selected period",
        });
      } finally {
        setIsLoadingOrders(false);
      }
    }
  };

  const handleSavePayout = async () => {
    if (!doctorId || !payoutForm.amount || !payoutForm.payoutDate) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Please fill all required fields",
      });
      return;
    }

    try {
      setIsSavingStaff(true); // Reuse loading state or create a new one for payout

      const payoutData = {
        doctor_id: doctorId,
        amount: payoutForm.amount,
        payment_method: payoutForm.method,
        reference: payoutForm.reference_no,
        notes: payoutForm.notes,
        date: payoutForm.payoutDate,
        start_date: payoutForm.dateRange?.start || "",
        end_date: payoutForm.dateRange?.end || "",
      };

      const response = await createPayout(payoutData);

      await fetchPayoutTransactions();

      setIsPayoutDialogOpen(false);

      toast({
        title: "Success",
        description: response.message || "Payout added successfully",
      });
    } catch (error: any) {
      console.error("Error creating payout:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to create payout",
      });
    } finally {
      setIsSavingStaff(false);
    }
  };

  const handleAddStaff = () => {
    // Check permission
    if (!hasPermission("doctorStaff_write")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to add staff members.",
      });
      return;
    }

    setSelectedStaff({
      name: "",
      email: "",
      phone_number: "",
      gender: "",
      status: "active",
    });
    setIsEditingStaff(false);
    setIsStaffDialogOpen(true);
  };

  const handleEditStaff = async (staff: StaffMember) => {
    // Check permission
    if (!hasPermission("doctorStaff_update")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to edit staff members.",
      });
      return;
    }

    try {
      const response = await getStaffById(staff.id);
      setSelectedStaff(response.data);
      setIsEditingStaff(true);
      setIsStaffDialogOpen(true);
    } catch (error) {
      console.error("Error fetching staff details:", error);
      // Fallback to local data if API fails
      setSelectedStaff(staff);
      setIsEditingStaff(true);
      setIsStaffDialogOpen(true);
      toast({
        title: "Warning",
        description: "Using cached staff data",
        variant: "default",
      });
    }
  };

  const handleDeleteStaff = async (staff: StaffMember) => {
    // Check permission
    if (!hasPermission("doctorStaff_delete")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to delete staff members.",
      });
      return;
    }

    setConfirmation({
      isOpen: true,
      title: "Delete Staff Member",
      description: `Are you sure you want to delete ${staff.name}? This action cannot be undone.`,
      staff: staff,
    });
  };

  // Add handleConfirmDelete function
  const handleConfirmDelete = async () => {
    if (!confirmation.staff) return;

    try {
      await deleteStaff(confirmation.staff.id);
      // Refresh staff list after deletion
      await fetchStaffMembers();
      toast({
        title: "Success",
        description: "Staff member deleted successfully",
      });
    } catch (error) {
      console.error("Error deleting staff member:", error);
      toast({
        title: "Error",
        description: "Failed to delete staff member. Please try again.",
        variant: "destructive",
      });
    } finally {
      // Close confirmation dialog
      setConfirmation({
        isOpen: false,
        title: "",
        description: "",
        staff: null,
      });
    }
  };

  // Add handleCancelDelete function
  const handleCancelDelete = () => {
    setConfirmation({
      isOpen: false,
      title: "",
      description: "",
      staff: null,
    });
  };

  const handleSaveStaff = async () => {
    if (!doctorId || !selectedStaff) return;

    // Validate required fields
    if (!selectedStaff.name?.trim()) {
      toast({
        title: "Error",
        description: "Name is required",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.email?.trim()) {
      toast({
        title: "Error",
        description: "Email is required",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.phone_number?.trim()) {
      toast({
        title: "Error",
        description: "Phone number is required",
        variant: "destructive",
      });
      return;
    }

    // Validate UAE phone number format
    const phoneNumber = selectedStaff.phone_number.trim();
    const uaePhoneRegex = /^\+971\s?\d{1,3}[\s-]?\d{3}[\s-]?\d{4}$/;

    if (!uaePhoneRegex.test(phoneNumber)) {
      toast({
        title: "Error",
        description:
          "Phone number must start with +971 (UAE country code). Example: +971 50 123 4567",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.gender) {
      toast({
        title: "Error",
        description: "Gender is required",
        variant: "destructive",
      });
      return;
    }

    if (!selectedStaff.status) {
      toast({
        title: "Error",
        description: "Status is required",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsSavingStaff(true);
      const payload = {
        doctor_id: doctorId,
        name: selectedStaff.name.trim(),
        email: selectedStaff.email.trim(),
        phone_number: selectedStaff.phone_number.trim(),
        gender: selectedStaff.gender,
        status: selectedStaff.status,
      };

      if (isEditingStaff) {
        await updateStaff(selectedStaff.id, payload);
        toast({
          title: "Success",
          description: "Staff member updated successfully",
        });
      } else {
        await createStaff(payload);
        toast({
          title: "Success",
          description: "Staff member added successfully",
        });
      }

      // Refresh staff list after successful operation
      await fetchStaffMembers();
      setIsStaffDialogOpen(false);
    } catch (error: any) {
      console.error("Error saving staff member:", error);
      const errorMessage =
        error.response?.data?.message ||
        "Failed to save staff member. Please try again.";
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsSavingStaff(false);
    }
  };

  const handleStaffInputChange = (field: string, value: string) => {
    setSelectedStaff({
      ...selectedStaff,
      [field]: value,
    });
  };

  const handleEditDoctor = () => {
    if (doctor) {
      setEditingDoctor(doctor);
    }
  };

  const handleDoctorUpdated = (updatedDoctor: Doctor) => {
    setDoctor(updatedDoctor);
    setEditingDoctor(null);
    toast({
      title: "Success",
      description: "Doctor information updated successfully",
    });
  };

  // Staff members columns for data table
  const staffColumns: ColumnDef<StaffMember>[] = [
    {
      accessorKey: "name",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Name" />
      ),
      cell: ({ row }) => {
        const name = row.getValue("name") as string;
        const getInitials = (name: string) => {
          return name
            .split(" ")
            .map((n) => n[0])
            .join("")
            .toUpperCase();
        };
        return (
          <div className="flex items-center space-x-3 min-w-[150px]">
            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
              <span className="text-xs font-semibold text-blue-600">
                {getInitials(name)}
              </span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="font-medium text-sm truncate">{name}</div>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "email",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Contact" />
      ),
      cell: ({ row }) => {
        const staff = row.original;
        return (
          <div className="min-w-[200px] space-y-1">
            <div className="flex items-center space-x-1 text-xs">
              <Mail className="h-3 w-3 text-muted-foreground flex-shrink-0" />
              <span className="truncate max-w-[160px]" title={staff.email}>
                {staff.email}
              </span>
            </div>
            <div className="flex items-center space-x-1 text-xs">
              <Phone className="h-3 w-3 text-muted-foreground flex-shrink-0" />
              <span className="truncate" title={staff.phone_number}>
                {staff.phone_number}
              </span>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "gender",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Gender" />
      ),
      cell: ({ row }) => {
        const gender = row.getValue("gender") as string;
        return (
          <div className="min-w-[80px]">
            <Badge variant="outline" className="text-xs capitalize">
              {gender}
            </Badge>
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Status" />
      ),
      cell: ({ row }) => {
        const status = row.getValue("status") as string;
        return (
          <div className="min-w-[80px]">
            <Badge
              variant={status === "active" ? "default" : "secondary"}
              className="capitalize"
            >
              {status}
            </Badge>
          </div>
        );
      },
      filterFn: (row, id, value) => {
        return value.includes(row.getValue(id));
      },
    },
    {
      accessorKey: "created_by",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Created By" />
      ),
      cell: ({ row }) => {
        const created_by = row.getValue("created_by") as string;
        return (
          <div className="min-w-[120px]">
            <div className="text-sm">{created_by || "-"}</div>
          </div>
        );
      },
    },
    {
      accessorKey: "created_at",
      header: ({ column }) => (
        <DataTableColumnHeader column={column} title="Join Date" />
      ),
      cell: ({ row }) => {
        const created_at = row.getValue("created_at") as string;
        const formattedDate = created_at ? convertToDubaiTime(created_at) : "-";
        return (
          <div className="min-w-[100px]">
            <div className="text-sm">{formattedDate}</div>
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }) => {
        const staff = row.original;
        const canEdit = hasPermission("doctorStaff_update");
        const canDelete = hasPermission("doctorStaff_delete");

        if (!canEdit && !canDelete) {
          return (
            <div className="min-w-[80px] text-xs text-muted-foreground">
              No actions
            </div>
          );
        }

        return (
          <div className="min-w-[80px]">
            <div className="flex gap-2">
              {canEdit && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleEditStaff(staff)}
                >
                  <Edit className="h-4 w-4" />
                </Button>
              )}
              {canDelete && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDeleteStaff(staff)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        );
      },
    },
  ];

  // Loading state
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Loading doctor profile...</p>
        </div>
      </div>
    );
  }

  // Doctor not found state
  if (!user || !doctor) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
        <div className="text-center space-y-2">
          <User className="h-12 w-12 text-muted-foreground mx-auto" />
          <h2 className="text-2xl font-bold text-gray-900">Doctor Not Found</h2>
          <p className="text-muted-foreground">
            The doctor you're looking for doesn't exist or you don't have access
            to view this profile.
          </p>
        </div>
        <Button onClick={() => router.push("/admin/doctors")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Doctors
        </Button>
      </div>
    );
  }

  // Check if user has permission to view staff section
  const canViewStaff = hasPermission("doctorStaff_read");
  const canAddStaff = hasPermission("doctorStaff_write");

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={() => router.push("/admin/doctors")}
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Doctors
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{doctor.name}</h1>
            <p className="text-muted-foreground">Doctor Profile Management</p>
          </div>
        </div>
      </div>

      {/* Tabs - Now controlled with activeTab state */}
      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="space-y-4"
      >
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="orders" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Orders
          </TabsTrigger>
          <TabsTrigger value="commission" className="flex items-center gap-2">
            <Wallet className="h-4 w-4" />
            Commission & Wallet
          </TabsTrigger>
          <TabsTrigger value="documents" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Documents
          </TabsTrigger>
          <TabsTrigger value="general" className="flex items-center gap-2">
            <User className="h-4 w-4" />
            General Information
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Orders */}
        <TabsContent value="orders" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Orders ({doctorOrders.length})
              </CardTitle>
              <CardDescription>
                All orders linked to this doctor
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DataTable
                columns={orderColumns}
                data={doctorOrders}
                searchColumnId="order_id"
                manual={true}
                state={{
                  searchValue: ordersSearchTerm,
                  pagination: ordersPagination,
                  sorting: ordersSorting,
                }}
                onSearchChange={handleOrdersSearchChange}
                onPaginationChange={handleOrdersPaginationChange}
                onSortingChange={handleOrdersSortingChange}
                isLoading={isLoadingOrders}
                doctor_id={doctorId}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 2: Commission & Wallet */}
        <TabsContent value="commission" className="space-y-4">
          {/* Statistics Cards - Using Actual API Data */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Commission Earned
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  <DirhamIcon />
                  {payoutSummary ? payoutSummary.total_credit_amount : "0.00"}
                </div>
                <p className="text-xs text-muted-foreground">
                  Sum of all commissions
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Payouts Made
                </CardTitle>
                <TrendingDown className="h-4 w-4 text-red-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">
                  <DirhamIcon />
                  {payoutSummary ? payoutSummary.total_debit_amount : "0.00"}
                </div>
                <p className="text-xs text-muted-foreground">
                  Sum of all payouts
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Current Wallet Balance
                </CardTitle>
                <Wallet className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  <DirhamIcon />
                  {payoutSummary ? payoutSummary.net_amount : "0.00"}
                </div>
                <p className="text-xs text-muted-foreground">
                  Available for payout
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Pending Commission
                </CardTitle>
                <Clock className="h-4 w-4 text-amber-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-600">
                  <DirhamIcon />
                  {payoutSummary ? payoutSummary.pending_amount : "0.00"}
                </div>
                <p className="text-xs text-muted-foreground">Awaiting payout</p>
              </CardContent>
            </Card>
          </div>

          {/* Transaction Ledger */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Transaction Ledger</CardTitle>
                  <CardDescription>
                    Complete history of commissions and payouts
                  </CardDescription>
                </div>
                <Button onClick={handleAddPayout}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Payout
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <DataTable
                columns={transactionColumns}
                data={payoutTransactions}
                searchColumnId="description"
                manual={true}
                state={{
                  searchValue: payoutsSearchTerm,
                  pagination: payoutsPagination,
                  sorting: payoutsSorting,
                }}
                onSearchChange={handlePayoutsSearchChange}
                onPaginationChange={handlePayoutsPaginationChange}
                onSortingChange={handlePayoutsSortingChange}
                isLoading={isLoadingPayouts}
                doctor_id={doctorId}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 3: Documents */}
        <TabsContent value="documents" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Doctor Documents
              </CardTitle>
              <CardDescription>
                View and manage doctor's verification documents
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DocumentUpload
                documents={documents}
                onDocumentsChange={setDocuments}
                title="Doctor Documents"
                description="Manage doctor's verification documents. Maximum 5 files, 2MB each."
                maxFiles={5}
                maxSize={2}
                showServerDocuments={true}
                onSaveDocuments={handleSaveDocuments}
                isSaving={isSavingDocuments}
                onFetchServerDocuments={fetchServerDocuments}
                onDeleteServerDocument={deleteServerDocument}
              />
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab 4: General Information */}
        <TabsContent value="general" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-3">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Basic Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Full Name
                  </Label>
                  <p className="text-sm">{doctor.name}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Specialization
                  </Label>
                  <p className="text-sm">{doctor.specialization}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    License
                  </Label>
                  <p className="text-sm">{doctor.license}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Experience
                  </Label>
                  <p className="text-sm">{doctor.experience}</p>
                </div>
              </CardContent>
            </Card>

            {/* Contact Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Contact Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Email
                  </Label>
                  <p className="text-sm">{doctor.email}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Phone
                  </Label>
                  <p className="text-sm">{doctor.phone}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Clinic
                  </Label>
                  <p className="text-sm">{doctor.clinic}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Address
                  </Label>
                  <p className="text-sm">{doctor.address}</p>
                </div>
              </CardContent>
            </Card>

            {/* Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Statistics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Status
                  </Label>
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        doctor.status === "Active" ? "default" : "secondary"
                      }
                    >
                      {doctor.status}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Product Commission Rate
                  </Label>
                  <p className="text-sm">{doctor?.product_commission}%</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Labtest Commission Rate
                  </Label>
                  <p className="text-sm">{doctor?.lab_test_commission}%</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Total Patients
                  </Label>
                  <p className="text-sm">{doctor.patients}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500">
                    Join Date
                  </Label>
                  <p className="text-sm">
                    {convertToDubaiTime(doctor.joinDate)}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Bio */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Biography
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-700 whitespace-pre-line">
                {doctor.bio || "No biography provided."}
              </p>
            </CardContent>
          </Card>

          {/* Staff Management */}
          {canViewStaff && (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Users className="h-5 w-5" />
                      Staff Members
                    </CardTitle>
                    <CardDescription>
                      Manage staff members associated with this doctor
                    </CardDescription>
                  </div>
                  {canAddStaff && (
                    <Button onClick={handleAddStaff}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Staff
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <DataTable
                  columns={staffColumns}
                  data={staffMembers}
                  searchColumnId="name"
                  manual={true}
                  state={{
                    searchValue: searchTerm,
                    pagination: paginationState,
                    sorting: sortingState,
                  }}
                  onSearchChange={handleSearchChange}
                  onPaginationChange={handlePaginationChange}
                  onSortingChange={handleSortingChange}
                  canExport={hasPermission("doctorStaff_export")}
                  isDoctorStaff={true}
                  isLoading={isLoadingStaff}
                  doctor_id={doctorId}
                />
              </CardContent>
            </Card>
          )}

          {/* No Access Message for Staff Section */}
          {!canViewStaff && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Staff Members
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-center py-8">
                  <div className="text-center">
                    <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium mb-2">Access Denied</h3>
                    <p className="text-muted-foreground">
                      You don't have permission to view staff members.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Status Change Dialog */}
      <Dialog open={isStatusDialogOpen} onOpenChange={setIsStatusDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Status Change</DialogTitle>
            <DialogDescription>
              Are you sure you want to change the status of{" "}
              <span className="font-semibold">{doctor.name}</span> to{" "}
              <span className="font-semibold">
                {doctor?.status === "Active" ? "Inactive" : "Active"}
              </span>
              ?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsStatusDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={handleToggleStatus}>Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Payout Dialog - Combined for Add/Edit */}
      <Dialog
        open={isPayoutDialogOpen || isEditPayoutDialogOpen}
        onOpenChange={(open) => {
          if (!open) {
            setIsPayoutDialogOpen(false);
            setIsEditPayoutDialogOpen(false);
            setEditingPayout(null);
            setCommissionCalculation(null);
          }
        }}
      >
        <DialogContent className="max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingPayout ? "Edit Payout" : "Add Payout"}
            </DialogTitle>
            <DialogDescription>
              {editingPayout
                ? "Update payout information for this doctor."
                : "Record a new payout for this doctor."}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Date Range Field - Only show for Add Payout */}
            {!editingPayout && (
              <div className="space-y-2">
                <Label htmlFor="date-range" className="flex items-center gap-1">
                  Date Range *<span className="text-red-500">*</span>
                </Label>
                <div className="flex gap-2">
                  <div className="flex-1">
                    <div className="space-y-1">
                      <div className="relative">
                        <Input
                          id="date-range-start"
                          type="date"
                          placeholder="Start Date"
                          value={payoutForm.dateRange?.start || ""}
                          onChange={(e) => {
                            const startDate = e.target.value;
                            setPayoutForm((prev) => ({
                              ...prev,
                              dateRange: {
                                start: startDate,
                                end: "", // Clear end date when start date changes
                              },
                              amount: "", // Clear amount when date range changes
                            }));
                            setCommissionCalculation(null);
                          }}
                          className={`cursor-pointer pr-10 ${
                            !payoutForm.dateRange?.start &&
                            payoutForm.dateRange?.end
                              ? "border-red-500 focus:ring-red-500"
                              : ""
                          }`}
                          min="2020-01-01"
                          max="2030-12-31"
                          required
                          onClick={(e) => e.currentTarget.showPicker()}
                        />
                        <div
                          className="absolute inset-0 cursor-pointer"
                          onClick={(e) => {
                            const input = e.currentTarget
                              .previousElementSibling as HTMLInputElement;
                            input.showPicker();
                          }}
                        />
                      </div>
                      {!payoutForm.dateRange?.start &&
                        payoutForm.dateRange?.end && (
                          <p className="text-xs text-red-500">
                            Start date is required
                          </p>
                        )}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="space-y-1">
                      <div className="relative">
                        <Input
                          id="date-range-end"
                          type="date"
                          placeholder="End Date"
                          value={payoutForm.dateRange?.end || ""}
                          onChange={(e) => {
                            const endDate = e.target.value;
                            setCommissionCalculation(null);
                            setPayoutForm((prev) => ({
                              ...prev,
                              dateRange: {
                                ...prev.dateRange,
                                end: endDate,
                              },
                            }));
                            handleEndDateChange(endDate);
                          }}
                          className={`cursor-pointer pr-10 ${
                            !payoutForm.dateRange?.end &&
                            payoutForm.dateRange?.start
                              ? "border-red-500 focus:ring-red-500"
                              : !payoutForm.dateRange?.start
                              ? "bg-gray-100 text-gray-400"
                              : ""
                          }`}
                          min={payoutForm.dateRange?.start || "2020-01-01"}
                          max="2030-12-31"
                          disabled={!payoutForm.dateRange?.start}
                          required
                          onClick={(e) => {
                            if (payoutForm.dateRange?.start) {
                              e.currentTarget.showPicker();
                            }
                          }}
                        />
                        <div
                          className={`absolute inset-0 ${
                            payoutForm.dateRange?.start
                              ? "cursor-pointer"
                              : "cursor-not-allowed"
                          }`}
                          onClick={(e) => {
                            if (payoutForm.dateRange?.start) {
                              const input = e.currentTarget
                                .previousElementSibling as HTMLInputElement;
                              input.showPicker();
                            }
                          }}
                        />
                      </div>
                      {!payoutForm.dateRange?.end &&
                        payoutForm.dateRange?.start && (
                          <p className="text-xs text-red-500">
                            End date is required
                          </p>
                        )}
                    </div>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Select date range to calculate commission amount automatically
                </p>
              </div>
            )}

            {/* Payout Date Field */}
            <div className="space-y-2">
              <Label htmlFor="payout-date">Payout Date *</Label>
              <div className="relative">
                <Input
                  id="payout-date"
                  type="date"
                  value={
                    payoutForm.payoutDate ||
                    new Date().toISOString().split("T")[0]
                  }
                  onChange={(e) =>
                    setPayoutForm({ ...payoutForm, payoutDate: e.target.value })
                  }
                  className="cursor-pointer pr-10"
                  min={
                    editingPayout
                      ? undefined
                      : new Date().toISOString().split("T")[0]
                  }
                  max="2030-12-31"
                  required
                  onClick={(e) => e.currentTarget.showPicker()}
                />
                <div
                  className="absolute inset-0 cursor-pointer"
                  onClick={(e) => {
                    const input = e.currentTarget
                      .previousElementSibling as HTMLInputElement;
                    input.showPicker();
                  }}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                {editingPayout
                  ? "Payout date"
                  : "Payout date cannot be in the past"}
              </p>
            </div>

            {/* Amount Field */}
            {/* Amount Field */}
            <div className="space-y-2">
              <Label htmlFor="amount">Amount *</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                placeholder="0.00"
                value={
                  commissionCalculation?.pending_summary
                    .minimum_amount_required_message
                    ? commissionCalculation.pending_summary.total_pending_amount // Show the calculated amount (53.90)
                    : payoutForm.amount
                }
                onChange={(e) =>
                  setPayoutForm({ ...payoutForm, amount: e.target.value })
                }
                disabled={
                  !!commissionCalculation?.pending_summary
                    .minimum_amount_required_message
                }
                required
                className={
                  commissionCalculation?.pending_summary
                    .minimum_amount_required_message
                    ? "bg-gray-100 cursor-not-allowed"
                    : ""
                }
              />

              {/* Show minimum amount requirement message */}
              {commissionCalculation?.pending_summary
                .minimum_amount_required_message && (
                <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-md">
                  <div className="flex-shrink-0">
                    <Clock className="h-4 w-4 text-amber-600" />
                  </div>
                  <p className="text-xs text-amber-800">
                    {
                      commissionCalculation.pending_summary
                        .minimum_amount_required_message
                    }
                  </p>
                </div>
              )}

              {/* Regular info message */}
              {!commissionCalculation?.pending_summary
                .minimum_amount_required_message && (
                <p className="text-xs text-muted-foreground">
                  {!editingPayout &&
                  payoutForm.dateRange?.start &&
                  payoutForm.dateRange?.end
                    ? "Amount calculated based on selected date range"
                    : !editingPayout
                    ? "Amount will be auto-filled when you calculate commission for a date range"
                    : "Enter the payout amount"}
                </p>
              )}
            </div>

            {/* Rest of the fields remain the same */}
            <div className="space-y-2">
              <Label htmlFor="method">Payment Method</Label>
              <Select
                value={payoutForm.method}
                onValueChange={(value) =>
                  setPayoutForm({ ...payoutForm, method: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                  <SelectItem value="Cash">Cash</SelectItem>
                  <SelectItem value="Check">Check</SelectItem>
                  <SelectItem value="Digital Wallet">Digital Wallet</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="reference">Reference Number</Label>
              <Input
                id="reference"
                placeholder="TRF-001"
                value={payoutForm.reference_no}
                onChange={(e) =>
                  setPayoutForm({ ...payoutForm, reference_no: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional notes about this payout..."
                value={payoutForm.notes}
                onChange={(e) =>
                  setPayoutForm({ ...payoutForm, notes: e.target.value })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setIsPayoutDialogOpen(false);
                setIsEditPayoutDialogOpen(false);
                setEditingPayout(null);
                setCommissionCalculation(null);
              }}
            >
              Cancel
            </Button>
            <Button
              onClick={editingPayout ? handleUpdatePayout : handleSavePayout}
              disabled={
                !payoutForm.amount ||
                !payoutForm.payoutDate ||
                isSavingStaff ||
                !!commissionCalculation?.pending_summary
                  .minimum_amount_required_message ||
                // Add date range validation for new payouts
                (!editingPayout &&
                  (!payoutForm.dateRange?.start || !payoutForm.dateRange?.end))
              }
            >
              {isSavingStaff && (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              )}
              {commissionCalculation?.pending_summary
                .minimum_amount_required_message
                ? "Minimum Amount Not Met"
                : editingPayout
                ? "Update Payout"
                : "Save Payout"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Staff Dialog */}
      <Dialog open={isStaffDialogOpen} onOpenChange={setIsStaffDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {isEditingStaff ? "Edit Staff Member" : "Add Staff Member"}
            </DialogTitle>
            <DialogDescription>
              {isEditingStaff
                ? "Update staff member information"
                : "Add a new staff member to this doctor's account"}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name *</Label>
              <Input
                id="name"
                placeholder="Enter full name"
                value={selectedStaff?.name || ""}
                onChange={(e) => handleStaffInputChange("name", e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter email address"
                value={selectedStaff?.email || ""}
                onChange={(e) =>
                  handleStaffInputChange("email", e.target.value)
                }
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number *</Label>
              <Input
                id="phone"
                placeholder="+971 50 123 4567"
                value={selectedStaff?.phone_number || ""}
                onChange={(e) =>
                  handleStaffInputChange("phone_number", e.target.value)
                }
                required
              />
              <p className="text-xs text-muted-foreground">
                Must start with +971 (UAE country code)
              </p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Select
                  value={selectedStaff?.gender || ""}
                  onValueChange={(value) =>
                    handleStaffInputChange("gender", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="male">Male</SelectItem>
                    <SelectItem value="female">Female</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">Status *</Label>
                <Select
                  value={selectedStaff?.status || ""}
                  onValueChange={(value) =>
                    handleStaffInputChange("status", value)
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsStaffDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={handleSaveStaff} disabled={isSavingStaff}>
              {isSavingStaff && (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              )}
              {isEditingStaff ? "Update Staff" : "Add Staff"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Doctor Modal */}
      <EditDoctorModal
        isOpen={!!editingDoctor}
        onClose={() => setEditingDoctor(null)}
        doctor={editingDoctor}
        onDoctorUpdated={handleDoctorUpdated}
      />
      {selectedOrder && (
        <PatientOrderDetailsModal
          order={selectedOrder}
          isOpen={isOrderModalOpen}
          onClose={() => {
            setIsOrderModalOpen(false);
            setSelectedOrder(null);
          }}
        />
      )}
      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        onClose={handleCancelDelete}
        onConfirm={handleConfirmDelete}
        title={confirmation.title}
        description={confirmation.description}
        confirmText="Delete"
        cancelText="Cancel"
        variant="destructive"
      />
    </div>
  );
}
