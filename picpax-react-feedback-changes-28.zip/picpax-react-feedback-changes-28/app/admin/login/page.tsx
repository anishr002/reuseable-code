"use client";

import type React from "react";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Eye, EyeOff, AlertCircle, CheckCircle } from "lucide-react";
import { useAuth } from "@/lib/auth-context";

export default function AdminLoginPage() {
  const router = useRouter();
  const { login } = useAuth();

  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  });

  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  // Email validation
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      setEmailError("Email is required");
      return false;
    } else if (!emailRegex.test(email)) {
      setEmailError("Please enter a valid email address");
      return false;
    } else {
      setEmailError("");
      return true;
    }
  };

  // Password validation
  const validatePassword = (password: string): boolean => {
    if (!password) {
      setPasswordError("Password is required");
      return false;
    } else if (password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      return false;
    } else {
      setPasswordError("");
      return true;
    }
  };

  const performLogin = async () => {
    // Reset errors
    setError("");
    setEmailError("");
    setPasswordError("");

    // Validate inputs
    const isEmailValid = validateEmail(loginData.email);
    const isPasswordValid = validatePassword(loginData.password);

    if (!isEmailValid || !isPasswordValid) {
      return;
    }

    setIsLoading(true);

    try {
      const success = await login(loginData.email, loginData.password);

      if (!success) {
        setError("Invalid admin credentials. Please try again.");
      }
    } catch (err: any) {
      setError(
        err.response?.data?.message ||
          "An error occurred during login. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await performLogin();
  };

  const handleLoginInputChange = (field: string, value: string | boolean) => {
    setLoginData((prev) => ({ ...prev, [field]: value }));

    // Clear errors when user starts typing
    if (error) setError("");
    if (field === "email" && emailError) setEmailError("");
    if (field === "password" && passwordError) setPasswordError("");
  };

  const handleAutoLogin = async () => {
    const demoCredentials = {
      email: "admin@picpax.com",
      password: "admin123",
      rememberMe: false,
    };

    setLoginData(demoCredentials);
    setError("");
    setEmailError("");
    setPasswordError("");

    setTimeout(async () => {
      setIsLoading(true);
      setError("");

      try {
        const success = await login(
          demoCredentials.email,
          demoCredentials.password
        );
        if (!success) {
          setError("Auto-login failed. Please try again.");
        }
      } catch (err: any) {
        setError(
          err.response?.data?.message ||
            "An error occurred during auto-login. Please try again."
        );
      } finally {
        setIsLoading(false);
      }
    }, 100);
  };

  return (
    <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2">
      {/* Left side - Sticky */}
      <div className="hidden bg-muted lg:block lg:sticky lg:top-0 lg:h-screen">
        <div className="flex h-full items-center justify-center bg-gradient-to-br from-primary to-secondary p-10">
          <div className="text-center text-white space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold">PicPax Admin Portal</h1>
              <p className="text-lg text-white/90 max-w-md">
                Administrative control panel for managing doctors, orders, and
                system-wide operations.
              </p>
            </div>
            <div className="space-y-3 text-left max-w-sm mx-auto">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Manage doctor accounts and permissions
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Monitor all orders and commissions
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  System-wide analytics and reporting
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="flex items-center justify-center py-12 min-h-screen">
        <div className="mx-auto grid w-[350px] gap-6">
          {/* Logo */}
          <div className="text-center mb-6">
            <div className="flex justify-center">
              <img
                src="/images/logo.png"
                alt="PicPax"
                className="h-10 sm:h-12 w-auto object-contain"
              />
            </div>
          </div>

          {/* Login Form */}
          <div>
            <div className="grid gap-2 text-center mb-6">
              <h2 className="text-2xl font-bold">Admin Login</h2>
              <p className="text-balance text-muted-foreground">
                Enter your admin credentials to access the portal
              </p>
            </div>
            <form onSubmit={handleLoginSubmit} className="grid gap-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@picpax.com"
                  value={loginData.email}
                  onChange={(e) =>
                    handleLoginInputChange("email", e.target.value)
                  }
                  onBlur={() => validateEmail(loginData.email)}
                  required
                  className={emailError ? "border-destructive" : ""}
                />
                {emailError && (
                  <p className="text-destructive text-xs">{emailError}</p>
                )}
              </div>
              <div className="grid gap-2">
                <div className="flex items-center">
                  <Label htmlFor="password">Password</Label>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={loginData.password}
                    onChange={(e) =>
                      handleLoginInputChange("password", e.target.value)
                    }
                    onBlur={() => validatePassword(loginData.password)}
                    required
                    className={passwordError ? "border-destructive" : ""}
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                {passwordError && (
                  <p className="text-destructive text-xs">{passwordError}</p>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="remember"
                  checked={loginData.rememberMe}
                  onCheckedChange={(checked) =>
                    handleLoginInputChange("rememberMe", checked as boolean)
                  }
                />
                <Label htmlFor="remember" className="text-sm font-normal">
                  Remember me
                </Label>
              </div>
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Signing in..." : "Admin Login"}
              </Button>
            </form>
            <div className="mt-4 text-center text-sm">
              <a href="/login" className="text-blue-600 hover:underline">
                Back to Doctor Login
              </a>
            </div>
            <div className="mt-6 rounded-lg border bg-muted/50 p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold">Admin Demo Access</h3>
                <Button
                  variant="default"
                  size="sm"
                  onClick={handleAutoLogin}
                  disabled={isLoading}
                  className="text-xs h-7 px-3 bg-primary hover:bg-primary/90"
                >
                  {isLoading ? "Logging in..." : "Quick Login"}
                </Button>
              </div>
              <div className="text-sm space-y-1">
                <p>
                  <strong>Email:</strong> admin@picpax.com
                </p>
                <p>
                  <strong>Password:</strong> admin123
                </p>
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Click "Quick Login" to automatically sign in with admin
                credentials
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
