"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/lib/auth-context";
import AuthLoading from "@/components/auth-loading";

export default function AdminPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading) {
      if (!user) {
        // If no user, redirect to admin login
        router.push("/admin/login");
      } else if (
        user.role === "admin" ||
        user.role === "super admin" ||
        user.type === "system"
      ) {
        // If admin, redirect to admin dashboard
        router.push("/admin/dashboard");
      } else {
        // If not admin, redirect to doctor dashboard
        router.push("/dashboard");
      }
    }
  }, [user, isLoading, router]);

  return <AuthLoading />;
}
