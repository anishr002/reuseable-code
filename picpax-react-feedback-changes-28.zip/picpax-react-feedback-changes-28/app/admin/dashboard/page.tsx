"use client";

import { useEffect, useState, useRef } from "react";
import { useAuth } from "@/lib/auth-context";
import { WelcomeBanner } from "@/components/welcome-banner";
import {
  RevenueChart,
  OrdersDistributionChart,
  DoctorActivityChart,
  CommissionTrendChart,
} from "@/components/admin/dashboard-charts";
import { getDashboardData, DashboardResponse } from "@/lib/dashboardService";
import { DirhamIcon } from "@/components/ui/DirhamIcon";
import { AddDoctorModal } from "@/components/admin/add-doctor-modal";
import { useToast } from "@/hooks/use-toast";
import { useRouter } from "next/navigation";
import { convertToDubaiTime } from "@/components/convertToDubaiTime";
import { DateRangeFilter } from "@/components/admin/DateRangeFilter";
import { DoctorFilter } from "@/components/admin/DoctorFilter";
import { getDoctors, type Doctor } from "@/lib/orderService";

// Import UI components
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, TrendingUp, UserCog, FileText, Settings } from "lucide-react";

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

// Skeleton Loader Components
const StatCardSkeleton = () => (
  <Card className="animate-pulse">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <div className="h-4 w-24 bg-gray-200 rounded"></div>
      <div className="h-4 w-4 bg-gray-200 rounded"></div>
    </CardHeader>
    <CardContent>
      <div className="h-8 w-16 bg-gray-200 rounded mb-2"></div>
      <div className="h-3 w-20 bg-gray-200 rounded"></div>
    </CardContent>
  </Card>
);

const ChartSkeleton = () => (
  <Card className="animate-pulse">
    <CardHeader>
      <div className="h-6 w-32 bg-gray-200 rounded mb-2"></div>
      <div className="h-4 w-48 bg-gray-200 rounded"></div>
    </CardHeader>
    <CardContent>
      <div className="h-64 bg-gray-200 rounded"></div>
    </CardContent>
  </Card>
);

const RecentOrdersSkeleton = () => (
  <Card className="animate-pulse">
    <CardHeader>
      <div className="h-6 w-32 bg-gray-200 rounded mb-2"></div>
      <div className="h-4 w-48 bg-gray-200 rounded"></div>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        {[...Array(5)].map((_, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-4 border rounded-lg"
          >
            <div className="flex-1 space-y-2">
              <div className="h-5 w-32 bg-gray-200 rounded"></div>
              <div className="h-4 w-24 bg-gray-200 rounded"></div>
              <div className="h-3 w-40 bg-gray-200 rounded"></div>
            </div>
            <div className="text-right space-y-2">
              <div className="h-5 w-16 bg-gray-200 rounded ml-auto"></div>
              <div className="h-6 w-20 bg-gray-200 rounded"></div>
            </div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const QuickActionsSkeleton = () => (
  <Card className="animate-pulse">
    <CardHeader>
      <div className="h-6 w-32 bg-gray-200 rounded mb-2"></div>
      <div className="h-4 w-48 bg-gray-200 rounded"></div>
    </CardHeader>
    <CardContent>
      <div className="grid gap-4 md:grid-cols-3">
        {[...Array(3)].map((_, index) => (
          <div
            key={index}
            className="flex flex-col items-center p-4 border rounded-lg"
          >
            <div className="h-8 w-8 bg-gray-200 rounded mb-2"></div>
            <div className="h-4 w-20 bg-gray-200 rounded mb-1"></div>
            <div className="h-3 w-24 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const WelcomeBannerSkeleton = () => (
  <div className="animate-pulse bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
    <div className="flex items-center justify-between">
      <div className="space-y-3">
        <div className="h-7 w-64 bg-gray-200 rounded"></div>
        <div className="h-4 w-96 bg-gray-200 rounded"></div>
      </div>
      <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
    </div>
  </div>
);

const HeaderSkeleton = () => (
  <div className="animate-pulse space-y-2">
    <div className="h-8 w-64 bg-gray-200 rounded"></div>
    <div className="h-4 w-96 bg-gray-200 rounded"></div>
  </div>
);

// Content Skeleton (for filter loading)
const DashboardContentSkeleton = () => (
  <div className="space-y-6">
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {[...Array(8)].map((_, index) => (
        <StatCardSkeleton key={index} />
      ))}
    </div>
    <div className="grid gap-6 md:grid-cols-2">
      <ChartSkeleton />
      <ChartSkeleton />
    </div>
    <div className="grid gap-6 md:grid-cols-2">
      <ChartSkeleton />
      <ChartSkeleton />
    </div>
    <RecentOrdersSkeleton />
    <QuickActionsSkeleton />
  </div>
);

// Main Dashboard Skeleton (for initial load)
const DashboardSkeleton = () => (
  <div className="space-y-6">
    <WelcomeBannerSkeleton />
    <HeaderSkeleton />
    <DashboardContentSkeleton />
  </div>
);

export default function AdminDashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  const [dashboardData, setDashboardData] = useState<
    DashboardResponse["data"] | null
  >(null);
  const [loading, setLoading] = useState(true);
  const [filterLoading, setFilterLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAddDoctorModalOpen, setIsAddDoctorModalOpen] = useState(false);
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date } | null>(
    null
  );
  const [selectedDoctor, setSelectedDoctor] = useState("all");
  const [doctors, setDoctors] = useState<Doctor[]>([]);

  const initialLoadRef = useRef(false);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }
    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          console.log("User permissions loaded:", user.permission);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Load doctors for the filter
  const loadDoctors = async () => {
    try {
      const response = await getDoctors();
      setDoctors(response.data.doctors);
    } catch (error) {
      console.error("Failed to load doctors:", error);
    }
  };

  const fetchDashboardData = async (
    range?: { from: Date; to: Date } | null,
    doctorId?: string
  ) => {
    try {
      // Determine if this is initial load or filter load
      const isInitialLoad = !dashboardData && !range && doctorId === "all";

      if (isInitialLoad) {
        setLoading(true);
      } else {
        setFilterLoading(true);
      }

      // Build query parameters
      const params: any = {};
      if (range?.from && range?.to) {
        params.start_date = range.from.toISOString().split("T")[0];
        params.end_date = range.to.toISOString().split("T")[0];
      }
      if (doctorId && doctorId !== "all") {
        params.doctor_id = doctorId;
      }

      console.log("Fetching dashboard data with params:", params);
      const response = await getDashboardData(params);
      setDashboardData(response.data);
      setError(null);
    } catch (err) {
      setError("Failed to load dashboard data");
      console.error("Error fetching dashboard data:", err);
    } finally {
      setLoading(false);
      setFilterLoading(false);
    }
  };

  const handleDoctorAdded = () => {
    setIsAddDoctorModalOpen(false);
    fetchDashboardData(dateRange, selectedDoctor);
    loadDoctors(); // Reload doctors list after adding a new one
  };

  const handleDateRangeChange = (range: { from: Date; to: Date } | null) => {
    setDateRange(range);
    fetchDashboardData(range, selectedDoctor);
  };

  const handleDoctorChange = (doctorId: string) => {
    setSelectedDoctor(doctorId);
    fetchDashboardData(dateRange, doctorId);
  };

  const handleAddDoctorClick = () => {
    if (!hasPermission("doctor_write")) {
      toast({
        variant: "destructive",
        title: "Access Denied",
        description: "You don't have permission to add doctors.",
      });
      return;
    }
    setIsAddDoctorModalOpen(true);
  };

  // FIX: Proper useEffect with useRef
  useEffect(() => {
    if (user && !initialLoadRef.current) {
      initialLoadRef.current = true;
      fetchDashboardData();
      loadDoctors();
    }
  }, [user]);

  if (!user) return null;

  // Show skeleton loader while loading for initial load
  if (loading && !dashboardData) {
    return <DashboardSkeleton />;
  }

  if (error) {
    return (
      <div className="space-y-6">
        <WelcomeBanner />
        <div className="flex items-center justify-center h-64">
          <div className="text-lg text-red-500">{error}</div>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="space-y-6">
        <WelcomeBanner />
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">No dashboard data available</div>
        </div>
      </div>
    );
  }

  const { stats, recent_orders, summary, charts } = dashboardData;

  return (
    <div className="space-y-6">
      <WelcomeBanner />

      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {user.name}. Here's your system overview.
            {summary &&
              ` Last updated: ${convertToDubaiTime(summary.last_updated)}`}
          </p>
        </div>
      </div>

      {/* Filters Section - Always visible */}
      <div className="flex justify-end">
        <div className="flex flex-col sm:flex-row sm:items-center items-end gap-4 w-full sm:w-auto sm:justify-end">
          <div className="flex-1 sm:flex-none w-full sm:w-[260px]">
            <DateRangeFilter
              onDateRangeChange={handleDateRangeChange}
              selectedRange={dateRange}
            />
          </div>
          <div className="flex-1 sm:flex-none w-full sm:w-[260px]">
            <DoctorFilter
              onDoctorChange={handleDoctorChange}
              selectedDoctor={selectedDoctor}
            />
          </div>
        </div>
      </div>

      {/* Dashboard Content with Filter Loading State */}
      {filterLoading ? (
        <DashboardContentSkeleton />
      ) : (
        <>
          {/* Admin Stats Cards - 4x2 Grid */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {/* Row 1 */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Doctors
                </CardTitle>
                <UserCog className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {stats.total_doctors.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.total_doctors.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Patients
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-secondary">
                  {stats.total_patients.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.total_patients.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Orders
                </CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {stats.total_orders.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.total_orders.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Revenue
                </CardTitle>
                <DirhamIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  <DirhamIcon /> {stats.total_revenue.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.total_revenue.subtitle}
                </p>
              </CardContent>
            </Card>

            {/* Row 2 */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Commission
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  <DirhamIcon /> {stats.total_commission.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.total_commission.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Monthly Commission
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  <DirhamIcon /> {stats.monthly_commission.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.monthly_commission.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Pending Payouts
                </CardTitle>
                <DirhamIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-600">
                  <DirhamIcon /> {stats.pending_payouts.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.pending_payouts.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Avg. Order Value
                </CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  <DirhamIcon /> {stats.avg_order_value.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.avg_order_value.subtitle}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Charts Section */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Financial Overview</CardTitle>
                <CardDescription>
                  Revenue and commission trends over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <RevenueChart revenueData={charts?.revenue_data} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Orders Status</CardTitle>
                <CardDescription>
                  Current order status distribution
                </CardDescription>
              </CardHeader>
              <CardContent>
                <OrdersDistributionChart ordersData={charts?.orders_data} />
              </CardContent>
            </Card>
          </div>

          {/* Bottom Charts Row */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Top Performers</CardTitle>
                <CardDescription>
                  Doctor activity and revenue comparison
                </CardDescription>
              </CardHeader>
              <CardContent>
                <DoctorActivityChart
                  doctorActivityData={charts?.doctor_activity_data}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Commission Analytics</CardTitle>
                <CardDescription>
                  Monthly commission earnings trend
                </CardDescription>
              </CardHeader>
              <CardContent>
                <CommissionTrendChart revenueData={charts?.revenue_data} />
              </CardContent>
            </Card>
          </div>

          {/* Recent Orders */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Orders</CardTitle>
              <CardDescription>
                Latest orders across all doctors
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recent_orders.map((order) => (
                  <div
                    key={order.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex-1">
                      <div className="font-medium">{order.doctor_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {order.patient_name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {order.order_id} • {convertToDubaiTime(order.date)}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">
                        <DirhamIcon /> {order.amount}
                      </div>
                      <Badge
                        variant={
                          order.status === "completed"
                            ? "default"
                            : order.status === "open"
                            ? "outline"
                            : "secondary"
                        }
                        className="text-xs"
                      >
                        {order.status.charAt(0).toUpperCase() +
                          order.status.slice(1)}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Common administrative tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                {hasPermission("doctor_write") && (
                  <div
                    className="flex flex-col items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                    onClick={handleAddDoctorClick}
                  >
                    <UserCog className="h-8 w-8 text-blue-600 mb-2" />
                    <div className="text-sm font-medium">Add Doctor</div>
                    <div className="text-xs text-muted-foreground">
                      Register new doctor
                    </div>
                  </div>
                )}

                <div
                  className="flex flex-col items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                  onClick={() => router.push("/admin/commission")}
                >
                  <Users className="h-8 w-8 text-green-600 mb-2" />
                  <div className="text-sm font-medium">View Reports</div>
                  <div className="text-xs text-muted-foreground">
                    Analytics dashboard
                  </div>
                </div>
                <div
                  className="flex flex-col items-center p-4 border rounded-lg hover:bg-gray-50 cursor-pointer"
                  onClick={() => router.push("/admin/settings")}
                >
                  <Settings className="h-8 w-8 text-gray-600 mb-2" />
                  <div className="text-sm font-medium">Settings</div>
                  <div className="text-xs text-muted-foreground">
                    System configuration
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* Add Doctor Modal - Only render if user has permission */}
      {hasPermission("doctor_write") && (
        <AddDoctorModal
          isOpen={isAddDoctorModalOpen}
          onClose={() => setIsAddDoctorModalOpen(false)}
          onDoctorAdded={handleDoctorAdded}
          isDashboard={true}
        />
      )}
    </div>
  );
}
