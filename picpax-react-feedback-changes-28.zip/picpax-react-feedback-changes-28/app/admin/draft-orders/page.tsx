"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, FileText, List, ArrowLeft, Clock, Loader2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { DataTable } from "@/components/orders/data-table";
import { columns, type Order } from "@/components/orders/columns";
import { OrderDetailsModal } from "@/components/orders/order-details-modal";
import { useRouter } from "next/navigation";
import {
  deleteDraftOrder,
  getDraftOrders,
  type OrdersListResponse,
} from "@/lib/orderService";
import { DirhamIcon } from "@/components/ui/DirhamIcon";
import { createOrderFromDraft } from "@/lib/orderService";
import { useToast } from "@/hooks/use-toast";
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog";

// Types for API responses
interface ApiOrder {
  id: string;
  order_id: string;
  doctor: {
    id: string;
    full_name: string | null;
    email: string;
    clinic_name: string;
    commission: string;
  };
  patient: {
    id: string;
    full_name: string;
    email: string;
  } | null;
  status: string;
  order_date: string;
  products_count: number;
  products: string[];
  total_price?: string;
  total?: string;
  commission: string;
  created_at: string;
  updated_at: string;
}

interface PaginationInfo {
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
  from: number;
  to: number;
}

// Types for user permissions
interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

interface ConfirmationState {
  isOpen: boolean;
  title: string;
  description: string;
  order: Order | null;
  action: "delete" | "create" | null;
}

export default function DraftOrdersPage() {
  const router = useRouter();
  const { user } = useAuth();
  const { toast } = useToast();
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isOrderDetailsOpen, setIsOrderDetailsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [pagination, setPagination] = useState<PaginationInfo>({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 1,
    to: 0,
  });
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState<{
    sort_by: string;
    sort_order: string;
  }>({
    sort_by: "updated_at",
    sort_order: "desc",
  });

  // Permission state
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);
  const [total, setTotal] = useState<any>(null);

  // Confirmation state
  const [confirmation, setConfirmation] = useState<ConfirmationState>({
    isOpen: false,
    title: "",
    description: "",
    order: null,
    action: null,
  });

  // Use refs to track current state to avoid dependencies
  const paginationRef = useRef(pagination);
  const searchTermRef = useRef(searchTerm);
  const sortConfigRef = useRef(sortConfig);
  // refs for fetch guards
  const fetchInFlightRef = useRef(false);
  const lastFetchKeyRef = useRef<string | null>(null);
  const lastFetchFinishedAtRef = useRef<number | null>(null);
  const [isCreatingOrder, setIsCreatingOrder] = useState(false);
  const [isDeletingOrder, setIsDeletingOrder] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Update refs when state changes
  useEffect(() => {
    paginationRef.current = pagination;
    searchTermRef.current = searchTerm;
    sortConfigRef.current = sortConfig;
  }, [pagination, searchTerm, sortConfig]);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          console.log("User permissions loaded:", user.permission);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Handle logout and authentication state changes
  useEffect(() => {
    const handleStorageChange = () => {
      const userData = localStorage.getItem("picpax_user");
      if (!userData) {
        // User logged out, clear state and stop any pending requests
        setOrders([]);
        setIsLoading(false);
      }
    };

    window.addEventListener("storage", handleStorageChange);

    // Also check on mount if user exists
    const userData = localStorage.getItem("picpax_user");
    if (!userData) {
      setIsLoading(false);
    }

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  // Transform API order to local Order type
  const transformApiOrder = (apiOrder: ApiOrder): Order => {
    try {
      // Handle null patient
      const patientName = apiOrder.patient?.full_name || "N/A";
      const patientEmail = apiOrder.patient?.email || "N/A";
      const patientId = apiOrder.patient?.id || "N/A";

      const amount = parseFloat(apiOrder.total_price || apiOrder.total || "0");
      const commission = parseFloat(apiOrder.commission || "0");

      const transformed = {
        id: apiOrder.order_id,
        doctorName: apiOrder.doctor.full_name || apiOrder.doctor.email,
        doctorClinic: apiOrder.doctor.clinic_name,
        patientName: patientName,
        patientEmail: patientEmail,
        amount: amount,
        status: "draft" as any,
        date: apiOrder.order_date,
        products: apiOrder.products || [],
        products_count: apiOrder.products_count,
        commission: commission,
        doctorId: apiOrder.doctor.id,
        patientId: patientId,
        draft_id: apiOrder.id,
      };

      return transformed;
    } catch (error) {
      console.error("Error transforming order:", error, apiOrder);
      // Return a fallback order to prevent complete failure
      return {
        id: "error",
        doctorName: "Error",
        doctorClinic: "Error",
        patientName: "Error",
        patientEmail: "Error",
        amount: 0,
        status: "draft" as any,
        date: new Date().toISOString().split("T")[0],
        products: [],
        products_count: 0,
        commission: 0,
        doctorId: "error",
        patientId: "error",
      };
    }
  };

  // Fetch draft orders
  const fetchDraftOrders = useCallback(
    async (
      page: number = 1,
      search: string = "",
      sort_by: string = "updated_at",
      sort_order: string = "desc"
    ) => {
      const key = JSON.stringify({ page, search, sort_by, sort_order });
      const now = Date.now();

      if (
        lastFetchFinishedAtRef.current &&
        lastFetchKeyRef.current === key &&
        now - lastFetchFinishedAtRef.current < 300
      ) {
        return;
      }

      if (fetchInFlightRef.current && lastFetchKeyRef.current === key) {
        return;
      }

      fetchInFlightRef.current = true;
      lastFetchKeyRef.current = key;

      try {
        setIsLoading(true);
        const response = await getDraftOrders({
          page,
          per_page: paginationRef.current.per_page,
          search,
          sort_by,
          sort_order,
        });

        if (response.success) {
          const apiOrders: ApiOrder[] = response.data.draft_orders || [];
          const paginationData: PaginationInfo = response.data.pagination;

          const transformedOrders = apiOrders.map(transformApiOrder);
          console.log("Transformed Orders:", transformedOrders);

          setOrders(transformedOrders);
          setPagination(paginationData);
          setTotal(response?.data?.summary);
        } else {
          console.error("API returned success: false", response);
          setOrders([]);
          setPagination({
            current_page: 1,
            last_page: 1,
            per_page: 10,
            total: 0,
            from: 1,
            to: 0,
          });
        }
      } catch (error) {
        console.error("Error fetching draft orders:", error);
        setOrders([]);
        setTotal(null);
        setPagination({
          current_page: 1,
          last_page: 1,
          per_page: 10,
          total: 0,
          from: 1,
          to: 0,
        });
      } finally {
        setIsLoading(false);
        fetchInFlightRef.current = false;
        lastFetchFinishedAtRef.current = Date.now();
        lastFetchKeyRef.current = null;
      }
    },
    []
  );

  // Handle create order with confirmation
  const handleCreateOrder = useCallback((order: Order) => {
    setConfirmation({
      isOpen: true,
      title: "Create Order from Draft",
      description: `Are you sure you want to create an order from draft ${order.id}? This will move it from drafts to active orders.`,
      order: order,
      action: "create",
    });
  }, []);

  // Handle delete draft order with confirmation
  const handleDeleteDraftOrder = useCallback((order: Order) => {
    setConfirmation({
      isOpen: true,
      title: "Delete Draft Order",
      description: `Are you sure you want to delete draft order ${order.id}? This action cannot be undone.`,
      order: order,
      action: "delete",
    });
  }, []);

  // Handle confirmation actions
  const handleConfirmAction = async () => {
    if (!confirmation.order || !confirmation.action) return;

    try {
      if (confirmation.action === "delete") {
        await handleConfirmDelete(confirmation.order);
      } else if (confirmation.action === "create") {
        await handleConfirmCreate(confirmation.order);
      }
    } catch (error) {
      console.error("Error in confirmation action:", error);
    } finally {
      // Close confirmation dialog
      setConfirmation({
        isOpen: false,
        title: "",
        description: "",
        order: null,
        action: null,
      });
    }
  };

  // Actual delete implementation
  const handleConfirmDelete = async (order: Order) => {
    if (!order.draft_id) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Cannot delete draft: missing draft ID",
      });
      return;
    }

    setIsDeletingOrder(true);
    try {
      const response = await deleteDraftOrder(order.draft_id);

      toast({
        title: "Success",
        description: response.message || "Draft order deleted successfully",
      });

      // Refresh the draft orders list after successful deletion
      setTimeout(() => {
        fetchDraftOrders(
          paginationRef.current.current_page,
          searchTermRef.current,
          sortConfigRef.current.sort_by,
          sortConfigRef.current.sort_order
        );
      }, 500);
    } catch (error: any) {
      console.error("Error deleting draft order:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message || "Failed to delete draft order",
      });
    } finally {
      setIsDeletingOrder(false);
    }
  };

  // Actual create implementation
  const handleConfirmCreate = async (order: Order) => {
    setIsCreatingOrder(true);
    setSuccessMessage(null);

    try {
      const payload = {
        draft_order_id: order.draft_id || order.id,
      };

      const response = await createOrderFromDraft(payload);

      toast({
        title: "Success",
        description: response.message || "Order created successfully",
      });

      setSuccessMessage(response.message || "Order created successfully");

      // Refresh the draft orders list after successful creation
      setTimeout(() => {
        fetchDraftOrders(
          paginationRef.current.current_page,
          searchTermRef.current,
          sortConfigRef.current.sort_by,
          sortConfigRef.current.sort_order
        );
      }, 1000);
    } catch (error: any) {
      console.error("Error creating order from draft:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description:
          error.response?.data?.message || "Failed to create order from draft",
      });
    } finally {
      setIsCreatingOrder(false);
    }
  };

  const handleCancelAction = () => {
    setConfirmation({
      isOpen: false,
      title: "",
      description: "",
      order: null,
      action: null,
    });
    setIsDeletingOrder(false);
    setIsCreatingOrder(false);
  };

  // Determine loading state and button text based on action
  const getConfirmationButtonState = () => {
    if (confirmation.action === "delete") {
      return {
        isLoading: isDeletingOrder,
        confirmText: "Delete",
        variant: "destructive" as const,
      };
    } else if (confirmation.action === "create") {
      return {
        isLoading: isCreatingOrder,
        confirmText: "Create Order",
        variant: "default" as const,
      };
    }
    return {
      isLoading: false,
      confirmText: "Confirm",
      variant: "default" as const,
    };
  };

  const {
    isLoading: isConfirmLoading,
    confirmText,
    variant,
  } = getConfirmationButtonState();

  // Handle search - properly memoized
  const handleSearch = useCallback(
    (search: string) => {
      setSearchTerm(search);
      fetchDraftOrders(
        1,
        search,
        sortConfigRef.current.sort_by,
        sortConfigRef.current.sort_order
      );
    },
    [fetchDraftOrders]
  );

  // Handle pagination - properly memoized
  const handlePaginationChange = useCallback(
    (page: number) => {
      fetchDraftOrders(
        page,
        searchTermRef.current,
        sortConfigRef.current.sort_by,
        sortConfigRef.current.sort_order
      );
    },
    [fetchDraftOrders]
  );

  const handlePageSizeChange = useCallback(
    (pageSize: number) => {
      setPagination((p) => ({ ...p, per_page: pageSize, current_page: 1 }));
      paginationRef.current = {
        ...paginationRef.current,
        per_page: pageSize,
        current_page: 1,
      };
      fetchDraftOrders(
        1,
        searchTermRef.current,
        sortConfigRef.current.sort_by,
        sortConfigRef.current.sort_order
      );
    },
    [fetchDraftOrders]
  );

  // Handle sort - properly memoized
  const handleSort = useCallback(
    (sort_by: string, sort_order: string) => {
      if (
        sortConfigRef.current.sort_by === sort_by &&
        sortConfigRef.current.sort_order === sort_order
      ) {
        setSortConfig({ sort_by, sort_order });
        return;
      }

      setSortConfig({ sort_by, sort_order });
      fetchDraftOrders(1, searchTermRef.current, sort_by, sort_order);
    },
    [fetchDraftOrders]
  );

  // Initial fetch - only run once when permissions are loaded
  useEffect(() => {
    if (permissionsLoaded) {
      fetchDraftOrders();
    }
  }, [fetchDraftOrders, permissionsLoaded]);

  const handleViewOrderDetails = useCallback((order: Order) => {
    setSelectedOrder(order);
    setIsOrderDetailsOpen(true);
  }, []);

  // Calculate stats based on current draft orders
  const totalAmount = orders.reduce((sum, order) => sum + order.amount, 0);
  const totalCommission = orders.reduce(
    (sum, order) => sum + order.commission,
    0
  );

  if (!user) return null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Draft Orders</h1>
          <p className="text-muted-foreground">View and manage draft orders</p>
        </div>
        {hasPermission("draftOrder_write") && (
          <div className="flex items-center space-x-2">
            <Button onClick={() => router.push("/admin/orders/create")}>
              <Plus className="h-4 w-4 mr-2" />
              Create Order
            </Button>
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Drafts</CardTitle>
            <List className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {total?.total_draft_orders || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Showing {pagination.from}-{pagination.to} of {pagination.total}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600 flex items-center">
              <DirhamIcon className="mr-2" />
              <span>{total?.total_amount || 0}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              From all draft orders
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Commission
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600 flex items-center">
              <DirhamIcon className="mr-2" />
              <span>{total?.total_commission || 0}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              {total?.total_amount > 0
                ? Math.round(
                    (total?.total_commission / total?.total_amount) * 100
                  )
                : 0}
              % of amount
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Draft Orders Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Draft Orders</CardTitle>
          <CardDescription>
            View and manage draft orders. Click on any draft to view detailed
            information.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DataTable
            columns={columns}
            data={orders}
            onViewOrderDetails={handleViewOrderDetails}
            onCreateOrder={handleCreateOrder}
            onDeleteDraftOrder={handleDeleteDraftOrder}
            onSearch={handleSearch}
            search={searchTerm}
            onPaginationChange={handlePaginationChange}
            onPageSizeChange={handlePageSizeChange}
            onSort={handleSort}
            pagination={pagination}
            isLoading={isLoading}
            canExport={hasPermission("draftOrder_export")}
            canViewDetails={hasPermission("draftOrder_read")}
            canCreateOrder={hasPermission("draftOrder_write")}
            canDeleteDraft={hasPermission("draftOrder_delete")}
            entity="draft-orders"
          />
        </CardContent>
      </Card>

      {/* Order Details Modal */}
      <OrderDetailsModal
        order={selectedOrder}
        isOpen={isOrderDetailsOpen}
        onClose={() => setIsOrderDetailsOpen(false)}
        orderType="draft"
      />

      {/* Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        onClose={handleCancelAction}
        onConfirm={handleConfirmAction}
        title={confirmation.title}
        description={confirmation.description}
        confirmText={confirmText}
        cancelText="Cancel"
        variant={variant}
        isLoading={isConfirmLoading}
      />
    </div>
  );
}
