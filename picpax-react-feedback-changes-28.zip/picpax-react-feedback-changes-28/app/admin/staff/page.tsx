"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StaffFormDialog } from "@/components/staff/staff-form-dialog";
import { RoleFormDialog } from "@/components/staff/role-form-dialog";
import { ConfirmationDialog } from "@/components/ui/confirmation-dialog";
import {
  StaffMember,
  Role,
  RoleFilters,
  StaffFilters,
} from "@/lib/staff-types";
import { staffService } from "@/lib/staff-service";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  Shield,
  Search,
  Plus,
  MoreHorizontal,
  Edit,
  Trash2,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ArrowUp,
  ArrowDown,
  FileText,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { debounce } from "lodash";

// Confirmation type
type ConfirmationType = "staff" | "role";

interface ConfirmationState {
  isOpen: boolean;
  type: ConfirmationType | null;
  item: StaffMember | Role | null;
  title: string;
  description: string;
}

interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

export default function AdminStaffPage() {
  const { toast } = useToast();
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRoleDialogOpen, setIsRoleDialogOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [isEditingRole, setIsEditingRole] = useState(false);
  const [isStaffDialogOpen, setIsStaffDialogOpen] = useState(false);
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [isEditingStaff, setIsEditingStaff] = useState(false);
  const [activeTab, setActiveTab] = useState("staff");
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [hasError, setHasError] = useState(false);
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);

  // Confirmation dialog state
  const [confirmation, setConfirmation] = useState<ConfirmationState>({
    isOpen: false,
    type: null,
    item: null,
    title: "",
    description: "",
  });

  // Staff pagination and filters
  const [staffPagination, setStaffPagination] = useState({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
  });
  const [staffFilters, setStaffFilters] = useState<StaffFilters>({
    name: "",
    email: "",
    department: "",
    role: "",
    sort_by: "name",
    sort_order: "asc",
    per_page: 10,
    page: 1,
  });

  // Roles pagination and filters
  const [rolesPagination, setRolesPagination] = useState({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 0,
    to: 0,
  });
  const [rolesFilters, setRolesFilters] = useState<RoleFilters>({
    name: "",
    permission: "",
    sort_by: "name",
    sort_order: "asc",
    per_page: 10,
    page: 1,
  });

  // Load user permissions from localStorage and listen for changes
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
      }
    };

    loadUserPermissions();

    const handleStorage = (event: StorageEvent) => {
      if (event.key === "picpax_user") {
        loadUserPermissions();
      }
    };
    const handlePermissionsChanged = () => {
      loadUserPermissions();
    };
    window.addEventListener("storage", handleStorage);
    window.addEventListener("permissionsChanged", handlePermissionsChanged);

    return () => {
      window.removeEventListener("storage", handleStorage);
      window.removeEventListener(
        "permissionsChanged",
        handlePermissionsChanged
      );
    };
  }, []);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    return userPermissions?.permission?.includes(permission) || false;
  };

  // Determine which tabs to show based on string permissions
  const showStaffTab = hasPermission("staff_read");
  const showRolesTab = hasPermission("role_read");

  // Set default active tab based on permissions
  useEffect(() => {
    if (!showStaffTab && showRolesTab) {
      setActiveTab("roles");
    } else if (showStaffTab) {
      setActiveTab("staff");
    }
  }, [showStaffTab, showRolesTab]);

  // Custom debounce hook
  const useDebounce = (callback: Function, delay: number) => {
    const timeoutRef = useRef<NodeJS.Timeout>();

    return useCallback(
      (...args: any[]) => {
        if (timeoutRef.current) {
          clearTimeout(timeoutRef.current);
        }

        timeoutRef.current = setTimeout(() => {
          callback(...args);
        }, delay);
      },
      [callback, delay]
    );
  };

  // Then use it like this:
  const debouncedStaffSearch = useDebounce((filters: StaffFilters) => {
    loadStaff(filters);
  }, 500);

  const debouncedRolesSearch = useDebounce((filters: RoleFilters) => {
    loadRoles(filters);
  }, 500);

  // Load data when component mounts - only load data based on permissions
  useEffect(() => {
    setIsLoading(true);

    if (showStaffTab) {
      loadStaff(staffFilters);
    } else if (showRolesTab) {
      loadRoles(rolesFilters);
    } else {
      setIsLoading(false);
    }
  }, [showStaffTab, showRolesTab]);

  // Load data when tab changes - only load data for the active tab
  useEffect(() => {
    if (activeTab === "staff" && showStaffTab) {
      loadStaff(staffFilters);
    } else if (activeTab === "roles" && showRolesTab) {
      loadRoles(rolesFilters);
    }
  }, [activeTab]);

  const loadStaff = async (filters?: StaffFilters) => {
    if (!hasPermission("staff_read")) return;

    setIsLoading(true);
    setHasError(false);
    try {
      const filtersToUse = filters || staffFilters;
      const response = await staffService.getStaffMembers(filtersToUse);
      setStaffMembers(response.staff);
      setStaffPagination(response.pagination);
      if (filters) {
        setStaffFilters(filters);
      }
    } catch (error) {
      setHasError(true);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load staff data",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const loadRoles = async (filters?: RoleFilters) => {
    if (!hasPermission("role_read")) return;

    setIsLoading(true);
    setHasError(false);
    try {
      const filtersToUse = filters || rolesFilters;
      const response = await staffService.getRolesWithFilters(filtersToUse);
      setRoles(response.roles);
      setRolesPagination(response.pagination);
      if (filters) {
        setRolesFilters(filters);
      }
    } catch (error) {
      setHasError(true);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load roles data",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateStaff = () => {
    setSelectedStaff(null);
    setIsEditingStaff(false);
    setIsStaffDialogOpen(true);
  };

  const handleEditStaff = (staff: StaffMember) => {
    setSelectedStaff(staff);
    setIsEditingStaff(true);
    setIsStaffDialogOpen(true);
  };

  // Staff deletion handlers
  const handleDeleteStaffClick = (staff: StaffMember) => {
    setConfirmation({
      isOpen: true,
      type: "staff",
      item: staff,
      title: "Delete Staff Member",
      description: `Are you sure you want to delete ${staff.name}? This action cannot be undone and all associated data will be permanently removed.`,
    });
  };

  const handleDeleteStaff = async () => {
    if (!confirmation.item || confirmation.type !== "staff") return;

    const staff = confirmation.item as StaffMember;

    try {
      setDeletingId(staff.id);
      await staffService.deleteStaffMember(staff.id);

      toast({
        title: "Success",
        description: `${staff.name} has been deleted successfully`,
      });

      // Close confirmation dialog
      setConfirmation({ ...confirmation, isOpen: false });

      // Reload the staff list
      await loadStaff(staffFilters);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete staff member",
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleSaveStaff = async () => {
    setIsStaffDialogOpen(false);
    await loadStaff(staffFilters);
  };

  const handleCreateRole = () => {
    setSelectedRole(null);
    setIsEditingRole(false);
    setIsRoleDialogOpen(true);
  };

  const handleEditRole = (role: Role) => {
    setSelectedRole(role);
    setIsEditingRole(true);
    setIsRoleDialogOpen(true);
  };

  // Role deletion handlers
  const handleDeleteRoleClick = (role: Role) => {
    setConfirmation({
      isOpen: true,
      type: "role",
      item: role,
      title: "Delete Role",
      description: `Are you sure you want to delete the role "${role.name}"? This action cannot be undone. Any staff members assigned to this role will need to be reassigned.`,
    });
  };

  const handleDeleteRole = async () => {
    if (!confirmation.item || confirmation.type !== "role") return;

    const role = confirmation.item as Role;

    try {
      setDeletingId(role.id);
      await staffService.deleteRole(role.id);

      toast({
        title: "Success",
        description: `Role "${role.name}" has been deleted successfully`,
      });

      // Close confirmation dialog
      setConfirmation({ ...confirmation, isOpen: false });

      // Reload the roles list
      await loadRoles(rolesFilters);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Error",
        description: error.message || "Failed to delete role",
      });
    } finally {
      setDeletingId(null);
    }
  };

  const handleSaveRole = async () => {
    setIsRoleDialogOpen(false);
    await loadRoles(rolesFilters);
    setActiveTab("roles");
  };

  // Common confirmation handler
  const handleConfirm = async () => {
    if (confirmation.type === "staff") {
      await handleDeleteStaff();
    } else if (confirmation.type === "role") {
      await handleDeleteRole();
    }
  };

  const handleCancel = () => {
    setConfirmation({
      isOpen: false,
      type: null,
      item: null,
      title: "",
      description: "",
    });
  };

  // Staff filter handlers with debouncing
  const handleStaffFilterChange = (key: keyof StaffFilters, value: string) => {
    const newFilters = {
      ...staffFilters,
      [key]: value,
      page: 1,
    };
    setStaffFilters(newFilters);
    debouncedStaffSearch(newFilters);
  };

  const handleStaffSort = (column: string) => {
    const newSortOrder =
      staffFilters.sort_by === column && staffFilters.sort_order === "asc"
        ? "desc"
        : "asc";

    const newFilters = {
      ...staffFilters,
      sort_by: column,
      sort_order: newSortOrder,
      page: 1,
    };
    setStaffFilters(newFilters);
    loadStaff(newFilters);
  };

  const getStaffSortIcon = (column: string) => {
    if (staffFilters.sort_by !== column) {
      return <ArrowUp className="h-4 w-4 opacity-30" />;
    }
    return staffFilters.sort_order === "asc" ? (
      <ArrowUp className="h-4 w-4" />
    ) : (
      <ArrowDown className="h-4 w-4" />
    );
  };

  // Role filter handlers with debouncing
  const handleRoleFilterChange = (key: keyof RoleFilters, value: string) => {
    const newFilters = {
      ...rolesFilters,
      [key]: value,
      page: 1,
    };
    setRolesFilters(newFilters);
    debouncedRolesSearch(newFilters);
  };

  const handleRoleSort = (column: string) => {
    const newSortOrder =
      rolesFilters.sort_by === column && rolesFilters.sort_order === "asc"
        ? "desc"
        : "asc";

    const newFilters = {
      ...rolesFilters,
      sort_by: column,
      sort_order: newSortOrder,
      page: 1,
    };
    setRolesFilters(newFilters);
    loadRoles(newFilters);
  };

  const getRoleSortIcon = (column: string) => {
    if (rolesFilters.sort_by !== column) {
      return <ArrowUp className="h-4 w-4 opacity-30" />;
    }
    return rolesFilters.sort_order === "asc" ? (
      <ArrowUp className="h-4 w-4" />
    ) : (
      <ArrowDown className="h-4 w-4" />
    );
  };

  // Pagination handlers
  const handleStaffPageChange = (newPage: number) => {
    const newFilters = {
      ...staffFilters,
      page: newPage,
    };
    setStaffFilters(newFilters);
    loadStaff(newFilters);
  };

  const handleRolesPageChange = (newPage: number) => {
    const newFilters = {
      ...rolesFilters,
      page: newPage,
    };
    setRolesFilters(newFilters);
    loadRoles(newFilters);
  };

  // Empty state components
  const StaffEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <Users className="h-16 w-16 text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium mb-2">No staff members found</h3>
      <p className="text-muted-foreground mb-4 max-w-md">
        {hasError
          ? "There was an error loading staff data. Please try again."
          : staffFilters.name
          ? "No staff members match your search criteria. Try adjusting your filters."
          : "Get started by adding your first staff member to the system."}
      </p>
      {!hasError && hasPermission("staff_write") && (
        <Button onClick={handleCreateStaff}>
          <Plus className="h-4 w-4 mr-2" />
          Add Staff Member
        </Button>
      )}
      {hasError && (
        <Button onClick={() => loadStaff(staffFilters)} variant="outline">
          Try Again
        </Button>
      )}
    </div>
  );

  const RolesEmptyState = () => (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      <Shield className="h-16 w-16 text-muted-foreground mb-4" />
      <h3 className="text-lg font-medium mb-2">No roles found</h3>
      <p className="text-muted-foreground mb-4 max-w-md">
        {hasError
          ? "There was an error loading roles data. Please try again."
          : rolesFilters.name
          ? "No roles match your search criteria. Try adjusting your filters."
          : "Get started by creating your first role to assign permissions."}
      </p>
      {!hasError && hasPermission("role_write") && (
        <Button onClick={handleCreateRole}>
          <Plus className="h-4 w-4 mr-2" />
          Create Role
        </Button>
      )}
      {hasError && (
        <Button onClick={() => loadRoles(rolesFilters)} variant="outline">
          Try Again
        </Button>
      )}
    </div>
  );

  // Show no access message if user has no permissions for either tab
  if (!showStaffTab && !showRolesTab) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Shield className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">Access Denied</h3>
          <p className="text-muted-foreground">
            You don't have permission to access staff or role management.
          </p>
        </div>
      </div>
    );
  }

  // Show loading only when initially loading and no data
  if (isLoading && staffMembers.length === 0 && roles.length === 0) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Staff & Role Management</h1>
          <p className="text-muted-foreground">
            Manage admin staff, roles, and permissions
          </p>
        </div>
      </div>
      <Tabs
        value={activeTab}
        onValueChange={setActiveTab}
        className="space-y-6"
      >
        <TabsList
          className={`grid w-full ${
            showStaffTab && showRolesTab ? "grid-cols-2" : "grid-cols-1"
          }`}
        >
          {showStaffTab && (
            <TabsTrigger value="staff" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Staff Members
            </TabsTrigger>
          )}
          {showRolesTab && (
            <TabsTrigger value="roles" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Roles & Permissions
            </TabsTrigger>
          )}
        </TabsList>

        {showStaffTab && (
          <TabsContent value="staff" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Staff Members</CardTitle>
                    <CardDescription>
                      Manage admin staff accounts and permissions
                    </CardDescription>
                  </div>
                  {hasPermission("staff_write") && (
                    <Button onClick={handleCreateStaff}>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Staff
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {/* Search and Filter */}
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search..."
                      value={staffFilters.name || ""}
                      onChange={(e) =>
                        handleStaffFilterChange("name", e.target.value)
                      }
                      className="pl-8"
                    />
                  </div>
                </div>

                <>
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead
                            className="cursor-pointer hover:bg-muted/50"
                            onClick={() => handleStaffSort("name")}
                          >
                            <div className="flex items-center gap-1">
                              Name
                              {getStaffSortIcon("name")}
                            </div>
                          </TableHead>
                          <TableHead
                            className="cursor-pointer hover:bg-muted/50"
                            onClick={() => handleStaffSort("email")}
                          >
                            <div className="flex items-center gap-1">
                              Email
                              {getStaffSortIcon("email")}
                            </div>
                          </TableHead>
                          <TableHead
                            className="cursor-pointer hover:bg-muted/50"
                            onClick={() => handleStaffSort("role")}
                          >
                            <div className="flex items-center gap-1">
                              Role
                              {getStaffSortIcon("role")}
                            </div>
                          </TableHead>
                          <TableHead
                            className="cursor-pointer hover:bg-muted/50"
                            onClick={() => handleStaffSort("department")}
                          >
                            <div className="flex items-center gap-1">
                              Department
                              {getStaffSortIcon("department")}
                            </div>
                          </TableHead>
                          <TableHead
                            className="cursor-pointer hover:bg-muted/50"
                            onClick={() => handleStaffSort("status")}
                          >
                            <div className="flex items-center gap-1">
                              Status
                              {getStaffSortIcon("status")}
                            </div>
                          </TableHead>
                          {(hasPermission("staff_update") ||
                            hasPermission("staff_delete")) && (
                            <TableHead>Actions</TableHead>
                          )}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {isLoading ? (
                          <TableRow>
                            <TableCell
                              colSpan={
                                hasPermission("staff_update") ||
                                hasPermission("staff_delete")
                                  ? 6
                                  : 5
                              }
                              className="h-64 text-center p-0"
                            >
                              <div className="flex items-center justify-center h-full w-full">
                                <div className="text-center">
                                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                                  <p className="text-muted-foreground">
                                    Loading staff...
                                  </p>
                                </div>
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : (
                          <>
                            {" "}
                            {staffMembers?.map((staff) => (
                              <TableRow key={staff.id}>
                                <TableCell className="font-medium">
                                  {staff.name}
                                </TableCell>
                                <TableCell>{staff.email}</TableCell>
                                <TableCell>
                                  <Badge variant="secondary">
                                    {staff?.role}
                                  </Badge>
                                </TableCell>
                                <TableCell>{staff.department || "-"}</TableCell>
                                <TableCell>
                                  <Badge
                                    variant={
                                      staff.status === "active"
                                        ? "default"
                                        : staff.status === "inactive"
                                        ? "secondary"
                                        : "destructive"
                                    }
                                  >
                                    {staff.status}
                                  </Badge>
                                </TableCell>
                                {(hasPermission("staff_update") ||
                                  hasPermission("staff_delete")) && (
                                  <TableCell>
                                    <DropdownMenu>
                                      <DropdownMenuTrigger asChild>
                                        <Button
                                          variant="ghost"
                                          className="h-8 w-8 p-0"
                                        >
                                          <span className="sr-only">
                                            Open menu
                                          </span>
                                          <MoreHorizontal className="h-4 w-4" />
                                        </Button>
                                      </DropdownMenuTrigger>
                                      <DropdownMenuContent align="end">
                                        <DropdownMenuLabel>
                                          Actions
                                        </DropdownMenuLabel>
                                        {hasPermission("staff_update") && (
                                          <DropdownMenuItem
                                            onClick={() =>
                                              handleEditStaff(staff)
                                            }
                                          >
                                            <Edit className="mr-2 h-4 w-4" />
                                            Edit Staff
                                          </DropdownMenuItem>
                                        )}
                                        {hasPermission("staff_delete") && (
                                          <>
                                            {hasPermission("staff_update") && (
                                              <DropdownMenuSeparator />
                                            )}
                                            <DropdownMenuItem
                                              onClick={() =>
                                                handleDeleteStaffClick(staff)
                                              }
                                              className="text-red-600"
                                            >
                                              <Trash2 className="mr-2 h-4 w-4" />
                                              Delete Staff
                                            </DropdownMenuItem>
                                          </>
                                        )}
                                      </DropdownMenuContent>
                                    </DropdownMenu>
                                  </TableCell>
                                )}
                              </TableRow>
                            ))}
                          </>
                        )}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Pagination for Staff */}
                  <div className="flex items-center justify-between px-2 py-4">
                    <div className="flex-1 text-sm text-muted-foreground">
                      Showing {staffPagination.from} to {staffPagination.to} of{" "}
                      {staffPagination.total} entries
                    </div>
                    <div className="flex items-center space-x-6 lg:space-x-8">
                      <div className="flex items-center space-x-2">
                        <p className="text-sm font-medium">Rows per page</p>
                        <Select
                          value={`${staffFilters.per_page}`}
                          onValueChange={(value) => {
                            handleStaffFilterChange("per_page", value);
                          }}
                        >
                          <SelectTrigger className="h-8 w-[70px]">
                            <SelectValue placeholder={staffFilters.per_page} />
                          </SelectTrigger>
                          <SelectContent side="top">
                            {[10, 20, 30, 40, 50].map((pageSize) => (
                              <SelectItem key={pageSize} value={`${pageSize}`}>
                                {pageSize}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex w-[100px] items-center justify-center text-sm font-medium">
                        Page {staffPagination.current_page} of{" "}
                        {staffPagination.last_page}
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          className="hidden h-8 w-8 p-0 lg:flex"
                          onClick={() => handleStaffPageChange(1)}
                          disabled={staffPagination.current_page === 1}
                        >
                          <span className="sr-only">Go to first page</span>
                          <ChevronsLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          className="h-8 w-8 p-0"
                          onClick={() =>
                            handleStaffPageChange(
                              staffPagination.current_page - 1
                            )
                          }
                          disabled={staffPagination.current_page === 1}
                        >
                          <span className="sr-only">Go to previous page</span>
                          <ChevronLeft className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          className="h-8 w-8 p-0"
                          onClick={() =>
                            handleStaffPageChange(
                              staffPagination.current_page + 1
                            )
                          }
                          disabled={
                            staffPagination.current_page >=
                            staffPagination.last_page
                          }
                        >
                          <span className="sr-only">Go to next page</span>
                          <ChevronRight className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          className="hidden h-8 w-8 p-0 lg:flex"
                          onClick={() =>
                            handleStaffPageChange(staffPagination.last_page)
                          }
                          disabled={
                            staffPagination.current_page >=
                            staffPagination.last_page
                          }
                        >
                          <span className="sr-only">Go to last page</span>
                          <ChevronsRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </>
              </CardContent>
            </Card>
          </TabsContent>
        )}

        {showRolesTab && (
          <TabsContent value="roles" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Roles & Permissions</CardTitle>
                    <CardDescription>
                      Manage system roles and their permissions
                    </CardDescription>
                  </div>
                  {hasPermission("role_write") && (
                    <Button onClick={handleCreateRole}>
                      <Plus className="h-4 w-4 mr-2" />
                      Create Role
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {/* Search and Filter */}
                <div className="flex flex-col sm:flex-row gap-4 mb-4">
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search..."
                      value={rolesFilters.name || ""}
                      onChange={(e) =>
                        handleRoleFilterChange("name", e.target.value)
                      }
                      className="pl-8"
                    />
                  </div>
                </div>

                <>
                  <div className="rounded-md border">
                    <div className="overflow-x-auto">
                      <table className="w-full">
                        <thead>
                          <tr className="border-b bg-muted/50">
                            <th
                              className="h-12 px-4 text-left align-middle font-medium text-muted-foreground cursor-pointer hover:bg-muted/70 transition-colors"
                              onClick={() => handleRoleSort("name")}
                            >
                              <div className="flex items-center gap-1">
                                Role Name
                                {getRoleSortIcon("name")}
                              </div>
                            </th>
                            <th
                              className="h-12 px-4 text-left align-middle font-medium text-muted-foreground cursor-pointer hover:bg-muted/70 transition-colors"
                              onClick={() => handleRoleSort("description")}
                            >
                              <div className="flex items-center gap-1">
                                Description
                                {getRoleSortIcon("description")}
                              </div>
                            </th>
                            <th
                              className="h-12 px-4 text-left align-middle font-medium text-muted-foreground"
                              onClick={() => handleRoleSort("permissions")}
                            >
                              <div className="flex items-center gap-1">
                                Permissions
                                {getRoleSortIcon("permissions")}
                              </div>
                            </th>
                            <th
                              className="h-12 px-4 text-left align-middle font-medium text-muted-foreground cursor-pointer hover:bg-muted/70 transition-colors"
                              onClick={() => handleRoleSort("users_count")}
                            >
                              <div className="flex items-center gap-1">
                                Staff Count
                                {getRoleSortIcon("users_count")}
                              </div>
                            </th>
                            {(hasPermission("role_update") ||
                              hasPermission("role_delete")) && (
                              <th className="h-12 px-4 text-left align-middle font-medium text-muted-foreground">
                                Actions
                              </th>
                            )}
                          </tr>
                        </thead>
                        <tbody>
                          {isLoading ? (
                            <TableRow>
                              <TableCell
                                colSpan={
                                  hasPermission("staff_update") ||
                                  hasPermission("staff_delete")
                                    ? 6
                                    : 5
                                }
                                className="h-64 text-center p-0"
                              >
                                <div className="flex items-center justify-center h-full w-full">
                                  <div className="text-center">
                                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                                    <p className="text-muted-foreground">
                                      Loading roles...
                                    </p>
                                  </div>
                                </div>
                              </TableCell>
                            </TableRow>
                          ) : (
                            <>
                              {" "}
                              {roles.map((role: any) => (
                                <tr
                                  key={role.id}
                                  className="border-b hover:bg-muted/50"
                                >
                                  <td className="p-4 align-middle">
                                    <div className="flex items-center gap-2">
                                      <Shield className="h-4 w-4" />
                                      <span className="font-medium">
                                        {role.name}
                                      </span>
                                    </div>
                                  </td>
                                  <td className="p-4 align-middle">
                                    <div className="text-sm text-muted-foreground">
                                      {role.description}
                                    </div>
                                  </td>
                                  <td className="p-4 align-middle">
                                    <div className="text-sm">
                                      <div className="font-medium">
                                        {role.permissions_count} permissions
                                      </div>
                                      <div className="text-muted-foreground">
                                        {role.permissions}
                                      </div>
                                    </div>
                                  </td>
                                  <td className="p-4 align-middle">
                                    <div className="text-sm font-medium">
                                      {role.users_count} staff
                                    </div>
                                  </td>
                                  {(hasPermission("role_update") ||
                                    hasPermission("role_delete")) && (
                                    <td className="p-4 align-middle">
                                      <DropdownMenu>
                                        <DropdownMenuTrigger asChild>
                                          <Button
                                            variant="ghost"
                                            className="h-8 w-8 p-0"
                                          >
                                            <span className="sr-only">
                                              Open menu
                                            </span>
                                            <MoreHorizontal className="h-4 w-4" />
                                          </Button>
                                        </DropdownMenuTrigger>
                                        <DropdownMenuContent align="end">
                                          <DropdownMenuLabel>
                                            Actions
                                          </DropdownMenuLabel>
                                          {hasPermission("role_update") && (
                                            <DropdownMenuItem
                                              onClick={() =>
                                                handleEditRole(role)
                                              }
                                            >
                                              <Edit className="mr-2 h-4 w-4" />
                                              Edit Role
                                            </DropdownMenuItem>
                                          )}
                                          {hasPermission("role_delete") && (
                                            <>
                                              {hasPermission("role_update") && (
                                                <DropdownMenuSeparator />
                                              )}
                                              <DropdownMenuItem
                                                onClick={() =>
                                                  handleDeleteRoleClick(role)
                                                }
                                                className="text-red-600"
                                              >
                                                <Trash2 className="mr-2 h-4 w-4" />
                                                Delete Role
                                              </DropdownMenuItem>
                                            </>
                                          )}
                                        </DropdownMenuContent>
                                      </DropdownMenu>
                                    </td>
                                  )}
                                </tr>
                              ))}
                            </>
                          )}
                        </tbody>
                      </table>
                    </div>

                    {/* Pagination for Roles */}
                    <div className="flex items-center justify-between px-2 py-4">
                      <div className="flex-1 text-sm text-muted-foreground">
                        Showing {rolesPagination.from} to {rolesPagination.to}{" "}
                        of {rolesPagination.total} entries
                      </div>
                      <div className="flex items-center space-x-6 lg:space-x-8">
                        <div className="flex items-center space-x-2">
                          <p className="text-sm font-medium">Rows per page</p>
                          <Select
                            value={`${rolesFilters.per_page}`}
                            onValueChange={(value) => {
                              handleRoleFilterChange("per_page", value);
                            }}
                          >
                            <SelectTrigger className="h-8 w-[70px]">
                              <SelectValue
                                placeholder={rolesFilters.per_page}
                              />
                            </SelectTrigger>
                            <SelectContent side="top">
                              {[10, 20, 30, 40, 50].map((pageSize) => (
                                <SelectItem
                                  key={pageSize}
                                  value={`${pageSize}`}
                                >
                                  {pageSize}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="flex w-[100px] items-center justify-center text-sm font-medium">
                          Page {rolesPagination.current_page} of{" "}
                          {rolesPagination.last_page}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="outline"
                            className="hidden h-8 w-8 p-0 lg:flex"
                            onClick={() => handleRolesPageChange(1)}
                            disabled={rolesPagination.current_page === 1}
                          >
                            <span className="sr-only">Go to first page</span>
                            <ChevronsLeft className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            className="h-8 w-8 p-0"
                            onClick={() =>
                              handleRolesPageChange(
                                rolesPagination.current_page - 1
                              )
                            }
                            disabled={rolesPagination.current_page === 1}
                          >
                            <span className="sr-only">Go to previous page</span>
                            <ChevronLeft className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            className="h-8 w-8 p-0"
                            onClick={() =>
                              handleRolesPageChange(
                                rolesPagination.current_page + 1
                              )
                            }
                            disabled={
                              rolesPagination.current_page >=
                              rolesPagination.last_page
                            }
                          >
                            <span className="sr-only">Go to next page</span>
                            <ChevronRight className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            className="hidden h-8 w-8 p-0 lg:flex"
                            onClick={() =>
                              handleRolesPageChange(rolesPagination.last_page)
                            }
                            disabled={
                              rolesPagination.current_page >=
                              rolesPagination.last_page
                            }
                          >
                            <span className="sr-only">Go to last page</span>
                            <ChevronsRight className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
      {/* Common Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={confirmation.isOpen}
        onClose={handleCancel}
        onConfirm={handleConfirm}
        title={confirmation.title}
        description={confirmation.description}
        confirmText="Delete"
        cancelText="Cancel"
        variant="destructive"
        isLoading={deletingId === (confirmation.item?.id || null)}
      />
      {/* Role Form Dialog */}
      <RoleFormDialog
        isOpen={isRoleDialogOpen}
        onClose={() => setIsRoleDialogOpen(false)}
        onSubmit={handleSaveRole}
        role={selectedRole}
        isEditing={isEditingRole}
      />
      {/* Staff Form Dialog */}
      <StaffFormDialog
        isOpen={isStaffDialogOpen}
        onClose={() => setIsStaffDialogOpen(false)}
        onSubmit={handleSaveStaff}
        staff={selectedStaff}
        isEditing={isEditingStaff}
      />{" "}
    </div>
  );
}
