"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Package, DollarSign, TrendingUp } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { WelcomeBanner } from "@/components/welcome-banner";
import { QuickStartCard } from "@/components/quick-start-card";
import Link from "next/link";
import { getDashboardData } from "@/lib/dashboardService";
import { useEffect, useState } from "react";
import { DirhamIcon } from "@/components/ui/DirhamIcon";
import { convertToDubaiTime } from "@/components/convertToDubaiTime";
import { DateRangeFilter } from "@/components/admin/DateRangeFilter";

interface DashboardData {
  stats: {
    active_patients: {
      value: number;
      total: number;
      subtitle: string;
    };
    total_orders: {
      value: number;
      completed: number;
      draft: number;
      subtitle: string;
    };
    this_month_commission: {
      value: string;
      currency: string;
      subtitle: string;
    };
    total_earnings: {
      value: string;
      currency: string;
      subtitle: string;
    };
  };
  recent_orders: Array<{
    id: string;
    patient_name: string;
    items_count: number;
    amount: string;
    status: string;
    date: string;
    created_by: string;
  }>;
  recent_patients: Array<{
    id: string;
    name: string;
    last_visit: string;
    status: string;
  }>;
  summary: {
    role: string;
    doctor_staff_count: number;
    last_updated: string;
  };
}

// Skeleton Loader Components
const StatCardSkeleton = () => (
  <Card className="animate-pulse">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <div className="h-4 w-24 bg-gray-200 rounded"></div>
      <div className="h-4 w-4 bg-gray-200 rounded"></div>
    </CardHeader>
    <CardContent>
      <div className="h-8 w-16 bg-gray-200 rounded mb-2"></div>
      <div className="h-3 w-20 bg-gray-200 rounded"></div>
    </CardContent>
  </Card>
);

const RecentActivitySkeleton = () => (
  <Card className="animate-pulse">
    <CardHeader>
      <div className="h-6 w-32 bg-gray-200 rounded mb-2"></div>
      <div className="h-4 w-48 bg-gray-200 rounded"></div>
    </CardHeader>
    <CardContent>
      <div className="space-y-4">
        {[...Array(3)].map((_, index) => (
          <div key={index} className="flex items-center justify-between">
            <div className="space-y-2">
              <div className="h-5 w-32 bg-gray-200 rounded"></div>
              <div className="h-4 w-40 bg-gray-200 rounded"></div>
            </div>
            <div className="h-6 w-20 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const WelcomeBannerSkeleton = () => (
  <div className="animate-pulse bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
    <div className="flex items-center justify-between">
      <div className="space-y-3">
        <div className="h-7 w-64 bg-gray-200 rounded"></div>
        <div className="h-4 w-96 bg-gray-200 rounded"></div>
      </div>
      <div className="h-12 w-12 bg-gray-200 rounded-full"></div>
    </div>
  </div>
);

const HeaderSkeleton = () => (
  <div className="animate-pulse space-y-2">
    <div className="h-8 w-64 bg-gray-200 rounded"></div>
    <div className="h-4 w-96 bg-gray-200 rounded"></div>
  </div>
);

const QuickStartCardSkeleton = () => (
  <Card className="animate-pulse">
    <CardHeader>
      <div className="h-6 w-32 bg-gray-200 rounded mb-2"></div>
      <div className="h-4 w-48 bg-gray-200 rounded"></div>
    </CardHeader>
    <CardContent>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, index) => (
          <div
            key={index}
            className="flex flex-col items-center p-4 border rounded-lg"
          >
            <div className="h-8 w-8 bg-gray-200 rounded mb-2"></div>
            <div className="h-4 w-20 bg-gray-200 rounded mb-1"></div>
            <div className="h-3 w-24 bg-gray-200 rounded"></div>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

// Content Skeleton (for filter loading)
const DashboardContentSkeleton = () => (
  <div className="space-y-6">
    {/* Stats Cards Grid */}
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {[...Array(4)].map((_, index) => (
        <StatCardSkeleton key={index} />
      ))}
    </div>

    {/* Quick Start Actions */}
    <QuickStartCardSkeleton />

    {/* Recent Activity */}
    <div className="grid gap-4 md:grid-cols-2">
      <RecentActivitySkeleton />
      <RecentActivitySkeleton />
    </div>
  </div>
);

// Main Dashboard Skeleton (for initial load)
const DashboardSkeleton = () => (
  <div className="space-y-6">
    <WelcomeBannerSkeleton />
    <HeaderSkeleton />
    <DashboardContentSkeleton />
  </div>
);

export default function DashboardPage() {
  const { user } = useAuth();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(
    null
  );
  const [loading, setLoading] = useState(true);
  const [filterLoading, setFilterLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date } | null>(
    null
  );

  const fetchDashboardData = async (
    range?: { from: Date; to: Date } | null
  ) => {
    try {
      // Determine if this is initial load or filter load
      const isInitialLoad = !dashboardData && !range;

      if (isInitialLoad) {
        setLoading(true);
      } else {
        setFilterLoading(true);
      }

      // Build query parameters
      const params: any = {};
      if (range?.from && range?.to) {
        params.start_date = range.from.toISOString().split("T")[0];
        params.end_date = range.to.toISOString().split("T")[0];
      }

      console.log("Fetching dashboard data with params:", params);
      const response: any = await getDashboardData(params);
      setDashboardData(response.data);
      setError(null);
    } catch (err) {
      setError("Failed to load dashboard data");
      console.error("Error fetching dashboard data:", err);
    } finally {
      setLoading(false);
      setFilterLoading(false);
    }
  };

  const handleDateRangeChange = (range: { from: Date; to: Date } | null) => {
    setDateRange(range);
    fetchDashboardData(range);
  };

  useEffect(() => {
    if (user) {
      fetchDashboardData();
    }
  }, [user]);

  if (!user) return null;

  // Show skeleton loader while loading for initial load
  if (loading && !dashboardData) {
    return <DashboardSkeleton />;
  }

  if (error) {
    return (
      <div className="space-y-6">
        <WelcomeBanner />
        <div className="flex items-center justify-center h-64">
          <div className="text-lg text-red-500">{error}</div>
        </div>
      </div>
    );
  }

  if (!dashboardData) {
    return (
      <div className="space-y-6">
        <WelcomeBanner />
        <div className="flex items-center justify-center h-64">
          <div className="text-lg">No dashboard data available</div>
        </div>
      </div>
    );
  }

  const { stats, recent_orders, recent_patients, summary } = dashboardData;

  return (
    <div className="space-y-6">
      <WelcomeBanner />

      {/* Header and Date Filter */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {user.name}. Here's your practice overview.
            {` Last updated: ${convertToDubaiTime(summary.last_updated)}`}
          </p>
        </div>
      </div>

      {/* Filters Section - Always visible */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-end">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end">
          <DateRangeFilter
            onDateRangeChange={handleDateRangeChange}
            selectedRange={dateRange}
          />
        </div>
      </div>

      {/* Dashboard Content with Filter Loading State */}
      {filterLoading ? (
        <DashboardContentSkeleton />
      ) : (
        <>
          {/* Stats Cards */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Active Patients
                </CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  {stats.active_patients.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.active_patients.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Orders
                </CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-secondary">
                  {stats.total_orders.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.total_orders.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  This Month Commission
                </CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  <DirhamIcon /> {stats.this_month_commission.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.this_month_commission.subtitle}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Earnings
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-primary">
                  <DirhamIcon /> {stats.total_earnings.value}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.total_earnings.subtitle}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Quick Start Actions */}
          <QuickStartCard />

          {/* Recent Activity */}
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Recent Orders</CardTitle>
                <CardDescription>
                  Your latest prescription orders
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recent_orders.slice(0, 3).map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between"
                    >
                      <div>
                        <div className="font-medium">{order.patient_name}</div>
                        <p className="text-sm text-muted-foreground">
                          {order.items_count} items • <DirhamIcon />{" "}
                          {order.amount}
                        </p>
                      </div>
                      <Badge
                        variant={
                          order.status === "completed"
                            ? "default"
                            : order.status === "open"
                            ? "secondary"
                            : "outline"
                        }
                      >
                        {order.status.charAt(0).toUpperCase() +
                          order.status.slice(1)}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Patients</CardTitle>
                <CardDescription>
                  Recently added or updated patients
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recent_patients.slice(0, 3).map((patient) => (
                    <div
                      key={patient.id}
                      className="flex items-center justify-between"
                    >
                      <div>
                        <Link
                          href={`/patients/${patient.id}`}
                          className="font-medium hover:text-primary hover:underline cursor-pointer"
                        >
                          {patient.name}
                        </Link>
                        <p className="text-sm text-muted-foreground">
                          Last visit: {patient.last_visit}
                        </p>
                      </div>
                      <Badge
                        variant={
                          patient.status === "active" ? "default" : "secondary"
                        }
                      >
                        {patient.status.charAt(0).toUpperCase() +
                          patient.status.slice(1)}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}
