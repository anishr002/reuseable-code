"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import AuthLoading from "@/components/auth-loading"

export default function HomePage() {
  const router = useRouter()
  const { user, isLoading } = useAuth()

  useEffect(() => {
    if (!isLoading) {
      if (user) {
        // User is authenticated, redirect to portal dashboard
        router.push("/dashboard")
      } else {
        // User is not authenticated, redirect to login
        router.push("/login")
      }
    }
  }, [user, isLoading, router])

  return <AuthLoading />
}
