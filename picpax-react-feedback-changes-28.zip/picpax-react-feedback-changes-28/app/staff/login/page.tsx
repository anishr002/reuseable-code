"use client";

import type React from "react";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Eye, EyeOff, AlertCircle, ArrowLeft, CheckCircle } from "lucide-react";
import Link from "next/link";
import { useAuth } from "@/lib/auth-context";
import { forgotPassword } from "@/lib/userService";

export default function StaffLoginPage() {
  const router = useRouter();
  const { login } = useAuth();
  const [currentView, setCurrentView] = useState<
    "login" | "forgot-password" | "reset-success"
  >("login");

  // Login form state
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
    rememberMe: false,
  });

  // Forgot password form state
  const [forgotPasswordData, setForgotPasswordData] = useState({
    email: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  // Email validation
  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      setEmailError("Email is required");
      return false;
    } else if (!emailRegex.test(email)) {
      setEmailError("Please enter a valid email address");
      return false;
    } else {
      setEmailError("");
      return true;
    }
  };

  // Password validation
  const validatePassword = (password: string): boolean => {
    if (!password) {
      setPasswordError("Password is required");
      return false;
    } else if (password.length < 6) {
      setPasswordError("Password must be at least 6 characters");
      return false;
    } else {
      setPasswordError("");
      return true;
    }
  };

  const performLogin = async () => {
    // Reset errors
    setError("");
    setEmailError("");
    setPasswordError("");

    // Validate inputs
    const isEmailValid = validateEmail(loginData.email);
    const isPasswordValid = validatePassword(loginData.password);

    if (!isEmailValid || !isPasswordValid) {
      return;
    }

    setIsLoading(true);

    try {
      // Use the auth context login function - explicitly set isAdmin to false for doctor login
      const success = await login(loginData.email, loginData.password, false);

      if (!success) {
        setError("Invalid doctor credentials. Please try again.");
      }
    } catch (err: any) {
      setError(
        err.response?.data?.message ||
          "An error occurred during login. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await performLogin();
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Validate email
    if (!forgotPasswordData.email) {
      setError("Email is required");
      setIsLoading(false);
      return;
    }

    if (!validateEmail(forgotPasswordData.email)) {
      setIsLoading(false);
      return;
    }

    try {
      // Call the actual forgot password API
      await forgotPassword(forgotPasswordData.email);

      // Success - show reset success view
      setCurrentView("reset-success");
    } catch (err: any) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "An error occurred. Please try again."
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleLoginInputChange = (field: string, value: string | boolean) => {
    setLoginData((prev) => ({ ...prev, [field]: value }));
    if (error) setError(""); // Clear error when user starts typing
    if (field === "email" && emailError) setEmailError("");
    if (field === "password" && passwordError) setPasswordError("");
  };

  const handleForgotPasswordInputChange = (field: string, value: string) => {
    setForgotPasswordData((prev) => ({ ...prev, [field]: value }));
    if (error) setError(""); // Clear error when user starts typing
  };

  const resetToLogin = () => {
    setCurrentView("login");
    setError("");
    setForgotPasswordData({ email: "" });
  };

  // Auto-fill and auto-login
  const handleAutoLogin = async () => {
    const demoCredentials = {
      email: "doctor@picpax.com",
      password: "password123",
      rememberMe: false,
    };

    // Set the credentials
    setLoginData(demoCredentials);
    setError(""); // Clear any existing errors
    setEmailError("");
    setPasswordError("");

    // Wait a moment for state to update, then perform login using auth context
    setTimeout(async () => {
      setIsLoading(true);
      setError("");

      try {
        // Use the auth context login function - explicitly set isAdmin to false for doctor login
        const success = await login(
          demoCredentials.email,
          demoCredentials.password,
          false
        );

        if (!success) {
          setError("Auto-login failed. Please try again.");
        }
        // If successful, the auth context will handle the redirect
      } catch (err) {
        setError("An error occurred during auto-login. Please try again.");
      } finally {
        setIsLoading(false);
      }
    }, 100);
  };

  return (
    <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2">
      {/* Left side - Sticky */}
      <div className="hidden bg-muted lg:block lg:sticky lg:top-0 lg:h-screen">
        <div className="flex h-full items-center justify-center bg-gradient-to-br from-primary to-secondary p-10">
          <div className="text-center text-white space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold">PicPax Portal</h1>
              <p className="text-lg text-white/90 max-w-md">
                Your comprehensive healthcare nutrition management platform for
                better patient outcomes.
              </p>
            </div>
            <div className="space-y-3 text-left max-w-sm mx-auto">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Personalized supplement prescriptions
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">Patient management system</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Commission tracking & analytics
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="flex items-center justify-center py-12 min-h-screen">
        <div className="mx-auto grid w-[350px] gap-6">
          {/* Logo - Responsive sizing */}
          <div className="text-center mb-6">
            <div className="flex justify-center">
              <img
                src="/images/logo.png"
                alt="PicPax"
                className="h-10 sm:h-12 w-auto object-contain"
              />
            </div>
          </div>

          {/* Login Form */}
          {currentView === "login" && (
            <div>
              <div className="grid gap-2 text-center mb-6">
                <h2 className="text-2xl font-bold">Welcome Back</h2>
                <p className="text-balance text-muted-foreground">
                  Enter your credentials to access your account
                </p>
              </div>
              <form onSubmit={handleLoginSubmit} className="grid gap-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="grid gap-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="doctor@picpax.com"
                    value={loginData.email}
                    onChange={(e) =>
                      handleLoginInputChange("email", e.target.value)
                    }
                    onBlur={() => validateEmail(loginData.email)}
                    required
                    className={emailError ? "border-destructive" : ""}
                  />
                  {emailError && (
                    <p className="text-destructive text-xs">{emailError}</p>
                  )}
                </div>
                <div className="grid gap-2">
                  <div className="flex items-center">
                    <Label htmlFor="password">Password</Label>
                    <Button
                      type="button"
                      variant="link"
                      className="ml-auto inline-block text-sm underline"
                      onClick={() => setCurrentView("forgot-password")}
                    >
                      Forgot your password?
                    </Button>
                  </div>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={loginData.password}
                      onChange={(e) =>
                        handleLoginInputChange("password", e.target.value)
                      }
                      onBlur={() => validatePassword(loginData.password)}
                      required
                      className={passwordError ? "border-destructive" : ""}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  {passwordError && (
                    <p className="text-destructive text-xs">{passwordError}</p>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="remember"
                    checked={loginData.rememberMe}
                    onCheckedChange={(checked) =>
                      handleLoginInputChange("rememberMe", checked as boolean)
                    }
                  />
                  <Label htmlFor="remember" className="text-sm font-normal">
                    Remember me
                  </Label>
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Signing in..." : "Login"}
                </Button>
              </form>
            </div>
          )}

          {/* Forgot Password Form */}
          {currentView === "forgot-password" && (
            <div>
              <div className="grid gap-2 text-center mb-6">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={resetToLogin}
                  className="absolute top-4 left-4 md:top-8 md:left-8 text-white hover:text-white hover:bg-white/10"
                >
                  <ArrowLeft className="h-4 w-4" />
                  Back
                </Button>
                <h2 className="text-2xl font-bold">Reset Password</h2>
                <p className="text-balance text-muted-foreground">
                  Enter your email address and we&apos;ll send you a link to
                  reset your password
                </p>
              </div>
              <form
                onSubmit={handleForgotPasswordSubmit}
                className="grid gap-4"
              >
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="grid gap-2">
                  <Label htmlFor="forgot-email">Email</Label>
                  <Input
                    id="forgot-email"
                    type="email"
                    placeholder="doctor@picpax.com"
                    value={forgotPasswordData.email}
                    onChange={(e) =>
                      handleForgotPasswordInputChange("email", e.target.value)
                    }
                    required
                  />
                </div>
                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Sending..." : "Send Reset Link"}
                </Button>
              </form>
              <div className="mt-4 text-center text-sm">
                <Button
                  variant="link"
                  onClick={resetToLogin}
                  className="underline"
                >
                  Back to Login
                </Button>
              </div>
            </div>
          )}

          {/* Reset Success View */}
          {currentView === "reset-success" && (
            <div>
              <div className="grid gap-2 text-center">
                <div className="flex justify-center mb-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <h2 className="text-2xl font-bold">Check Your Email</h2>
                <p className="text-balance text-muted-foreground">
                  We&apos;ve sent a password reset link to{" "}
                  <span className="font-medium">
                    {forgotPasswordData.email}
                  </span>
                </p>
              </div>
              <div className="grid gap-4">
                <div className="rounded-lg border bg-card p-4 text-sm">
                  <p className="font-medium mb-2">What&apos;s next?</p>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• Check your email inbox (and spam folder)</li>
                    <li>• Click the reset link in the email</li>
                    <li>• Create a new password</li>
                    <li>• Sign in with your new password</li>
                  </ul>
                </div>
                <Button onClick={resetToLogin} className="w-full">
                  Back to Login
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setCurrentView("forgot-password")}
                  className="w-full"
                >
                  Try Different Email
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
