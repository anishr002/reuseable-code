"use client";

import { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Users,
  UserCheck,
  UserX,
  Clock,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Mail,
  Phone,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";

// Mock clinic staff data for doctors
const mockClinicStaff = [
  {
    id: "clinic_staff_001",
    title: "Dr.",
    firstName: "Sarah",
    lastName: "Johnson",
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@medicenter.com",
    phone: "+1 (555) 123-4567",
    contact_number: "+1 (555) 123-4567",
    designation: "Assistant Doctor",
    role: "assistant",
    status: 1,
    createdAt: "2024-01-15T10:30:00Z",
    lastLogin: "2024-01-15T09:15:00Z",
    avatar: "/placeholder.svg",
  },
  {
    id: "clinic_staff_002",
    title: "Ms.",
    firstName: "Emma",
    lastName: "Wilson",
    name: "Ms. Emma Wilson",
    email: "emma.wilson@medicenter.com",
    phone: "+1 (555) 987-6543",
    contact_number: "+1 (555) 987-6543",
    designation: "Nurse Practitioner",
    role: "nurse",
    status: 1,
    createdAt: "2024-01-10T14:20:00Z",
    lastLogin: "2024-01-14T14:20:00Z",
    avatar: "/placeholder.svg",
  },
  {
    id: "clinic_staff_003",
    title: "Mr.",
    firstName: "James",
    lastName: "Rodriguez",
    name: "Mr. James Rodriguez",
    email: "james.rodriguez@medicenter.com",
    phone: "+1 (555) 456-7890",
    contact_number: "+1 (555) 456-7890",
    designation: "Medical Assistant",
    role: "assistant",
    status: 0,
    createdAt: "2024-01-08T11:30:00Z",
    lastLogin: "2024-01-10T16:20:00Z",
    avatar: "/placeholder.svg",
  },
];

interface ClinicStaff {
  id: string;
  title: string;
  firstName: string;
  lastName: string;
  name: string;
  email: string;
  phone: string;
  contact_number: string;
  designation: string;
  role: string;
  status: number;
  createdAt: string;
  lastLogin: string;
  avatar?: string;
}

export default function DoctorStaffManagementPage() {
  const { toast } = useToast();
  const [staff, setStaff] = useState<ClinicStaff[]>(mockClinicStaff);
  const [isAddStaffModalOpen, setIsAddStaffModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStaff, setSelectedStaff] = useState<ClinicStaff | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Filter staff based on search
  const filteredStaff = staff.filter(
    (member) =>
      member.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.designation.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalStaff = staff.length;
  const activeStaff = staff.filter((s) => s.status === 1).length;
  const inactiveStaff = staff.filter((s) => s.status === 0).length;
  const recentLogins = staff.filter((s) => {
    const lastLogin = new Date(s.lastLogin);
    const threeDaysAgo = new Date();
    threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
    return lastLogin >= threeDaysAgo;
  }).length;

  const handleEditStaff = (staffMember: ClinicStaff) => {
    setSelectedStaff(staffMember);
    setIsEditModalOpen(true);
  };

  const handleDeleteStaff = (staffMember: ClinicStaff) => {
    if (
      confirm(
        `Are you sure you want to remove ${staffMember.name} from your clinic staff?`
      )
    ) {
      setStaff((prev) => prev.filter((s) => s.id !== staffMember.id));
      toast({
        title: "Staff Removed",
        description: `${staffMember.name} has been removed from your clinic staff.`,
      });
    }
  };

  const handleSendCredentials = (staffMember: ClinicStaff) => {
    toast({
      title: "Credentials Sent",
      description: `Login credentials sent to ${staffMember.email}`,
    });
  };

  const handleToggleStatus = (staffMember: ClinicStaff) => {
    setStaff((prev) =>
      prev.map((s) =>
        s.id === staffMember.id ? { ...s, status: s.status === 1 ? 0 : 1 } : s
      )
    );
    toast({
      title: "Status Updated",
      description: `${staffMember.name} is now ${
        staffMember.status === 1 ? "inactive" : "active"
      }.`,
    });
  };

  const ActionsCell = ({ staffMember }: { staffMember: ClinicStaff }) => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="h-8 w-8 p-0">
          <span className="sr-only">Open menu</span>
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuLabel>Actions</DropdownMenuLabel>
        <DropdownMenuItem onClick={() => handleEditStaff(staffMember)}>
          <Edit className="mr-2 h-4 w-4" />
          Edit Staff
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleSendCredentials(staffMember)}>
          <Mail className="mr-2 h-4 w-4" />
          Send Login Info
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => handleToggleStatus(staffMember)}>
          {staffMember.status === 1 ? (
            <UserX className="mr-2 h-4 w-4" />
          ) : (
            <UserCheck className="mr-2 h-4 w-4" />
          )}
          {staffMember.status === 1 ? "Deactivate" : "Activate"}
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem
          onClick={() => handleDeleteStaff(staffMember)}
          className="text-red-600"
        >
          <Trash2 className="mr-2 h-4 w-4" />
          Remove Staff
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );

  const columns = [
    {
      accessorKey: "staff",
      header: "Staff Member",
      cell: ({ row }: { row: { original: ClinicStaff } }) => {
        const staffMember = row.original;
        const initials = `${staffMember.firstName.charAt(
          0
        )}${staffMember.lastName.charAt(0)}`;

        return (
          <div className="flex items-center space-x-3">
            <Avatar className="h-8 w-8">
              <AvatarImage
                src={staffMember.avatar || "/placeholder.svg"}
                alt={`${staffMember.firstName} ${staffMember.lastName}`}
              />
              <AvatarFallback className="text-xs">{initials}</AvatarFallback>
            </Avatar>
            <div>
              <div className="font-medium">{staffMember.name}</div>
              <div className="text-sm text-muted-foreground">
                {staffMember.designation}
              </div>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "contact",
      header: "Contact",
      cell: ({ row }: { row: { original: ClinicStaff } }) => {
        const staffMember = row.original;
        return (
          <div className="space-y-1">
            <div className="flex items-center text-sm">
              <Mail className="mr-2 h-3 w-3 text-muted-foreground" />
              {staffMember.email}
            </div>
            <div className="flex items-center text-sm text-muted-foreground">
              <Phone className="mr-2 h-3 w-3" />
              {staffMember.phone}
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: { row: { original: ClinicStaff } }) => {
        const status = row.getValue("status") as number;
        return (
          <Badge
            variant={status === 1 ? "default" : "secondary"}
            className="text-xs"
          >
            {status === 1 ? "Active" : "Inactive"}
          </Badge>
        );
      },
    },
    {
      accessorKey: "lastLogin",
      header: "Last Login",
      cell: ({ row }: { row: { original: ClinicStaff } }) => {
        const lastLogin = row.getValue("lastLogin") as string;
        return (
          <div className="text-sm text-muted-foreground">
            {new Date(lastLogin).toLocaleDateString()}
          </div>
        );
      },
    },
    {
      accessorKey: "createdAt",
      header: "Created",
      cell: ({ row }: { row: { original: ClinicStaff } }) => {
        const createdAt = row.getValue("createdAt") as string;
        return (
          <div className="text-sm text-muted-foreground">
            {new Date(createdAt).toLocaleDateString()}
          </div>
        );
      },
    },
    {
      id: "actions",
      header: "Actions",
      cell: ({ row }: { row: { original: ClinicStaff } }) => (
        <ActionsCell staffMember={row.original} />
      ),
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Clinic Staff Management
          </h1>
          <p className="text-muted-foreground">
            Manage your clinic staff who can work on your behalf
          </p>
        </div>
        <Button
          onClick={() => setIsAddStaffModalOpen(true)}
          className="bg-primary hover:bg-primary/90"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Staff Member
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-primary" />
              <div>
                <div className="text-2xl font-bold">{totalStaff}</div>
                <p className="text-sm text-muted-foreground">Total Staff</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <UserCheck className="h-5 w-5 text-green-600" />
              <div>
                <div className="text-2xl font-bold text-green-600">
                  {activeStaff}
                </div>
                <p className="text-sm text-muted-foreground">Active</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <UserX className="h-5 w-5 text-red-600" />
              <div>
                <div className="text-2xl font-bold text-red-600">
                  {inactiveStaff}
                </div>
                <p className="text-sm text-muted-foreground">Inactive</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-blue-600" />
              <div>
                <div className="text-2xl font-bold text-blue-600">
                  {recentLogins}
                </div>
                <p className="text-sm text-muted-foreground">Recent Logins</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Clinic Staff Members</CardTitle>
              <CardDescription>
                Manage your clinic staff accounts and permissions
              </CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b bg-muted/50">
                    {columns.map((column, index) => (
                      <th
                        key={index}
                        className="h-12 px-4 text-left align-middle font-medium text-muted-foreground"
                      >
                        {column.header as string}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filteredStaff.map((staffMember) => (
                    <tr
                      key={staffMember.id}
                      className="border-b hover:bg-muted/50"
                    >
                      {columns.map((column, cellIndex) => (
                        <td key={cellIndex} className="p-4 align-middle">
                          {column.cell({
                            row: { original: staffMember },
                          } as any)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Simple Add Staff Modal */}
      <Dialog open={isAddStaffModalOpen} onOpenChange={setIsAddStaffModalOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Clinic Staff Member</DialogTitle>
            <DialogDescription>
              Add a new staff member to your clinic who can work on your behalf.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Name
              </Label>
              <Input id="name" className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                Email
              </Label>
              <Input id="email" type="email" className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="phone" className="text-right">
                Phone
              </Label>
              <Input id="phone" className="col-span-3" />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="role" className="text-right">
                Role
              </Label>
              <Select>
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="assistant">Assistant Doctor</SelectItem>
                  <SelectItem value="nurse">Nurse Practitioner</SelectItem>
                  <SelectItem value="coordinator">Care Coordinator</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" onClick={() => setIsAddStaffModalOpen(false)}>
              Add Staff Member
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
