"use client";

import type React from "react";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Eye, EyeOff, AlertCircle, CheckCircle } from "lucide-react";
import Link from "next/link";
import { DocumentUpload } from "@/components/ui/document-upload";
import type { DocumentFile } from "@/components/ui/document-upload";
import { doctorSignup } from "@/lib/doctorApi";
import { getCountriesWithStates } from "@/services/doctorService";

interface CountryWithStates {
  country_code: string;
  country_name: string;
  states: string[];
}

export default function SignUpPage() {
  const router = useRouter();
  const [currentView, setCurrentView] = useState<"signup" | "success">(
    "signup"
  );

  // Sign up form state
  const [signupData, setSignupData] = useState({
    title: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    contact_number: "",
    password: "",
    confirmPassword: "",
    specialization: "",
    other_speciality: "", // New field for other specialty
    clinic_name: "",
    gender: "",
    address: "",
    country: "",
    state: "",
    emirates: "",
    licenseNumber: "",
    agreeToTerms: false,
    agreeToMarketing: false,
    countryName: "",
    villaApartment: "",
    areaStreet: "",
    nearbyLandmark: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingCountries, setIsLoadingCountries] = useState(false);
  const [error, setError] = useState("");
  const [documents, setDocuments] = useState<DocumentFile[]>([]);
  const [countries, setCountries] = useState<CountryWithStates[]>([]);

  const titles = ["Dr.", "Prof.", "Mr.", "Ms.", "Mrs."];

  const specialties = [
    "General Practice",
    "Nutritional Medicine",
    "Functional Medicine",
    "Integrative Medicine",
    "Naturopathic Medicine",
    "Internal Medicine",
    "Family Medicine",
    "Preventive Medicine",
    "Gynecologist",
    "Other",
  ];

  // Check if "Other" is selected
  const isOtherSpecialtySelected = signupData.specialization === "Other";

  // Fetch countries on component mount
  useEffect(() => {
    const fetchCountries = async () => {
      setIsLoadingCountries(true);
      try {
        const response = await getCountriesWithStates();
        setCountries(response.data);
      } catch (error) {
        console.error("Error fetching countries:", error);
        setError("Failed to load countries. Please refresh the page.");
      } finally {
        setIsLoadingCountries(false);
      }
    };

    fetchCountries();
  }, []);

  // Get unique country names from the countries data
  const getCountryNames = (): string[] => {
    const uniqueCountries = countries.reduce((acc: string[], country) => {
      if (country.country_name && !acc.includes(country.country_name)) {
        acc.push(country.country_name);
      }
      return acc;
    }, []);

    console.log("Available country names:", uniqueCountries);
    return uniqueCountries;
  };

  // Get states for selected country
  const getStatesForSelectedCountry = (): string[] => {
    if (!signupData.country) {
      console.log("No country selected for states");
      return [];
    }

    const selectedCountry = countries.find(
      (country) => country.country_name === signupData.country
    );

    console.log("Selected country for states:", selectedCountry);
    console.log("Available states:", selectedCountry?.states);

    return selectedCountry?.states || [];
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      // Validation for required fields
      if (!signupData.title) {
        setError("Title is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.firstName.trim()) {
        setError("First name is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.lastName.trim()) {
        setError("Last name is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.email.trim()) {
        setError("Email is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.phone.trim()) {
        setError("Phone number is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.gender) {
        setError("Gender is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.specialization) {
        setError("Medical specialty is required.");
        setIsLoading(false);
        return;
      }

      // Validate other_speciality only when "Other" is selected
      if (isOtherSpecialtySelected && !signupData.other_speciality.trim()) {
        setError("Please specify your medical specialty.");
        setIsLoading(false);
        return;
      }

      if (!signupData.clinic_name.trim()) {
        setError("Clinic name is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.licenseNumber.trim()) {
        setError("Medical license number is required.");
        setIsLoading(false);
        return;
      }

      if (signupData.password !== signupData.confirmPassword) {
        setError("Passwords do not match.");
        setIsLoading(false);
        return;
      }

      if (signupData.password.length < 8) {
        setError("Password must be at least 8 characters long.");
        setIsLoading(false);
        return;
      }

      if (!signupData.agreeToTerms) {
        setError("You must agree to the Terms of Service and Privacy Policy.");
        setIsLoading(false);
        return;
      }

      if (!signupData.country) {
        setError("Please select your country.");
        setIsLoading(false);
        return;
      }

      // Add validation for new address fields
      if (!signupData.villaApartment.trim()) {
        setError("Villa/Apartment is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.areaStreet.trim()) {
        setError("Area/Street is required.");
        setIsLoading(false);
        return;
      }

      if (!signupData.state) {
        setError("State/Emirate is required.");
        setIsLoading(false);
        return;
      }

      // Rest of your code remains the same...
      let addressString: any = [
        signupData.villaApartment,
        signupData.areaStreet,
        signupData.state,
        signupData.countryName,
        signupData.nearbyLandmark && `Near ${signupData.nearbyLandmark}`,
      ];

      // Prepare FormData for API
      const formData = new FormData();

      // Add all form fields to FormData
      formData.append("title", signupData.title);
      formData.append("first_name", signupData.firstName);
      formData.append("last_name", signupData.lastName);
      formData.append("email", signupData.email);
      formData.append("phone_number", signupData.phone);
      formData.append("contact_number", signupData.contact_number);
      formData.append("gender", signupData.gender.toLowerCase());
      formData.append("medical_speciality", signupData.specialization);

      // Add other_speciality only when "Other" is selected
      if (isOtherSpecialtySelected) {
        formData.append("other_speciality", signupData.other_speciality);
      }

      formData.append("clinic_name", signupData.clinic_name);
      formData.append("address", addressString);

      // Use state/emirate based on country selection
      formData.append("country", signupData.country);
      formData.append("emirates_states", signupData.state);
      formData.append("villa_apartment", signupData.villaApartment);
      formData.append("area_street", signupData.areaStreet);
      formData.append("nearby_landmark", signupData.nearbyLandmark || "");

      formData.append("medical_license", signupData.licenseNumber);
      formData.append("password", signupData.password);
      formData.append("password_confirmation", signupData.confirmPassword);
      formData.append("terms_service", signupData.agreeToTerms ? "1" : "0");
      formData.append(
        "receive_updates",
        signupData.agreeToMarketing ? "1" : "0"
      );

      // Add documents
      documents.forEach((document, index) => {
        if (document.file) {
          formData.append("documents[]", document.file);
        }
      });

      // Call the actual API
      const response = await doctorSignup(formData);

      if (response.success) {
        // Success - show success view
        setCurrentView("success");
      } else {
        setError(response.message || "Registration failed. Please try again.");
      }
    } catch (err: any) {
      console.error("Registration error:", err);

      // Handle API errors
      if (err.response?.data?.message) {
        setError(err.response.data.message);
      } else if (err.response?.data?.errors) {
        // Handle validation errors
        const errorMessages = Object.values(err.response.data.errors).flat();
        setError(errorMessages.join(", "));
      } else {
        setError("An error occurred during registration. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setSignupData((prev) => {
      const updatedData = { ...prev, [field]: value };

      // If country changes, reset state
      if (field === "country") {
        updatedData.state = "";
        updatedData.emirates = "";
        updatedData.countryName = getCountryNameByCode(value as string);

        console.log("Country changed to:", value);
      }

      // If specialization changes from "Other" to something else, clear other_speciality
      if (field === "specialization" && value !== "Other") {
        updatedData.other_speciality = "";
      }

      return updatedData;
    });

    if (error) setError(""); // Clear error when user starts typing
  };

  // Add helper function to get country name by code
  const getCountryNameByCode = (countryCode: string): string => {
    const country = countries.find((c) => c.country_code === countryCode);
    return country?.country_name || "";
  };

  const handleLoginRedirect = () => {
    router.push("/login");
  };

  const countryNames = getCountryNames();
  const states = getStatesForSelectedCountry();

  return (
    <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2">
      {/* Left side - Sticky */}
      <div className="hidden bg-muted lg:block lg:sticky lg:top-0 lg:h-screen">
        <div className="flex h-full items-center justify-center bg-gradient-to-br from-primary to-secondary p-10">
          <div className="text-center text-white space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold">Join PicPax Portal</h1>
              <p className="text-lg text-white/90 max-w-md">
                Start providing personalized nutrition solutions to your
                patients today.
              </p>
            </div>
            <div className="space-y-3 text-left max-w-sm mx-auto">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">Easy patient management</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Earn commission on every order
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Professional support & training
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="flex items-center justify-center py-12 min-h-screen">
        <div className="mx-auto grid w-[450px] gap-6">
          {/* Logo - Responsive sizing */}
          <div className="text-center mb-6">
            <div className="flex justify-center">
              <img
                src="/images/logo.png"
                alt="PicPax"
                className="h-10 sm:h-12 w-auto object-contain"
              />
            </div>
          </div>

          {/* Sign Up Form */}
          {currentView === "signup" && (
            <>
              <div className="grid gap-2 text-center">
                <h2 className="text-2xl font-bold">Create Account</h2>
                <p className="text-balance text-muted-foreground">
                  Enter your information to create your healthcare provider
                  account
                </p>
              </div>
              <form onSubmit={handleSignupSubmit} className="grid gap-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {/* Personal Information */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="title">Title *</Label>
                    <Select
                      value={signupData.title}
                      onValueChange={(value) =>
                        handleInputChange("title", value)
                      }
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Title" />
                      </SelectTrigger>
                      <SelectContent>
                        {titles.map((title) => (
                          <SelectItem key={title} value={title}>
                            {title}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      placeholder="John"
                      value={signupData.firstName}
                      onChange={(e) =>
                        handleInputChange("firstName", e.target.value)
                      }
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      placeholder="Doe"
                      value={signupData.lastName}
                      onChange={(e) =>
                        handleInputChange("lastName", e.target.value)
                      }
                      required
                    />
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="doctor@example.com"
                    value={signupData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+971 27 052 4601"
                      value={signupData.phone}
                      onChange={(e) =>
                        handleInputChange("phone", e.target.value)
                      }
                      required
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="contact_number">Contact Number</Label>
                    <Input
                      id="contact_number"
                      type="tel"
                      placeholder="+971 27 052 4601"
                      value={signupData.contact_number}
                      onChange={(e) =>
                        handleInputChange("contact_number", e.target.value)
                      }
                    />
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="gender">Gender *</Label>
                  <Select
                    value={signupData.gender}
                    onValueChange={(value) =>
                      handleInputChange("gender", value)
                    }
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Professional Information */}
                <div className="grid gap-2">
                  <Label htmlFor="specialization">Medical Specialty *</Label>
                  <Select
                    value={signupData.specialization}
                    onValueChange={(value) =>
                      handleInputChange("specialization", value)
                    }
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select your specialty" />
                    </SelectTrigger>
                    <SelectContent>
                      {specialties.map((specialty) => (
                        <SelectItem key={specialty} value={specialty}>
                          {specialty}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Other Specialty Input - Only shown when "Other" is selected */}
                {isOtherSpecialtySelected && (
                  <div className="grid gap-2">
                    <Label htmlFor="other_speciality">
                      Specify Your Specialty *
                    </Label>
                    <Input
                      id="other_speciality"
                      placeholder="Enter your medical specialty"
                      value={signupData.other_speciality}
                      onChange={(e) =>
                        handleInputChange("other_speciality", e.target.value)
                      }
                      required
                    />
                  </div>
                )}

                <div className="grid gap-2">
                  <Label htmlFor="clinic_name">Clinic Name *</Label>
                  <Input
                    id="clinic_name"
                    placeholder="Clinic Name"
                    value={signupData.clinic_name}
                    onChange={(e) =>
                      handleInputChange("clinic_name", e.target.value)
                    }
                    required
                  />
                </div>

                {/* Address Information */}
                <div className="space-y-2 ">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="grid gap-2">
                      <Label htmlFor="country">Country *</Label>
                      <Select
                        value={signupData.country}
                        onValueChange={(value) =>
                          handleInputChange("country", value)
                        }
                        disabled={isLoadingCountries}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select country">
                            {signupData.country || "Select country"}
                          </SelectValue>
                        </SelectTrigger>
                        <SelectContent>
                          {countryNames.map((countryName) => (
                            <SelectItem key={countryName} value={countryName}>
                              {countryName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="state">State/Emirate *</Label>
                      <Select
                        value={signupData.state}
                        onValueChange={(value) =>
                          handleInputChange("state", value)
                        }
                        disabled={!signupData.country || states.length === 0}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select state/emirate">
                            {signupData.state || "Select state/emirate"}
                          </SelectValue>
                        </SelectTrigger>
                        <SelectContent>
                          {states.map((state) => (
                            <SelectItem key={state} value={state}>
                              {state}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2 col-span-2">
                      <Label htmlFor="villaApartment">
                        Villa/Apartment Number *
                      </Label>
                      <Input
                        id="villaApartment"
                        value={signupData.villaApartment}
                        onChange={(e) =>
                          handleInputChange("villaApartment", e.target.value)
                        }
                        placeholder="Villa 123, Apt 4B"
                        required
                      />
                    </div>

                    <div className="space-y-2 col-span-2">
                      <Label htmlFor="areaStreet">Area/Street *</Label>
                      <Input
                        id="areaStreet"
                        value={signupData.areaStreet}
                        onChange={(e) =>
                          handleInputChange("areaStreet", e.target.value)
                        }
                        placeholder="Al Nahda, Sheikh Zayed Road"
                        required
                      />
                    </div>

                    <div className="space-y-2 col-span-2">
                      <Label htmlFor="nearbyLandmark">Nearby Landmark</Label>
                      <Input
                        id="nearbyLandmark"
                        value={signupData.nearbyLandmark}
                        onChange={(e) =>
                          handleInputChange("nearbyLandmark", e.target.value)
                        }
                        placeholder="Near Dubai Mall, Next to Metro Station"
                      />
                    </div>
                  </div>
                </div>

                {/* Country and State Selection */}
                <div className="grid grid-cols-2 gap-2"></div>

                <div className="grid gap-2">
                  <Label htmlFor="licenseNumber">Medical License *</Label>
                  <Input
                    id="licenseNumber"
                    placeholder="MD12345"
                    value={signupData.licenseNumber}
                    onChange={(e) =>
                      handleInputChange("licenseNumber", e.target.value)
                    }
                    required
                  />
                </div>

                {/* Document Upload Section */}
                <div className="space-y-4">
                  <DocumentUpload
                    documents={documents}
                    onDocumentsChange={setDocuments}
                    // categories={[
                    //   "Medical License",
                    //   "Degree Certificate",
                    //   "ID Proof",
                    //   "Clinic Registration",
                    //   "Insurance Document",
                    //   "Other",
                    // ]}
                    title="Verification Documents"
                    description="Upload required documents for account verification. All documents must be clear and valid."
                  />
                </div>

                {/* Password Fields */}
                <div className="grid gap-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Create a strong password"
                      value={signupData.password}
                      onChange={(e) =>
                        handleInputChange("password", e.target.value)
                      }
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Must be at least 8 characters long
                  </p>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="confirmPassword">Confirm Password</Label>
                  <div className="relative">
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Confirm your password"
                      value={signupData.confirmPassword}
                      onChange={(e) =>
                        handleInputChange("confirmPassword", e.target.value)
                      }
                      required
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>

                {/* Terms and Conditions */}
                <div className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="terms"
                      checked={signupData.agreeToTerms}
                      onCheckedChange={(checked) =>
                        handleInputChange("agreeToTerms", checked as boolean)
                      }
                      className="mt-1"
                    />
                    <Label htmlFor="terms" className="text-sm leading-5">
                      I agree to the{" "}
                      <Button
                        variant="link"
                        className="p-0 h-auto text-sm underline"
                      >
                        Terms of Service
                      </Button>{" "}
                      and{" "}
                      <Button
                        variant="link"
                        className="p-0 h-auto text-sm underline"
                      >
                        Privacy Policy
                      </Button>
                    </Label>
                  </div>
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="marketing"
                      checked={signupData.agreeToMarketing}
                      onCheckedChange={(checked) =>
                        handleInputChange(
                          "agreeToMarketing",
                          checked as boolean
                        )
                      }
                      className="mt-1"
                    />
                    <Label htmlFor="marketing" className="text-sm leading-5">
                      I would like to receive marketing communications and
                      product updates
                    </Label>
                  </div>
                </div>

                <Button type="submit" className="w-full" disabled={isLoading}>
                  {isLoading ? "Creating Account..." : "Create Account"}
                </Button>
              </form>
              <div className="mt-4 text-center text-sm">
                Already have an account?{" "}
                <Link href="/login" className="underline">
                  Sign in
                </Link>
              </div>
            </>
          )}

          {/* Success View */}
          {currentView === "success" && (
            <>
              <div className="grid gap-2 text-center">
                <div className="flex justify-center mb-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                    <CheckCircle className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <h2 className="text-2xl font-bold">Account Created!</h2>
                <p className="text-balance text-muted-foreground">
                  Welcome to PicPax Portal, {signupData.title}{" "}
                  {signupData.firstName} {signupData.lastName}
                </p>
              </div>
              <div className="grid gap-4">
                <div className="rounded-lg border bg-card p-4 text-sm">
                  <p className="font-medium mb-2">What happens next?</p>
                  <ul className="space-y-1 text-muted-foreground">
                    <li>• Your account is being reviewed by our team</li>
                    <li>
                      • You'll receive a verification email within 24 hours
                    </li>
                    <li>• Once approved, you can start managing patients</li>
                    <li>• Our support team will contact you for onboarding</li>
                  </ul>
                </div>
                <div className="rounded-lg border bg-blue-50 p-4 text-sm">
                  <p className="font-medium text-blue-900 mb-2">
                    Account Details
                  </p>
                  <div className="space-y-1 text-blue-800">
                    <p>
                      <strong>Name:</strong> {signupData.title}{" "}
                      {signupData.firstName} {signupData.lastName}
                    </p>
                    <p>
                      <strong>Email:</strong> {signupData.email}
                    </p>
                    <p>
                      <strong>Specialty:</strong> {signupData.specialization}
                      {isOtherSpecialtySelected &&
                        ` - ${signupData.other_speciality}`}
                    </p>
                    <p>
                      <strong>Clinic Name:</strong> {signupData.clinic_name}
                    </p>
                    <p>
                      <strong>Country:</strong> {signupData.country}
                    </p>
                    <p>
                      <strong>Location:</strong>{" "}
                      {signupData.state || signupData.emirates}
                    </p>
                  </div>
                </div>
                <Button onClick={handleLoginRedirect} className="w-full">
                  Continue to Login
                </Button>
                <div className="text-center text-sm text-muted-foreground">
                  Need help?{" "}
                  <Button
                    variant="link"
                    className="p-0 h-auto text-sm underline"
                  >
                    Contact Support
                  </Button>
                </div>
              </div>
            </>
          )}

          {/* Application Process Info */}
          {currentView === "signup" && (
            <div className="rounded-lg border bg-muted/50 p-4 text-center">
              <h3 className="font-semibold mb-2">Application Process</h3>
              <div className="text-sm space-y-1 text-muted-foreground">
                <p>• Account review within 24 hours</p>
                <p>• Medical license verification required</p>
                <p>• Free onboarding and training provided</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
