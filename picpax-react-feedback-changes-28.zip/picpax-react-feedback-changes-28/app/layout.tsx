import type React from "react";
import ClientLayout from "./ClientLayout";

export const metadata = {
  title: "PicPax Doctor Portal",
  description:
    "Comprehensive nutrition management portal for healthcare professionals and administrators",
  generator: "Next.js",
  keywords: [
    "healthcare",
    "nutrition",
    "doctor",
    "supplements",
    "patient management",
  ],
  authors: [{ name: "PicPax Team" }],
  openGraph: {
    title: "PicPax Doctor Portal",
    description:
      "Comprehensive nutrition management portal for healthcare professionals",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "PicPax Doctor Portal",
    description:
      "Comprehensive nutrition management portal for healthcare professionals",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <ClientLayout>{children}</ClientLayout>;
}
