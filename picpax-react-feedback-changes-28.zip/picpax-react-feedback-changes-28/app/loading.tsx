export default function Loading() {
  return (
    <div className="min-h-[60vh] p-4 sm:p-6 space-y-6">
      {/* Thin top bar placeholder */}
      <div className="h-1 w-full bg-gray-100 overflow-hidden rounded">
        <div className="h-full w-1/3 bg-gradient-to-r from-sky-500 to-violet-500 animate-pulse" />
      </div>

      {/* Title placeholder */}
      <div className="h-8 w-48 rounded-md bg-gray-200 animate-pulse" />

      {/* Cards placeholder */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <div className="h-28 rounded-lg bg-gray-100 animate-pulse" />
        <div className="h-28 rounded-lg bg-gray-100 animate-pulse" />
        <div className="h-28 rounded-lg bg-gray-100 animate-pulse" />
      </div>

      {/* Table/content block placeholder */}
      <div className="h-96 rounded-lg bg-gray-100 animate-pulse" />
    </div>
  );
}
