// Updated CommissionTrackingPage (component 1)
"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DollarSign,
  TrendingUp,
  Clock,
  CheckCircle,
  Loader2,
} from "lucide-react";
// import { CommissionDataTableApi } from "@/components/commission/commission-data-table-api";
import {
  commissionColumns,
  type CommissionOrder,
} from "@/components/commission/commission-columns";
// import { getCommissions } from "@/services/axiosInstance";
import { useEffect, useState } from "react";
import { getCommissions } from "@/lib/orderService";
import { CommissionDataTableApi } from "@/components/commission/commission-data-table";
import { DirhamIcon } from "@/components/ui/DirhamIcon";

export default function CommissionTrackingPage() {
  const [summaryData, setSummaryData] = useState({
    totalEarnings: 0,
    thisMonth: 0,
    lastMonth: 0,
    pendingCommission: 0,
    paidCommission: 0,
  });

  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchCommissionSummary = async () => {
      try {
        setIsLoading(true);
        const response: any = await getCommissions({ per_page: 1 });

        if (response.success) {
          const summary = response.data.summary;
          setSummaryData({
            totalEarnings: summary.total_commission_amount,
            thisMonth: summary.this_month_commissions_amount, // You might want to adjust this based on your API
            lastMonth: summary.last_month_commissions_amount, // Example calculation
            pendingCommission: summary?.pending_commissions_amount,
            paidCommission: summary?.completed_commissions_amount,
          });
        }
      } catch (error) {
        console.error("Error fetching commission summary:", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchCommissionSummary();
  }, []);

  const monthlyGrowth =
    summaryData.lastMonth > 0
      ? ((summaryData.thisMonth - summaryData.lastMonth) /
          summaryData.lastMonth) *
        100
      : 0;

  const handleSummaryUpdate = (newSummary: any) => {
    setSummaryData({
      totalEarnings: newSummary.total_commission_amount,
      thisMonth: newSummary?.this_month_commissions_amount,
      lastMonth: newSummary.last_month_commissions_amount,
      pendingCommission: newSummary?.pending_commissions_amount,
      paidCommission: newSummary?.completed_commissions_amount,
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <Loader2 className="h-16 w-16 text-muted-foreground mx-auto mb-4 animate-spin" />
          <h3 className="text-lg font-medium mb-2">Loading...</h3>
          <p className="text-muted-foreground">commission data</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">
          Commission Tracking
        </h1>
        <p className="text-muted-foreground">
          Monitor your earnings and commission payments
        </p>
      </div>

      {/* Commission Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Earnings
            </CardTitle>
            <DirhamIcon className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              <DirhamIcon />
              {summaryData.totalEarnings}
            </div>
            <p className="text-xs text-muted-foreground">All time earnings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              <DirhamIcon />
              {summaryData.thisMonth}
            </div>
            <p className="text-xs text-muted-foreground">
              {monthlyGrowth >= 0 ? "+" : ""}
              {monthlyGrowth.toFixed(1)}% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">
              <DirhamIcon />
              {summaryData.pendingCommission}
            </div>
            <p className="text-xs text-muted-foreground">Awaiting payment</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paid</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              <DirhamIcon />
              {summaryData.paidCommission}
            </div>
            <p className="text-xs text-muted-foreground">
              From completed orders
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Commission History - Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>Commission History</CardTitle>
          <CardDescription>
            Your commission earnings with advanced filtering and sorting
          </CardDescription>
        </CardHeader>
        <CardContent>
          <CommissionDataTableApi
            columns={commissionColumns}
            canExport={true}
            onSummaryUpdate={handleSummaryUpdate}
          />
        </CardContent>
      </Card>

      {/* Monthly Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Monthly Comparison</CardTitle>
          <CardDescription>Commission earnings comparison</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="p-4 border rounded-lg">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">This Month</span>
                <span className="text-lg font-bold text-green-600">
                  <DirhamIcon />
                  {summaryData.thisMonth}
                </span>
              </div>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Last Month</span>
                <span className="text-lg font-bold text-muted-foreground">
                  <DirhamIcon />
                  {summaryData.lastMonth}
                </span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
