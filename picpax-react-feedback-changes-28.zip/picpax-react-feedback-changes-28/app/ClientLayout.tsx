"use client";

import type React from "react";
import { Inter } from "next/font/google";
import "./globals.css";
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { AdminSidebar } from "@/components/admin-sidebar";
import { AuthProvider, useAuth } from "@/lib/auth-context";
import { usePathname } from "next/navigation";
import AuthLoading from "@/components/auth-loading";
import { Toaster } from "@/components/toaster";
import RouteProgress from "@/components/route-progress";
import { Provider } from "react-redux";
import { PersistGate } from "redux-persist/integration/react";
import { store, persistor } from "@/store/store";

const inter = Inter({ subsets: ["latin"] });

interface Props {
  children: React.ReactNode;
}

export default function ClientLayout({ children }: Props) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Provider store={store}>
          <PersistGate loading={null} persistor={persistor}>
            <AuthProvider>
              <RouteProgress />
              <AppContent>{children}</AppContent>
              <Toaster />
            </AuthProvider>
          </PersistGate>
        </Provider>
      </body>
    </html>
  );
}

function AppContent({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const pathname = usePathname();

  // Show loading while checking authentication
  if (isLoading) {
    return <AuthLoading />;
  }

  // Show public pages without sidebar
  const isPublic =
    pathname === "/login" ||
    pathname === "/signup" ||
    pathname.startsWith("/staff/login") ||
    pathname === "/admin/login" ||
    pathname.startsWith("/reset-password");

  if (isPublic) {
    return <div className="min-h-screen">{children}</div>;
  }

  // Block protected content until auth redirect occurs
  if (!user) {
    return <AuthLoading />;
  }

  // Show admin portal with admin sidebar for admin users
  if (
    pathname.startsWith("/admin/") &&
    (user.role === "admin" ||
      user.role === "super admin" ||
      user.type === "system")
  ) {
    return (
      <SidebarProvider>
        <AdminSidebar />
        <SidebarInset>
          <main className="flex-1 p-4 sm:p-6">{children}</main>
        </SidebarInset>
      </SidebarProvider>
    );
  }

  // Show portal with sidebar for authenticated users
  return (
    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <main className="flex-1 p-4 sm:p-6">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  );
}
