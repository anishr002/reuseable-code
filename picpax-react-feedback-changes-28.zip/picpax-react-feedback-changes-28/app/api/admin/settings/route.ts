import { NextRequest, NextResponse } from 'next/server'

// Mock system settings
const mockSettings = {
  general: {
    siteName: "PicPax Health Portal",
    siteUrl: "https://picpax.com",
    adminEmail: "admin@picpax.com",
    supportPhone: "+1 (555) 123-4567",
    supportEmail: "support@picpax.com",
    address: "123 Health St, Medical City, MC 12345",
    timezone: "America/New_York",
    currency: "USD",
  },
  commission: {
    defaultRate: 20,
    minimumPayout: 50,
    payoutFrequency: "monthly",
    autoPayout: true,
    payoutProcessingDay: 1,
  },
  notifications: {
    emailNotifications: true,
    pushNotifications: true,
    newOrderAlert: true,
    commissionAlert: true,
    doctorRegistrationAlert: true,
    systemAlerts: true,
  },
  security: {
    sessionTimeout: 30,
    maxLoginAttempts: 5,
    passwordExpiry: 90,
    twoFactorAuth: true,
    ipWhitelist: "",
  },
  integrations: {
    paymentGateway: "stripe",
    emailProvider: "sendgrid",
    smsProvider: "twilio",
    analyticsProvider: "google-analytics",
  },
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const category = searchParams.get('category')
  
  if (category && category in mockSettings) {
    return NextResponse.json({
      success: true,
      data: mockSettings[category as keyof typeof mockSettings]
    })
  }
  
  return NextResponse.json({
    success: true,
    data: mockSettings
  })
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json()
    const { category, settings } = body
    
    if (!category || !settings) {
      return NextResponse.json({
        success: false,
        message: "Category and settings are required"
      }, { status: 400 })
    }
    
    if (category in mockSettings) {
      // In a real application, you would update the settings in a database
      // For now, we'll just simulate the update
      Object.assign(mockSettings[category as keyof typeof mockSettings], settings)
      
      return NextResponse.json({
        success: true,
        data: mockSettings[category as keyof typeof mockSettings],
        message: "Settings updated successfully"
      })
    }
    
    return NextResponse.json({
      success: false,
      message: "Invalid category"
    }, { status: 400 })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "Failed to update settings"
    }, { status: 400 })
  }
}