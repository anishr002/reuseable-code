import { NextRequest, NextResponse } from 'next/server'

// Mock orders data
const mockOrders = [
  {
    id: "ORD_001",
    doctorName: "Dr. Sarah Johnson",
    doctorClinic: "MediCenter Clinic",
    patientName: "John Smith",
    patientEmail: "john.smith@email.com",
    amount: 120,
    status: "Completed",
    date: "2024-01-15",
    products: ["Vitamin D3", "Omega-3", "Probiotics"],
    commission: 24,
  },
  {
    id: "ORD_002",
    doctorName: "Dr. Michael Chen",
    doctorClinic: "Health First Medical",
    patientName: "Emma Davis",
    patientEmail: "emma.davis@email.com",
    amount: 85,
    status: "Processing",
    date: "2024-01-16",
    products: ["Multivitamin", "Calcium"],
    commission: 15.3,
  },
  {
    id: "ORD_003",
    doctorName: "Dr. James Wilson",
    doctorClinic: "Care Plus Clinic",
    patientName: "Robert Brown",
    patientEmail: "robert.brown@email.com",
    amount: 200,
    status: "Pending",
    date: "2024-01-17",
    products: ["Vitamin C", "Zinc", "Elderberry", "Echinacea"],
    commission: 44,
  },
  {
    id: "ORD_004",
    doctorName: "Dr. Emily Rodriguez",
    doctorClinic: "Wellness Center",
    patientName: "Lisa Garcia",
    patientEmail: "lisa.garcia@email.com",
    amount: 150,
    status: "Completed",
    date: "2024-01-14",
    products: ["Iron", "B-Complex", "Magnesium"],
    commission: 22.5,
  },
  {
    id: "ORD_005",
    doctorName: "Dr. Sarah Johnson",
    doctorClinic: "MediCenter Clinic",
    patientName: "David Lee",
    patientEmail: "david.lee@email.com",
    amount: 95,
    status: "Processing",
    date: "2024-01-18",
    products: ["Vitamin B12", "Vitamin D3"],
    commission: 19,
  },
  {
    id: "ORD_006",
    doctorName: "Dr. Michael Chen",
    doctorClinic: "Health First Medical",
    patientName: "Maria Rodriguez",
    patientEmail: "maria.rodriguez@email.com",
    amount: 180,
    status: "Completed",
    date: "2024-01-13",
    products: ["CoQ10", "Fish Oil", "Vitamin E"],
    commission: 32.4,
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const status = searchParams.get('status')
  const doctor = searchParams.get('doctor')
  const search = searchParams.get('search')
  
  let filteredOrders = mockOrders
  
  if (status && status !== 'all') {
    filteredOrders = filteredOrders.filter(order => order.status === status)
  }
  
  if (doctor && doctor !== 'all') {
    filteredOrders = filteredOrders.filter(order => order.doctorName === doctor)
  }
  
  if (search) {
    filteredOrders = filteredOrders.filter(order => 
      order.id.toLowerCase().includes(search.toLowerCase()) ||
      order.doctorName.toLowerCase().includes(search.toLowerCase()) ||
      order.patientName.toLowerCase().includes(search.toLowerCase()) ||
      order.patientEmail.toLowerCase().includes(search.toLowerCase())
    )
  }
  
  // Calculate summary statistics
  const totalRevenue = filteredOrders.reduce((sum, order) => sum + order.amount, 0)
  const totalCommission = filteredOrders.reduce((sum, order) => sum + order.commission, 0)
  const completedOrders = filteredOrders.filter(order => order.status === 'Completed').length
  const processingOrders = filteredOrders.filter(order => order.status === 'Processing').length
  const pendingOrders = filteredOrders.filter(order => order.status === 'Pending').length
  
  const uniqueDoctors = [...new Set(filteredOrders.map(order => order.doctorName))]
  
  const doctorSummary = uniqueDoctors.map(doctorName => {
    const doctorOrders = filteredOrders.filter(order => order.doctorName === doctorName)
    const doctorRevenue = doctorOrders.reduce((sum, order) => sum + order.amount, 0)
    const doctorCommission = doctorOrders.reduce((sum, order) => sum + order.commission, 0)
    
    return {
      doctorName,
      orderCount: doctorOrders.length,
      revenue: doctorRevenue,
      commission: doctorCommission
    }
  })
  
  return NextResponse.json({
    success: true,
    data: {
      orders: filteredOrders,
      summary: {
        totalOrders: filteredOrders.length,
        totalRevenue,
        totalCommission,
        completedOrders,
        processingOrders,
        pendingOrders
      },
      doctorSummary
    }
  })
}