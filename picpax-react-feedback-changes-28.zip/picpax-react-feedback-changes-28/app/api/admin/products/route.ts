import { NextRequest, NextResponse } from 'next/server'

// Mock products data with Shopify-like structure
const mockProducts = [
  {
    id: "PROD_001",
    shopifyId: "8204862998828",
    title: "Vitamin D3 5000 IU",
    description: "High-potency Vitamin D3 supplement for immune health and bone strength",
    vendor: "PicPax Supplements",
    productType: "Vitamins",
    tags: ["vitamin", "immunity", "bone-health", "d3"],
    status: "active",
    inventory: {
      available: 245,
      locations: [
        { name: "Main Warehouse", available: 150 },
        { name: "East Coast", available: 95 }
      ]
    },
    pricing: {
      price: 24.99,
      compareAtPrice: 29.99,
      cost: 12.50,
      currency: "USD"
    },
    variants: [
      {
        id: "VAR_001",
        title: "Default",
        sku: "VIT-D3-5000-60",
        price: 24.99,
        inventory: 245
      }
    ],
    images: [
      {
        id: "IMG_001",
        src: "https://via.placeholder.com/300x300/4F46E5/white?text=Vitamin+D3",
        alt: "Vitamin D3 Bottle"
      }
    ],
    createdAt: "2024-01-15T10:30:00Z",
    updatedAt: "2024-01-18T14:45:00Z",
    shopifySync: {
      lastSync: "2024-01-18T14:45:00Z",
      syncStatus: "synced",
      shopifyUrl: "https://picpax.myshopify.com/products/vitamin-d3-5000-iu"
    }
  },
  {
    id: "PROD_002",
    shopifyId: "8204863031596",
    title: "Omega-3 Fish Oil 1000mg",
    description: "Premium molecularly distilled fish oil for heart and brain health",
    vendor: "PicPax Supplements",
    productType: "Omega-3",
    tags: ["omega-3", "fish-oil", "heart-health", "epa-dha"],
    status: "active",
    inventory: {
      available: 189,
      locations: [
        { name: "Main Warehouse", available: 120 },
        { name: "East Coast", available: 69 }
      ]
    },
    pricing: {
      price: 34.99,
      compareAtPrice: null,
      cost: 18.75,
      currency: "USD"
    },
    variants: [
      {
        id: "VAR_002",
        title: "60 Softgels",
        sku: "OMG3-1000-60",
        price: 34.99,
        inventory: 120
      },
      {
        id: "VAR_003",
        title: "120 Softgels",
        sku: "OMG3-1000-120",
        price: 59.99,
        inventory: 69
      }
    ],
    images: [
      {
        id: "IMG_002",
        src: "https://via.placeholder.com/300x300/059669/white?text=Omega-3",
        alt: "Omega-3 Fish Oil Bottle"
      }
    ],
    createdAt: "2024-01-10T09:15:00Z",
    updatedAt: "2024-01-18T14:45:00Z",
    shopifySync: {
      lastSync: "2024-01-18T14:45:00Z",
      syncStatus: "synced",
      shopifyUrl: "https://picpax.myshopify.com/products/omega-3-fish-oil-1000mg"
    }
  },
  {
    id: "PROD_003",
    shopifyId: "8204863064364",
    title: "Probiotic 50 Billion CFU",
    description: "Multi-strain probiotic for digestive health and immune support",
    vendor: "PicPax Supplements",
    productType: "Probiotics",
    tags: ["probiotic", "digestive-health", "immunity", "gut-health"],
    status: "active",
    inventory: {
      available: 78,
      locations: [
        { name: "Main Warehouse", available: 50 },
        { name: "East Coast", available: 28 }
      ]
    },
    pricing: {
      price: 42.99,
      compareAtPrice: 49.99,
      cost: 22.00,
      currency: "USD"
    },
    variants: [
      {
        id: "VAR_004",
        title: "30 Capsules",
        sku: "PRO-50B-30",
        price: 42.99,
        inventory: 78
      }
    ],
    images: [
      {
        id: "IMG_003",
        src: "https://via.placeholder.com/300x300/DC2626/white?text=Probiotic",
        alt: "Probiotic Bottle"
      }
    ],
    createdAt: "2024-01-08T11:20:00Z",
    updatedAt: "2024-01-18T14:45:00Z",
    shopifySync: {
      lastSync: "2024-01-18T14:45:00Z",
      syncStatus: "synced",
      shopifyUrl: "https://picpax.myshopify.com/products/probiotic-50-billion-cfu"
    }
  },
  {
    id: "PROD_004",
    shopifyId: "8204863097132",
    title: "Magnesium Glycinate 400mg",
    description: "Highly bioavailable magnesium for muscle relaxation and sleep",
    vendor: "PicPax Supplements",
    productType: "Minerals",
    tags: ["magnesium", "sleep", "muscle-relaxation", "mineral"],
    status: "draft",
    inventory: {
      available: 0,
      locations: [
        { name: "Main Warehouse", available: 0 },
        { name: "East Coast", available: 0 }
      ]
    },
    pricing: {
      price: 28.99,
      compareAtPrice: null,
      cost: 14.50,
      currency: "USD"
    },
    variants: [
      {
        id: "VAR_005",
        title: "120 Tablets",
        sku: "MAG-GLY-400-120",
        price: 28.99,
        inventory: 0
      }
    ],
    images: [
      {
        id: "IMG_004",
        src: "https://via.placeholder.com/300x300/7C3AED/white?text=Magnesium",
        alt: "Magnesium Bottle"
      }
    ],
    createdAt: "2024-01-18T16:00:00Z",
    updatedAt: "2024-01-18T16:00:00Z",
    shopifySync: {
      lastSync: null,
      syncStatus: "not_synced",
      shopifyUrl: null
    }
  }
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const status = searchParams.get('status')
  const type = searchParams.get('type')
  const search = searchParams.get('search')
  
  let filteredProducts = mockProducts
  
  if (status && status !== 'all') {
    filteredProducts = filteredProducts.filter(product => product.status === status)
  }
  
  if (type && type !== 'all') {
    filteredProducts = filteredProducts.filter(product => product.productType === type)
  }
  
  if (search) {
    filteredProducts = filteredProducts.filter(product => 
      product.title.toLowerCase().includes(search.toLowerCase()) ||
      product.description.toLowerCase().includes(search.toLowerCase()) ||
      product.variants.some((v: any) => v.sku?.toLowerCase().includes(search.toLowerCase())) ||
      product.tags.some(tag => tag.toLowerCase().includes(search.toLowerCase()))
    )
  }
  
  // Calculate summary statistics
  const totalInventory = filteredProducts.reduce((sum, product) => sum + product.inventory.available, 0)
  const totalValue = filteredProducts.reduce((sum, product) => sum + (product.pricing.price * product.inventory.available), 0)
  const activeProducts = filteredProducts.filter(p => p.status === 'active').length
  const draftProducts = filteredProducts.filter(p => p.status === 'draft').length
  const syncedProducts = filteredProducts.filter(p => p.shopifySync.syncStatus === 'synced').length
  
  const uniqueProductTypes = [...new Set(filteredProducts.map(product => product.productType))]
  
  return NextResponse.json({
    success: true,
    data: {
      products: filteredProducts,
      summary: {
        totalProducts: filteredProducts.length,
        totalInventory,
        totalValue,
        activeProducts,
        draftProducts,
        syncedProducts,
        uniqueProductTypes: uniqueProductTypes.length
      }
    }
  })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { action, productId, productData } = body
    
    if (action === 'create') {
      const newProduct = {
        id: `PROD_${String(mockProducts.length + 1).padStart(3, '0')}`,
        shopifyId: `820486${String(Date.now()).slice(-8)}`,
        ...productData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        shopifySync: {
          lastSync: null,
          syncStatus: "not_synced",
          shopifyUrl: null
        }
      }
      
      mockProducts.push(newProduct)
      
      return NextResponse.json({
        success: true,
        data: newProduct,
        message: "Product created successfully"
      })
    }
    
    if (action === 'update') {
      const productIndex = mockProducts.findIndex(p => p.id === productId)
      
      if (productIndex === -1) {
        return NextResponse.json({
          success: false,
          message: "Product not found"
        }, { status: 404 })
      }
      
      mockProducts[productIndex] = {
        ...mockProducts[productIndex],
        ...productData,
        updatedAt: new Date().toISOString()
      }
      
      return NextResponse.json({
        success: true,
        data: mockProducts[productIndex],
        message: "Product updated successfully"
      })
    }
    
    if (action === 'sync') {
      const productIndex = mockProducts.findIndex(p => p.id === productId)
      
      if (productIndex === -1) {
        return NextResponse.json({
          success: false,
          message: "Product not found"
        }, { status: 404 })
      }
      
      mockProducts[productIndex] = {
        ...mockProducts[productIndex],
        shopifySync: {
          lastSync: new Date().toISOString(),
          syncStatus: "synced",
          shopifyUrl: `https://picpax.myshopify.com/products/${mockProducts[productIndex].title.toLowerCase().replace(/\s+/g, '-')}`
        },
        updatedAt: new Date().toISOString()
      }
      
      return NextResponse.json({
        success: true,
        data: mockProducts[productIndex],
        message: "Product synced successfully"
      })
    }
    
    if (action === 'bulk_sync') {
      const updatedProducts = mockProducts.map(product => ({
        ...product,
        shopifySync: {
          lastSync: new Date().toISOString(),
          syncStatus: "synced",
          shopifyUrl: `https://picpax.myshopify.com/products/${product.title.toLowerCase().replace(/\s+/g, '-')}`
        },
        updatedAt: new Date().toISOString()
      }))
      
      // In a real implementation, you would update the database
      mockProducts.splice(0, mockProducts.length, ...updatedProducts)
      
      return NextResponse.json({
        success: true,
        data: {
          syncedProducts: updatedProducts.length,
          message: "Bulk sync completed successfully"
        }
      })
    }
    
    return NextResponse.json({
      success: false,
      message: "Invalid action"
    }, { status: 400 })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "Failed to process request"
    }, { status: 400 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const productId = searchParams.get('id')
    
    if (!productId) {
      return NextResponse.json({
        success: false,
        message: "Product ID is required"
      }, { status: 400 })
    }
    
    const productIndex = mockProducts.findIndex(p => p.id === productId)
    
    if (productIndex === -1) {
      return NextResponse.json({
        success: false,
        message: "Product not found"
      }, { status: 404 })
    }
    
    const deletedProduct = mockProducts.splice(productIndex, 1)[0]
    
    return NextResponse.json({
      success: true,
      data: deletedProduct,
      message: "Product deleted successfully"
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "Failed to delete product"
    }, { status: 400 })
  }
}