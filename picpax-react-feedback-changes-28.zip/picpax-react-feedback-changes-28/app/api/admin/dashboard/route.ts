import { NextRequest, NextResponse } from 'next/server'

// Mock dashboard data
const mockDashboardData = {
  totalDoctors: 12,
  activeDoctors: 10,
  totalPatients: 248,
  totalOrders: 156,
  completedOrders: 142,
  pendingOrders: 14,
  totalRevenue: 45680,
  monthlyRevenue: 12800,
  totalCommission: 9136,
  monthlyCommission: 2560,
  recentDoctors: [
    { id: "doc_001", name: "Dr. Sarah Johnson", clinic: "MediCenter Clinic", status: "Active", patients: 45 },
    { id: "doc_002", name: "Dr. Michael Chen", clinic: "Health First Medical", status: "Active", patients: 38 },
    { id: "doc_003", name: "Dr. Emily Rodriguez", clinic: "Wellness Center", status: "Inactive", patients: 22 },
  ],
  recentOrders: [
    { id: "ORD_001", doctor: "Dr. Sarah Johnson", patient: "John Smith", amount: 120, status: "Completed" },
    { id: "ORD_002", doctor: "Dr. Michael Chen", patient: "Emma Davis", amount: 85, status: "Processing" },
    { id: "ORD_003", doctor: "Dr. James Wilson", patient: "Robert Brown", amount: 200, status: "Pending" },
  ],
  systemStats: {
    activeUsers: 24,
    serverUptime: "99.9%",
    lastBackup: "2024-01-18 02:00:00",
    storageUsed: "45%",
    memoryUsage: "67%"
  }
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const period = searchParams.get('period') || 'all'
  
  // In a real application, you would filter data based on the period
  // For now, we'll return the same mock data regardless of period
  
  return NextResponse.json({
    success: true,
    data: mockDashboardData,
    meta: {
      period,
      generatedAt: new Date().toISOString(),
      version: "1.0"
    }
  })
}