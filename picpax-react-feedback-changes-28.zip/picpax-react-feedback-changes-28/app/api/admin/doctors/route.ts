import { NextRequest, NextResponse } from 'next/server'

// Mock doctors data
const mockDoctors = [
  {
    id: "doc_001",
    name: "Dr. Sarah Johnson",
    email: "sarah.johnson@medicenter.com",
    phone: "+1 (555) 123-4567",
    clinic: "MediCenter Clinic",
    address: "123 Medical Ave, New York, NY 10001",
    status: "Active",
    patients: 45,
    totalOrders: 78,
    joinDate: "2023-01-15",
    commission: 20,
  },
  {
    id: "doc_002",
    name: "Dr. Michael Chen",
    email: "michael.chen@healthfirst.com",
    phone: "+1 (555) 234-5678",
    clinic: "Health First Medical",
    address: "456 Health St, Los Angeles, CA 90001",
    status: "Active",
    patients: 38,
    totalOrders: 65,
    joinDate: "2023-02-20",
    commission: 18,
  },
  {
    id: "doc_003",
    name: "Dr. Emily Rodriguez",
    email: "emily.rodriguez@wellness.com",
    phone: "+1 (555) 345-6789",
    clinic: "Wellness Center",
    address: "789 Wellness Blvd, Chicago, IL 60001",
    status: "Inactive",
    patients: 22,
    totalOrders: 34,
    joinDate: "2023-03-10",
    commission: 15,
  },
  {
    id: "doc_004",
    name: "Dr. James Wilson",
    email: "james.wilson@careplus.com",
    phone: "+1 (555) 456-7890",
    clinic: "Care Plus Clinic",
    address: "321 Care Lane, Houston, TX 70001",
    status: "Active",
    patients: 31,
    totalOrders: 52,
    joinDate: "2023-04-05",
    commission: 22,
  },
]

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const status = searchParams.get('status')
  const search = searchParams.get('search')
  
  let filteredDoctors = mockDoctors
  
  if (status && status !== 'all') {
    filteredDoctors = filteredDoctors.filter(doctor => doctor.status === status)
  }
  
  if (search) {
    filteredDoctors = filteredDoctors.filter(doctor => 
      doctor.name.toLowerCase().includes(search.toLowerCase()) ||
      doctor.clinic.toLowerCase().includes(search.toLowerCase()) ||
      doctor.email.toLowerCase().includes(search.toLowerCase())
    )
  }
  
  return NextResponse.json({
    success: true,
    data: filteredDoctors,
    total: filteredDoctors.length
  })
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const newDoctor = {
      id: `doc_${String(mockDoctors.length + 1).padStart(3, '0')}`,
      name: body.name,
      email: body.email,
      phone: body.phone,
      clinic: body.clinic,
      address: body.address,
      status: body.status || "Active",
      patients: body.patients || 0,
      totalOrders: body.totalOrders || 0,
      joinDate: body.joinDate || new Date().toISOString().split('T')[0],
      commission: body.commission || 20,
    }
    
    mockDoctors.push(newDoctor)
    
    return NextResponse.json({
      success: true,
      data: newDoctor,
      message: "Doctor created successfully"
    })
  } catch (error) {
    return NextResponse.json({
      success: false,
      message: "Failed to create doctor"
    }, { status: 400 })
  }
}