"use client";

import type React from "react";
import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Eye,
  EyeOff,
  AlertCircle,
  CheckCircle,
  ArrowLeft,
  Mail,
} from "lucide-react";
import { resetPasswordApi } from "@/lib/userService";

// Zod schema for form validation
const createPasswordSchema = z
  .object({
    password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(
        /[^A-Za-z0-9]/,
        "Password must contain at least one special character"
      ),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

type CreatePasswordFormData = z.infer<typeof createPasswordSchema>;

export default function CreateNewPasswordPage() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [token, setToken] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
  } = useForm<CreatePasswordFormData>({
    resolver: zodResolver(createPasswordSchema),
  });

  // Get token and email from URL parameters
  useEffect(() => {
    const urlToken = searchParams.get("token");
    const urlEmail = searchParams.get("email");

    if (urlToken) {
      setToken(urlToken);
    } else {
      setError("Invalid or missing reset token");
    }

    if (urlEmail) {
      setEmail(urlEmail);
    } else {
      setError("Email parameter is missing");
    }
  }, [searchParams]);

  const onSubmit = async (data: CreatePasswordFormData) => {
    if (!token || !email) {
      setError("Missing required parameters");
      return;
    }

    setIsLoading(true);
    setError("");
    setSuccess("");

    try {
      // Call the actual reset password API
      const resp = await resetPasswordApi({
        email: email,
        token: token,
        password: data.password,
        password_confirmation: data.confirmPassword,
      });

      // Response shape example from backend:
      // { message, email, role, reset_at }
      const apiMessage =
        resp?.message || resp?.data?.message || "Password reset successfully!";
      const apiRole = (resp?.role || resp?.data?.role || "")
        .toString()
        .toLowerCase()
        .trim();

      setSuccess(apiMessage + " Redirecting...");

      // Decide redirect based on role returned by API
      const dest = apiRole === "doctor" ? "/login" : "/staff/login";

      setTimeout(() => {
        router.push(dest);
      }, 2000);
    } catch (err: any) {
      setError(
        err.response?.data?.message ||
          err.message ||
          "Failed to reset password. Please try again."
      );
      console.error("Password reset error:", err);
    } finally {
      setIsLoading(false);
    }
  };

  const passwordValue = watch("password");

  const getPasswordStrength = (password: string) => {
    if (!password) return { strength: 0, label: "" };

    let strength = 0;
    if (password.length >= 8) strength += 1;
    if (/[A-Z]/.test(password)) strength += 1;
    if (/[a-z]/.test(password)) strength += 1;
    if (/[0-9]/.test(password)) strength += 1;
    if (/[^A-Za-z0-9]/.test(password)) strength += 1;

    const labels = [
      "Very Weak",
      "Weak",
      "Fair",
      "Good",
      "Strong",
      "Very Strong",
    ];
    return { strength, label: labels[strength] };
  };

  const passwordStrength = getPasswordStrength(passwordValue || "");

  return (
    <div className="w-full lg:grid lg:min-h-screen lg:grid-cols-2">
      {/* Left side - Sticky */}
      <div className="hidden bg-muted lg:block lg:sticky lg:top-0 lg:h-screen">
        <div className="flex h-full items-center justify-center bg-gradient-to-br from-primary to-secondary p-10">
          <div className="text-center text-white space-y-6">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold">PicPax Portal</h1>
              <p className="text-lg text-white/90 max-w-md">
                Your comprehensive healthcare nutrition management platform for
                better patient outcomes.
              </p>
            </div>
            <div className="space-y-3 text-left max-w-sm mx-auto">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Personalized supplement prescriptions
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">Patient management system</span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-white rounded-full"></div>
                <span className="text-white/90">
                  Commission tracking & analytics
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Right side - Form */}
      <div className="flex items-center justify-center py-8 min-h-screen">
        <div className="mx-auto grid w-[350px] gap-4">
          {/* Logo */}
          <div className="text-center mb-4">
            <div className="flex justify-center">
              <img
                src="/images/logo.png"
                alt="PicPax"
                className="h-10 w-auto object-contain"
              />
            </div>
          </div>

          {/* Create New Password Form */}
          <div>
            <div className="grid gap-2 text-center mb-4">
              <h2 className="text-2xl font-bold">Create New Password</h2>
              <p className="text-balance text-muted-foreground text-sm">
                Enter your new secure password below
              </p>

              {/* Display email from URL */}
              {email && (
                <div className="flex items-center justify-center gap-2 mt-1 p-2 bg-muted/50 rounded-lg">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">{email}</span>
                </div>
              )}
            </div>

            <form onSubmit={handleSubmit(onSubmit)} className="grid gap-3">
              {error && (
                <Alert variant="destructive" className="py-2">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    {error}
                  </AlertDescription>
                </Alert>
              )}

              {success && (
                <Alert className="bg-green-50 border-green-200 py-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800 text-sm">
                    {success}
                  </AlertDescription>
                </Alert>
              )}

              {/* New Password Field */}
              <div className="grid gap-2">
                <Label htmlFor="password" className="text-sm">
                  New Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    {...register("password")}
                    className={errors.password ? "border-destructive" : ""}
                    placeholder="Enter your new password"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                {errors.password && (
                  <p className="text-destructive text-xs">
                    {errors.password.message}
                  </p>
                )}
              </div>

              {/* Confirm Password Field */}
              <div className="grid gap-2">
                <Label htmlFor="confirmPassword" className="text-sm">
                  Confirm New Password
                </Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    {...register("confirmPassword")}
                    className={
                      errors.confirmPassword ? "border-destructive" : ""
                    }
                    placeholder="Confirm your new password"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                {errors.confirmPassword && (
                  <p className="text-destructive text-xs">
                    {errors.confirmPassword.message}
                  </p>
                )}
              </div>

              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Resetting Password..." : "Reset Password"}
              </Button>
            </form>

            {/* Password Requirements */}
            <div className="mt-4 rounded-lg border bg-muted/50 p-3">
              <h3 className="font-semibold text-sm mb-2">
                Password Requirements
              </h3>
              <div className="text-xs space-y-1">
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      (passwordValue?.length || 0) >= 8
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span
                    className={
                      passwordValue && passwordValue.length >= 8
                        ? "text-green-600"
                        : "text-muted-foreground"
                    }
                  >
                    At least 8 characters
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      /[A-Z]/.test(passwordValue || "")
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span
                    className={
                      /[A-Z]/.test(passwordValue || "")
                        ? "text-green-600"
                        : "text-muted-foreground"
                    }
                  >
                    One uppercase letter (A-Z)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      /[a-z]/.test(passwordValue || "")
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span
                    className={
                      /[a-z]/.test(passwordValue || "")
                        ? "text-green-600"
                        : "text-muted-foreground"
                    }
                  >
                    One lowercase letter (a-z)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      /[0-9]/.test(passwordValue || "")
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span
                    className={
                      /[0-9]/.test(passwordValue || "")
                        ? "text-green-600"
                        : "text-muted-foreground"
                    }
                  >
                    One number (0-9)
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      /[^A-Za-z0-9]/.test(passwordValue || "")
                        ? "bg-green-500"
                        : "bg-gray-300"
                    }`}
                  ></div>
                  <span
                    className={
                      /[^A-Za-z0-9]/.test(passwordValue || "")
                        ? "text-green-600"
                        : "text-muted-foreground"
                    }
                  >
                    One special character (!@#$%^&* etc.)
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
