"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, FileText, Package } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { DataTable } from "@/components/orders/data-table";
import { columns, type Order } from "@/components/orders/columns";
import { OrderDetailsModal } from "@/components/orders/order-details-modal";
import { useRouter } from "next/navigation";
import { getOrders, type OrdersListResponse } from "@/lib/orderService";
import { DirhamIcon } from "@/components/ui/DirhamIcon";

// Types for API responses
interface ApiOrder {
  id: string;
  order_id: string;
  doctor: {
    id: string;
    full_name: string | null;
    email: string;
    clinic_name: string;
    commission: string;
  };
  patient: {
    id: string;
    full_name: string;
    email: string;
  };
  status: string;
  order_date: string;
  products_count: number;
  products: string[];
  total_price?: string;
  total?: string;
  commission: string;
  created_at: string;
  updated_at: string;
}

interface PaginationInfo {
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
  from: number;
  to: number;
}

// Types for user permissions
interface UserPermissions {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

export default function OrderHistoryPage() {
  const router = useRouter();
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isOrderDetailsOpen, setIsOrderDetailsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [pagination, setPagination] = useState<PaginationInfo>({
    current_page: 1,
    last_page: 1,
    per_page: 10,
    total: 0,
    from: 1,
    to: 0,
  });
  const [total, setTotal] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState<{
    sort_by: string;
    sort_order: string;
  }>({
    sort_by: "updated_at",
    sort_order: "desc",
  });

  // Permission state
  const [userPermissions, setUserPermissions] =
    useState<UserPermissions | null>(null);
  const [permissionsLoaded, setPermissionsLoaded] = useState(false);

  // Use refs to track current state to avoid dependencies
  const paginationRef = useRef(pagination);
  const searchTermRef = useRef(searchTerm);
  const sortConfigRef = useRef(sortConfig);
  // refs for fetch guards
  const fetchInFlightRef = useRef(false);
  const lastFetchKeyRef = useRef<string | null>(null);
  const lastFetchFinishedAtRef = useRef<number | null>(null);

  // Update refs when state changes
  useEffect(() => {
    paginationRef.current = pagination;
    searchTermRef.current = searchTerm;
    sortConfigRef.current = sortConfig;
  }, [pagination, searchTerm, sortConfig]);

  // Check if user has specific permission
  const hasPermission = (permission: string): boolean => {
    if (!userPermissions || !userPermissions.permission) {
      console.log("No user permissions found");
      return false;
    }

    const hasPerm = userPermissions.permission.includes(permission);
    console.log(`Permission check for ${permission}:`, hasPerm);
    return hasPerm;
  };

  // Load user permissions from localStorage
  useEffect(() => {
    const loadUserPermissions = () => {
      try {
        const userData = localStorage.getItem("picpax_user");
        if (userData) {
          const user = JSON.parse(userData);
          setUserPermissions(user);
          console.log("User permissions loaded:", user.permission);
        } else {
          setUserPermissions(null);
        }
      } catch (error) {
        console.error("Error loading user permissions:", error);
        setUserPermissions(null);
      } finally {
        setPermissionsLoaded(true);
      }
    };

    loadUserPermissions();
    window.addEventListener("storage", loadUserPermissions);

    return () => {
      window.removeEventListener("storage", loadUserPermissions);
    };
  }, []);

  // Handle logout and authentication state changes
  useEffect(() => {
    const handleStorageChange = () => {
      const userData = localStorage.getItem("picpax_user");
      if (!userData) {
        // User logged out, clear state and stop any pending requests
        setOrders([]);
        setIsLoading(false);
      }
    };

    window.addEventListener("storage", handleStorageChange);

    // Also check on mount if user exists
    const userData = localStorage.getItem("picpax_user");
    if (!userData) {
      setIsLoading(false);
    }

    return () => {
      window.removeEventListener("storage", handleStorageChange);
    };
  }, []);

  // Map API status to local status
  const mapStatus = (
    status: string
  ): "Completed" | "Processing" | "Pending" | "Cancelled" => {
    switch (status.toLowerCase()) {
      case "completed":
      case "fulfilled":
      case "paid":
        return "Completed";
      case "processing":
        return "Processing";
      case "pending":
        return "Pending";
      case "cancelled":
      case "failed":
        return "Cancelled";
      default:
        return (status && status[0]?.toUpperCase() + status.slice(1)) as any;
    }
  };

  // Transform API order to local Order type
  const transformApiOrder = (apiOrder: ApiOrder): Order => {
    const amount = parseFloat(apiOrder.total_price || apiOrder.total || "0");
    const commission = parseFloat(apiOrder.commission || "0");

    return {
      id: apiOrder.order_id || apiOrder.id,
      doctorName: apiOrder.doctor.full_name || apiOrder.doctor.email,
      doctorClinic: apiOrder.doctor.clinic_name,
      patientName: apiOrder.patient.full_name,
      patientEmail: apiOrder.patient.email,
      amount: amount,
      status: mapStatus(apiOrder.status),
      date: apiOrder.order_date,
      products: apiOrder.products,
      products_count: apiOrder.products_count,
      commission: commission,
      doctorId: apiOrder.doctor.id,
      patientId: apiOrder.patient.id,
      order_Id: apiOrder.id,
    };
  };

  // Fetch orders - properly memoized
  const fetchOrders = useCallback(
    async (
      page: number = 1,
      search: string = "",
      sort_by: string = "updated_at",
      sort_order: string = "desc"
    ) => {
      const key = JSON.stringify({ page, search, sort_by, sort_order });
      const now = Date.now();

      if (
        lastFetchFinishedAtRef.current &&
        lastFetchKeyRef.current === key &&
        now - lastFetchFinishedAtRef.current < 300
      ) {
        return;
      }

      if (fetchInFlightRef.current && lastFetchKeyRef.current === key) {
        return;
      }

      fetchInFlightRef.current = true;
      lastFetchKeyRef.current = key;

      try {
        setIsLoading(true);
        const response = await getOrders({
          page,
          per_page: paginationRef.current.per_page,
          search,
          sort_by,
          sort_order,
          type: "all",
        });

        if (response.success) {
          const apiOrders: ApiOrder[] = response.data.orders?.data || [];
          const paginationData: PaginationInfo = response.data.pagination;

          const transformedOrders = apiOrders.map(transformApiOrder);
          setOrders(transformedOrders);
          setPagination(paginationData);
          setTotal(response?.data?.summary || null);
        }
      } catch (error) {
        console.error("Error fetching orders:", error);
        setOrders([]);
        setTotal(null);
      } finally {
        setIsLoading(false);
        fetchInFlightRef.current = false;
        lastFetchFinishedAtRef.current = Date.now();
        lastFetchKeyRef.current = null;
      }
    },
    []
  );

  // Handle search - properly memoized
  const handleSearch = useCallback(
    (search: string) => {
      setSearchTerm(search);
      fetchOrders(
        1,
        search,
        sortConfigRef.current.sort_by,
        sortConfigRef.current.sort_order
      );
    },
    [fetchOrders]
  );

  // Handle pagination - properly memoized
  const handlePaginationChange = useCallback(
    (page: number) => {
      fetchOrders(
        page,
        searchTermRef.current,
        sortConfigRef.current.sort_by,
        sortConfigRef.current.sort_order
      );
    },
    [fetchOrders]
  );

  const handlePageSizeChange = useCallback(
    (pageSize: number) => {
      setPagination((p) => ({ ...p, per_page: pageSize, current_page: 1 }));
      paginationRef.current = {
        ...paginationRef.current,
        per_page: pageSize,
        current_page: 1,
      };
      fetchOrders(
        1,
        searchTermRef.current,
        sortConfigRef.current.sort_by,
        sortConfigRef.current.sort_order
      );
    },
    [fetchOrders]
  );

  // Handle sort - properly memoized
  const handleSort = useCallback(
    (sort_by: string, sort_order: string) => {
      if (
        sortConfigRef.current.sort_by === sort_by &&
        sortConfigRef.current.sort_order === sort_order
      ) {
        setSortConfig({ sort_by, sort_order });
        return;
      }

      setSortConfig({ sort_by, sort_order });
      fetchOrders(1, searchTermRef.current, sort_by, sort_order);
    },
    [fetchOrders]
  );

  // Initial fetch - only run once when permissions are loaded
  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const handleViewOrderDetails = useCallback((order: Order) => {
    setSelectedOrder(order);
    setIsOrderDetailsOpen(true);
  }, []);

  // Calculate stats based on current orders
  const totalRevenue = orders.reduce((sum, order) => sum + order.amount, 0);
  const totalCommission = orders.reduce(
    (sum, order) => sum + order.commission,
    0
  );
  const completedOrders = orders.filter(
    (order) => order.status === "Completed"
  ).length;
  const processingOrders = orders.filter(
    (order) => order.status === "Processing"
  ).length;

  if (!user) return null;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Orders Management
          </h1>
          <p className="text-muted-foreground">
            View and manage all orders across all doctors
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Button onClick={() => router.push("/orders/create")}>
            <Plus className="h-4 w-4 mr-2" />
            Create Order
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">
              {total?.total_orders || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              Showing {pagination.from}-{pagination.to} of {pagination.total}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed</CardTitle>
            <FileText className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {total?.total_completed_orders || 0}
            </div>
            <p className="text-xs text-muted-foreground">
              {total?.total_orders > 0
                ? Math.round(
                    (total?.total_completed_orders / total?.total_orders) * 100
                  )
                : 0}
              % success rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600 flex items-center">
              <DirhamIcon className="mr-2" />
              <span>{total?.total_revenue.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground">From all orders</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Commission
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600 flex items-center">
              <DirhamIcon className="mr-2" />
              <span>{total?.total_commission.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground">
              {total?.total_revenue > 0
                ? Math.round(
                    (total?.total_commission / total?.total_revenue) * 100
                  )
                : 0}
              % of revenue
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Orders Data Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Orders</CardTitle>
          <CardDescription>
            View and manage orders from all doctors. Click on any order to view
            detailed information.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <DataTable
            columns={columns}
            data={orders}
            onViewOrderDetails={handleViewOrderDetails}
            onSearch={handleSearch}
            search={searchTerm}
            onPaginationChange={handlePaginationChange}
            onPageSizeChange={handlePageSizeChange}
            onSort={handleSort}
            pagination={pagination}
            isLoading={isLoading}
            canExport={hasPermission("order_export")}
            canViewDetails={hasPermission("order_read")} // Also pass to meta for cell access
            entity="orders"
          />
        </CardContent>
      </Card>

      {/* Order Details Modal */}
      <OrderDetailsModal
        order={selectedOrder}
        isOpen={isOrderDetailsOpen}
        onClose={() => setIsOrderDetailsOpen(false)}
        orderType="regular"
      />
    </div>
  );
}
