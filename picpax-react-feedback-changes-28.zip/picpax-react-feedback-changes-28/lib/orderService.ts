import axiosInstance from "@/services/axiosInstance";

// Patient API Types
export interface Patient {
  id: string;
  full_name: string;
  email: string;
  status: string;
  doctor_name: string;
}

export interface PatientsResponse {
  success: boolean;
  message: string;
  data: {
    patients: Patient[];
    total_count: number;
    search_term: string;
  };
}

// Doctor API Types
export interface Doctor {
  id: string;
  full_name: string;
  email: string;
  status: string;
  commission: any;
}

export interface DoctorsResponse {
  success: boolean;
  message: string;
  data: {
    doctors: Doctor[];
    total_count: number;
    search_term: string;
  };
}

// Product API Types
export interface ProductVariant {
  id: string;
  product_id: number;
  variant_id: number;
  title: string;
  price: number;
  sku: string;
  inventory_summary: {
    total_available: number;
    in_stock: boolean;
    locations_count: number;
  };
}

export interface ProductImage {
  id: string;
  image_id: number;
  alt: string | null;
  url: string;
}

export interface Product {
  id: string;
  product_id: number;
  title: string;
  vendor: string;
  handle: string;
  product_type: string;
  tags: string;
  status: string;
  sync_status: string;
  created_at: string;
  updated_at: string;
  product_variants: ProductVariant[];
  variants_count: number;
  variants: string;
  sku: string[];
  prices: number[];
  inventory: number;
  locations_count: number;
  locations: string;
  image: ProductImage;
}

export interface ProductsResponse {
  success: boolean;
  message: string;
  data: {
    products: Product[];
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    filters_applied: {
      search: string | null;
      category: string | null;
    };
  };
}

export interface ProductTypesResponse {
  success: boolean;
  message: string;
  data: string[];
}

// Orders list response (generic)
export interface OrdersListResponse {
  success: boolean;
  message: string;
  data: any;
}

export interface Discount {
  type: "shipping" | "order" | "line_item";
  shipping_line?: {
    title: string;
    custom: boolean;
    handle: string | null;
    price: string;
  };
  applied_discount?: {
    value_type: "fixed_amount" | "percentage";
    value: number;
    amount?: number;
    title: string;
  };
  line_items?: Array<{
    variant_id: number;
    quantity: string;
    price: string;
    name: string;
    applied_discount?: {
      value_type: "fixed_amount" | "percentage";
      value: number;
      title: string;
    };
  }>;
}
export interface CreateOrderFromDraftPayload {
  draft_order_id: string;
}

export interface CreateOrderFromDraftResponse {
  success: boolean;
  message: string;
  data: {
    uuid: string;
  };
}

export const getOrders = async (params?: {
  page?: number;
  per_page?: number;
  search?: string;
  sort_by?: string;
  sort_order?: string;
  type?: string;
}): Promise<OrdersListResponse> => {
  try {
    const q = new URLSearchParams();
    if (params?.page) q.append("page", String(params.page));
    if (params?.per_page) q.append("per_page", String(params.per_page));
    if (params?.search) q.append("search", params.search);
    if (params?.sort_by) q.append("sort_by", params.sort_by);
    if (params?.sort_order) q.append("sort_order", params.sort_order);
    // if (params?.type) q.append("type", params.type);

    const response = await axiosInstance.get(`/orders?${q.toString()}`);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

export const getDraftOrders = async (params?: {
  page?: number;
  per_page?: number;
  search?: string;
  sort_by?: string;
  sort_order?: string;
}): Promise<OrdersListResponse> => {
  try {
    const q = new URLSearchParams();
    if (params?.page) q.append("page", String(params.page));
    if (params?.per_page) q.append("per_page", String(params.per_page));
    if (params?.search) q.append("search", params.search);
    if (params?.sort_by) q.append("sort_by", params.sort_by);
    if (params?.sort_order) q.append("sort_order", params.sort_order);

    const response = await axiosInstance.get(`/draft-orders?${q.toString()}`);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Draft Order Types
export interface DraftOrderItem {
  variant_id: number | string;
  quantity: number | string;
  price: number | string;
  name: string;
}

export interface DraftOrderPayload {
  doctor_id: string;
  patient_id: string;
  items: DraftOrderItem[];
  coupon?: string | null;
  discount?: Discount | null; // Add discount object
  commission_rate?: number;
  status: string; // 'draft' or 'processing'
}

export interface DraftOrderResponse {
  success: boolean;
  message: string;
  data: any;
}
// Commission API Types
export interface Commission {
  id: string;
  order_id: string;
  order_status: string;
  patient_name: string;
  order_subtotal: string;
  order_total: string;
  commission: string;
  commission_rate: string;
  status: string;
  order_date: string;
  created_at: string;
}

export interface CommissionsResponse {
  success: boolean;
  message: string;
  data: {
    commissions: Commission[];
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    summary: {
      total_commissions: number;
      total_average_commission_amount: string;
      total_commission_amount: string;
      total_order_value: string;
      completed_commissions: number;
      pending_commissions: number;
      filtered_count: number;
    };
    filter_options: {
      status_options: string[];
    };
    applied_filters: {
      search: string | null;
      status: string | null;
      sort_by: string;
      sort_direction: string;
    };
  };
}

// Create Draft / Processing Order
export const createDraftOrder = async (
  payload: DraftOrderPayload
): Promise<DraftOrderResponse> => {
  try {
    const response = await axiosInstance.post(`/draft-order`, payload);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Get Patients List
export const getPatients = async (
  params?: { search?: string; doctor_id?: string } | string
): Promise<PatientsResponse> => {
  try {
    const query = new URLSearchParams();
    if (typeof params === "string") {
      if (params) query.append("search", params);
    } else if (params) {
      if (params.search) query.append("search", params.search);
      if (params.doctor_id) query.append("doctor_id", params.doctor_id);
    }

    const response = await axiosInstance.get(
      `/patients/list?${query.toString()}`
    );
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Get Doctors List
export const getDoctors = async (search?: string): Promise<DoctorsResponse> => {
  try {
    const params = new URLSearchParams();
    if (search) params.append("search", search);

    const response = await axiosInstance.get(
      `/doctors/list?${params.toString()}`
    );
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Get Products List
export const getProducts = async (params?: {
  search?: string;
  category?: string;
  page?: number;
  per_page?: number;
}): Promise<ProductsResponse> => {
  try {
    const queryParams = new URLSearchParams();
    if (params?.search) queryParams.append("search", params.search);
    if (params?.category && params.category !== "all")
      queryParams.append("category", params.category);
    if (params?.page) queryParams.append("page", params.page.toString());
    if (params?.per_page)
      queryParams.append("per_page", params.per_page.toString());

    const response = await axiosInstance.get(
      `/products/list?${queryParams.toString()}`
    );
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Get Product Types
export const getProductTypes = async (): Promise<ProductTypesResponse> => {
  try {
    const response = await axiosInstance.get("/products/type");
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Get Commissions API
export const getCommissions = async (params?: {
  page?: number;
  per_page?: number;
  search?: string;
  status?: string;
  sort_by?: string;
  sort_direction?: string;
  start_date?: string; // NEW: Date range filter
  end_date?: string; // NEW: Date range filter
  doctor_id?: string; // NEW: Doctor filter
}): Promise<CommissionsResponse> => {
  try {
    const q = new URLSearchParams();
    if (params?.page) q.append("page", String(params.page));
    if (params?.per_page) q.append("per_page", String(params.per_page));
    if (params?.search) q.append("search", params.search);
    if (params?.status) q.append("status", params.status);
    if (params?.sort_by) q.append("sort_by", params.sort_by);
    if (params?.sort_direction)
      q.append("sort_direction", params.sort_direction);

    // NEW FILTERS
    if (params?.start_date) q.append("start_date", params.start_date);
    if (params?.end_date) q.append("end_date", params.end_date);
    if (params?.doctor_id) q.append("doctor_id", params.doctor_id);

    const response = await axiosInstance.get(`/commissions?${q.toString()}`);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Add this function to your existing orderService.ts exports
export const createOrderFromDraft = async (
  payload: CreateOrderFromDraftPayload
): Promise<CreateOrderFromDraftResponse> => {
  try {
    const response = await axiosInstance.post(`/draft-order/create`, payload);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Add to your orderService.ts exports
export const deleteDraftOrder = async (
  draftId: string
): Promise<{ success: boolean; message: string }> => {
  try {
    const response = await axiosInstance.delete(`/draft-order/${draftId}`);
    return {
      success: true,
      message: response.data.message || "Draft order deleted successfully",
    };
  } catch (error: any) {
    console.error("Error deleting draft order:", error);
    throw error;
  }
};
