"use client";

import type React from "react";

import { createContext, useContext, useEffect, useState, useRef } from "react";
import { useRouter, usePathname } from "next/navigation";
import { Role, systemRoles } from "./staff-types";
import { fetchUserProfile, loginUser, logoutUser } from "@/lib/userService";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  userRole?: Role; // For staff members with detailed role information
  type?: any;
  first_name?: string;
  last_name?: string;
  medical_speciality?: string;
}

interface AuthContextType {
  user: User | null;
  login: (
    email: string,
    password: string,
    isAdmin?: boolean
  ) => Promise<boolean>;
  logout: () => Promise<void>;
  isLoading: boolean;
  hasPermission: (permission: string) => boolean;
  hasAnyPermission: (permissions: string[]) => boolean;
  hasAllPermissions: (permissions: string[]) => boolean;
  updateUser: (userData: Partial<User>) => void; // NEW: Add updateUser function
  isRouting: boolean;
  startRouting: () => void;
  stopRouting: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRouting, setIsRouting] = useState(false);
  const router = useRouter();
  const pathname = usePathname();

  // NEW: Function to update user data
  const updateUser = (userData: Partial<User>) => {
    setUser((prev) => {
      if (!prev) return prev;

      const updatedUser = { ...prev, ...userData };

      // Update localStorage to persist changes
      localStorage.setItem("picpax_user", JSON.stringify(updatedUser));

      return updatedUser;
    });
  };

  const startRouting = () => setIsRouting(true);
  const stopRouting = () => setIsRouting(false);

  // Prevent redirect races when performing logout navigation
  const isPerformingLogoutRef = useRef(false);

  // Permission checking methods
  const hasPermission = (permission: string): boolean => {
    if (!user) return false;

    // Admin has all permissions
    if (user.role === "admin") return true;

    // Check specific user role permissions (for staff members)
    if (user.userRole) {
      return user.userRole.permissions.some((p) => p.id === permission);
    }

    // Default permissions for doctors
    const doctorPermissions = [
      "doctor.dashboard.view",
      "doctor.patients.view",
      "doctor.patients.create",
      "doctor.orders.view",
      "doctor.orders.create",
      "doctor.commission.view",
    ];

    if (user.role === "doctor") {
      return doctorPermissions.includes(permission);
    }

    return false;
  };

  const hasAnyPermission = (permissions: string[]): boolean => {
    return permissions.some((permission) => hasPermission(permission));
  };

  const hasAllPermissions = (permissions: string[]): boolean => {
    return permissions.every((permission) => hasPermission(permission));
  };

  useEffect(() => {
    // Check for existing auth token on mount
    const checkAuth = () => {
      const token = localStorage.getItem("picpax_auth_token");
      const storedUser = localStorage.getItem("picpax_user");

      if (token && storedUser) {
        try {
          // Use the stored user data directly
          const parsedUser = JSON.parse(storedUser);
          setUser(parsedUser);
        } catch (parseError) {
          console.error("Failed to parse stored user:", parseError);
          // Invalid user data, clear storage
          localStorage.removeItem("picpax_auth_token");
          localStorage.removeItem("picpax_user");
        }
      } else if (token && !storedUser) {
        // We have a token but no stored user data - clear invalid token
        localStorage.removeItem("picpax_auth_token");
      } else if (!token && storedUser) {
        // No token but stored user exists - clean up
        localStorage.removeItem("picpax_user");
      }

      setIsLoading(false);
    };

    checkAuth();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      // If we're in the middle of programmatic logout navigation, skip automatic redirects
      if (isPerformingLogoutRef.current) return;
      if (!user) {
        // If no user, redirect to appropriate login based on route
        if (pathname.startsWith("/admin/") && pathname !== "/admin/login") {
          setIsRouting(true);
          router.replace("/admin/login");
        } else if (
          // Allow public staff routes (/staff/*) and auth routes
          pathname !== "/login" &&
          pathname !== "/signup" &&
          !pathname.startsWith("/reset-password") &&
          !pathname.startsWith("/admin/") &&
          !pathname.startsWith("/staff/")
        ) {
          setIsRouting(true);
          router.replace("/login");
        }
      } else if (
        user &&
        (pathname === "/login" ||
          pathname === "/signup" ||
          pathname.startsWith("/reset-password") ||
          pathname.startsWith("/staff/"))
      ) {
        // If user is logged in and tries to access login/signup, redirect to dashboard
        setIsRouting(true);
        router.push(
          user.role === "admin" ||
            user.role === "super admin" ||
            user.type === "system"
            ? "/admin/dashboard"
            : "/dashboard"
        );
      } else if (user && pathname === "/") {
        // If user is on home page, redirect to appropriate dashboard
        setIsRouting(true);
        router.push(
          user.role === "admin" ||
            user.role === "super admin" ||
            user.type === "system"
            ? "/admin/dashboard"
            : "/dashboard"
        );
      } else if (
        user &&
        pathname.startsWith("/admin/") &&
        user.role !== "admin" &&
        user.role !== "super admin" &&
        user?.type !== "system"
      ) {
        // If non-admin/super-admin tries to access admin routes, redirect to doctor dashboard
        setIsRouting(true);
        router.push("/dashboard");
      } else if (
        user &&
        !pathname.startsWith("/admin/") &&
        (user.role === "admin" ||
          user.role === "super admin" ||
          user?.type === "system")
      ) {
        // If admin/super-admin tries to access doctor routes, redirect to admin dashboard
        setIsRouting(true);
        router.push("/admin/dashboard");
      }
    }
  }, [user, isLoading, pathname, router]);

  // Stop routing indicator when path changes (new route rendered)
  useEffect(() => {
    setIsRouting(false);
  }, [pathname]);

  const login = async (
    email: string,
    password: string,
    isAdmin?: boolean
  ): Promise<boolean> => {
    try {
      // Determine if this is an admin login based on parameter or current path
      const adminLogin =
        isAdmin !== undefined ? isAdmin : pathname.startsWith("/admin/");

      // Call the API for authentication with appropriate endpoint
      const response = await loginUser({ email, password }, adminLogin);
      console.log(response, "response1233");

      if (response.success) {
        // Store token and user data
        localStorage.setItem("picpax_auth_token", response?.data?.token);
        localStorage.setItem(
          "picpax_user",
          JSON.stringify(response?.data?.user)
        );
        sessionStorage.setItem("picpax_just_logged_in", "true");
        setUser(response?.data?.user);
        console.log(response, "response1233");
        // Navigate to appropriate dashboard
        setIsRouting(true);
        router.push(
          response?.data?.user?.role === "admin" ||
            response?.data?.user?.role === "super admin" ||
            response?.data?.user?.type === "system"
            ? "/admin/dashboard"
            : "/dashboard"
        );
        return true;
      } else {
        return false;
      }
    } catch (error: any) {
      console.error("Login error:", error);
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      // Call API first while token still exists
      await logoutUser();
    } catch (error) {
      console.error("Logout API error:", error);
      // Even if API fails, continue cleanup
    } finally {
      // Compute redirect destination first (use stored user as fallback)
      const storedUserRaw =
        typeof window !== "undefined"
          ? localStorage.getItem("picpax_user")
          : null;
      let storedRole = "";
      if (storedUserRaw) {
        try {
          storedRole = JSON.parse(storedUserRaw).role || "";
        } catch (e) {
          storedRole = (storedUserRaw || "").toString();
        }
      }

      const roleStr = (user?.role || storedRole || "")
        .toString()
        .toLowerCase()
        .trim();
      let dest: string;
      if (pathname.startsWith("/admin/")) {
        dest = "/admin/login";
      } else if (roleStr.includes("admin")) {
        dest = "/admin/login";
      } else if (roleStr === "doctor") {
        dest = "/login";
      } else {
        dest = "/staff/login";
      }

      // Redirect first so it wins over any reactive redirect logic that runs when user becomes null
      setIsRouting(true);
      // Mark that we're performing logout navigation so other effects don't interrupt
      isPerformingLogoutRef.current = true;
      router.replace(dest);

      // Clear client-side auth state after navigation settles (short delay)
      setTimeout(() => {
        localStorage.removeItem("picpax_auth_token");
        localStorage.removeItem("picpax_user");
        setUser(null);
        isPerformingLogoutRef.current = false;
      }, 400);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        logout,
        isLoading,
        hasPermission,
        hasAnyPermission,
        hasAllPermissions,
        updateUser, // NEW: Add updateUser to context value
        isRouting,
        startRouting,
        stopRouting,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
