import axiosInstance from "@/services/axiosInstance";

// Log API Types
export interface ActivityLog {
  uuid: string;
  module: string;
  description: string;
  event: string;
  properties: {
    old?: any;
    attributes?: any;
  };
  created_at: string;
  causer: {
    id: string;
    name: string;
  } | null;
  subject: {
    uuid: string;
    key: string;
    display_key: string;
    value: string;
  };
}

export interface ActivityLogsResponse {
  success: boolean;
  message: string;
  data: {
    activity_logs: ActivityLog[];
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
  };
}

export interface ActivityLogsQueryParams {
  page?: number;
  per_page?: number;
  search?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  event?: string;
  module?: string;
}

// Get Activity Logs with search, sort, and pagination
export const getActivityLogs = async (
  params?: ActivityLogsQueryParams
): Promise<ActivityLogsResponse> => {
  try {
    const response = await axiosInstance.get("/activity/logs", {
      params: {
        subject: "system_setting",
        ...params,
      },
    });
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};
