import axiosInstance from "@/services/axiosInstance";

// Dashboard Types
export interface DashboardStats {
  total_doctors: {
    value: number;
    active: number;
    inactive: number;
    subtitle: string;
  };
  total_patients: {
    value: number;
    subtitle: string;
  };
  total_orders: {
    value: number;
    completed: number;
    pending: number;
    subtitle: string;
  };
  total_revenue: {
    value: string;
    monthly: string;
    subtitle: string;
  };
  total_commission: {
    value: string;
    monthly: string;
    subtitle: string;
  };
  monthly_commission: {
    value: string;
    subtitle: string;
  };
  pending_payouts: {
    value: string;
    subtitle: string;
  };
  avg_order_value: {
    value: string;
    subtitle: string;
  };
}

export interface RecentOrder {
  id: string;
  order_id: string;
  doctor_name: string;
  patient_name: string;
  amount: string;
  status: string;
  date: string;
}

export interface RecentPatient {
  id: string;
  name: string;
  last_visit: string;
  status: string;
  doctor_name: string;
}

export interface DashboardSummary {
  role: string;
  access_level: string;
  last_updated: string;
}

export interface DashboardResponse {
  success: boolean;
  message: string;
  data: {
    stats: DashboardStats;
    recent_orders: RecentOrder[];
    recent_patients: RecentPatient[];
    summary: DashboardSummary;
    charts?: any;
  };
}

// Get Dashboard Data with optional date range
// Get Dashboard Data with optional date range and doctor filter
export const getDashboardData = async (params?: {
  start_date?: string;
  end_date?: string;
  doctor_id?: string;
}): Promise<DashboardResponse> => {
  try {
    const response = await axiosInstance.get("/dashboard", {
      params: params || {},
    });
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};
