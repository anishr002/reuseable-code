import axiosInstance from "@/services/axiosInstance";

// Product API Types
export interface ProductImage {
  id: string;
  image_id: number;
  alt: string | null;
  url: string;
}

export interface Product {
  id: string;
  product_id: number;
  title: string;
  vendor: string;
  handle: string;
  product_type: string;
  tags: string;
  status: "active" | "draft" | "archived";
  sync_status: "synced" | "syncing" | "not_synced" | "error";
  created_at: string;
  updated_at: string;
  variants_count: number;
  variants: string;
  sku: string[];
  prices: number[];
  inventory: number;
  locations_count: number;
  locations: string;
  image: ProductImage | null;
}

export interface ProductsResponse {
  success: boolean;
  message: string;
  data: {
    products: Product[];
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    filters_applied: {
      search: string | null;
      sort_by: string;
      sort_order: "asc" | "desc";
    };
  };
}

export interface ProductsQueryParams {
  page?: number;
  per_page?: number;
  search?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  status?: string;
  vendor?: string;
  product_type?: string;
  sync_status?: string;
}

export interface ProductInfo {
  uuid: string;
  shopify_product_id: number;
  dose: string;
  ingredients: string;
}

export interface ProductInfoResponse {
  success: boolean;
  message: string;
  data: {
    product_info: ProductInfo;
  };
}

export interface ProductInfoPayload {
  product_id: string;
  dose: string;
  ingredients: string;
}

// Get Products with search, sort, and pagination
export const getProducts = async (
  params?: ProductsQueryParams
): Promise<ProductsResponse> => {
  try {
    const response = await axiosInstance.get("/products", { params });
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Get Product by ID
export const getProductById = async (
  id: string
): Promise<{
  success: boolean;
  message: string;
  data: { product: Product };
}> => {
  try {
    const response = await axiosInstance.get(`/product/${id}`);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// POST /product/sync with payload { product_id }
export const postSyncProduct = async (
  product_id: string | number
): Promise<{ success: boolean; message: string; data?: any }> => {
  try {
    const response = await axiosInstance.post(`/product/sync`, {
      product_id,
    });
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// POST /product/info
export const postProductInfo = async (
  payload: ProductInfoPayload
): Promise<ProductInfoResponse> => {
  try {
    const response = await axiosInstance.post(`/product/info`, payload);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// GET /product/info/{product_id}
export const getProductInfo = async (
  product_id: string
): Promise<{
  success: boolean;
  message: string;
  data: { product_info: ProductInfo | null };
}> => {
  try {
    const response = await axiosInstance.get(`/product/info/${product_id}`);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};
