import axiosInstance from "@/services/axiosInstance";

// System Settings API Types
export interface SystemSetting {
  id: string;
  title: string;
  key: string;
  value: string;
}

export interface SystemSettingsResponse {
  success: boolean;
  message: string;
  data: {
    settings: SystemSetting[];
  };
}

export interface UpdateSystemSettingsPayload {
  settings: {
    key: string;
    value: string;
  }[];
}

// Notification Settings API Types
export interface NotificationSetting {
  key: string;
  title: string;
  description: string;
  value: boolean;
  type: string;
}

export interface NotificationSettingsResponse {
  success: boolean;
  message: string;
  data: {
    notification_settings: NotificationSetting[];
  };
}

export interface UpdateNotificationSettingsPayload {
  email_notifications: boolean;
  push_notifications: boolean;
  new_order_alerts: boolean;
  commission_alerts: boolean;
  doctor_registration_alerts: boolean;
  system_alerts: boolean;
}

export interface UpdateNotificationSettingsResponse {
  success: boolean;
  message: string;
  data: {
    updated_settings: Array<{
      key: string;
      value: boolean;
      updated_at: string;
    }>;
    message: string;
    updated_count: number;
    current_settings: {
      system_alerts: boolean;
      new_order_alerts: boolean;
      commission_alerts: boolean;
      push_notifications: boolean;
      email_notifications: boolean;
      doctor_registration_alerts: boolean;
    };
  };
}

// Get System Settings
export const getSystemSettings = async (): Promise<SystemSettingsResponse> => {
  try {
    const response = await axiosInstance.get("/system-settings/general");
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Update System Settings
export const updateSystemSettings = async (
  payload: UpdateSystemSettingsPayload
) => {
  try {
    const response = await axiosInstance.post(
      "/system-settings/general",
      payload
    );
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Get Notification Settings
export const getNotificationSettings =
  async (): Promise<NotificationSettingsResponse> => {
    try {
      const response = await axiosInstance.get("/notification-settings");
      return response.data;
    } catch (error: any) {
      if (error.response && error.response.status === 401) {
        localStorage.removeItem("picpax_auth_token");
        localStorage.removeItem("picpax_user");
      }
      throw error;
    }
  };

// Update Notification Settings
export const updateNotificationSettings = async (
  payload: UpdateNotificationSettingsPayload
): Promise<UpdateNotificationSettingsResponse> => {
  try {
    const response = await axiosInstance.post(
      "/notification-settings",
      payload
    );
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};
