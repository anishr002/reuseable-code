import {
  StaffMember,
  CreateStaffData,
  UpdateStaffData,
  Role,
  CreateRoleData,
  UpdateRoleData,
  Permission,
  RoleFilters,
  RolesResponse,
  systemRoles,
  systemPermissions,
  mockStaffMembers,
} from "./staff-types";
import axiosInstance from "@/services/axiosInstance";
import { logoutUser } from "./userService";

interface ApiPermission {
  id: number;
  name: string;
  action: string;
}

interface ModulePermissions {
  name: string;
  permissions: ApiPermission[];
}

interface ApiResponse {
  success: boolean;
  message: string;
  data: {
    module: {
      name: string;
      actions: string[];
    };
    permissions: ModulePermissions[];
  };
}

// API Response Interfaces for Role Creation
interface CreateRoleResponse {
  success: boolean;
  message: string;
  data: {
    id: number;
    name: string;
    description: string;
    type: any;
    guard_name: string;
    permissions: string[];
    created_at: string;
    updated_at: string;
  };
}

// API Response Interface for getting a single role
interface GetRoleResponse {
  success: boolean;
  message: string;
  data: {
    id: number;
    name: string;
    description: string;
    permissions: {
      id: number;
      name: string;
    }[];
    created_at: string;
    updated_at: string;
  };
}

// API Response Interface for updating a role
interface UpdateRoleResponse {
  success: boolean;
  message: string;
  data: {
    id: number;
    name: string;
    description: string;
    guard_name: string;
    permissions: string[];
    created_at: string;
    updated_at: string;
  };
}

// API Response Interfaces for Staff
interface StaffApiResponse {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  department: string | null;
  role: string;
  status: "active" | "inactive" | "suspended";
  created_at: string;
  updated_at: string;
}

interface StaffListResponse {
  success: boolean;
  message: string;
  data: {
    staff: StaffApiResponse[];
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    filters: {
      name?: string;
      email?: string;
      phone?: string;
      department?: string;
      role?: string;
      sort_by?: string;
      sort_order?: string;
      per_page?: number;
    };
  };
}

interface StaffFilters {
  name?: string;
  email?: string;
  phone?: string;
  department?: string;
  role?: string;
  sort_by?: string;
  sort_order?: string;
  per_page?: number;
  page?: number;
}

interface StaffResponse {
  staff: StaffMember[];
  pagination: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  };
  filters: StaffFilters;
}

// Interface for auth/permissions API response
interface AuthPermissionsResponse {
  success: boolean;
  message: string;
  data: {
    permissions: string[];
  };
}

// Interface for user data in localStorage
interface PicpaxUser {
  id: string;
  name: string;
  email: string;
  role: string;
  type: string;
  permission: string[];
}

class StaffService {
  // Helper method to get current user from localStorage
  private getCurrentUser(): PicpaxUser | null {
    if (typeof window === "undefined") return null;

    const userStr = localStorage.getItem("picpax_user");
    if (!userStr) return null;

    try {
      return JSON.parse(userStr) as PicpaxUser;
    } catch (error) {
      console.error("Error parsing user data from localStorage:", error);
      return null;
    }
  }

  // Helper method to update user permissions in localStorage
  private updateUserPermissions(permissions: string[]): void {
    if (typeof window === "undefined") return;

    const user = this.getCurrentUser();
    if (!user) return;

    const updatedUser: PicpaxUser = {
      ...user,
      permission: permissions,
    };

    localStorage.setItem("picpax_user", JSON.stringify(updatedUser));
    console.log("User permissions updated in localStorage");
  }

  // Method to fetch user permissions from auth/permissions endpoint
  private async fetchUserPermissions(): Promise<string[]> {
    try {
      const response = await axiosInstance.get<AuthPermissionsResponse>(
        `${process.env.NEXT_PUBLIC_API_URL}/auth/permissions`
      );

      if (response.data.success) {
        return response.data.data.permissions;
      }

      throw new Error(
        response.data.message || "Failed to fetch user permissions"
      );
    } catch (error: any) {
      console.error("Error fetching user permissions:", error);
      throw new Error(
        error.response?.data?.message || "Failed to fetch user permissions"
      );
    }
  }

  // Method to check if the updated role is the same as current user's role
  private isCurrentUserRole(roleId: string, roleName: string): boolean {
    const user = this.getCurrentUser();
    if (!user) return false;

    // Check by role name (since localStorage stores role name, not ID)
    return user.role === roleName;
  }

  // Method to update user permissions if the updated role is the same as current user's role// Add this method to the StaffService class
  private async logoutCurrentUser(): Promise<void> {
    if (typeof window === "undefined") return;

    try {
      // Call the logout API
      await logoutUser();
    } catch (error) {
      console.error("Logout API error during permission update:", error);
    } finally {
      // Clear local storage
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");

      // Dispatch a custom event to notify the auth context
      window.dispatchEvent(new CustomEvent("permission-update-logout"));

      console.log("User logged out due to permission/role changes");
    }
  }

  // Update the updateCurrentUserPermissionsIfNeeded method
  private async updateCurrentUserPermissionsIfNeeded(
    roleId: string,
    roleName: string
  ): Promise<void> {
    if (!this.isCurrentUserRole(roleId, roleName)) {
      console.log(
        "Updated role is not the current user role, skipping permission update"
      );
      return;
    }

    try {
      console.log("Updating permissions for current user role:", roleName);
      const permissions = await this.fetchUserPermissions();
      this.updateUserPermissions(permissions);

      // Logout the user after permission update to ensure changes take effect
      await this.logoutCurrentUser();
    } catch (error) {
      console.error("Failed to update user permissions:", error);
      // Even if update fails, logout to ensure security
      await this.logoutCurrentUser();
    }
  }

  // Staff management methods - UPDATED TO USE API
  async getStaffMembers(filters?: any): Promise<any> {
    try {
      const params = new URLSearchParams();

      // Add all filter parameters
      if (filters) {
        Object.entries(filters).forEach(([key, value]) => {
          if (value !== null && value !== undefined && value !== "") {
            params.append(key, value.toString());
          }
        });
      }

      const response = await axiosInstance.get(
        `${process.env.NEXT_PUBLIC_API_URL}/staff?${params.toString()}`
      );

      if (response.data.success) {
        const apiData = response.data.data;
        console.log(apiData, "apiData123");

        // Get all roles to map role names to role objects
        // const allRoles = await this.getRoles();

        const staffMembers: StaffMember[] = apiData.staff.map(
          (staff: any): StaffMember => {
            // Handle role data - it can be an array or single object
            let roleData;
            if (Array.isArray(staff.role) && staff.role.length > 0) {
              roleData = staff.role[0];
            } else if (typeof staff.role === "object") {
              roleData = staff.role;
            } else {
              // Fallback: find role by name
              // roleData = allRoles.find((r) => r.name === staff.role);
            }

            const role = roleData;

            return {
              id: staff.id || staff.uuid,
              name: staff.name,
              email: staff.email,
              phone: staff.phone || staff.phone_number || "",
              role: staff?.role,
              status: staff.status || "active",
              department: staff.department || undefined,
              createdAt: staff.created_at,
              updatedAt: staff.updated_at,
            };
          }
        );

        return {
          staff: staffMembers,
          pagination: apiData.pagination,
          filters: apiData.filters || filters || {},
        };
      }

      throw new Error(response.data.message || "Failed to fetch staff members");
    } catch (error: any) {
      console.error("Error fetching staff members:", error);

      // Fallback to mock data if API fails
      if (error.response?.status === 404 || error.response?.status >= 500) {
        console.log("Using fallback staff data");
        await new Promise((resolve) => setTimeout(resolve, 500));

        // Apply basic filtering to mock data
        let filteredStaff = [...mockStaffMembers];

        if (filters?.name) {
          filteredStaff = filteredStaff.filter((staff) =>
            staff.name.toLowerCase().includes(filters.name!.toLowerCase())
          );
        }

        if (filters?.email) {
          filteredStaff = filteredStaff.filter((staff) =>
            staff.email.toLowerCase().includes(filters.email!.toLowerCase())
          );
        }

        if (filters?.department) {
          filteredStaff = filteredStaff.filter((staff) =>
            staff.department
              ?.toLowerCase()
              .includes(filters.department!.toLowerCase())
          );
        }

        if (filters?.role) {
          filteredStaff = filteredStaff.filter((staff) =>
            staff.role.name.toLowerCase().includes(filters.role!.toLowerCase())
          );
        }

        // Apply sorting
        if (filters?.sort_by) {
          filteredStaff.sort((a, b) => {
            let aValue: any = a[filters.sort_by as keyof StaffMember];
            let bValue: any = b[filters.sort_by as keyof StaffMember];

            // Handle nested properties
            if (filters.sort_by === "role") {
              aValue = a.role.name;
              bValue = b.role.name;
            }

            if (aValue < bValue) return filters.sort_order === "asc" ? -1 : 1;
            if (aValue > bValue) return filters.sort_order === "asc" ? 1 : -1;
            return 0;
          });
        }

        // Apply pagination
        const page = filters?.page || 1;
        const perPage = filters?.per_page || 10;
        const startIndex = (page - 1) * perPage;
        const endIndex = startIndex + perPage;
        const paginatedStaff = filteredStaff.slice(startIndex, endIndex);

        return {
          staff: paginatedStaff,
          pagination: {
            current_page: page,
            last_page: Math.ceil(filteredStaff.length / perPage),
            per_page: perPage,
            total: filteredStaff.length,
            from: startIndex + 1,
            to: Math.min(endIndex, filteredStaff.length),
          },
          filters: filters || {},
        };
      }

      throw new Error(
        error.response?.data?.message || "Failed to fetch staff members"
      );
    }
  }

  async getStaffMember(id: string): Promise<StaffMember | null> {
    try {
      const response = await axiosInstance.get(
        `${process.env.NEXT_PUBLIC_API_URL}/staff/${id}`
      );

      if (response.data.success) {
        const apiStaff = response.data.data;
        const allRoles = await this.getRoles();

        // Handle role data from API
        let roleData;
        if (Array.isArray(apiStaff.role) && apiStaff.role.length > 0) {
          roleData = apiStaff.role[0];
        } else {
          roleData = allRoles.find((r) => r.name === apiStaff.role);
        }

        const role = roleData || allRoles[0];

        return {
          id: apiStaff.id,
          name: apiStaff.name,
          email: apiStaff.email,
          phone: apiStaff.phone || apiStaff.phone_number || "",
          role: role,
          status: apiStaff.status || "active",
          department: apiStaff.department || undefined,
          createdAt: apiStaff.created_at,
          updatedAt: apiStaff.updated_at,
        };
      }

      throw new Error(response.data.message || "Failed to fetch staff member");
    } catch (error: any) {
      console.error("Error fetching staff member:", error);

      // Fallback to mock data
      await new Promise((resolve) => setTimeout(resolve, 300));
      return mockStaffMembers.find((staff) => staff.id === id) || null;
    }
  }

  async createStaffMember(data: any): Promise<StaffMember> {
    try {
      const response = await axiosInstance.post(
        `${process.env.NEXT_PUBLIC_API_URL}/staff`,
        {
          name: data.name,
          email: data.email,
          phone_number: data.phone_number,
          department: data.department,
          role: data.role, // This should be the role ID as string
          password: data.password,
          password_confirmation: data.password_confirmation,
        }
      );

      if (response.data.success) {
        const apiStaff = response.data.data;
        const allRoles = await this.getRoles();
        const role = allRoles.find((r) => r.id === data.role) || allRoles[0];

        const newStaff: StaffMember = {
          id: apiStaff.id || apiStaff.uuid,
          name: apiStaff.name,
          email: apiStaff.email,
          phone: apiStaff.phone || apiStaff.phone_number || "",
          role: role,
          status: "active",
          department: apiStaff.department || undefined,
          createdAt: apiStaff.created_at,
          updatedAt: apiStaff.updated_at,
        };

        return newStaff;
      }

      throw new Error(response.data.message || "Failed to create staff member");
    } catch (error: any) {
      console.error("Error creating staff member:", error);
      throw new Error(
        error.response?.data?.message || "Failed to create staff member"
      );
    }
  }

  async updateStaffMember(id: string, data: any): Promise<StaffMember> {
    try {
      const updateData: any = {
        name: data.name,
        email: data.email,
        phone_number: data.phone_number,
        department: data.department,
        role: data.role,
        status: data.status,
      };

      // Only include password if provided
      if (data.password) {
        updateData.password = data.password;
        updateData.password_confirmation = data.password_confirmation;
      }

      const response = await axiosInstance.put(
        `${process.env.NEXT_PUBLIC_API_URL}/staff/${id}`,
        updateData
      );

      if (response.data.success) {
        const apiStaff = response.data.data;
        const allRoles = await this.getRoles();
        const role = allRoles.find((r) => r.id === data.role) || allRoles[0];

        const updatedStaff: StaffMember = {
          id: apiStaff.id,
          name: apiStaff.name,
          email: apiStaff.email,
          phone: apiStaff.phone || apiStaff.phone_number || "",
          role: role,
          status: apiStaff.status || "active",
          department: apiStaff.department || undefined,
          createdAt: apiStaff.created_at,
          updatedAt: apiStaff.updated_at,
        };

        return updatedStaff;
      }

      throw new Error(response.data.message || "Failed to update staff member");
    } catch (error: any) {
      console.error("Error updating staff member:", error);
      throw new Error(
        error.response?.data?.message || "Failed to update staff member"
      );
    }
  }

  async deleteStaffMember(id: string): Promise<void> {
    try {
      const response = await axiosInstance.delete(
        `${process.env.NEXT_PUBLIC_API_URL}/staff/${id}`
      );

      if (response.data.success) {
        return;
      }

      throw new Error(response.data.message || "Failed to delete staff member");
    } catch (error: any) {
      console.error("Error deleting staff member:", error);

      // Handle specific error cases
      if (error.response?.status === 404) {
        throw new Error("Staff member not found");
      } else if (error.response?.status === 403) {
        throw new Error(
          "You don't have permission to delete this staff member"
        );
      } else if (error.response?.status === 409) {
        throw new Error("Cannot delete staff member with active assignments");
      }

      throw new Error(
        error.response?.data?.message || "Failed to delete staff member"
      );
    }
  }

  async updateStaffStatus(
    id: string,
    status: "active" | "inactive" | "suspended"
  ): Promise<StaffMember> {
    return this.updateStaffMember(id, { status });
  }

  // Role management methods (updated to include permission sync)
  async getRoles(): Promise<Role[]> {
    try {
      const response = await axiosInstance.get(
        `${process.env.NEXT_PUBLIC_API_URL}/staff/roles`
      );

      if (response.data.success) {
        // First, get all permissions to map them to roles
        const allPermissions = await this.getPermissions();

        // Map roles and fetch permissions for each role individually
        const rolesWithPermissions = await Promise.all(
          response.data.data.roles.map(async (apiRole: any) => {
            try {
              // Fetch permissions for this specific role
              const roleResponse = await axiosInstance.get(
                `${process.env.NEXT_PUBLIC_API_URL}/role/${apiRole.id}`
              );

              if (roleResponse.data.success) {
                const roleData = roleResponse.data.data;
                const rolePermissions = roleData.permissions.map(
                  (apiPerm: any) => {
                    const permission = allPermissions.find(
                      (p) => p.id === apiPerm.id.toString()
                    );
                    return (
                      permission || {
                        id: apiPerm.id.toString(),
                        name: apiPerm.name,
                        description: `${apiPerm.name} permission`,
                        module: apiPerm.name.split("_")[0],
                        action: apiPerm.name.split("_")[1],
                        category: "admin",
                      }
                    );
                  }
                );

                return {
                  id: apiRole.id.toString(),
                  name: apiRole.name,
                  description: apiRole.description,
                  permissions: apiRole?.permissions,
                  createdAt: apiRole.created_at || new Date().toISOString(),
                  updatedAt: apiRole.updated_at || new Date().toISOString(),
                };
              }
            } catch (error) {
              console.error(
                `Error fetching permissions for role ${apiRole.name}:`,
                error
              );
              // Return role without permissions if there's an error
              return {
                id: apiRole.id.toString(),
                name: apiRole.name,
                description: apiRole.description,
                permissions: [],
                createdAt: apiRole.created_at || new Date().toISOString(),
                updatedAt: apiRole.updated_at || new Date().toISOString(),
              };
            }
          })
        );

        return rolesWithPermissions;
      }

      throw new Error("Failed to fetch roles");
    } catch (error) {
      console.error("Error fetching roles:", error);

      // Fallback to mock roles with proper error handling
      await new Promise((resolve) => setTimeout(resolve, 300));
      return systemRoles.map((role) => ({
        ...role,
        createdAt: role.createdAt || new Date().toISOString(),
        updatedAt: role.updatedAt || new Date().toISOString(),
      }));
    }
  }

  async getRole(id: string): Promise<Role | null> {
    try {
      const response = await axiosInstance.get<GetRoleResponse>(
        `${process.env.NEXT_PUBLIC_API_URL}/role/${id}`
      );

      if (response.data.success) {
        const apiRole: any = response.data.data;
        const allPermissions = await this.getPermissions();

        const rolePermissions: any = apiRole.permissions.map((apiPerm: any) => {
          const permission = allPermissions.find(
            (p) => p.id === apiPerm.id.toString()
          );
          return (
            permission || {
              id: apiPerm.id.toString(),
              name: apiPerm.name,
              description: `${apiPerm.name} permission`,
              module: apiPerm.name.split("_")[0],
              action: apiPerm.name.split("_")[1],
              category: "admin",
            }
          );
        });

        const role: Role = {
          id: apiRole.id.toString(),
          name: apiRole.name,
          description: apiRole.description,
          type: apiRole.type,
          permissions: rolePermissions,
          createdAt: apiRole.created_at,
          updatedAt: apiRole.updated_at,
        };

        return role;
      }

      throw new Error(response.data.message || "Failed to fetch role");
    } catch (error: any) {
      console.error("Error fetching role:", error);
      throw new Error(error.response?.data?.message || "Failed to fetch role");
    }
  }

  async getRolesWithFilters(filters: RoleFilters): Promise<RolesResponse> {
    try {
      const params = new URLSearchParams();

      Object.entries(filters).forEach(([key, value]) => {
        if (value !== null && value !== undefined && value !== "") {
          params.append(key, value.toString());
        }
      });

      const response = await axiosInstance.get(
        `${process.env.NEXT_PUBLIC_API_URL}/roles?${params.toString()}`
      );

      if (response.data.success) {
        return response.data.data;
      }

      throw new Error(response.data.message || "Failed to fetch roles");
    } catch (error: any) {
      console.error("Error fetching roles:", error);
      throw new Error(error.response?.data?.message || "Failed to fetch roles");
    }
  }

  async createRole(data: CreateRoleData): Promise<Role> {
    try {
      const permissionIds = data.permissionIds.map((id) => parseInt(id));

      const response = await axiosInstance.post<CreateRoleResponse>(
        `${process.env.NEXT_PUBLIC_API_URL}/roles`,
        {
          name: data.name,
          description: data.description,
          permissions: permissionIds,
          type: data?.type,
        }
      );

      if (response.data.success) {
        const apiRole = response.data.data;
        const allPermissions = await this.getPermissions();
        const rolePermissions = allPermissions.filter((p) =>
          apiRole.permissions.includes(p.name)
        );

        const newRole: Role = {
          id: apiRole.id.toString(),
          name: apiRole.name,
          description: apiRole.description,
          type: apiRole.type,
          permissions: rolePermissions,
          createdAt: apiRole.created_at,
          updatedAt: apiRole.updated_at,
        };

        systemRoles.push(newRole);
        return newRole;
      }

      throw new Error(response.data.message || "Failed to create role");
    } catch (error: any) {
      console.error("Error creating role:", error);
      throw new Error(error.response?.data?.message || "Failed to create role");
    }
  }
  // Update the updateRole method to handle logout
  async updateRole(id: string, data: any): Promise<Role> {
    try {
      const permissionIds = data.permissionIds.map((id: any) => parseInt(id));

      const response = await axiosInstance.put<UpdateRoleResponse>(
        `${process.env.NEXT_PUBLIC_API_URL}/roles/${id}`,
        {
          name: data.name,
          description: data.description,
          permissions: permissionIds,
          type: data?.type,
        }
      );

      if (response.data.success) {
        const apiRole: any = response.data.data;
        const allPermissions = await this.getPermissions();
        const rolePermissions = allPermissions.filter((p) =>
          apiRole.permissions.includes(p.name)
        );

        const updatedRole: Role = {
          id: apiRole.id.toString(),
          name: apiRole.name,
          description: apiRole.description,
          type: apiRole.type,
          permissions: rolePermissions,
          createdAt: apiRole.created_at,
          updatedAt: apiRole.updated_at,
        };

        const roleIndex = systemRoles.findIndex((role) => role.id === id);
        if (roleIndex !== -1) {
          systemRoles[roleIndex] = updatedRole;
        }

        // Update current user permissions if the updated role is the same as current user's role
        // This will now automatically logout the user if it's their role
        await this.updateCurrentUserPermissionsIfNeeded(id, data.name);

        return updatedRole;
      }

      throw new Error(response.data.message || "Failed to update role");
    } catch (error: any) {
      console.error("Error updating role:", error);
      throw new Error(error.response?.data?.message || "Failed to update role");
    }
  }

  // Update the deleteRole method to handle logout
  async deleteRole(id: string): Promise<void> {
    try {
      // Get the role details before deletion to check if it's the current user's role
      let roleName = "";
      const currentRole = systemRoles.find((role) => role.id === id);
      if (currentRole) {
        roleName = currentRole.name;
      }

      const response = await axiosInstance.delete(
        `${process.env.NEXT_PUBLIC_API_URL}/roles/${id}`
      );

      if (response.data.success) {
        // Check if this is the current user's role and logout if needed
        if (this.isCurrentUserRole(id, roleName)) {
          await this.logoutCurrentUser();
        }

        const roleIndex = systemRoles.findIndex((role) => role.id === id);
        if (roleIndex !== -1) {
          systemRoles.splice(roleIndex, 1);
        }
        return;
      }

      throw new Error(response.data.message || "Failed to delete role");
    } catch (error: any) {
      console.error("Error deleting role:", error);

      if (error.response?.status === 409) {
        throw new Error("Cannot delete role that is assigned to staff members");
      }

      throw new Error(error.response?.data?.message || "Failed to delete role");
    }
  }

  // Permission management methods
  async getPermissions(): Promise<Permission[]> {
    try {
      const response = await axiosInstance.get<ApiResponse>(
        `${process.env.NEXT_PUBLIC_API_URL}/permissions`
      );

      if (response.data.success) {
        const permissions: Permission[] = [];

        response.data.data.permissions.forEach((module: ModulePermissions) => {
          module.permissions.forEach((perm: ApiPermission) => {
            permissions.push({
              id: perm.id.toString(),
              name: perm.name,
              description: `${module.name} ${perm.action} permission`,
              module: module.name.toLowerCase(),
              action: perm.action,
              category: "admin",
            });
          });
        });

        return permissions;
      }
      throw new Error("Failed to fetch permissions");
    } catch (error) {
      console.error("Error fetching permissions:", error);
      return systemPermissions;
    }
  }

  async getPermissionsByCategory(
    category: "admin" | "doctor" | "staff" | "all"
  ): Promise<Permission[]> {
    const permissions = await this.getPermissions();
    return permissions.filter(
      (p) => p.category === category || category === "all"
    );
  }

  async getPermissionsApiFormat(): Promise<ApiResponse> {
    try {
      const response = await axiosInstance.get<ApiResponse>(
        `${process.env.NEXT_PUBLIC_API_URL}/permissions`
      );

      if (response.data.success) {
        return response.data;
      }
      throw new Error("Failed to fetch permissions");
    } catch (error) {
      console.error("Error fetching permissions:", error);
      return {
        success: true,
        message: "Using fallback permissions",
        data: {
          module: {
            name: "Module",
            actions: ["Read", "Write", "Update", "Delete"],
          },
          permissions: [
            {
              name: "Role",
              permissions: [
                { id: 1, name: "role_read", action: "read" },
                { id: 2, name: "role_write", action: "write" },
                { id: 3, name: "role_update", action: "update" },
                { id: 4, name: "role_delete", action: "delete" },
              ],
            },
            {
              name: "Staff",
              permissions: [
                { id: 5, name: "staff_read", action: "read" },
                { id: 6, name: "staff_write", action: "write" },
                { id: 7, name: "staff_update", action: "update" },
                { id: 8, name: "staff_delete", action: "delete" },
              ],
            },
          ],
        },
      };
    }
  }

  // Permission checking utility
  hasPermission(userRole: Role, requiredPermission: string): boolean {
    return userRole.permissions.some((p) => p.id === requiredPermission);
  }

  hasAnyPermission(userRole: Role, requiredPermissions: string[]): boolean {
    return requiredPermissions.some((permission) =>
      this.hasPermission(userRole, permission)
    );
  }

  hasAllPermissions(userRole: Role, requiredPermissions: string[]): boolean {
    return requiredPermissions.every((permission) =>
      this.hasPermission(userRole, permission)
    );
  }
}

export const staffService = new StaffService();
