// services/doctorApi.ts
import axiosInstance from "@/services/axiosInstance";

export interface DoctorSignupPayload {
  title: string;
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  contact_number: string;
  gender: string;
  medical_speciality: string;
  clinic_practice: string;
  clinic_name: string;
  address: string;
  emirates_states: string;
  medical_license: string;
  password: string;
  password_confirmation: string;
  terms_service: string;
  receive_updates: string;
  documents: PendingUserDocument[]; // This should match your API
}

export interface PendingUserDocument {
  id: string;
  name: string;
  url: string;
  uploaded_at: string;
  file_size: string;
}

export interface PendingUserDetail {
  id: string;
  title: string;
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  contact_number: string;
  gender: string;
  medical_speciality: string;
  clinic_practice: string;
  clinic_name: string;
  address: string;
  emirates_states: string;
  medical_license: string;
  documents: PendingUserDocument[];
}

export interface PendingUser {
  id: string;
  title: string;
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  clinic_name: string;
  emirates_states: string;
  status: string;
  created_at?: string;
}

export interface PendingUsersFilters {
  email?: string;
  first_name?: string;
  last_name?: string;
  name?: string;
  status?: string;
  emirates_states?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  per_page?: number;
  page?: number;
}

export interface PendingUsersResponse {
  success: boolean;
  message: string;
  data: {
    doctors: PendingUser[];
    filters: PendingUsersFilters;
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
      has_more_pages: boolean;
    };
    summary: {
      total_pending: number;
      total_approved: number;
      total_rejected: number;
      filtered_count: number;
    };
  };
}

export interface PendingUserDetailResponse {
  success: boolean;
  message: string;
  data: PendingUserDetail;
}

export interface BulkActionPayload {
  id: string[];
  action: "approve" | "reject" | "delete" | "request_more_documents";
  request_more?: string;
}

export interface CreatePatientPayload {
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  age: string | number;
  gender: string;
  address: string;
  status?: string; // Add this line
  doctor_id?: string; // Add doctor_id
}

export interface CreatePatientResponse {
  success: boolean;
  message: string;
  data: {
    patient: Patient;
  };
}

export interface Patient {
  id: string;
  first_name: string;
  last_name: string;
  full_name: string;
  email: string;
  phone_number: string;
  age: number;
  gender: string;
  address: string;
  doctor_name: string;
  created_at: string;
  status: any; // You might want to add this field
  last_visit?: string; // You might want to add this field
  total_orders?: number; // You might want to add this field
}

export interface PatientsResponse {
  success: boolean;
  message: string;
  data: {
    patients: Patient[];
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    filters_applied: {
      search?: string;
      gender?: string;
      doctor_id?: string;
      sort_by?: string;
      sort_order?: "asc" | "desc";
    };
  };
}

export interface PatientsFilters {
  search?: string;
  gender?: string;
  doctor_id?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  per_page?: number;
  page?: number;
}

export interface PatientDetailResponse {
  success: boolean;
  message: string;
  data: Patient;
}

export interface UpdatePatientPayload {
  first_name: string;
  last_name: string;
  email: string;
  phone_number: string;
  age: string | number;
  gender: string;
  address: string;
  status?: string; // Add status field
  doctor_id?: string; // Add doctor_id
}

export interface UpdatePatientResponse {
  success: boolean;
  message: string;
  data: {
    patient: Patient;
  };
}

export interface Doctor {
  id: string;
  name: string;
  email: string;
  medical_speciality: string;
}

export interface DoctorsListResponse {
  success: boolean;
  message: string;
  data: Doctor[];
}

export interface StaffMember {
  id: string;
  name: string;
  email: string;
  phone_number: string;
  gender: string;
  status: string;
  created_at?: string;
  updated_at?: string;
  doctor_name?: string;
  created_by?: string;
}

export interface CreateStaffPayload {
  doctor_id: string;
  name: string;
  email: string;
  phone_number: string;
  gender: string;
  status: string;
}

export interface UpdateStaffPayload {
  doctor_id: string;
  name: string;
  email: string;
  phone_number: string;
  gender: string;
  status: string;
}

export interface CreateStaffResponse {
  success: boolean;
  message: string;
  data: {
    staff: StaffMember;
  };
}

export interface StaffDetailResponse {
  success: boolean;
  message: string;
  data: StaffMember;
}

export interface UpdateStaffResponse {
  success: boolean;
  message: string;
  data: StaffMember;
}

export interface DeleteStaffResponse {
  success: boolean;
  message: string;
  data: [];
}

export interface StaffMember {
  id: string;
  name: string;
  email: string;
  phone_number: string;
  gender: string;
  status: string;
  doctor_name?: string;
  created_by?: string;
  created_at?: string;
  updated_at?: string;
}

export interface StaffListResponse {
  success: boolean;
  message: string;
  data: {
    staff: StaffMember[];
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    filters_applied: {
      search?: string;
      gender?: string;
      status?: string;
      doctor_id?: string;
      sort_by?: string;
      sort_order?: string;
    };
  };
}

export interface StaffFilters {
  search?: string;
  gender?: string;
  status?: string;
  doctor_id?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  per_page?: number;
  page?: number;
}

export interface ExportPayload {
  format: "csv" | "excel";
  filters?: Record<string, any>;
}

export interface ExportResponse {
  success: boolean;
  message: string;
  data: {
    export: {
      filename: string;
      file_url: string;
      file_size: string;
    };
  };
}

export interface PatientOrder {
  id: string;
  order_id: string;
  doctor: {
    id: string;
    full_name: string | null;
    email: string;
    clinic_name: string;
    commission: string;
  };
  patient: {
    id: string;
    full_name: string;
    email: string;
  };
  status: string;
  order_date: string;
  products_count: number;
  products: string[];
  total_price: string;
  commission: string;
  created_at: string;
  updated_at: string;
}

export interface PatientOrdersResponse {
  success: boolean;
  message: string;
  data: {
    orders: {
      current_page: number;
      data: PatientOrder[];
      first_page_url: string;
      from: number;
      last_page: number;
      last_page_url: string;
      links: Array<{
        url: string | null;
        label: string;
        page: number | null;
        active: boolean;
      }>;
      next_page_url: string | null;
      path: string;
      per_page: number;
      prev_page_url: string | null;
      to: number;
      total: number;
    };
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    filters: {
      type: string | null;
      search: string | null;
      sort_by: string;
      sort_order: string;
      per_page: number;
    };
  };
}

export interface PatientOrdersFilters {
  patient_id: string;
  search?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  per_page?: number;
  page?: number;
}

export interface DoctorOrder {
  id: string;
  order_id: string;
  doctor: {
    id: string;
    full_name: string | null;
    email: string;
    clinic_name: string;
    commission: string;
  };
  patient: {
    id: string;
    full_name: string;
    email: string;
  };
  status: string;
  order_date: string;
  products_count: number;
  products: string[];
  total_price: string;
  commission: string;
  created_at: string;
  updated_at: string;
}

export interface DoctorOrdersResponse {
  success: boolean;
  message: string;
  data: {
    orders: {
      current_page: number;
      data: DoctorOrder[];
      first_page_url: string;
      from: number;
      last_page: number;
      last_page_url: string;
      links: Array<{
        url: string | null;
        label: string;
        page: number | null;
        active: boolean;
      }>;
      next_page_url: string | null;
      path: string;
      per_page: number;
      prev_page_url: string | null;
      to: number;
      total: number;
    };
    pagination: {
      current_page: number;
      last_page: number;
      per_page: number;
      total: number;
      from: number;
      to: number;
    };
    filters: {
      type: string | null;
      search: string | null;
      sort_by: string;
      sort_order: string;
      per_page: number;
    };
  };
}

export interface DoctorOrdersFilters {
  doctor_id: string;
  search?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc";
  per_page?: number;
  page?: number;
}

// Add to your existing doctorApi.ts interfaces
export interface PendingUserCommission {
  product_commission: string;
  lab_test_commission: string;
}

export interface PendingUserCommissionResponse {
  success: boolean;
  message: string;
  data: {
    uuid: string;
    product_commission: string;
    lab_test_commission: string;
  };
}
export const doctorSignup = async (formData: FormData): Promise<any> => {
  try {
    const endpoint = "/doctor/signup";
    const response = await axiosInstance.post(endpoint, formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  } catch (error: any) {
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const getPendingUsers = async (
  filters: PendingUsersFilters = {}
): Promise<PendingUsersResponse> => {
  try {
    const params = new URLSearchParams();

    // Add all filter parameters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        params.append(key, value.toString());
      }
    });

    const endpoint = `/pending/users?${params.toString()}`;
    console.log("API Call:", endpoint); // Debug log
    const response = await axiosInstance.get(endpoint);
    console.log("API Response:", response.data); // Debug log
    return response.data;
  } catch (error: any) {
    console.error("API Error:", error); // Debug log
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const getPendingUserDetail = async (
  userId: string
): Promise<PendingUserDetailResponse> => {
  try {
    const endpoint = `/pending/user/${userId}`;
    console.log("API Call - User Detail:", endpoint); // Debug log
    const response = await axiosInstance.get(endpoint);
    console.log("API Response - User Detail:", response.data); // Debug log
    return response.data;
  } catch (error: any) {
    console.error("API Error - User Detail:", error); // Debug log
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const bulkActionPendingUsers = async (
  payload: BulkActionPayload
): Promise<any> => {
  try {
    const endpoint = "/pending/users/action";
    const response = await axiosInstance.post(endpoint, payload);
    return response.data;
  } catch (error: any) {
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const createPatient = async (
  payload: CreatePatientPayload
): Promise<CreatePatientResponse> => {
  try {
    const endpoint = "/patient";
    const response = await axiosInstance.post(endpoint, payload);
    return response.data;
  } catch (error: any) {
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const getPatients = async (
  filters: PatientsFilters = {}
): Promise<PatientsResponse> => {
  try {
    const params = new URLSearchParams();

    // Add all filter parameters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        params.append(key, value.toString());
      }
    });

    const endpoint = `/patients?${params.toString()}`;
    console.log("Patients API Call:", endpoint); // Debug log
    const response = await axiosInstance.get(endpoint);
    console.log("Patients API Response:", response.data); // Debug log
    return response.data;
  } catch (error: any) {
    console.error("Patients API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const getPatientById = async (
  patientId: string
): Promise<PatientDetailResponse> => {
  try {
    const endpoint = `/patient/${patientId}`;
    console.log("Get Patient API Call:", endpoint);
    const response = await axiosInstance.get(endpoint);
    console.log("Get Patient API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Get Patient API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

// Update patient

export const updatePatient = async (
  patientId: string,
  payload: UpdatePatientPayload
): Promise<UpdatePatientResponse> => {
  try {
    const endpoint = `/patient/${patientId}`;
    console.log("Update Patient API Call:", endpoint, payload);
    const response = await axiosInstance.put(endpoint, payload);
    console.log("Update Patient API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Update Patient API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export interface DeletePatientResponse {
  success: boolean;
  message: string;
  data: [];
}

export const deletePatient = async (
  patientId: string
): Promise<DeletePatientResponse> => {
  try {
    // Ensure patientId is properly formatted and not undefined
    if (!patientId || patientId === "undefined") {
      throw new Error("Invalid patient ID");
    }

    const endpoint = `/patient/${patientId}`;
    console.log("Delete Patient API Call:", endpoint);
    const response = await axiosInstance.delete(endpoint);
    console.log("Delete Patient API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Delete Patient API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error(error.message || "An error occurred. Please try again.");
    }
  }
};
export const getDoctorsList = async (): Promise<DoctorsListResponse> => {
  try {
    const endpoint = "/doctors-list";
    console.log("Doctors List API Call:", endpoint);
    const response = await axiosInstance.get(endpoint);
    console.log("Doctors List API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Doctors List API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

/**
 * Create a new staff member for a doctor
 */
export const createStaff = async (
  payload: CreateStaffPayload
): Promise<CreateStaffResponse> => {
  try {
    const endpoint = "/doctor-subaccount";
    console.log("Create Staff API Call:", endpoint, payload);
    const response = await axiosInstance.post(endpoint, payload);
    console.log("Create Staff API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Create Staff API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

/**
 * Get staff member details by ID
 */
export const getStaffById = async (
  staffId: string
): Promise<StaffDetailResponse> => {
  try {
    const endpoint = `/doctor-subaccount/${staffId}`;
    console.log("Get Staff API Call:", endpoint);
    const response = await axiosInstance.get(endpoint);
    console.log("Get Staff API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Get Staff API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

/**
 * Update staff member
 */
export const updateStaff = async (
  staffId: string,
  payload: UpdateStaffPayload
): Promise<UpdateStaffResponse> => {
  try {
    const endpoint = `/doctor-subaccount/${staffId}`;
    console.log("Update Staff API Call:", endpoint, payload);
    const response = await axiosInstance.put(endpoint, payload);
    console.log("Update Staff API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Update Staff API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

/**
 * Delete staff member
 */
export const deleteStaff = async (
  staffId: string
): Promise<DeleteStaffResponse> => {
  try {
    if (!staffId || staffId === "undefined") {
      throw new Error("Invalid staff ID");
    }

    const endpoint = `/doctor-subaccount/${staffId}`;
    console.log("Delete Staff API Call:", endpoint);
    const response = await axiosInstance.delete(endpoint);
    console.log("Delete Staff API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Delete Staff API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error(error.message || "An error occurred. Please try again.");
    }
  }
};

/**
 * Get all staff members with filters and pagination
 */
export const getStaffList = async (
  filters: StaffFilters = {}
): Promise<StaffListResponse> => {
  try {
    const params = new URLSearchParams();

    // Add all filter parameters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        params.append(key, value.toString());
      }
    });

    const endpoint = `/doctor-subaccounts?${params.toString()}`;
    console.log("Get Staff List API Call:", endpoint);
    const response = await axiosInstance.get(endpoint);
    console.log("Get Staff List API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Get Staff List API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

/**
 * Export doctors data
 */
export const exportDoctors = async (): Promise<ExportResponse> => {
  try {
    const endpoint = "/doctors/export";
    console.log("Export Doctors API Call:", endpoint);
    const response = await axiosInstance.post(endpoint);
    console.log("Export Doctors API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Export Doctors API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

/**
 * Generic export function that can be used for different entities
 */
export const exportData = async (
  entity: string,
  format: "csv" | "excel" = "excel",
  filters: Record<string, any> = {},
  useCustomFilterStructure: boolean,
  // Add new parameters for search and sorting
  search?: string,
  sort_by?: string,
  sort_order?: string,
  doctor_id?: string
): Promise<ExportResponse> => {
  try {
    const endpoint = `/${entity}/export`;
    console.log(useCustomFilterStructure, filters, "1233");

    let payload: any;

    if (useCustomFilterStructure) {
      // For commissions: put status and date filters at root level
      payload = {
        format,
        ...filters, // Spread filters at root level
      };
    } else {
      // Default behavior: wrap filters in filters object
      payload = {
        format,
        ...(Object.keys(filters).length > 0 && { filters }),
      };
    }

    // Add search and sorting parameters to payload
    if (search) {
      payload.search = search;
    }
    if (sort_by) {
      payload.sort_by = sort_by;
    }
    if (sort_order) {
      payload.sort_order = sort_order;
    }

    // Add doctor_id to payload if provided
    if (doctor_id) {
      payload.doctor_id = doctor_id;
    }

    console.log(`Export ${entity} API Call:`, endpoint, payload);
    const response = await axiosInstance.post(endpoint, payload);
    console.log(`Export ${entity} API Response:`, response.data);
    return response.data;
  } catch (error: any) {
    console.error(`Export ${entity} API Error:`, error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const getPatientOrders = async (
  filters: PatientOrdersFilters
): Promise<PatientOrdersResponse> => {
  try {
    const params = new URLSearchParams();

    // Add all filter parameters
    Object.entries(filters).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== "") {
        params.append(key, value.toString());
      }
    });

    const endpoint = `/patient/orders`;
    console.log("Patient Orders API Call:", endpoint, filters);
    const response = await axiosInstance.post(endpoint, filters, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log("Patient Orders API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Patient Orders API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const getDoctorOrders = async (
  filters: DoctorOrdersFilters
): Promise<DoctorOrdersResponse> => {
  try {
    const endpoint = `/doctor/orders`;
    console.log("Doctor Orders API Call:", endpoint, filters);
    const response = await axiosInstance.post(endpoint, filters, {
      headers: {
        "Content-Type": "application/json",
      },
    });
    console.log("Doctor Orders API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Doctor Orders API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

// Add this to your existing doctorApi.ts file

export interface OrderDetailResponse {
  success: boolean;
  message: string;
  data: OrderDetail;
}

export interface OrderDetail {
  id: string;
  order_type: string;
  order_date: string;
  shopify_draft_order_id: string;
  shopify_order_id: string | null;
  shopify_customer_id: string;
  customer_first_name: string;
  customer_last_name: string;
  customer_email: string;
  customer_phone: string | null;
  name: string;
  status: string;
  subtotal_price: string;
  total_tax: string;
  total_price: string;
  currency: string;
  invoice_url: string;
  invoice_sent_at: string | null;
  completed_at: string | null;
  shipping_address: Address;
  billing_address: Address;
  line_items: LineItem[];
  raw_payload: any;
  shopify_created_at: string;
  shopify_updated_at: string;
  commission_rate: string;
  commission: string;
  created_by: number;
  updated_by: number;
  deleted_by: number | null;
  created_at: string;
  updated_at: string;
  deleted_at: string | null;
  order_id: string;
  patient: Patient;
  doctor: Doctor;
}

export interface Address {
  zip: string;
  city: string;
  name: string;
  phone: string;
  company: string | null;
  country: string;
  address1: string;
  address2: string;
  latitude: number | null;
  province: string;
  last_name: string;
  longitude: number | null;
  first_name: string;
  country_code: string;
  province_code: string | null;
}

export interface LineItem {
  id: number;
  sku: string;
  name: string;
  grams: number;
  price: string;
  title: string;
  custom: boolean;
  vendor: string;
  taxable: boolean;
  quantity: number;
  gift_card: boolean;
  tax_lines: TaxLine[];
  product_id: number;
  properties: any[];
  variant_id: number;
  variant_title: string | null;
  applied_discount: any | null;
  requires_shipping: boolean;
  fulfillment_service: string;
  admin_graphql_api_id: string;
  image: string;
}

export interface TaxLine {
  rate: number;
  price: string;
  title: string;
}

export interface Patient {
  id: string;
  full_name: string;
  email: string;
  phone_number: string;
  status: any;
  doctor_name: string;
  doctor_commission: string;
}

export interface Doctor {
  id: string;
  full_name: string;
  email: string;
  status: string;
  commission: string;
}

// Add this function to your existing doctorApi exports
export const getOrderDetails = async (
  orderId: string
): Promise<OrderDetailResponse> => {
  try {
    const endpoint = `/order/${orderId}`;
    console.log("Get Order Details API Call:", endpoint);
    const response = await axiosInstance.get(endpoint);
    console.log("Get Order Details API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Get Order Details API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

// Add these functions to your existing doctorApi.ts exports
export const getPendingUserCommission = async (
  userId: string
): Promise<PendingUserCommissionResponse> => {
  try {
    const endpoint = `/pending/user/${userId}`;
    console.log("Get Pending User Commission API Call:", endpoint);
    const response = await axiosInstance.get(endpoint);
    console.log("Get Pending User Commission API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Get Pending User Commission API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const updatePendingUserCommission = async (
  userId: string,
  payload: PendingUserCommission
): Promise<PendingUserCommissionResponse> => {
  try {
    const endpoint = `/pending/user/${userId}`;
    console.log("Update Pending User Commission API Call:", endpoint, payload);
    const response = await axiosInstance.put(endpoint, payload);
    console.log("Update Pending User Commission API Response:", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Update Pending User Commission API Error:", error);
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};
