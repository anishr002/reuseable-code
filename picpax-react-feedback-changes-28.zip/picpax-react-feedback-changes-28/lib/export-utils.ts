/**
 * Export utility for downloading data in various formats
 */
import * as XLSX from 'xlsx'

export interface ExportOptions {
  filename?: string
  format?: 'csv' | 'excel'
  includeHeaders?: boolean
}

export class DataExporter {
  /**
   * Convert data to CSV format
   */
  static toCSV(data: any[], headers?: string[]): string {
    if (data.length === 0) return ''

    const csvHeaders = headers || Object.keys(data[0])
    const csvRows = []

    // Add headers
    csvRows.push(csvHeaders.join(','))

    // Add data rows
    for (const row of data) {
      const values = csvHeaders.map(header => {
        const value = row[header]
        // Escape quotes and wrap in quotes if contains comma or quote
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`
        }
        return value
      })
      csvRows.push(values.join(','))
    }

    return csvRows.join('\n')
  }

  /**
   * Convert data to Excel format
   */
  static toExcel(data: any[]): XLSX.WorkBook {
    const worksheet = XLSX.utils.json_to_sheet(data)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1')
    return workbook
  }

  /**
   * Download data as a file
   */
  static download(data: string, filename: string, mimeType: string) {
    const blob = new Blob([data], { type: mimeType })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = filename
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  /**
   * Export data to CSV format
   */
  static exportToCSV(data: any[], filename: string = 'export', includeHeaders: boolean = true) {
    const csv = this.toCSV(data, includeHeaders ? Object.keys(data[0] || {}) : undefined)
    const fullFilename = `${filename}.csv`
    this.download(csv, fullFilename, 'text/csv;charset=utf-8;')
  }

  /**
   * Export data to Excel format
   */
  static exportToExcel(data: any[], filename: string = 'export') {
    const workbook = this.toExcel(data)
    const fullFilename = `${filename}.xlsx`
    XLSX.writeFile(workbook, fullFilename)
  }

  /**
   * Export data with options
   */
  static export(data: any[], options: ExportOptions = {}) {
    const {
      filename = 'export',
      format = 'csv',
      includeHeaders = true
    } = options

    switch (format) {
      case 'csv':
        this.exportToCSV(data, filename, includeHeaders)
        break
      case 'excel':
        this.exportToExcel(data, filename)
        break
      default:
        throw new Error(`Unsupported export format: ${format}`)
    }
  }

  /**
   * Get formatted filename with timestamp
   */
  static getTimestampedFilename(baseName: string, extension: string = ''): string {
    const timestamp = new Date().toISOString().split('T')[0] // YYYY-MM-DD
    const time = new Date().toTimeString().split(' ')[0].replace(/:/g, '-') // HH-MM-SS
    return `${baseName}_${timestamp}_${time}${extension}`
  }
}