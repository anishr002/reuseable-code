// Types for Staff Management System

export interface Permission {
  id: string;
  name: string;
  description: string;
  module: string;
  action: string;
  category: "admin" | "doctor" | "staff" | "all";
}

export interface Role {
  id: string;
  name: string;
  description: string;
  permissions: Permission[];
  type: any;
  createdAt: string;
  updatedAt: string;
}

export interface StaffMember {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: any;
  status: "active" | "inactive" | "suspended";
  lastLogin?: string;
  createdAt: string;
  updatedAt: string;
  profilePicture?: string;
  department?: string;
}

export interface CreateStaffData {
  name: string;
  email: string;
  phone: string;
  roleId: string;
  department?: string;
}

export interface UpdateStaffData {
  name?: string;
  email?: string;
  phone?: string;
  roleId?: string;
  status?: "active" | "inactive" | "suspended";
  department?: string;
}

export interface CreateRoleData {
  name: string;
  description: string;
  permissionIds: string[];
  type: any;
}

export interface UpdateRoleData {
  name?: string;
  description?: string;
  permissionIds?: string[];
}

// Staff Filters Interface
export interface StaffFilters {
  name?: string;
  email?: string;
  phone?: string;
  department?: string;
  role?: string;
  sort_by?: string;
  sort_order?: string;
  per_page?: number;
  page?: number;
}

export interface StaffResponse {
  staff: StaffMember[];
  pagination: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  };
  filters: StaffFilters;
}

// Role Filters Interface
export interface RoleFilters {
  name?: string;
  permission?: string;
  sort_by?: string;
  sort_order?: string;
  per_page?: number;
  page?: number;
}

export interface RolesResponse {
  roles: Role[];
  pagination: {
    current_page: number;
    last_page: number;
    per_page: number;
    total: number;
    from: number;
    to: number;
  };
  filters: RoleFilters;
}

// Predefined permissions for the system
export const systemPermissions: Permission[] = [
  // Admin permissions
  {
    id: "admin.dashboard.view",
    name: "View Dashboard",
    description: "Access to admin dashboard",
    module: "dashboard",
    action: "view",
    category: "admin",
  },
  {
    id: "admin.doctors.view",
    name: "View Doctors",
    description: "View list of doctors",
    module: "doctors",
    action: "view",
    category: "admin",
  },
  {
    id: "admin.doctors.create",
    name: "Create Doctors",
    description: "Create new doctor accounts",
    module: "doctors",
    action: "create",
    category: "admin",
  },
  {
    id: "admin.doctors.edit",
    name: "Edit Doctors",
    description: "Edit doctor information",
    module: "doctors",
    action: "edit",
    category: "admin",
  },
  {
    id: "admin.doctors.delete",
    name: "Delete Doctors",
    description: "Delete doctor accounts",
    module: "doctors",
    action: "delete",
    category: "admin",
  },
  {
    id: "admin.orders.view",
    name: "View Orders",
    description: "View all orders in the system",
    module: "orders",
    action: "view",
    category: "admin",
  },
  {
    id: "admin.orders.create",
    name: "Create Orders",
    description: "Create new orders",
    module: "orders",
    action: "create",
    category: "admin",
  },
  {
    id: "admin.orders.edit",
    name: "Edit Orders",
    description: "Edit existing orders",
    module: "orders",
    action: "edit",
    category: "admin",
  },
  {
    id: "admin.products.view",
    name: "View Products",
    description: "View product catalog",
    module: "products",
    action: "view",
    category: "admin",
  },
  {
    id: "admin.products.create",
    name: "Create Products",
    description: "Create new products",
    module: "products",
    action: "create",
    category: "admin",
  },
  {
    id: "admin.products.edit",
    name: "Edit Products",
    description: "Edit product information",
    module: "products",
    action: "edit",
    category: "admin",
  },
  {
    id: "admin.settings.view",
    name: "View Settings",
    description: "View system settings",
    module: "settings",
    action: "view",
    category: "admin",
  },
  {
    id: "admin.settings.edit",
    name: "Edit Settings",
    description: "Modify system settings",
    module: "settings",
    action: "edit",
    category: "admin",
  },
  {
    id: "admin.staff.view",
    name: "View Staff",
    description: "View staff members",
    module: "staff",
    action: "view",
    category: "admin",
  },
  {
    id: "admin.staff.create",
    name: "Create Staff",
    description: "Create new staff accounts",
    module: "staff",
    action: "create",
    category: "admin",
  },
  {
    id: "admin.staff.edit",
    name: "Edit Staff",
    description: "Edit staff information",
    module: "staff",
    action: "edit",
    category: "admin",
  },
  {
    id: "admin.staff.delete",
    name: "Delete Staff",
    description: "Delete staff accounts",
    module: "staff",
    action: "delete",
    category: "admin",
  },
  {
    id: "admin.roles.view",
    name: "View Roles",
    description: "View system roles",
    module: "roles",
    action: "view",
    category: "admin",
  },
  {
    id: "admin.roles.create",
    name: "Create Roles",
    description: "Create new roles",
    module: "roles",
    action: "create",
    category: "admin",
  },
  {
    id: "admin.roles.edit",
    name: "Edit Roles",
    description: "Edit existing roles",
    module: "roles",
    action: "edit",
    category: "admin",
  },
  {
    id: "admin.roles.delete",
    name: "Delete Roles",
    description: "Delete roles",
    module: "roles",
    action: "delete",
    category: "admin",
  },

  // Doctor permissions
  {
    id: "doctor.dashboard.view",
    name: "View Dashboard",
    description: "Access to doctor dashboard",
    module: "dashboard",
    action: "view",
    category: "doctor",
  },
  {
    id: "doctor.patients.view",
    name: "View Patients",
    description: "View patient list",
    module: "patients",
    action: "view",
    category: "doctor",
  },
  {
    id: "doctor.patients.create",
    name: "Create Patients",
    description: "Create new patient records",
    module: "patients",
    action: "create",
    category: "doctor",
  },
  {
    id: "doctor.orders.view",
    name: "View Orders",
    description: "View order history",
    module: "orders",
    action: "view",
    category: "doctor",
  },
  {
    id: "doctor.orders.create",
    name: "Create Orders",
    description: "Create new orders for patients",
    module: "orders",
    action: "create",
    category: "doctor",
  },
  {
    id: "doctor.commission.view",
    name: "View Commission",
    description: "View commission earnings",
    module: "commission",
    action: "view",
    category: "doctor",
  },

  // Staff permissions (limited access)
  {
    id: "staff.dashboard.view",
    name: "View Dashboard",
    description: "Access to staff dashboard",
    module: "dashboard",
    action: "view",
    category: "staff",
  },
  {
    id: "staff.patients.view",
    name: "View Patients",
    description: "View patient list",
    module: "patients",
    action: "view",
    category: "staff",
  },
  {
    id: "staff.orders.view",
    name: "View Orders",
    description: "View order history",
    module: "orders",
    action: "view",
    category: "staff",
  },
  {
    id: "staff.orders.create",
    name: "Create Orders",
    description: "Create new orders for patients",
    module: "orders",
    action: "create",
    category: "staff",
  },
];

// Predefined system roles
export const systemRoles: Role[] = [
  {
    id: "super_admin",
    name: "Super Admin",
    description: "Full system access",
    type: "system",
    permissions: systemPermissions.filter((p) => p.category === "admin"),
    createdAt: "2024-01-01T00:00:00Z",
    updatedAt: "2024-01-01T00:00:00Z",
  },
  {
    id: "admin_manager",
    name: "Admin Manager",
    description: "Can manage admins and settings",
    type: "system",

    permissions: systemPermissions.filter(
      (p) =>
        p.category === "admin" &&
        !p.id.includes("roles.") &&
        !p.id.includes("staff.delete")
    ),
    createdAt: "2024-01-01T00:00:00Z",
    updatedAt: "2024-01-01T00:00:00Z",
  },
  {
    id: "content_manager",
    name: "Content Manager",
    description: "Can manage products and content",
    type: "system",

    permissions: systemPermissions.filter(
      (p) =>
        p.category === "admin" &&
        (p.module === "products" || p.module === "orders")
    ),
    createdAt: "2024-01-01T00:00:00Z",
    updatedAt: "2024-01-01T00:00:00Z",
  },
  {
    id: "support_staff",
    name: "Support Staff",
    description: "Customer support role",
    type: "system",

    permissions: systemPermissions.filter(
      (p) =>
        p.category === "staff" ||
        (p.category === "admin" && p.module === "orders" && p.action === "view")
    ),
    createdAt: "2024-01-01T00:00:00Z",
    updatedAt: "2024-01-01T00:00:00Z",
  },
];

// Mock staff data
export const mockStaffMembers: StaffMember[] = [
  {
    id: "staff_001",
    name: "Emma Wilson",
    email: "emma.wilson@medicenter.com",
    phone: "+1 (555) 987-6543",
    role: systemRoles[2], // content_manager
    status: "active",
    lastLogin: "2024-01-15T10:30:00Z",
    createdAt: "2024-01-01T00:00:00Z",
    updatedAt: "2024-01-10T15:45:00Z",
    department: "Content Management",
  },
  {
    id: "staff_002",
    name: "James Rodriguez",
    email: "james.rodriguez@medicenter.com",
    phone: "+1 (555) 456-7890",
    role: systemRoles[3], // support_staff
    status: "active",
    lastLogin: "2024-01-14T14:20:00Z",
    createdAt: "2024-01-02T00:00:00Z",
    updatedAt: "2024-01-08T11:30:00Z",
    department: "Customer Support",
  },
  {
    id: "staff_003",
    name: "Lisa Chen",
    email: "lisa.chen@medicenter.com",
    phone: "+1 (555) 321-0987",
    role: systemRoles[1], // admin_manager
    status: "active",
    lastLogin: "2024-01-15T09:15:00Z",
    createdAt: "2024-01-03T00:00:00Z",
    updatedAt: "2024-01-12T16:20:00Z",
    department: "Administration",
  },
];
