import axiosInstance from "../services/axiosInstance";

interface LoginPayload {
  email: string;
  password: string;
}
export interface ServerDocument {
  name: string;
  url: string;
  uploaded_at: string;
}

export const loginUser = async (
  payload: LoginPayload,
  isAdmin: boolean = false
) => {
  try {
    // Determine endpoint based on whether it's admin login or doctor login
    const endpoint = isAdmin ? "/admin/login" : "/doctor/login";
    const response = await axiosInstance.post(endpoint, payload);
    console.log(response, "response from login");
    return response.data;
  } catch (error: any) {
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

export const logoutUser = async (): Promise<boolean> => {
  try {
    await axiosInstance.post("/logout");
    return true;
  } catch (error: any) {
    console.error("Logout error:", error);
    return false;
  }
};

// ... rest of the functions remain the same
export const fetchUserProfile = async () => {
  try {
    const response = await axiosInstance.get("/user/profile");
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

export const updateUserProfile = async (payload: {
  name: string;
  email: string;
  phone_number: string | null;
  department: string | null;
  type: string;
}) => {
  try {
    const response = await axiosInstance.put("/user/profile", payload);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

export const changePassword = async (payload: {
  current_password: string;
  new_password: string;
  new_password_confirmation: string;
}) => {
  try {
    const response = await axiosInstance.post("/change-password", payload);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

export const storeDocuments = async (formData: FormData) => {
  try {
    const response = await axiosInstance.post("/documents/store", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// FIXED: Corrected the response type to match your actual API response
export const getDocuments = async (): Promise<{
  success: boolean;
  message: string;
  data: {
    documents: ServerDocument[];
  };
}> => {
  try {
    const response = await axiosInstance.get("/documents");
    console.log("Documents API Response:", response.data); // Debug log
    return response.data;
  } catch (error: any) {
    console.error("Error fetching documents:", error); // Debug log
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

export const deleteDocument = async (
  documentId: string
): Promise<{
  success: boolean;
  message: string;
  data: any[];
}> => {
  try {
    const response = await axiosInstance.delete(`/document/${documentId}`);
    return response.data;
  } catch (error: any) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("picpax_auth_token");
      localStorage.removeItem("picpax_user");
    }
    throw error;
  }
};

// Forgot Password API
export const forgotPassword = async (email: string) => {
  try {
    const response = await axiosInstance.post("/forgot-password", { email });
    return response.data;
  } catch (error: any) {
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};

// Reset Password API - using FormData
export const resetPasswordApi = async (payload: {
  email: string;
  token: string;
  password: string;
  password_confirmation: string;
}) => {
  try {
    // Create FormData object
    const formData = new FormData();
    formData.append("email", payload.email);
    formData.append("token", payload.token);
    formData.append("password", payload.password);
    formData.append("password_confirmation", payload.password_confirmation);

    const response = await axiosInstance.post("/reset-password", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
    return response.data;
  } catch (error: any) {
    if (error.response) {
      throw error;
    } else if (error.request) {
      throw new Error("No response from server. Please try again.");
    } else {
      throw new Error("An error occurred. Please try again.");
    }
  }
};
