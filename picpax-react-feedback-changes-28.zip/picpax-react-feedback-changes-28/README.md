# PicPax Doctor Portal

A comprehensive web-based nutrition management system designed for healthcare professionals and administrators. Built with Next.js 14, TypeScript, and modern UI components to provide a seamless experience for managing patient nutrition plans, supplement orders, and practice operations.

## 🚀 Features

### Doctor Portal
- **Patient Management**: Add, edit, and manage patient profiles with comprehensive health information
- **Order Creation**: Create supplement orders with product variations and duration-based pricing
- **Coupon System**: Apply discount coupons with validation and automatic calculations
- **Commission Tracking**: View detailed commission reports and earnings history
- **Dashboard**: Overview of practice metrics, recent orders, and patient statistics

### Admin Portal
- **User Management**: Manage doctors, staff, and patient accounts
- **Product Catalog**: Comprehensive supplement inventory with variation support
- **Order Management**: View and manage all orders across the platform
- **Coupon Management**: Create and manage discount coupons with flexible rules
- **Analytics**: Detailed reporting and business insights
- **Commission Payouts**: Manage commission calculations and payments

### Key Features
- **Product Variations**: Support for duration-based pricing (30/60/90 days) with bulk discounts
- **Export Functionality**: CSV and Excel export capabilities for all data tables
- **Responsive Design**: Mobile-friendly interface built with Tailwind CSS
- **Real-time Updates**: Dynamic pricing and inventory management
- **Authentication**: Secure user authentication and role-based access control

## 🛠 Technology Stack

- **Frontend**: Next.js 14 with App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS + Shadcn/UI Components
- **State Management**: React Hooks
- **Data Tables**: TanStack Table
- **Forms**: React Hook Form with Zod validation
- **Icons**: Lucide React
- **Date Handling**: date-fns
- **Export**: xlsx library for Excel export functionality

## 📦 Installation

### Prerequisites
- Node.js 18.x or later
- npm or yarn package manager

### Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd picpax-react
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Run the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to [http://localhost:3000](http://localhost:3000)

### Build for Production

```bash
npm run build
npm start
```

## 🗂 Project Structure

```
picpax-react/
├── app/                          # Next.js App Router
│   ├── admin/                    # Admin portal pages
│   │   ├── dashboard/
│   │   ├── doctors/
│   │   ├── orders/
│   │   ├── products/
│   │   ├── coupons/
│   │   └── settings/
│   ├── dashboard/                # Doctor dashboard
│   ├── orders/                   # Doctor order management
│   ├── patients/                 # Patient management
│   ├── commission/               # Commission tracking
│   └── staff/                    # Staff management
├── components/                   # Reusable components
│   ├── ui/                       # Shadcn UI components
│   ├── coupons/                  # Coupon management components
│   ├── products/                 # Product-related components
│   └── admin/                    # Admin-specific components
├── lib/                          # Utility libraries
│   ├── auth-                     # Authentication utilities
│   ├── export-                   # Export functionality
│   ├── coupon-                   # Coupon service
│   └── mock-                     # Mock data
└── public/                       # Static assets
```

## 🎯 Key Components

### Core Features
- **Authentication System**: Role-based access control for doctors and admins
- **Product Management**: Full CRUD operations with variation support
- **Order System**: Complete order lifecycle with cart functionality
- **Coupon System**: Flexible discount management with validation
- **Export System**: Multi-format export for all data tables

### UI Components
- **Data Tables**: Sortable, filterable tables with export functionality
- **Forms**: Dynamic forms with validation and error handling
- **Modals**: Reusable dialog components for various operations
- **Navigation**: Responsive sidebar and top navigation
- **Charts**: Analytics dashboard with visual representations

## 🔧 Configuration

### Environment Variables
Create a `.env.local` file for environment-specific configuration:

```env
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-key
NEXTAUTH_URL=http://localhost:3000
```

### Customization
- **Theme**: Modify `tailwind.config.js` for custom theming
- **Components**: Extend shadcn/ui components in `components/ui/`
- **Mock Data**: Update `lib/mock-data.ts` for development data

## 📊 Usage Examples

### Creating a New Order
1. Navigate to Orders → Create Order
2. Search and select products from the catalog
3. Choose product variations (duration options)
4. Apply available coupons if applicable
5. Review and confirm the order

### Managing Coupons
1. Go to Admin → Coupon Management
2. Create new coupons with flexible rules
3. Set discount types (percentage or fixed amount)
4. Configure usage limits and validity periods
5. Track coupon usage and effectiveness

### Exporting Data
1. Navigate to any management table
2. Click the export button in the table header
3. Choose export format (CSV or Excel)
4. Download the generated file

## 🧪 Development

### Code Style
- TypeScript for type safety
- ESLint for code quality
- Prettier for code formatting
- Conventional commits for versioning

### Testing
```bash
npm run test        # Run tests
npm run test:watch  # Run tests in watch mode
npm run test:cover  # Run tests with coverage
```

### Build Process
```bash
npm run build       # Production build
npm run lint        # Code linting
npm run type-check  # TypeScript type checking
```

## 🚀 Deployment

### Vercel (Recommended)
1. Connect your GitHub repository to Vercel
2. Configure environment variables
3. Deploy automatically on push

### Docker
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines
- Follow the existing code style
- Write tests for new functionality
- Update documentation as needed
- Use TypeScript for type safety
- Follow React best practices

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Shadcn/UI** for the excellent component library
- **Tailwind CSS** for the utility-first CSS framework
- **Next.js** for the amazing React framework
- **TypeScript** for bringing type safety to JavaScript

## 📞 Support

For support and questions:
- Create an issue in the GitHub repository
- Contact the development team
- Check the documentation for common issues

---

Built with ❤️ by the PicPax team for healthcare professionals.